<?php

namespace App\Http\Controllers;

use App\Models\Currency;
use App\Models\Language;
use App\Models\Order;
use Config;
use Hash;
use PDF;
use Session;
use Illuminate\Support\Facades\DB;

class InvoiceController extends Controller {
  public function open_invoice_download($hash) {
    $hash = base64_decode($hash);
    parse_str($hash, $params);
    if (Session::has('currency_code')) {
      $currency_code = Session::get('currency_code');
    } else {
      $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
    }
    $language_code = Session::get('locale', Config::get('app.locale'));

    if (Language::where('code', $language_code)->first()->rtl == 1) {
      $direction      = 'rtl';
      $text_align     = 'right';
      $not_text_align = 'left';
    } else {
      $direction      = 'ltr';
      $text_align     = 'left';
      $not_text_align = 'right';
    }

    if ($currency_code == 'BDT' || $language_code == 'bd') {
      // bengali font
      $font_family = "'Hind Siliguri','sans-serif'";
    } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
      // khmer font
      $font_family = "'Hanuman','sans-serif'";
    } elseif ($currency_code == 'AMD') {
      // Armenia font
      $font_family = "'arnamu','sans-serif'";
      // }elseif($currency_code == 'ILS'){
      //     // Israeli font
      //     $font_family = "'Varela Round','sans-serif'";
    } elseif ($currency_code == 'AED' || $currency_code == 'EGP' || $language_code == 'sa' || $currency_code == 'IQD' || $language_code == 'ir' || $language_code == 'om' || $currency_code == 'ROM' || $currency_code == 'SDG' || $currency_code == 'ILS' || $language_code == 'jo') {
      // middle east/arabic/Israeli font
      $font_family = "'Baloo Bhaijaan 2','sans-serif'";
    } elseif ($currency_code == 'THB') {
      // thai font
      $font_family = "'Kanit','sans-serif'";
    } else {
      // general for all
      $font_family = "'Roboto','sans-serif'";
    }

    // $config = ['instanceConfigurator' => function($mpdf) {
    //     $mpdf->showImageErrors = true;
    // }];
    // mpdf config will be used in 4th params of loadview

    $config = [];

    $order = Order::findOrFail($params['id']);
    if (Hash::check($params['hash'], Hash::make($order['combined_order_id'] . $order['user_id']))) {
      if (mb_substr($order->code, 0, 3) == 'MZ/') {
        return PDF::loadView('backend.invoices.invoice', [
          'order'          => $order,
          'font_family'    => $font_family,
          'direction'      => $direction,
          'text_align'     => $text_align,
          'not_text_align' => $not_text_align,
        ], [], $config)->download('order-' . $order->code . '.pdf');
      } else {
        return PDF::loadView('backend.invoices.proformainvoice', [
          'order'          => $order,
          'font_family'    => $font_family,
          'direction'      => $direction,
          'text_align'     => $text_align,
          'not_text_align' => $not_text_align,
        ], [], $config)->download('order-' . $order->code . '.pdf');
      }
    } else {}
  }
  //download invoice
  public function invoice_download($id) {
    if (Session::has('currency_code')) {
      $currency_code = Session::get('currency_code');
    } else {
      $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
    }
    $language_code = Session::get('locale', Config::get('app.locale'));

    if (Language::where('code', $language_code)->first()->rtl == 1) {
      $direction      = 'rtl';
      $text_align     = 'right';
      $not_text_align = 'left';
    } else {
      $direction      = 'ltr';
      $text_align     = 'left';
      $not_text_align = 'right';
    }

    if ($currency_code == 'BDT' || $language_code == 'bd') {
      // bengali font
      $font_family = "'Hind Siliguri','sans-serif'";
    } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
      // khmer font
      $font_family = "'Hanuman','sans-serif'";
    } elseif ($currency_code == 'AMD') {
      // Armenia font
      $font_family = "'arnamu','sans-serif'";
      // }elseif($currency_code == 'ILS'){
      //     // Israeli font
      //     $font_family = "'Varela Round','sans-serif'";
    } elseif ($currency_code == 'AED' || $currency_code == 'EGP' || $language_code == 'sa' || $currency_code == 'IQD' || $language_code == 'ir' || $language_code == 'om' || $currency_code == 'ROM' || $currency_code == 'SDG' || $currency_code == 'ILS' || $language_code == 'jo') {
      // middle east/arabic/Israeli font
      $font_family = "'Baloo Bhaijaan 2','sans-serif'";
    } elseif ($currency_code == 'THB') {
      // thai font
      $font_family = "'Kanit','sans-serif'";
    } else {
      // general for all
      $font_family = "'Roboto','sans-serif'";
    }

    // $config = ['instanceConfigurator' => function($mpdf) {
    //     $mpdf->showImageErrors = true;
    // }];
    // mpdf config will be used in 4th params of loadview

    $config = [];

    $order = Order::findOrFail($id);
    if (mb_substr($order->code, 0, 3) == 'MZ/') {
      return PDF::loadView('backend.invoices.invoice', [
        'order'          => $order,
        'font_family'    => $font_family,
        'direction'      => $direction,
        'text_align'     => $text_align,
        'not_text_align' => $not_text_align,
      ], [], $config)->download('order-' . $order->code . '.pdf');
    } else {
      return PDF::loadView('backend.invoices.proformainvoice', [
        'order'          => $order,
        'font_family'    => $font_family,
        'direction'      => $direction,
        'text_align'     => $text_align,
        'not_text_align' => $not_text_align,
      ], [], $config)->download('order-' . $order->code . '.pdf');
    }
  }



  //new invoice _file_path function created on 06 - aug- 2024
  public function invoice_file_path($id) {
    if (Session::has('currency_code')) {
      $currency_code = Session::get('currency_code');
    } else {
        $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
    }
    $language_code = Session::get('locale', Config::get('app.locale'));

    if (Language::where('code', $language_code)->first()->rtl == 1) {
        $direction      = 'rtl';
        $text_align     = 'right';
        $not_text_align = 'left';
    } else {
        $direction      = 'ltr';
        $text_align     = 'left';
        $not_text_align = 'right';
    }

    if ($currency_code == 'BDT' || $language_code == 'bd') {
        $font_family = "'Hind Siliguri','sans-serif'";
    } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
        $font_family = "'Hanuman','sans-serif'";
    } elseif ($currency_code == 'AMD') {
        $font_family = "'arnamu','sans-serif'";
    } elseif (in_array($currency_code, ['AED', 'EGP', 'IQD', 'ROM', 'SDG', 'ILS']) || in_array($language_code, ['sa', 'ir', 'om', 'jo'])) {
        $font_family = "'Baloo Bhaijaan 2','sans-serif'";
    } elseif ($currency_code == 'THB') {
        $font_family = "'Kanit','sans-serif'";
    } else {
        $font_family = "'Roboto','sans-serif'";
    }

    $config = [];

    $order = Order::findOrFail($id);

    $client_address = DB::table('addresses')
    ->where('id', $order->address_id)
    ->first();

    $view = mb_substr($order->code, 0, 3) == 'MZ/' ? 'backend.invoices.invoice' : 'backend.invoices.proformainvoice';
    $pdf = PDF::loadView($view, [
        'order'          => $order,
        'client_address' => $client_address,
        'font_family'    => $font_family,
        'direction'      => $direction,
        'text_align'     => $text_align,
        'not_text_align' => $not_text_align,
    ], [], $config);

    $fileName = 'order-' . $order->code . '.pdf';
    $filePath = public_path('pdfs/' . $fileName);
    $pdf->save($filePath);

    $publicUrl = url('public/pdfs/' . $fileName);

    return $publicUrl;
  }



  //new invoice _file_path for cart_quotations function created on 14 - aug- 2024
  public function invoice_file_path_cart_quotations($id,$newQuotationId) {
    
    if (Session::has('currency_code')) {
      $currency_code = Session::get('currency_code');
    } else {
        $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
    }
    $language_code = Session::get('locale', Config::get('app.locale'));
   

    if (Language::where('code', $language_code)->first()->rtl == 1) {
        $direction      = 'rtl';
        $text_align     = 'right';
        $not_text_align = 'left';
    } else {
        $direction      = 'ltr';
        $text_align     = 'left';
        $not_text_align = 'right';
    }
    

    if ($currency_code == 'BDT' || $language_code == 'bd') {
        $font_family = "'Hind Siliguri','sans-serif'";
    } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
        $font_family = "'Hanuman','sans-serif'";
    } elseif ($currency_code == 'AMD') {
        $font_family = "'arnamu','sans-serif'";
    } elseif (in_array($currency_code, ['AED', 'EGP', 'IQD', 'ROM', 'SDG', 'ILS']) || in_array($language_code, ['sa', 'ir', 'om', 'jo'])) {
        $font_family = "'Baloo Bhaijaan 2','sans-serif'";
    } elseif ($currency_code == 'THB') {
        $font_family = "'Kanit','sans-serif'";
    } else {
        $font_family = "'Roboto','sans-serif'";
    }

    $config = [];
    

    $cartItems = DB::table('users')
    ->leftJoin('carts', 'users.id', '=', 'carts.user_id')
    ->leftJoin('products', 'carts.product_id', '=', 'products.id')
    ->leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id')
    ->leftJoin('addresses', 'carts.address_id', '=', 'addresses.id')
    ->leftJoin('uploads', 'products.photos', '=', 'uploads.id') // Join uploads with products based on thumbnail_img
    ->select(
        'users.company_name',
        'users.phone',
        'users.manager_id',
        'users.party_code',
        'users.credit_days',
        'users.credit_limit',
        'products.part_no',
        'products.name as product_name',
        'warehouses.name as warehouse_name',
        'carts.created_at',
        'carts.quantity',
        'carts.address_id',
        'carts.price',
        'carts.user_id',
        'carts.product_id',
        'addresses.address',
        'addresses.address_2',
        'addresses.city',
        'carts.id as cart_id',
        DB::raw('carts.quantity * carts.price as total'),
        'uploads.file_name as thumbnail' // Select the file_name from uploads
    )
    ->where('carts.user_id', $id)
    ->get();

    $cartItemAddress = DB::table('users')
        ->join('carts', 'users.id', '=', 'carts.user_id')
        ->join('addresses', 'carts.address_id', '=', 'addresses.id') // Join with the addresses table
        ->where('carts.user_id', $id)  // Add the where condition
        ->select('carts.address_id', 'addresses.address', 'addresses.address_2') // Select specific columns
        ->first(); // Retrieve the first matching record

   $logo="https://storage.googleapis.com/mazing/uploads/all/PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png";         
    $view = 'backend.invoices.cart_quotations';
    $pdf = PDF::loadView($view, [
        'cart_items'          => $cartItems,
        'client_address' => $cartItemAddress,
        'quotation_id'=>$newQuotationId,
        'logo'=>$logo,
        'font_family'    => $font_family,
        'direction'      => $direction,
        'text_align'     => $text_align,
        'not_text_align' => $not_text_align,
    ], [], $config);

    $fileName = 'quotations-' . $newQuotationId . '.pdf';
    $filePath = public_path('pdfs/' . $fileName);
    $pdf->save($filePath);

    $publicUrl = url('public/pdfs/' . $fileName);

    return $publicUrl;
  }

    //new invoice _file_path for cart_quotations function created on 14 - aug- 2024
    public function invoice_file_path_abandoned_cart($id,$random_number) {
    
      if (Session::has('currency_code')) {
        $currency_code = Session::get('currency_code');
      } else {
          $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
      }
      $language_code = Session::get('locale', Config::get('app.locale'));
     
  
      if (Language::where('code', $language_code)->first()->rtl == 1) {
          $direction      = 'rtl';
          $text_align     = 'right';
          $not_text_align = 'left';
      } else {
          $direction      = 'ltr';
          $text_align     = 'left';
          $not_text_align = 'right';
      }
      
  
      if ($currency_code == 'BDT' || $language_code == 'bd') {
          $font_family = "'Hind Siliguri','sans-serif'";
      } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
          $font_family = "'Hanuman','sans-serif'";
      } elseif ($currency_code == 'AMD') {
          $font_family = "'arnamu','sans-serif'";
      } elseif (in_array($currency_code, ['AED', 'EGP', 'IQD', 'ROM', 'SDG', 'ILS']) || in_array($language_code, ['sa', 'ir', 'om', 'jo'])) {
          $font_family = "'Baloo Bhaijaan 2','sans-serif'";
      } elseif ($currency_code == 'THB') {
          $font_family = "'Kanit','sans-serif'";
      } else {
          $font_family = "'Roboto','sans-serif'";
      }
  
      $config = [];
      
      $cartItems = DB::table('users')
    ->leftJoin('carts', 'users.id', '=', 'carts.user_id')
    ->leftJoin('products', 'carts.product_id', '=', 'products.id')
    ->leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id')
    ->leftJoin('addresses', 'carts.address_id', '=', 'addresses.id')
	->leftJoin('uploads', 'products.thumbnail_img', '=', 'uploads.id')
    ->select(
        'users.company_name',
        'users.phone',
        'users.manager_id',
        'users.party_code',
        'products.name as product_name',
        'warehouses.name as warehouse_name',
        'carts.created_at',
        'carts.quantity',
        'carts.address_id',
        'carts.price',
        'carts.user_id',
        'carts.product_id',
        'addresses.address',
        'addresses.address_2',
        'addresses.city',
        'carts.id as cart_id',
        DB::raw('carts.quantity * carts.price as total')
    )
    ->where('carts.user_id', $id)
    ->get();

              // echo $cartItems->count();
              // die();
  
      $cartItemAddress = DB::table('users')
          ->join('carts', 'users.id', '=', 'carts.user_id')
          ->join('addresses', 'carts.address_id', '=', 'addresses.id') // Join with the addresses table
          ->where('carts.user_id', $id)  // Add the where condition
          ->select('carts.address_id', 'addresses.address', 'addresses.address_2') // Select specific columns
          ->first(); // Retrieve the first matching record
  
     $logo="https://storage.googleapis.com/mazing/uploads/all/PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png";         
      $view = 'backend.invoices.unfilled_order';
      $pdf = PDF::loadView($view, [
          'cart_items'          => $cartItems,
          'client_address' => $cartItemAddress,
          
          'logo'=>$logo,
          'font_family'    => $font_family,
          'direction'      => $direction,
          'text_align'     => $text_align,
          'not_text_align' => $not_text_align,
      ], [], $config);
      
      $hashCode = substr(md5(uniqid($random_number, true)), 0, 8);
      $fileName = 'abandoned_cart-' . '-' . $hashCode . '.pdf';
      // $fileName = 'quotations-' . $newQuotationId . '.pdf';
      $filePath = public_path('abandoned_cart_pdf/' . $fileName);
      $pdf->save($filePath);
  
      $publicUrl = url('public/abandoned_cart_pdf/' . $fileName);
  
      return $publicUrl;
    }


    //purchase order pdf generation (save & continuee)
     public function purchase_order_pdf_invoice($purchase_order_no) {
      if (Session::has('currency_code')) {
          $currency_code = Session::get('currency_code');
      } else {
          $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
      }
      $language_code = Session::get('locale', Config::get('app.locale'));
  
      if (Language::where('code', $language_code)->first()->rtl == 1) {
          $direction      = 'rtl';
          $text_align     = 'right';
          $not_text_align = 'left';
      } else {
          $direction      = 'ltr';
          $text_align     = 'left';
          $not_text_align = 'right';
      }
  
      if ($currency_code == 'BDT' || $language_code == 'bd') {
          $font_family = "'Hind Siliguri','sans-serif'";
      } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
          $font_family = "'Hanuman','sans-serif'";
      } elseif ($currency_code == 'AMD') {
          $font_family = "'arnamu','sans-serif'";
      } elseif (in_array($currency_code, ['AED', 'EGP', 'IQD', 'ROM', 'SDG', 'ILS']) || in_array($language_code, ['sa', 'ir', 'om', 'jo'])) {
          $font_family = "'Baloo Bhaijaan 2','sans-serif'";
      } elseif ($currency_code == 'THB') {
          $font_family = "'Kanit','sans-serif'";
      } else {
          $font_family = "'Roboto','sans-serif'";
      }
  
      // Fetch the purchase order details
      $order = DB::table('final_purchase_order')
          ->join('sellers', 'final_purchase_order.seller_id', '=', 'sellers.id')
          ->join('shops', 'sellers.id', '=', 'shops.seller_id')
          ->where('final_purchase_order.purchase_order_no', $purchase_order_no)
          ->select(
              'final_purchase_order.*',
              'shops.name as seller_company_name',
              'shops.address as seller_address',
              'sellers.gstin as seller_gstin',
              'shops.phone as seller_phone',
          )
          ->first();
         

  
      // Decode the product_info JSON
      $productInfo = json_decode($order->product_info, true);
  
      // Fetch product details (purchase_price, hsncode, product_name) for each part number
      foreach ($productInfo as &$product) {

        // if ($product['qty'] == 0) {
        //   continue;

        // }
          $productDetails = DB::table('products')
              ->where('part_no', $product['part_no'])
              ->select('name as product_name', 'purchase_price', 'hsncode','part_no')
              ->first();
  
          $product['product_name'] = $productDetails->product_name ?? 'Unknown';
          $product['purchase_price'] = $productDetails->purchase_price ?? 0;
          $product['hsncode'] = $productDetails->hsncode ?? 'N/A';
          $product['subtotal'] = $product['qty'] * $product['purchase_price'];
      }
  
      $logo = "https://storage.googleapis.com/mazing/uploads/all/PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png";         
      $view = 'backend.invoices.purchase_order_pdf';

      $randomNumber = rand(1000, 9999);
      $fileName = 'purchase_order-' . $randomNumber . '.pdf';

      $pdf = PDF::loadView($view, [
          'logo' => $logo,
          'font_family' => $font_family,
          'direction' => $direction,
          'text_align' => $text_align,
          'not_text_align' => $not_text_align,
          'order' => $order,
          'productInfo' => $productInfo
      ], [], []);
      
      
      $filePath = public_path('abandoned_cart_pdf/' . $fileName);
      $pdf->save($filePath);
  
      $publicUrl = url('public/abandoned_cart_pdf/' . $fileName);
      return $publicUrl;
  }

  //purchase order pdf generation (save & continuee)
  public function packing_list_pdf_invoice($purchase_order_no) {
    if (Session::has('currency_code')) {
        $currency_code = Session::get('currency_code');
    } else {
        $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
    }
    $language_code = Session::get('locale', Config::get('app.locale'));

    if (Language::where('code', $language_code)->first()->rtl == 1) {
        $direction      = 'rtl';
        $text_align     = 'right';
        $not_text_align = 'left';
    } else {
        $direction      = 'ltr';
        $text_align     = 'left';
        $not_text_align = 'right';
    }

    if ($currency_code == 'BDT' || $language_code == 'bd') {
        $font_family = "'Hind Siliguri','sans-serif'";
    } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
        $font_family = "'Hanuman','sans-serif'";
    } elseif ($currency_code == 'AMD') {
        $font_family = "'arnamu','sans-serif'";
    } elseif (in_array($currency_code, ['AED', 'EGP', 'IQD', 'ROM', 'SDG', 'ILS']) || in_array($language_code, ['sa', 'ir', 'om', 'jo'])) {
        $font_family = "'Baloo Bhaijaan 2','sans-serif'";
    } elseif ($currency_code == 'THB') {
        $font_family = "'Kanit','sans-serif'";
    } else {
        $font_family = "'Roboto','sans-serif'";
    }

    // Fetch the purchase order details
    $order = DB::table('final_purchase_order')
        ->join('sellers', 'final_purchase_order.seller_id', '=', 'sellers.id')
        ->join('shops', 'sellers.id', '=', 'shops.seller_id')
        ->where('final_purchase_order.purchase_order_no', $purchase_order_no)
        ->select(
            'final_purchase_order.*',
            'shops.name as seller_company_name',
            'shops.address as seller_address',
            'sellers.gstin as seller_gstin',
            'shops.phone as seller_phone'
        )
        ->first();
      
    // Decode the product_info JSON
    $productInfo = json_decode($order->product_info, true);

    // Fetch product details (purchase_price, hsncode, product_name) for each part number
    foreach ($productInfo as &$product) {
        $productDetails = DB::table('products')
            ->where('part_no', $product['part_no'])
            ->select('name as product_name', 'purchase_price', 'hsncode', 'part_no')
            ->first();

        $product['product_name'] = $productDetails->product_name ?? 'Unknown';
        $product['purchase_price'] = $productDetails->purchase_price ?? 0;
        $product['hsncode'] = $productDetails->hsncode ?? 'N/A';
        $product['subtotal'] = $product['qty'] * $product['purchase_price'];
    }
    $sellerName = DB::table('final_purchase_order')
          ->where('purchase_order_no', $purchase_order_no)
          ->value(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(seller_info, '$.seller_name'))"));

    $logo = "https://storage.googleapis.com/mazing/uploads/all/PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png";         
    $view = 'backend.invoices.packing_list';


    $randomNumber = rand(1000, 9999);
    $fileName = 'packing_list-' . $randomNumber . '.pdf';

    $pdf = PDF::loadView($view, [
        'logo' => $logo,
        'font_family' => $font_family,
        'direction' => $direction,
        'text_align' => $text_align,
        'not_text_align' => $not_text_align,
        'order' => $order,
        'seller_name'=>$sellerName,
        'productInfo' => $productInfo
    ])->save(public_path('packing_list_pdf/' . $fileName));

    $publicUrl = url('public/packing_list_pdf/' . $fileName);
    return $publicUrl;
}

  
  
}
