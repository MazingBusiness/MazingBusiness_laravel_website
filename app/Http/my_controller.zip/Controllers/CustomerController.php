<?php

namespace App\Http\Controllers;

use App\Models\Pincode;
use App\Models\Staff;
use App\Models\User;
use App\Models\Address;
use App\Models\City;
use App\Models\State;
use App\Utility\WhatsAppUtility;
use Hash;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use App\Services\WhatsAppWebService;
function debug_to_console($data) {
  $output = $data;
  if (is_array($output))
      $output = implode(',', $output);

  echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}

class CustomerController extends Controller {
  protected $WhatsAppWebService;

  public function __construct() {
    // Staff Permission Check
    $this->middleware(['permission:view_all_customers'])->only('index');
    $this->middleware(['permission:login_as_customer'])->only('login');
    $this->middleware(['permission:ban_customer'])->only('ban');
    // $this->middleware(['permission:add_new_customer'])->only('store');
    $this->middleware(['permission:edit_customer'])->only('edit', 'update');
    $this->middleware(['permission:delete_customer'])->only('destroy');
  }

  
  public function index(Request $request) {
    $sort_search = null;
    $filter = null;
    $user = Auth::user();
    
    if ($user) {
        $user_type = $user->user_type;
        $user_id = $user->id;
    }
    if( $user_id == '180' || $user_id == '25606' || $user_id == '169'){
      $users       = User::where('user_type', 'customer', 'warehouse')->where('email_verified_at', '!=', null)->orderBy('created_at', 'desc');
    }
    else if($user_type != 'admin')
    {
      $users       = User::where('user_type', 'customer', 'warehouse')->where('email_verified_at', '!=', null)->where('manager_id', $user_id)->orderBy('created_at', 'desc');
    }else{
      $users       = User::where('user_type', 'customer', 'warehouse')->where('email_verified_at', '!=', null)->orderBy('created_at', 'desc');
    }
    if ($request->has('search')) {
      $sort_search = $request->search;
      $filter = $request->filter;
      if($filter == 'approved'){
        $users->where('banned', '0');
      }elseif($filter == 'un_approved'){
        $users->where('banned', '1');
      }
      
      $users->where(function ($q) use ($sort_search) {
        $q->where('party_code', 'like', '%' . $sort_search . '%')->orWhere('phone', 'like', '%' . $sort_search . '%')->orWhere('name', 'like', '%' . $sort_search . '%');
      });
    }
    $users = $users->paginate(15);
    return view('backend.customer.customers.index', compact('users', 'sort_search','filter'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create() {
    $user = Auth::user();
    $managers = Staff::with('user:id,name')->where('role_id', 5)->get();
    // echo "<pre>"; print_r($user);die;
    return view('backend.customer.customers.create', compact('user', 'managers'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request) {
    
    try {
        // Append country code to the mobile number
        $request->merge(['mobile' => '+91' . $request->mobile]);

        // Logging the mobile number for debugging
        \Log::info('Mobile: ' . $request->mobile);

        // Validation rules based on the presence of GSTIN
        if ($request->gstin) {
          $validatedData = $request->validate([
                'warehouse_id' => 'required|exists:warehouses,id',
                'manager_id'   => 'required|exists:staff,user_id',
                'name'         => 'required|string|max:255|regex:/^[a-zA-Z\s]*$/',
                'company_name' => 'required|string|max:255',
                'address'      => 'required|string',
                'address2'     => 'required|string',
                'pincode'      => 'required',
                'email'        => 'unique:users|email',
                'mobile'       => 'required|unique:users,phone|regex:/^\+91[0-9]{10}$/',
                'gstin'        => 'required|string|size:15|unique:users',
            ]);
        } else {
            $request->validate([
                'warehouse_id' => 'required|exists:warehouses,id',
                'manager_id'   => 'required|exists:staff,user_id',
                'name'         => 'required|string|max:255|regex:/^[a-zA-Z\s]*$/',
                'company_name' => 'required|string|max:255',
                'address'      => 'required|string',
                'address2'     => 'required|string',
                'city'     => 'required|string',
                'email'        => 'required|unique:users|email',
                'mobile'       => 'required|unique:users,phone|regex:/^\+91[0-9]{10}$/',
                'aadhar_card'  => 'required|string|size:12',
                'pincode'  => 'required|numeric|digits:6|exists:pincodes,pincode',
            ]);
        }
        // Debug user data before creation
        $user = $request->all();
        \Log::info('User Data: ' . json_encode($user));
        // die;
        // Create user
        $user = $this->createUser($user);
        // If user creation is successful, modify the response status
        if ($user) {
            //SENDING WHATSAPP MESSAGE CODE START
            // **********************Message sending to Client************************ //
              $to = $user->phone;
              $templateData = [
                  'name' => 'activated_client_template', 
                  'language' => 'en_US', 
                  'components' => [
                      [
                          'type' => 'body',
                          'parameters' => [
                              ['type' => 'text','text' => $user->company_name],
                              ['type' => 'text','text' => str_replace("+91", "", $user->phone)],
                              ['type' => 'text','text' => $user->verification_code]
                          ],
                      ]
                  ],
              ];

            $this->WhatsAppWebService=new WhatsAppWebService();
            $response = $this->WhatsAppWebService->sendTemplateMessage($to, $templateData);

                // **********************Message sending to sub Manager ************************ //
                $user_city = DB::table('users')
                  ->join('addresses', 'users.id', '=', 'addresses.user_id')
                  ->where('users.id', $user->id)
                  ->value('addresses.city');

                $getManager = User::where('id',$user->manager_id)->first();
                $to=$getManager->phone;

                $subManagerTemplate = [
                  'name' => 'sub_manager_notification', 
                  'language' => 'en_US', 
                  'components' => [
                      [
                          'type' => 'body',
                          'parameters' => [
                              ['type' => 'text','text' => $getManager->name],
                              ['type' => 'text','text' => $user->company_name],
                              ['type' => 'text','text' => $user->phone],
                              ['type' => 'text','text' => $user->gstin],
                              ['type' => 'text','text' => $user->state],
                              ['type' => 'text','text' => $user_city]
                          ],
                      ]
                  ],
              ];

              $this->WhatsAppWebService=new WhatsAppWebService();
              $response = $this->WhatsAppWebService->sendTemplateMessage($to, $subManagerTemplate);
            //SENDING WHATSAPP MESSAGE CODE END
            return redirect()->route('customer.create')->with('success', 'Customer created successfully!');
        } else {
            return redirect()->route('customer.create')->with('error', 'There was a problem creating the user.');
        }
               
        // return response()->json($response);
    } catch (ValidationException $e) {
        // Log the validation error messages
        \Log::error('Validation Errors: ', $e->errors());

        // Return validation errors as JSON
        return response()->json([
            'status' => 'Error',
            'errors' => $e->errors(),
        ], 422);
    } catch (\Exception $e) {
        // Log any other exceptions
        \Log::error('An error occurred: ' . $e->getMessage());

        return response()->json([
            'status' => 'Error',
            'message' => 'An unexpected error occurred.',
        ], 500);
    }
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id) {
    //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function edit($id) {
    $user = User::findOrFail($id);
    return view('backend.customer.customers.edit', compact('user'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id) {
    $user               = User::findOrFail($id);
    $shipper_allocation = [];
    $loop               = 0;
    foreach ($user->shipper_allocation as $shipper) {
      $shipper_allocation[]                      = $shipper;
      $shipper_allocation[$loop]['carrier_id']   = $request->carrier_id[$loop];
      $shipper_allocation[$loop]['carrier_name'] = $request->carrier_name[$loop];
      $loop++;
    }
    $user->shipper_allocation = $shipper_allocation;
    $user->save();
    flash(translate('Customer details updated successfully'))->success();
    return redirect()->route('customers.index');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id) {
    $customer = User::findOrFail($id);
    $customer->customer_products()->delete();

    User::destroy($id);
    flash(translate('Customer has been deleted successfully'))->success();
    return redirect()->route('customers.index');
  }

  public function bulk_customer_delete(Request $request) {
    if ($request->id) {
      foreach ($request->id as $customer_id) {
        $customer = User::findOrFail($customer_id);
        $customer->customer_products()->delete();
        $this->destroy($customer_id);
      }
    }

    return 1;
  }

  public function login($id) {

    $staff_id = Auth::user()->id;
    session()->put('staff_id', $staff_id);
    // $ses_staff_id = session()->get('staff_id');
    
    $user = User::findOrFail(decrypt($id));
    session()->put('cl_name', $user->name);

    auth()->login($user, true);
    return redirect()->route('products.quickorder');
  }

  public function switch_back() {

    $staff_id = session()->get('staff_id');
    session()->forget('staff_id');

  
    $user = User::findOrFail($staff_id);
    auth()->login($user, true);
    return redirect()->route('customers.index');
  }

  protected function createUser(array $data) {
    $pincode      = Pincode::where('pincode', $data['pincode'])->first();
    $lastcustomer = User::where('user_type', 'customer')->where('warehouse_id', $data['warehouse_id'])->orderBy('id', 'desc')->orderBy('id', 'desc')->first();
    //echo "<pre>"; print_r($lastcustomer);
    if ($lastcustomer) {
      $party_code = 'OPEL0' . $data['warehouse_id'] . str_pad(((int) substr($lastcustomer->party_code, -5) + 1), 5, '0', STR_PAD_LEFT);
    } else {
      $party_code = 'OPEL0' . $data['warehouse_id'] . '00001';
    }
    
    $getManager = User::where('id',$data['manager_id'])->first();
    $data['password'] =  substr($getManager->name, 0, 1).substr($data['mobile'], -4);
    
    debug_to_console($party_code);
    debug_to_console(json_encode($pincode));
    debug_to_console(json_encode($data));
    
    if ($data['gstin']) {
      try {
          $user = User::create([
              'name'                   => $data['name'],
              'company_name'           => $data['company_name'],
              'phone'                  => $data['mobile'],
              'email'                  => $data['email'],
              'password'               => Hash::make($data['password']),
              'address'                => $data['address'],
              'gstin'                  => $data['gstin'],
              'aadhar_card'            => $data['aadhar_card'],
              'postal_code'            => $data['pincode'],
              'city'                   => $pincode->city,
              'state'                  => $pincode->state,
              'country'                => 'India',
              'warehouse_id'           => $data['warehouse_id'],
              'manager_id'             => $getManager->id,
              'party_code'             => $party_code,
              'virtual_account_number' => $party_code,
              'discount'               => $data['discount'],
              'user_type'              => 'customer',
              'banned'                 => false,
              'gst_data'               => $data['gst_data'],
              'verification_code'      => $data['password'],
              'email_verified_at'      => date("Y-m-d H:i:s"),
          ]);
               
          // Convert JSON to array          
          $gstDataArray = json_decode($data['gst_data'], true);          
          $gstDataArray = $gstDataArray['taxpayerInfo'];
          

          $pincode = Pincode::where('pincode', $gstDataArray['pradr']['addr']['pncd'])->first();
          $state = State::where('name', $pincode->state)->first();
          $cityData = City::where('name', $pincode->city)->first();          
          
          if(!isset($city->id)){
            $cityData = City::create([
              'name'               => $pincode->city,
              'state_id'           => $state->id
            ]);
            $city = $cityData->id;
          }else{
            $city = $cityData->id;
          }         
          
          // $cmp_address = $gstDataArray['pradr']['addr']['bnm']. ', '.$gstDataArray['pradr']['addr']['st'] . ', ' .$gstDataArray['pradr']['addr']['loc'] . ', ' .$gstDataArray['pradr']['addr']['bno'] . ', ' .$gstDataArray['pradr']['addr']['dst'];
          $cmp_address = $gstDataArray['pradr']['addr']['bnm']. ', '.$gstDataArray['pradr']['addr']['st'] . ', ' .$gstDataArray['pradr']['addr']['loc'];
          $cmp_address2 = $gstDataArray['pradr']['addr']['bno'] . ', ' .$gstDataArray['pradr']['addr']['dst']; 
          
          $address = Address::create([
              'user_id'=>$user->id,
              'acc_code'=>$party_code,
              'company_name'=> $gstDataArray['tradeNam'],
              'address' => trim($cmp_address,' ,'),
              'address_2' => trim($cmp_address2,' ,'),
              'gstin'=> $gstDataArray['gstin'],
              'country_id' => '101',
              'state_id'=>$state->id,
              'city_id'=> (int)$city,
              'city'=>$gstDataArray['pradr']['addr']['dst'],
              'longitude'=> $gstDataArray['pradr']['addr']['lt'],
              'latitude'=> $gstDataArray['pradr']['addr']['lg'],
              'postal_code'=> $gstDataArray['pradr']['addr']['pncd'],
              'phone'=> $data['mobile'],
              'set_default'=> 1
          ]);
          

          if(isset($gstDataArray['adadr']) AND count($gstDataArray['adadr']) > 0){
            $count = 10;
            foreach($gstDataArray['adadr'] as $key=>$value){                          
              $party_code =$user->party_code.$count;
              $address = $value['addr'];
              $pincode = Pincode::where('pincode', $address['pncd'])->first();
              $state = State::where('name', $pincode->state)->first();              
              $city = City::where('name', $pincode->city)->first();
              
              if(!isset($city->id)){
                $city_create = City::create([
                  'name'                   => $pincode->city,
                  'state_id'           => $state->id
                ]);
                $city = $city_create->id;
              }else{
                $city = $city->id;
              }
              // $cmp_address = $address['bnm']. ', '.$address['st'] . ', ' .$address['loc'] . ', ' .$address['bno'] . ', ' .$address['dst'];
              $cmp_address = $address['bnm']. ', '.$address['st'] . ', ' .$address['loc'];
              $cmp_address2 = $address['bno'] . ', ' .$address['dst'];
              Address::create([
                  'user_id'=>$user->id,
                  'acc_code'=>$party_code,
                  'company_name'=> $gstDataArray['tradeNam'],
                  'address' => trim($cmp_address,' ,'),
                  'address_2' => trim($cmp_address2,' ,'),
                  'gstin'=> $gstDataArray['gstin'],
                  'country_id' => '101',
                  'state_id'=>$state->id,
                  'city_id'=> (int)$city,
                  'city'=>$address['dst'],
                  'longitude'=> $address['lt'],
                  'latitude'=> $address['lg'],
                  'postal_code'=> $address['pncd'],
                  'phone'=> $data['mobile'],
                  'set_default'=> 0
              ]);
              $count++;
            }
          }
          
          \Log::info('Default Addresss: ' . json_encode($address));
          
      } catch (\Exception $e) {
          debug_to_console($e->getMessage());
          // Log::error($e->getMessage());
          // You can also log the stack trace
          // Log::error($e->getTraceAsString());
      }
    } else {
      $user = User::create([
        'name'                   => $data['name'],
        'company_name'           => $data['company_name'],
        'phone'                  => $data['mobile'],
        'email'                  => $data['email'],
        'password'               => Hash::make($data['password']),
        'address'                => $data['address'],
        'gstin'                  => null,
        'aadhar_card'            => $data['aadhar_card'],
        'postal_code'                => $data['pincode'],
        'city'                   => $pincode->city,
        'state'                  => $pincode->state,
        'country'                => 'India',
        'warehouse_id'           => $data['warehouse_id'],
        'party_code'             => $party_code,
        'virtual_account_number' => $party_code,
        'user_type'              => 'customer',
        'manager_id'             => $getManager->id,
        'banned'                 => false,
        'verification_code'      => $data['password'],
        'email_verified_at'      => date("Y-m-d H:i:s"),
        'discount'               => $data['discount'],

      ]);

      $pincode = Pincode::where('pincode', $data['pincode'])->first();
      $city = City::where('name', $pincode->city)->first();
      if(isset($city) AND $city->id != ""){
        $city = $city->id;
      }else{
        $city= 0;
      }
      $state = State::where('name', $pincode->state)->first();
      $cmp_address = $data['address'];
      $cmp_address2 = $data['address2'];
      $address = Address::create([
          'user_id'=>$user->id,
          'acc_code'=>$party_code,
          'company_name'=> $data['company_name'],
          'address' => $cmp_address,
          'address_2' => $cmp_address2,
          'gstin'=> null,
          'country_id' => '101',
          'state_id'=>$state->id,
          'city_id'=> $city,
          'city'=> $data['city'],
          'longitude'=> null,
          'latitude'=> null,
          'postal_code'=> $data['pincode'],
          'phone'=> $data['mobile'],
          'set_default'=> 1
      ]);

    }
    
    // Push User data to Salezing
    $result=array();
    $result['party_code']= $user->party_code;
    $response = Http::withHeaders([
        'Content-Type' => 'application/json',
    ])->post('https://mazingbusiness.com/api/v2/client-push', $result);

    return $user;
  }

  public function ban($id, $manager_id = null) {
    $user = User::findOrFail(decrypt($id));
    if ($user->banned == 1) {
      $user->banned = 0;
      if ($manager_id) {
        $user->manager_id = $manager_id;
      }
      WhatsAppUtility::accountRegistered($user, $user->address);
      flash(translate('Customer Approved Successfully'))->success();
    } else {
      $user->banned = 1;
      flash(translate('Customer Banned Successfully'))->success();
    }
    $user->save();
    return back();
  }
}
