<?php

namespace App\Http\Controllers;

use App\Http\Resources\V2\ProductDetailCollection;
use App\Models\Cart;
use App\Models\Product;
use App\Models\Warehouse;
use App\Models\User;
use Auth;
use Cookie;
use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\Services\WhatsAppWebService;

use App\Imports\ExternalPurchaseOrder;
use App\Exports\FinalPurchaseExport;
use Maatwebsite\Excel\Facades\Excel;
use Exception;


class CartController extends Controller {
  protected $WhatsAppWebService;
  public function index(Request $request) {
    if (auth()->user() != null) {
      $user_id = Auth::user()->id;
      if ($request->session()->get('temp_user_id')) {
        Cart::where('temp_user_id', $request->session()->get('temp_user_id'))
          ->update(
            [
              'user_id'      => $user_id,
              'temp_user_id' => null,
            ]
          );

        Session::forget('temp_user_id');
      }
      $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
    } else {
      $temp_user_id = $request->session()->get('temp_user_id');
      // $carts = Cart::where('temp_user_id', $temp_user_id)->get();
      $carts = ($temp_user_id != null) ? Cart::where('temp_user_id', $temp_user_id)->get() : [];
    }

    return view('frontend.view_cart', compact('carts'));
  }

  public function updateCartPrice(Request $request) {
    try {
        $user_id = Auth::user()->id;        
        $cart_id = $request->has('cart_id')? $request->cart_id : '';
        $update_price = $request->has('update_price')? $request->update_price : '0';

        $cartItem = Cart::findOrFail($cart_id);        
        $cartItem['price'] = $update_price;
        $cartItem->save();
        
        $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
        $view = view('frontend.updateCartPrice', compact('carts'))->render();
        return response()->json(['html' => $view]);

    } catch (\Exception $e) {
        // Log any other exceptions
        \Log::error('An error occurred: ' . $e->getMessage());
        return response()->json([
            'status' => 'Error',
            'message' => 'An unexpected error occurred.',
        ], 500);
    }

  }

  public function showCartModal(Request $request) {

    $product = Product::find($request->id);
  
   
    return view('frontend.partials.addToCart', compact('product'));
  }

  public function addToCart(Request $request) {

  //  return "test";
   
    $product = Product::find($request->id);
    $carts   = array();
    $data    = array();

    if (auth()->user() != null) {
      $user_id         = Auth::user()->id;
      $data['user_id'] = $user_id;
      $carts           = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
    } else {
      if ($request->session()->get('temp_user_id')) {
        $temp_user_id = $request->session()->get('temp_user_id');
      } else {
        $temp_user_id = bin2hex(random_bytes(10));
        $request->session()->put('temp_user_id', $temp_user_id);
      }
      $data['temp_user_id'] = $temp_user_id;
      $carts                = Cart::where('temp_user_id', $temp_user_id)->get();
    }

    $data['product_id'] = $product->id;
    $data['owner_id']   = $product->user_id;

    $str     = '';
    $tax     = $ctax     = $price     = $carton_price     = 0;
    $wmarkup = 0;
    if ($product->digital != 1 && $request->quantity < $product->min_qty) {
      return array(
        'status'        => 0,
        'cart_count'    => count($carts),
        'modal_view'    => view('frontend.partials.minQtyNotSatisfied', ['min_qty' => $product->min_qty])->render(),
        'nav_cart_view' => view('frontend.partials.cart')->render(),
      );
    }

    //check the color enabled or disabled for the product
    if ($request->has('color')) {
      $str = $request['color'];
    }

    if ($product->digital != 1) {
      //Gets all the choice values of customer choice option and generate a string like Black-S-Cotton
      if(is_countable(json_decode(Product::find($request->id)->choice_options))){
        foreach (json_decode(Product::find($request->id)->choice_options) as $key => $choice) {
          if ($str != null) {
            $str .= '_' . str_replace(' ', '', strtolower($request['attribute_id_' . $choice->attribute_id]));
          } else {
            $str .= str_replace(' ', '', strtolower($request['attribute_id_' . $choice->attribute_id]));
          }
        }
      }
      
    }
    $str = $product->slug;
    $data['variation'] = $str;

    $product_stock = $product->stocks->where('variant', $str);
    
    $user = Auth::user();

    $discount = 0;

    if ($user) {
        $discount = $user->discount;
    }

    if(!is_numeric($discount) || $discount == 0) {
      $discount = 20;
    }

    $product_mrp = Product::where('id', $product->id)->select('mrp')->first();
    if ($product_mrp) {
      $price = $product_mrp->mrp;
    } else {
      $price = 0;
    }
    
    if (!is_numeric($price)) {
      $price = 0;
    }
    $price = $price * ((100 - $discount) / 100);
    $price = ceil($price);

    // return array(
    //   'status'        => 0,
    //   'cart_count'    => count($carts),
    //   'modal_view'    => view('frontend.partials.outOfStockCart')->render(),
    //   'nav_cart_view' => view('frontend.partials.cart')->render(),
    // );

    //discount calculation
    $discount_applicable = false;

    if ($product->discount_start_date == null) {
      $discount_applicable = true;
    } elseif (strtotime(date('d-m-Y H:i:s')) >= $product->discount_start_date &&
      strtotime(date('d-m-Y H:i:s')) <= $product->discount_end_date) {
      $discount_applicable = true;
    }

    if ($discount_applicable) {
      if ($product->discount_type == 'percent') {
        $price -= ($price * $product->discount) / 100;
      } elseif ($product->discount_type == 'amount') {
        $price -= $product->discount;
      }
    }

    //calculation of taxes
    foreach ($product->taxes as $product_tax) {
      if ($product_tax->tax_type == 'percent') {
        $tax += ($price * $product_tax->tax) / 100;
      } elseif ($product_tax->tax_type == 'amount') {
        $tax += $product_tax->tax;
      }
    }

    $data['quantity']  = $request['quantity'];
    $data['price']     = $price;
    $data['tax']       = $tax;
    //$data['shipping'] = 0;
    $data['shipping_cost']         = 0;
    $data['product_referral_code'] = null;
    $data['cash_on_delivery']      = $product->cash_on_delivery;
    $data['digital']               = $product->digital;

    if ($request['quantity'] == null) {
      $data['quantity'] = 1;
    }

    if (Cookie::has('referred_product_id') && Cookie::get('referred_product_id') == $product->id) {
      $data['product_referral_code'] = Cookie::get('product_referral_code');
    }

    if ($carts && count($carts) > 0) {
      $foundInCart = false;
      foreach ($carts as $key => $cartItem) {
        $cart_product = Product::where('id', $cartItem['product_id'])->first();
        if ($cartItem['product_id'] == $request->id) {
          if ($cartItem['is_carton'] != $request['is_carton']) {
            $deleteCartRequest = new Request();
            $deleteCartRequest->replace(['id' => $cartItem['id']]);
            $this->removeFromCart($deleteCartRequest);
          }
          $product_stock = $cart_product->stocks->where('variant', $str);

          // $quantity = 1000;
          
          // if ($quantity < ($cartItem['quantity'] + $request['quantity'])) {
          //   return array(
          //     'status'        => 0,
          //     'cart_count'    => count($carts),
          //     'modal_view'    => view('frontend.partials.outOfStockCart')->render(),
          //     'nav_cart_view' => view('frontend.partials.cart')->render(),
          //   );
          // }
          if (($str != null && $cartItem['variation'] == $str) || $str == null) {
            $foundInCart = true;
              $cartItem['quantity'] += $request['quantity'];
              $cartItem['price'] = $price;
              $cartItem->save();
          }
        }
      }
      if (!$foundInCart) {
        Cart::create($data);
      }
    } else {
      Cart::create($data);
    }

    if (auth()->user() != null) {
      $user_id = Auth::user()->id;
      $carts   = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
    } else {
      $temp_user_id = $request->session()->get('temp_user_id');
      $carts        = Cart::where('temp_user_id', $temp_user_id)->get();
    }
   
    return array(
      'status'        => 1,
      'cart_count'    => count($carts),
      'modal_view'    => view('frontend.partials.addedToCart', compact('product', 'data'))->render(),
      'nav_cart_view' => view('frontend.partials.cart')->render(),
    );
  }

  //removes from Cart
  public function removeFromCart(Request $request) {
    Cart::destroy($request->id);
    if (auth()->user() != null) {
      $user_id = Auth::user()->id;
      $carts   = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
    } else {
      $temp_user_id = $request->session()->get('temp_user_id');
      $carts        = Cart::where('temp_user_id', $temp_user_id)->get();
    }

    return array(
      'cart_count'    => count($carts),
      'cart_view'     => view('frontend.partials.cart_details', compact('carts'))->render(),
      'nav_cart_view' => view('frontend.partials.cart')->render(),
    );
  }

  //updated the quantity for a cart item
  public function updateQuantity(Request $request) {
    $cartItem = Cart::findOrFail($request->id);

    if ($cartItem['id'] == $request->id) {
      $product       = Product::find($cartItem['product_id']);
      $product_stock = $product->stocks->where('variant', $cartItem['variation'])->first();
      $quantity      = $product_stock->qty;
      $price         = $product_stock->price;

      //discount calculation
      $discount_applicable = false;

      if ($product->discount_start_date == null) {
        $discount_applicable = true;
      } elseif (strtotime(date('d-m-Y H:i:s')) >= $product->discount_start_date &&
        strtotime(date('d-m-Y H:i:s')) <= $product->discount_end_date) {
        $discount_applicable = true;
      }

      if ($discount_applicable) {
        if ($product->discount_type == 'percent') {
          $price -= ($price * $product->discount) / 100;
        } elseif ($product->discount_type == 'amount') {
          $price -= $product->discount;
        }
      }

      if ($quantity >= $request->quantity) {
        if ($request->quantity >= $product->min_qty) {
          $cartItem['quantity'] = $request->quantity;
        }
      }

      if ($product->wholesale_product) {
        $wholesalePrice = $product_stock->wholesalePrices->where('min_qty', '<=', $request->quantity)->where('max_qty', '>=', $request->quantity)->first();
        if ($wholesalePrice) {
          $price = $wholesalePrice->price;
        }
      }

      $cartItem['price'] = $price;
      $cartItem->save();
    }

    if (auth()->user() != null) {
      $user_id = Auth::user()->id;
      $carts   = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
    } else {
      $temp_user_id = $request->session()->get('temp_user_id');
      $carts        = Cart::where('temp_user_id', $temp_user_id)->get();
    }

    return array(
      'cart_count'    => count($carts),
      'cart_view'     => view('frontend.partials.cart_details', compact('carts'))->render(),
      'nav_cart_view' => view('frontend.partials.cart')->render(),
    );
  }

  // public function productDetails($id)
  // {
  //   $cart = Cart::where('id',$id)->with('product')->first();
  //   return [
  //     'cart' => $cart,
  //     'product' => $cart['product'],
  //     'brand' => $cart['product']['brand'],
  //     'category' => $cart['product']['category'],
  //     'stocks' => $cart['product']['stocks']->first(),
  //   ];
  // }

  public function productDetails($id)
  {
    try {
        $cart = Cart::where('id', $id)->with('product')->first();

        if (!$cart) {
            return response()->json(['error' => 'Cart not found'], 404);
        }

        $product = $cart->product;

        if (!$product) {
            return response()->json(['error' => 'Product not found in cart'], 404);
        }

        $brand = $product->brand;
        $category = $product->category;
        $stocks = $product->stocks->first();

        return [
            'cart' => $cart,
            'product' => $product,
            'brand' => $brand,
            'category' => $category,
            'stocks' => $stocks,
        ];
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500);
    }
  }


  // ABANDONED CART CODE START


  public function sendBulkWhatsApp(Request $request)
  {
  
      $userIds = $request->input('selected_carts');
    
    
      if ($userIds) {
          foreach ($userIds as $userId) {
            $user = DB::table('users')
            ->join('carts', 'users.id', '=', 'carts.user_id')
            ->select('users.company_name', 'users.phone','users.manager_id')
            ->where('users.id', $userId)
            ->first();

            if (!$user) {
              return response()->json(['error' => 'User not found'], 404);
            }
             // Retrieve manager's information
             $manager = DB::table('users')
             ->select('name', 'phone')
             ->where('id', $user->manager_id)
             ->first();

              // Example of sending WhatsApp messages
              $cartItems = DB::table('carts')
              ->join('products', 'carts.product_id', '=', 'products.id')
              ->select('products.name as product_name', 'carts.quantity')
              ->where('carts.user_id', $userId)
              ->get();
  
              $itemCount = $cartItems->count();
            
      
              if ($itemCount == 1) {
                
                  $name = $user->company_name;
                  $item1 = $cartItems[0]->product_name ?? 'N/A';
                  $qty1 = $cartItems[0]->quantity ?? '0';
      
                  $singleItems = [
                      'name' => 'abandoned_cart_single_items', // Replace with your template name
                      'language' => 'en_US', // Replace with your desired language code
                      'components' => [
                          [
                              'type' => 'body',
                              'parameters' => [
                                  ['type' => 'text', 'text' => $name],
                                  ['type' => 'text', 'text' => $item1],
                                  ['type' => 'text', 'text' => $qty1],
                              ],
                          ],
                      ],
                  ];
      
                  $this->WhatsAppWebService = new WhatsAppWebService();
                  $response = $this->WhatsAppWebService->sendTemplateMessage($user->phone, $singleItems);
                  $response1 = $this->WhatsAppWebService->sendTemplateMessage($manager->phone, $singleItems);
                  return redirect()->back()->with('status', 'WhatsApp messages sent successfully!');
      
              } elseif ($itemCount > 1) {

                
                  $name = $user->company_name;
                 
                  $invoice=new InvoiceController();
                  $randomNumber = rand(1000, 9999); // Generates a random number between 1000 and 9999

                  $file_url=$invoice->invoice_file_path_abandoned_cart($userId,$randomNumber);
                  $file_name="Abandoned Cart";
                  $multipleItems = [
                    'name' => 'unfulfilled_order', // Replace with your template name, e.g., 'abandoned_cart_template'
                    'language' => 'en_US', // Replace with your desired language code
                    'components' => [
                        [
                            'type' => 'header',
                            'parameters' => [
                                ['type' => 'document', 'document' => ['link' => $file_url,'filename' => $file_name,]],
                            ],
                        ],
                        [
                            'type' => 'body',
                            'parameters' => [
                                ['type' => 'text', 'text' => $name],
                            ],
                        ],
                    ],
                ];

                 $this->WhatsAppWebService = new WhatsAppWebService();
                 $response = $this->WhatsAppWebService->sendTemplateMessage($user->phone, $multipleItems);
                  $response1 = $this->WhatsAppWebService->sendTemplateMessage($manager->phone, $multipleItems);
                 return redirect()->back()->with('status', 'WhatsApp messages sent successfully!');
              }
          }

          return redirect()->back()->with('status', 'WhatsApp messages sent successfully!')->withInput($request->all());
      }

      return redirect()->back()->with('status', 'No carts selected')->withInput($request->all());
  }
  public function abandoned_cart_send_single_whatsapp($cart_id)
  {
        
        // $userId = $user_id;
        $user = DB::table('users')
            ->join('carts', 'users.id', '=', 'carts.user_id')
            ->select('users.company_name', 'users.phone','users.manager_id','carts.user_id')
            ->where('carts.id', $cart_id)
            ->first();
           
        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }

         // Retrieve manager's information
          $manager = DB::table('users')
          ->select('name', 'phone')
          ->where('id', $user->manager_id)
          ->first();

        $cartItems = DB::table('carts')
            ->join('products', 'carts.product_id', '=', 'products.id')
            ->select('products.name as product_name', 'carts.quantity')
            ->where('carts.id', $cart_id)
            ->first();

        $name = $user->company_name;
        $item1 = $cartItems->product_name ?? 'N/A';
        $qty1 = $cartItems->quantity ?? '0';

        $singleItems = [
            'name' => 'abandoned_cart_single_items', // Replace with your template name
            'language' => 'en_US', // Replace with your desired language code
            'components' => [
                [
                    'type' => 'body',
                    'parameters' => [
                        ['type' => 'text', 'text' => $name],
                        ['type' => 'text', 'text' => $item1],
                        ['type' => 'text', 'text' => $qty1],
                    ],
                ],
            ],
        ];

        $this->WhatsAppWebService = new WhatsAppWebService();
        $response = $this->WhatsAppWebService->sendTemplateMessage($user->phone, $singleItems);
        
        $response1 = $this->WhatsAppWebService->sendTemplateMessage($manager->phone, $singleItems);
        return redirect()->back()->with('status', 'WhatsApp messages sent successfully!');
        
  }

  public function abandoned_cart_send_whatsapp(Request $request)
  {

    // echo "test";
    // die();
      $distinctUser = DB::table('users')
          ->join('carts', 'users.id', '=', 'carts.user_id')
          ->join('products', 'carts.product_id', '=', 'products.id')
          ->select('users.company_name', 'users.phone', 'carts.user_id','users.manager_id')
          //  ->where('carts.user_id', 24185)
          ->groupBy('carts.user_id', 'users.name')
          ->get();
  
      $responses = [];
  
      foreach ($distinctUser as $user) {

         // Retrieve manager's information
          $manager = DB::table('users')
          ->select('name', 'phone')
          ->where('id', $user->manager_id)
          ->first();

          $cartItems = DB::table('carts')
              ->join('products', 'carts.product_id', '=', 'products.id')
              ->select('products.name as product_name', 'carts.quantity')
              ->where('carts.user_id', $user->user_id)
              ->get();
  
          $itemCount = $cartItems->count();
  
          if ($itemCount == 1) {
              $name = $user->company_name;
              $item1 = $cartItems[0]->product_name ?? 'N/A';
              $qty1 = $cartItems[0]->quantity ?? '0';
  
              $singleItems = [
                  'name' => 'abandoned_cart_single_items', // Replace with your template name
                  'language' => 'en_US', // Replace with your desired language code
                  'components' => [
                      [
                          'type' => 'body',
                          'parameters' => [
                              ['type' => 'text', 'text' => $name],
                              ['type' => 'text', 'text' => $item1],
                              ['type' => 'text', 'text' => $qty1],
                          ],
                      ],
                  ],
              ];
  
              $this->WhatsAppWebService = new WhatsAppWebService();
              $response = $this->WhatsAppWebService->sendTemplateMessage($user->phone, $singleItems);
              $response1 = $this->WhatsAppWebService->sendTemplateMessage($manager->phone, $singleItems);
              $responses[] = $response;
  
          } elseif ($itemCount > 1) {
              $name = $user->company_name;

              $invoice=new InvoiceController();
              $randomNumber = rand(1000, 9999); // Generates a random number between 1000 and 9999

              $file_url=$invoice->invoice_file_path_abandoned_cart($user->user_id,$randomNumber);
              $file_name="Abandoned Cart";

              $multipleItems = [
                'name' => 'unfulfilled_order', // Replace with your template name, e.g., 'abandoned_cart_template'
                'language' => 'en_US', // Replace with your desired language code
                'components' => [
                    [
                        'type' => 'header',
                        'parameters' => [
                            ['type' => 'document', 'document' => ['link' => $file_url,'filename' => $file_name,]],
                        ],
                    ],
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $name],
                        ],
                    ],
                ],
            ];
  
              $this->WhatsAppWebService = new WhatsAppWebService();
              $response = $this->WhatsAppWebService->sendTemplateMessage($user->phone, $multipleItems);
              $response1 = $this->WhatsAppWebService->sendTemplateMessage($manager->phone, $multipleItems);
              $responses[] = $response;
          }
      }
  
      return redirect()->back()->with('status', 'WhatsApp messages sent to all successfully!');
  }
  
  public function abandoned_cart_list(Request $request)
  {
      // Retrieve the date filter and manager filter from the request
      $searchDate = $request->input('searchDate');
      $searchManager = $request->input('searchManager');

      $currentUserId = auth()->user()->id;

      // Determine if the current user should see all data or only data related to their manager_id
      $isSuperManager = in_array($currentUserId, [180, 169, 25606,1]);

      // Get distinct managers based on the current user role
      $distinctManagersQuery = DB::table('users')
          ->join('carts', 'users.id', '=', 'carts.user_id')
          ->select('users.manager_id')
          ->groupBy('users.manager_id');

      if (!$isSuperManager) {
          $distinctManagersQuery->where('users.manager_id', '=', $currentUserId);
      }

      $distinctManagers = $distinctManagersQuery->get();

      // Start building the main query
      $query = DB::table('users')
          ->join('carts', 'users.id', '=', 'carts.user_id')
          ->join('products', 'carts.product_id', '=', 'products.id')
          ->select(
              'users.company_name',
              'users.phone',
              'users.manager_id',
              'users.party_code',
              'products.name as product_name',
              'carts.created_at',
              'carts.quantity',
              'carts.price',
              'carts.user_id',
              'carts.product_id',
              'carts.id as cart_id',
              DB::raw('carts.quantity * carts.price as total') // Calculate total per item
          );

      // Apply manager filter
      if ($isSuperManager) {
          if ($searchManager) {
              $query->where('users.manager_id', '=', $searchManager);
          }
      } else {
          $query->where('users.manager_id', '=', $currentUserId);
      }

      // Apply the date filter if it exists
      if ($searchDate) {
          $query->whereDate('carts.created_at', '=', $searchDate);
      }

      // Get the total sum of all items
      $totalSum = $query->sum(DB::raw('carts.quantity * carts.price'));

      // Apply sorting and pagination
      $abandonedCart = $query->orderBy('carts.created_at', 'desc')
          ->paginate(30)
          ->appends($request->all());

      return view('backend.abandoned_cart.abandoned_cart_list', compact('abandonedCart', 'distinctManagers', 'totalSum'));
  }

  public function abandoned_cart_save_remark(Request $request){
    // return response()->json(['success' => true, 'message' => 'Remark saved successfully!']);
    // Validate the incoming request data
        $request->validate([
          'remark' => 'required'
          
      ]);

      // Insert the data into the remarks table
      DB::table('remarks')->insert([
          'remark_description' => $request->input('remark'),
          'created_at' => now(),
          'updated_at' => now(),
          'user_id' => $request->input('user_id'),
          'cart_id' => $request->input('cart_id'),
      ]);

      // Return a JSON response indicating success
      return response()->json([
          'success' => true,
          'message' => 'Remark saved successfully!',
      ]);
  }

  public function viewRemark($cart_id)
    {
        // Fetch the remark based on the cart_id
      
        $remarks = DB::table('remarks')
        ->join('users', 'remarks.user_id', '=', 'users.id')
        ->join('carts', 'remarks.cart_id', '=', 'carts.id')
        ->join('products', 'carts.product_id', '=', 'products.id')
        ->select(
            'remarks.remark_description',
            'remarks.created_at',
            'users.name as user_name',
            'carts.quantity',
            'carts.price',
            'products.name as product_name'
        )
        ->where('remarks.cart_id', $cart_id)
        ->get();

        // Pass the remark data to the view
        return view('backend.abandoned_cart.view_remark', compact('remarks'));
    }

    public function getRemarks(Request $request)
    {
        $cart_id = $request->input('cart_id');
    
        $remarks = DB::table('remarks')
            ->join('users', 'remarks.user_id', '=', 'users.id')
            ->select('remarks.remark_description', 'remarks.created_at', 'users.name as user_name')
            ->where('remarks.cart_id', $cart_id)
            ->orderBy('remarks.created_at', 'desc')
            ->get();
    
        if ($remarks->isNotEmpty()) {
            return response()->json([
                'success' => true,
                'remarks' => $remarks
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No remarks found for the selected cart.'
            ]);
        }
    }


    public function send_quotations(Request $request) {
      $user_id = Auth::user()->id;

      // Retrieve manager's information
      $manager = DB::table('users')
      ->select('name', 'phone')
      ->where('id', Auth::user()->manager_id)
      ->first();

      // Retrieve all cart items related to the user, including the warehouse name
      $cartItems = DB::table('users')
          ->leftJoin('carts', 'users.id', '=', 'carts.user_id')
          ->leftJoin('products', 'carts.product_id', '=', 'products.id')
          ->leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id') // Join with warehouses table via users table
          ->leftJoin('addresses', 'carts.address_id', '=', 'addresses.id')
          ->select(
              'users.company_name',
              'users.phone',
              'users.manager_id',
              'users.party_code',
              'products.name as product_name',
              'warehouses.name as warehouse_name', // Get the warehouse name with alias
              'carts.created_at',
              'carts.quantity',
              'carts.address_id',
              'carts.price',
              'carts.user_id',
              'carts.product_id',
              'carts.id as cart_id',
              DB::raw('carts.quantity * carts.price as total') // Calculate total per item
          )
          ->where('carts.user_id', $user_id)  // Add the where condition
          ->get();
  
      // Get the warehouse name of the user
      $warehouse_name = strtoupper(substr($cartItems->first()->warehouse_name, 0, 3)); // Extract the first 3 letters and convert to uppercase
  
      // Generate the new quotation_id
      $maxQuotationId = DB::table('quotations')
          ->where('quotation_id', 'LIKE', $warehouse_name . '-%')
          ->orderBy('quotation_id', 'desc')
          ->value('quotation_id');
  
      if ($maxQuotationId) {
          $lastNumber = (int)substr($maxQuotationId, strlen($warehouse_name) + 1);
          $newNumber = $lastNumber + 1;
      } else {
          $newNumber = 1;
      }
  
      $newQuotationId = $warehouse_name . '-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
      
      foreach ($cartItems as $item) {
          DB::table('quotations')->insert([
              'cart_id' => $item->cart_id,
              'user_id' => $user_id,
              'quotation_id' => $newQuotationId, // Use the new quotation ID
              'status' => '0', // Set the initial status
              'created_at' => now(),
              'updated_at' => now(),
          ]);
      }
      
      $invoice=new InvoiceController();
      $file_url=$invoice->invoice_file_path_cart_quotations($user_id,$newQuotationId);
     
      $file_name="Quotations";
    //  $to=['+916289062983'];
      $to=[Auth::user()->phone,$manager->phone];

      $templateData = [
          'name' => 'quotation_cart_template',
          'language' => 'en', 
          'components' => [
            [
              'type' => 'header',
                  'parameters' => [
                      [
                          'type' => 'document', // Use 'image', 'video', etc. as needed
                          'document' => [
                              'link' => $file_url,
                              'filename' => $file_name,
                          ]
                      ]
                  ]
              ],
             
            
          ],
      ];

      $this->WhatsAppWebService=new WhatsAppWebService();
      foreach($to as $person_to_send){
        $response = $this->WhatsAppWebService->sendTemplateMessage($person_to_send, $templateData);
      }

      return response()->json(['status' => 'Quotation Sent to whatsapp!']);
  }
  
  

  // ABANDONED CART CODE END


      //purchase order code start
      //negative stock inventory
      public function purchase_order(Request $request) {
        // Retrieve the list of sellers for the dropdown
        $sellers = DB::table('users')
            ->join('sellers', 'users.id', '=', 'sellers.user_id')
            ->select('users.id', 'users.name')
            ->orderBy('users.name', 'asc')
            ->get();
    
        // Start query for purchase orders
        $query = DB::table('purchase_order')
            ->leftJoin('products', 'purchase_order.part_no', '=', 'products.part_no')
            ->leftJoin('sellers', 'products.seller_id', '=', 'sellers.id')
            ->leftJoin('users', 'sellers.user_id', '=', 'users.id')
            ->select(
                'purchase_order.*',
                'products.seller_id',
                'sellers.user_id',
                'users.name as seller_name'
            );
    
        // Apply seller name filter if provided
        if ($request->filled('sellerName')) {
            $query->where('users.id', '=', $request->sellerName);
        }
    
        // Apply sorting if provided
        if ($request->filled('sort') && $request->filled('direction')) {
            $query->orderBy($request->sort, $request->direction);
        } else {
            $query->orderBy('purchase_order.id', 'asc'); // Default sorting
        }
    
        // Get paginated results
        $purchaseOrders = $query->paginate(20)->appends($request->all());
    
        return view('backend.purchase_order.purchase_order', compact('purchaseOrders', 'sellers'));
    }
    


    public function showSelected(Request $request)
    {
        // Get the selected orders' IDs
        $selectedOrders = $request->input('selectedOrders', []);
    
        // Fetch the selected orders from the database, grouping by part_no and combining order_no and quantities
        $orders = DB::table('purchase_order')
            ->whereIn('purchase_order.id', $selectedOrders)
            ->leftJoin('products', 'purchase_order.part_no', '=', 'products.part_no')
            ->leftJoin('sellers', 'products.seller_id', '=', 'sellers.id')
            ->leftJoin('shops', 'sellers.id', '=', 'shops.seller_id')
            ->select(
                'purchase_order.part_no',
                'purchase_order.item',
                DB::raw('GROUP_CONCAT(DISTINCT purchase_order.order_no ORDER BY purchase_order.order_no ASC SEPARATOR ", ") as order_no'),
                DB::raw('GROUP_CONCAT(DISTINCT purchase_order.age ORDER BY purchase_order.age ASC SEPARATOR ", ") as age'),
                DB::raw('GROUP_CONCAT(DISTINCT DATE_FORMAT(purchase_order.order_date, "%d/%m/%y") ORDER BY purchase_order.order_date ASC SEPARATOR ", ") as order_date'),
                DB::raw('SUM(purchase_order.to_be_ordered) as total_quantity'),
                'products.seller_id',
                'products.purchase_price',
                'shops.name as seller_company_name',
                'shops.address as seller_address',
                'sellers.gstin as seller_gstin',
                'shops.phone as seller_phone'
            )
            ->groupBy('purchase_order.part_no', 'purchase_order.item', 'products.seller_id', 'products.purchase_price', 'shops.name', 'shops.address', 'sellers.gstin', 'shops.phone')
            ->get();
    
        return view('backend.purchase_order.selected_orders', compact('orders'));
    }
    


    public function saveSelected(Request $request)
    {
      // save & continue.. 
        // Validate the input data
        $validatedData = $request->validate([
            'orders.*.quantity' => 'required|integer|min:0',
            'orders.*.purchase_price' => 'required|numeric|min:0',
            'orders.*.order_no' => 'required|string',
            'seller_info.seller_name' => 'required|string|max:255',
            'seller_info.seller_address' => 'required|string|max:255',
            'seller_info.seller_gstin' => 'required|string|max:15',
            'seller_info.seller_phone' => 'required|string|max:15',
        ], [
            'orders.*.quantity.required' => 'Quantity is required for each item.',
            'orders.*.quantity.integer' => 'Quantity must be a valid number.',
            'orders.*.purchase_price.required' => 'Purchase price is required for each item.',
            'orders.*.purchase_price.numeric' => 'Purchase price must be a valid number.',
            'orders.*.order_no.required' => 'Order number is required.',
            'seller_info.seller_name.required' => 'Seller name is required.',
            'seller_info.seller_address.required' => 'Seller address is required.',
            'seller_info.seller_gstin.required' => 'Seller GSTIN is required.',
            'seller_info.seller_phone.required' => 'Seller phone is required.',
        ]);
    
        $sellerId = null;  // Initialize a variable to store the seller ID
        $productInfo = [];   // Initialize an array to collect product information
        $orderNumbers = [];  // Initialize an array to collect order numbers
    
        // Loop through the orders to save the selected items
        foreach ($request->input('orders') as $orderId => $orderData) {
            $partNo = $orderData['part_no'];
            $quantity = $orderData['quantity'];
            $purchasePrice = $orderData['purchase_price']; // Get the purchase price from the request
            $currentSellerId = $orderData['seller_id'];  // Get the seller_id from the request
            $orderNo = $orderData['order_no']; // Get the order_no from the request
            $orderDate =  $orderData['order_date']; // Format the order date to d/m/y
            $age =  $orderData['age'];
    
            // Set the seller ID if it's not already set
            if (!$sellerId) {
                $sellerId = $currentSellerId;
            }
    
            // Update the purchase price in the products table using the part_no
            DB::table('products')
                ->where('part_no', $partNo)
                ->update(['purchase_price' => $purchasePrice]);
    
            // Concatenate the order_no with the formatted order_date
            $orderNoWithDate = $orderNo . " ($orderDate)";
    
            // Collect product information in JSON format
            $productInfo[] = [
                'part_no' => $partNo,
                'qty' => $quantity,
                'order_no' => $orderNoWithDate, // Include the concatenated order number in the product_info JSON
                'age'=>$age
            ];
    
            // Collect the order number with the date
            $orderNumbers[] = $orderNoWithDate;
        }
    
        // Fetch the last purchase order number from the database
        $lastOrder = DB::table('final_purchase_order')
            ->orderBy('id', 'desc')
            ->first();
    
        if ($lastOrder) {
            // Extract the number from the last purchase order number
            $lastOrderNumber = intval(substr($lastOrder->purchase_order_no, 3));
            $newOrderNumber = $lastOrderNumber + 1;
        } else {
            // Start from 1 if no purchase orders exist
            $newOrderNumber = 1;
        }
    
        // Format the new purchase order number with leading zeros (e.g., po-001)
        $purchaseOrderNo = 'po-' . str_pad($newOrderNumber, 3, '0', STR_PAD_LEFT);
    
        // Convert the order numbers to a comma-separated string
        $orderNumbersString = implode(',', array_unique($orderNumbers));
    
        // Prepare the seller_info array
        $sellerInfo = [
            'seller_name' => $request->input('seller_info.seller_name'),
            'seller_address' => $request->input('seller_info.seller_address'),
            'seller_gstin' => $request->input('seller_info.seller_gstin'),
            'seller_phone' => $request->input('seller_info.seller_phone'),
        ];
    
        // Prepare the data to be inserted into the final_purchase_order table
        $data = [
            'purchase_order_no' => $purchaseOrderNo,  // Use the newly generated purchase order number
            'order_no' => $orderNumbersString,  // Store the comma-separated order numbers with dates
            'date' => now()->format('Y-m-d'),  // Get the current date
            'seller_id' => $sellerId,  // Store seller_id in the 'seller_id' field
            'product_info' => json_encode($productInfo),  // Convert the product info to JSON
            'seller_info' => json_encode($sellerInfo),  // Convert the seller info to JSON
            'created_at' => now(),
            'updated_at' => now(),
        ];
    
        // Insert the data into the final_purchase_order table
        DB::table('final_purchase_order')->insert($data);
    
        $invoiceController = new InvoiceController();
        // $file_url = $invoiceController->purchase_order_pdf_invoice($purchaseOrderNo);
        // $file1_url = $invoiceController->packing_list_pdf_invoice($purchaseOrderNo);

        // echo $file1_url;
        // die();
        
        $fileUrls = [
          $invoiceController->purchase_order_pdf_invoice($purchaseOrderNo),
          $invoiceController->packing_list_pdf_invoice($purchaseOrderNo)
      ];
        
      $fileNames = ["Purchase Order", "Packing List"];
        
        $sellerPhone = DB::table('final_purchase_order')
          ->where('purchase_order_no', $purchaseOrderNo)
          ->value(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(seller_info, '$.seller_phone'))"));
         

        //Sending Whatsapp to ...
        $to = "+919894753728";
        $file_name = "Packing List";
        foreach ($fileUrls as $index => $fileUrl) {
                $templateData = [
                  'name' => 'purchase_order_template',
                  'language' => 'en_US',
                  'components' => [
                      [
                          'type' => 'header',
                          'parameters' => [
                              [
                                  'type' => 'document',
                                  'document' => [
                                      'link' => $fileUrl,
                                      'filename' => $fileNames[$index],
                                  ],
                              ],
                          ],
                      ],
                  ],
              ];

              $this->WhatsAppWebService = new WhatsAppWebService();
              // Send the template message using the WhatsApp web service
              $response1 = $this->WhatsAppWebService->sendTemplateMessage($to, $templateData);
        }
    
        // Store the PDF download URL in the session
        // session()->flash('pdf_download_url', $file_url);
    
        // Redirect back with a success message
        return redirect()->route('admin.purchase_order')->with('status', 'Purchase order saved successfully!');
    }
    
    

  


    
    public function showFinalizedOrders()
    {
        $orders = DB::table('final_purchase_order')
            ->join('sellers', 'final_purchase_order.seller_id', '=', 'sellers.id')
            ->join('users', 'sellers.user_id', '=', 'users.id')
            ->select(
                'final_purchase_order.*',
                'users.name as seller_name'
            )
            ->where('convert_to_purchase_status','=',0)
            ->get();

        // Decode the product_info JSON and retrieve product names
        foreach ($orders as $order) {
            $productInfo = json_decode($order->product_info, true);

            foreach ($productInfo as &$product) {
                // Get the product name based on the part number
                $productName = DB::table('products')
                    ->where('part_no', $product['part_no'])
                    ->value('name');

                $product['product_name'] = $productName;
            }

            $order->product_info = $productInfo;
        }

        // echo "<pre>";
        // print_r($orders);
        // die();

        return view('backend.purchase_order.finalized_purchase_order_listing', compact('orders'));
    }

    public function showProductInfo($id)
    {

      //supply order list
        // Fetch the purchase order by ID
        $order = DB::table('final_purchase_order')
            ->where('id', $id)
            ->first();

        // Decode the product info JSON
        $productInfo = json_decode($order->product_info, true);

        // echo "<pre>";
        // print_r($order);
        // die();

        // Fetch the seller information based on seller_id in the order
        $seller = DB::table('sellers')
            ->join('users', 'sellers.user_id', '=', 'users.id')
            ->where('sellers.id', $order->seller_id)
            ->select('sellers.id as seller_id', 'users.name as seller_name')
            ->first();

        // Fetch the product details for each part number
        foreach ($productInfo as &$product) {
            $productDetails = DB::table('products')
                ->where('part_no', $product['part_no'])
                ->select('name', 'purchase_price', 'hsncode')
                ->first();

            $product['product_name'] = $productDetails->name ?? 'Unknown';
            $product['purchase_price'] = $productDetails->purchase_price ?? 'N/A';
            $product['hsncode'] = $productDetails->hsncode ?? 'N/A';
        }
        
       
        
      
        // Pass the seller information and product information to the view
        return view('backend.purchase_order.product_info', compact('order', 'productInfo', 'seller'));
    }


    public function viewProducts($purchaseOrderNo)
    {
        // Retrieve the purchase order based on the purchase_order_no
        $order = DB::table('final_purchase_order')
            ->where('purchase_order_no', $purchaseOrderNo)
            ->first();

        // Decode the product info JSON
        $productInfo = json_decode($order->product_info, true);

        // Fetch additional product details if needed
        foreach ($productInfo as &$product) {
            $productDetails = DB::table('products')
                ->where('part_no', $product['part_no'])
                ->select('name', 'purchase_price', 'hsncode') // Adjust fields as needed
                ->first();

            $product['product_name'] = $productDetails->name ?? 'Unknown';
            $product['purchase_price'] = $productDetails->purchase_price ?? 'N/A';
            $product['hsncode'] = $productDetails->hsncode ?? 'N/A';
        }

        


        return view('backend.purchase_order.final_product_info', compact('order', 'productInfo'));
    }

    

    public function convertToPurchase(Request $request, $id)
    {
        // Validate the incoming request
        $validatedData = $request->validate([
            'seller_invoice_no' => 'required|string|max:255',
            'seller_invoice_date' => 'required|date',
            'products.*.hsncode' => 'required|string|max:255',
            'products.*.qty' => 'required|integer|min:0',
            'products.*.purchase_price' => 'required|numeric|min:0',
        ],[
            'seller_invoice_no.required' => "Seller Invoice Number is required.",
            'seller_invoice_date.required' => "Seller Invoice Date is required.",
            'products.*.hsncode.required' => "HSN Code is required for each product.",
            'products.*.qty.required' => "Quantity is required for each product.",
            'products.*.qty.integer' => "Quantity must be an integer.",
            'products.*.purchase_price.required' => "Purchase Price is required for each product.",
            'products.*.purchase_price.numeric' => "Purchase Price must be a valid number.",
        ]);

        // Get the product_info from the final_purchase_order table
        $order = DB::table('final_purchase_order')->where('id', $id)->first();
        $productInfo = json_decode($order->product_info, true);

        // Iterate through productInfo to delete items from purchase_order table
        foreach ($productInfo as $product) {
            $partNo = $product['part_no'];
            $orderNosWithDates = explode(',', $product['order_no']); // Split in case of multiple order numbers
            $qty = $product['qty']; // Quantity for the entire entry
            
            // Only proceed with deletion if qty is greater than 0
            if ($qty > 0) {
                foreach ($orderNosWithDates as $orderNoWithDate) {
                    // Extract the order number without the date part
                    if (preg_match('/(SO\/[^ ]+)/', trim($orderNoWithDate), $matches)) {
                        $orderNo = trim($matches[1]);

                        // Perform the deletion for the specific order_no and part_no
                        DB::table('purchase_order')
                            ->where('order_no', $orderNo)
                            ->where('part_no', $partNo)
                            ->delete();
                    }
                }
            }
        }

        // Initialize an array to collect updated product information
        $updatedProductInfo = [];

        // Iterate over the products from the request to update the product table and collect updated information
        foreach ($request->input('products') as $productData) {
            $partNo = $productData['part_no'];
            $qty = $productData['qty'];
            $hsncode = $productData['hsncode'];
            $purchasePrice = $productData['purchase_price'];
            $orderNo = $productData['order_no']; // Get the order number
            $age = $productData['age']; // Get the age

            $sellerId = $request->input('seller_id');
            $purchaseOrderNo = $request->input('purchase_order_no');

            // Update the product table with the new HSN code and purchase price
            DB::table('products')
                ->where('part_no', $partNo)
                ->update([
                    'hsncode' => $hsncode,
                    'purchase_price' => $purchasePrice,
                ]);

            // Collect updated product information
            $updatedProductInfo[] = [
                'part_no' => $partNo,
                'qty' => $qty,
                'order_no' => $orderNo, // Include the order number in the product info
                'age' => $age // Include the age in the product info
            ];
        }

        // Fetch the last purchase_no from the database
        $lastPurchase = DB::table('final_purchase')
            ->orderBy('id', 'desc')
            ->first();

        if ($lastPurchase) {
            // Extract the number from the last purchase_no
            $lastPurchaseNumber = intval(substr($lastPurchase->purchase_no, 3));
            $newPurchaseNumber = $lastPurchaseNumber + 1;
        } else {
            // Start from 1 if no purchase records exist
            $newPurchaseNumber = 1;
        }

        // Format the new purchase_no with leading zeros (e.g., pn-001)
        $purchaseNo = 'pn-' . str_pad($newPurchaseNumber, 3, '0', STR_PAD_LEFT);

        $sellerInfo = json_decode($order->seller_info, true);

        // Prepare data to be inserted into the final_purchase table
        $data = [
            'purchase_no' => $purchaseNo,
            'purchase_order_no' => $purchaseOrderNo,
            'seller_id' => $sellerId,
            'seller_invoice_no' => $request->input('seller_invoice_no'),  // Use the provided seller invoice number
            'seller_invoice_date' => $request->input('seller_invoice_date'), // Use the provided seller invoice date
            'seller_info' => json_encode($sellerInfo), // Insert seller info
            'product_info' => json_encode($updatedProductInfo), // Insert updated product info
            'created_at' => now(),
            'updated_at' => now(),
        ];

        // Insert data into the final_purchase table
        DB::table('final_purchase')->insert($data);

        // Update the final_purchase_order table with the updated product information and convert_to_purchase_status
        DB::table('final_purchase_order')
            ->where('id', $id)
            ->update([
                'convert_to_purchase_status' => 1,
                'product_info' => json_encode($updatedProductInfo), // Update product info in final_purchase_order table as well
            ]);

        // Return success message
        return redirect()->route('finalized.purchase.orders')->with('status', 'Purchase order converted successfully!');
    }


    public function showFinalizedPurchaseOrders()
    {
      $purchases = DB::table('final_purchase')
      ->join('final_purchase_order', 'final_purchase.purchase_order_no', '=', 'final_purchase_order.purchase_order_no')
      ->join('sellers', 'final_purchase.seller_id', '=', 'sellers.id')
      ->join('users', 'sellers.user_id', '=', 'users.id') // Join with users table
      ->select('final_purchase.*', 'final_purchase_order.product_info', 'users.name as seller_name') // Get seller name from users table
      ->get();

            // echo "<pre>";
            // print_r($purchases);
            // die();

        return view('backend.purchase_order.final_purchase_list', compact('purchases'));
    }




    public function showImportForm()
    {
        return view('backend.purchase_order.purchase_order_excel_import');
    }

    public function importExcel(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'excel_file' => 'required|file|mimes:xls,xlsx'
        ], ['excel_file' => "File is required"]);

        // Get the real path of the uploaded file
        $filePath = $request->file('excel_file');

        $tableName = 'purchase_order';

        try {
            // Attempt to import the file
            Excel::import(new ExternalPurchaseOrder($tableName), $filePath);

            // If no exception occurs, consider it a success
            return redirect()->back()->with('success', 'Data imported successfully!');
        } catch (Exception $e) {
            // If an exception occurs, handle it and return an error message
            return redirect()->back()->with('error', 'Data import failed: ' . $e->getMessage());
        }
    }

    public function export()
    {

      // $purchases=DB::table('final_purchase')
      // ->join('final_purchase_order', 'final_purchase.purchase_order_no', '=', 'final_purchase_order.purchase_order_no')
      // ->join('sellers', 'final_purchase.seller_id', '=', 'sellers.id')
      // ->join('users', 'sellers.user_id', '=', 'users.id')
      // ->select(
      //     'final_purchase.purchase_no',
      //     'final_purchase.purchase_order_no',
      //     'users.name as seller_name',
      //     'final_purchase.seller_invoice_no',
      //     'final_purchase.seller_invoice_date',
      //     DB::raw('JSON_UNQUOTE(JSON_EXTRACT(product_info, "$[*].part_no")) as part_no'),
      //     DB::raw('JSON_UNQUOTE(JSON_EXTRACT(product_info, "$[*].qty")) as quantity')
      // )
      // ->orderBy('final_purchase.created_at', 'desc')->get();
      //      echo "<pre>";

      //      print_r($purchases);
      //      return;
        return Excel::download(new FinalPurchaseExport, 'final_purchases.xlsx');
    }

  //purchase order code end
}