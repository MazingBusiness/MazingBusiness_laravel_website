<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use App\Models\Order;
use App\Models\OrderApproval;
use App\Models\Upload;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class PurchaseHistoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $orders = Order::where('user_id', Auth::user()->id)->orderBy('code', 'desc')->paginate(9);
        foreach ($orders as $key => $value) {            
            $ordersApprovalCount = OrderApproval::where('code', $value->code)->count();
            if ($ordersApprovalCount > 0) {
                $ordersApproval = OrderApproval::where('code', $value->code)->first();
                $value->approved = true;
                $details = $ordersApproval->details;
                if (substr($details, 0, 1) !== '[') {
                    $details = '[' . $details;
                }
                if (substr($details, -1) !== ']') {
                    $details = $details . ']';
                }                
                $detailsData = json_decode($details, true);
                $bill_amount = 0.0;
                // foreach($detailsData as $odKey=>$odValue){
                //     $bill_amount = $bill_amount + (float)$odValue['bill_amount'];
                // }                
                $value->bill_amount = $bill_amount;
                $value->order_details = $detailsData;
            } else {
                $value->approved = false;
                $value->bill_amount = "";
                $value->order_details = "";
            }
        }
        // echo "<pre>";print_r($orders);die;
        return view('frontend.user.purchase_history', compact('orders'));
    }

    public function digital_index()
    {
        $orders = DB::table('orders')
                        ->orderBy('code', 'desc')
                        ->join('order_details', 'orders.id', '=', 'order_details.order_id')
                        ->join('products', 'order_details.product_id', '=', 'products.id')
                        ->where('orders.user_id', Auth::user()->id)
                        ->where('products.digital', '1')
                        ->where('order_details.payment_status', 'paid')
                        ->select('order_details.id')
                        ->paginate(15);
        return view('frontend.user.digital_purchase_history', compact('orders'));
    }

    public function purchase_history_details($id)
    {
        $order = Order::findOrFail(decrypt($id));
        $order->delivery_viewed = 1;
        $order->payment_status_viewed = 1;
        $order->save();
        $ordersApprovalCount = OrderApproval::where('code', $order->code)->count();
        if ($ordersApprovalCount > 0) {
            $ordersApproval = OrderApproval::where('code', $order->code)->first();
            $details = $ordersApproval->details;
            if (substr($details, 0, 1) !== '[') {
                $details = '[' . $details;
            }
            if (substr($details, -1) !== ']') {
                $details = $details . ']';
            }                
            $detailsData = json_decode($details, true);
            $bill_amount = 0.0;
            foreach($detailsData as $odKey=>$odValue){
                $bill_amount = $bill_amount + (float)$odValue['bill_amount'];
                $productDetails = Product::where('part_no',$odValue['part_no'])->first();
                $detailsData[$odKey]['slug'] = $productDetails->slug;
                $detailsData[$odKey]['product_id'] = $productDetails->id;
            }                
            $order->bill_amount = $bill_amount;
            $order->order_details = $detailsData;
        } else {
            $order->bill_amount = "";
            $order->order_details = array();
        }
        // echo "<pre>";print_r($order);die;
        return view('frontend.user.order_details_customer', compact('order'));
    }

    public function download(Request $request)
    {
        $product = Product::findOrFail(decrypt($request->id));
        $downloadable = false;
        foreach (Auth::user()->orders as $key => $order) {
            foreach ($order->orderDetails as $key => $orderDetail) {
                if ($orderDetail->product_id == $product->id && $orderDetail->payment_status == 'paid') {
                    $downloadable = true;
                    break;
                }
            }
        }
        if ($downloadable) {
            $upload = Upload::findOrFail($product->file_name);
            if (env('FILESYSTEM_DRIVER') == "s3") {
                return \Storage::disk('s3')->download($upload->file_name, $upload->file_original_name . "." . $upload->extension);
            } else {
                if (file_exists(base_path('public/' . $upload->file_name))) {
                    return response()->download(base_path('public/' . $upload->file_name));
                }
            }
        } else {
            flash(translate('You cannot download this product at this product.'))->success();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function order_cancel($id)
    {
        $order = Order::where('id', $id)->where('user_id', auth()->user()->id)->first();
        if($order && ($order->delivery_status == 'pending' && $order->payment_status == 'unpaid')) {
            $order->delivery_status = 'cancelled';
            $order->save();

            foreach ($order->orderDetails as $key => $orderDetail) {
                $orderDetail->delivery_status = 'cancelled';
                $orderDetail->save();
                product_restock($orderDetail);
            }

            flash(translate('Order has been canceled successfully'))->success();
        } else {
            flash(translate('Something went wrong'))->error();
        }

        return back();
    }

    // Statement

    public function statement()
    {
        $orders = Order::where('user_id', Auth::user()->id)->orderBy('code', 'desc')->paginate(9);
        foreach ($orders as $key => $value) {
            
            $ordersApprovalCount = OrderApproval::where('code', $value->code)->count();
            if ($ordersApprovalCount > 0) {
                // $ordersApproval = OrderApproval::where('code', $value->code)->first();
                // $details = $ordersApproval->details;
                // if (substr($details, 0, 1) !== '[') {
                //     $details = '[' . $details;
                // }
                // if (substr($details, -1) !== ']') {
                //     $details = $details . ']';
                // }
                // $detailsData = json_decode($details, true);
                // $value->approved = true;
                // $value->bill_amount = $detailsData['bill_amount'];

                $ordersApproval = OrderApproval::where('code', $value->code)->first();
                $details = $ordersApproval->details;
                if (substr($details, 0, 1) !== '[') {
                    $details = '[' . $details;
                }
                if (substr($details, -1) !== ']') {
                    $details = $details . ']';
                }                
                $detailsData = json_decode($details, true);
                $bill_amount = 0.0;
                foreach($detailsData as $odKey=>$odValue){
                    $bill_amount = $bill_amount + (float)$odValue['bill_amount'];
                    $productDetails = Product::where('part_no',$odValue['part_no'])->first();
                    $detailsData[$odKey]['slug'] = $productDetails->slug;
                    $detailsData[$odKey]['product_id'] = $productDetails->id;
                }                
                $value->bill_amount = $bill_amount;
                $value->order_details = $detailsData;
            } else {
                $value->approved = false;
                $value->bill_amount = "";
            }
        }
        return view('frontend.user.statement', compact('orders'));
    }
    public function statement_details($party_code = "")
    {
        $party_code = decrypt($party_code);
        $headers = [
            'authtoken' => '65d448afc6f6b',
        ];        
        $body = [
            'party_code' => $party_code,
            'from_date' => '2022-01-01',
            'to_date' => '2024-06-30',
        ];
        \Log::info('Sending request to API', [
            'url' => 'https://saleszing.info/itaapi/getclientstatement.php',
            'headers' => $headers,
            'body' => $body
        ]);        
        $response = Http::withHeaders($headers)->post('https://saleszing.info/itaapi/getclientstatement.php', $body);        
        \Log::info('Received response from API', [
            'status' => $response->status(),
            'body' => $response->body()
        ]);

        if ($response->successful()) {
            $getData = $response->json();
            $getData = $getData['data'];
            $openingBalance = "0";
            $closingBalance = "0";
            $openDrOrCr = "";
            $drBalance = "0";
            $crBalance = "0";
            foreach($getData as $gKey=>$gValue){
                //echo "<pre>";print_r($gValue);
                if($gValue['ledgername'] == "Opening"){
                    if($gValue['dramount'] != "0.00"){
                        $openingBalance = $gValue['dramount'];
                        $openDrOrCr = "Dr";
                    }else{
                        $openingBalance = $gValue['cramount'];
                        $openDrOrCr = "Cr";
                    }
                }else{
                    if($gValue['dramount'] != "0.00"){
                        $drBalance = $gValue['dramount'];
                    }else{
                        $crBalance = $gValue['cramount'];
                    }
                }
            }
            $closingBalance = ($openingBalance + $drBalance) - $crBalance;
            
            return view('frontend.user.statement_details', compact('getData','openingBalance','closingBalance'));
        } else {
            return response()->json(['error' => 'Failed to fetch data'], $response->status());
        }
        
    }
}
