<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AffiliateController;
use App\Mail\InvoiceEmailManager;
use App\Models\Address;
use App\Models\Cart;
use App\Models\CombinedOrder;
use App\Models\Coupon;
use App\Models\CouponUsage;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\Product;
use App\Models\Pincode;
use App\Models\ProductWarehouse;
use App\Models\SmsTemplate;
use App\Models\User;
use App\Models\Warehouse;
use App\Utility\NotificationUtility;
use App\Utility\SmsUtility;
use App\Utility\WhatsAppUtility;
use Auth;
use CoreComponentRepository;

use Illuminate\Support\Facades\Route;
use Mail;
use PDF;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;

class OrderController extends Controller {

  public function __construct() {
    // Staff Permission Check
    $this->middleware(['permission:view_all_orders|view_inhouse_orders|view_seller_orders|view_pickup_point_orders'])->only('all_orders');
    $this->middleware(['permission:view_order_details'])->only('show');
    $this->middleware(['permission:delete_order'])->only('destroy');
  }

  // All Orders
  public function all_orders(Request $request) {
    CoreComponentRepository::instantiateShopRepository();

    $date            = $request->date;
    $sort_search     = null;
    $delivery_status = null;
    $payment_status  = '';

    $orders        = Order::orderBy('id', 'desc');
    $admin_user_id = User::where('user_type', 'admin')->first()->id;

    if (
      Route::currentRouteName() == 'inhouse_orders.index' &&
      Auth::user()->can('view_inhouse_orders')
    ) {
      $orders = $orders->where('orders.seller_id', '=', $admin_user_id);
    } else if (
      Route::currentRouteName() == 'seller_orders.index' &&
      Auth::user()->can('view_seller_orders')
    ) {
      $orders = $orders->where('orders.seller_id', '!=', $admin_user_id);
    } else if (
      Route::currentRouteName() == 'pick_up_point.index' &&
      Auth::user()->can('view_pickup_point_orders')
    ) {
      $orders->where('shipping_type', 'pickup_point')->orderBy('code', 'desc');
      if (
        Auth::user()->user_type == 'staff' &&
        Auth::user()->staff->pick_up_point != null
      ) {
        $orders->where('shipping_type', 'pickup_point')
          ->where('pickup_point_id', Auth::user()->staff->pick_up_point->id);
      }
    } else if (
      Route::currentRouteName() == 'all_orders.index' &&
      Auth::user()->can('view_all_orders')
    ) {
    } else {
      abort(403);
    }

    if ($request->search) {
      $sort_search = $request->search;
      $orders      = $orders->where('code', 'like', '%' . $sort_search . '%');
    }
    if ($request->payment_status != null) {
      $orders         = $orders->where('payment_status', $request->payment_status);
      $payment_status = $request->payment_status;
    }
    if ($request->delivery_status != null) {
      $orders          = $orders->where('delivery_status', $request->delivery_status);
      $delivery_status = $request->delivery_status;
    }
    if ($date != null) {
      $orders = $orders->where('created_at', '>=', date('Y-m-d', strtotime(explode(" to ", $date)[0])) . '  00:00:00')
        ->where('created_at', '<=', date('Y-m-d', strtotime(explode(" to ", $date)[1])) . '  23:59:59');
    }
    $orders = $orders->paginate(15);
    return view('backend.sales.index', compact('orders', 'sort_search', 'payment_status', 'delivery_status', 'date'));
  }

  public function show($id) {
    $order                  = Order::findOrFail(decrypt($id));
    $order_shipping_address = json_decode($order->shipping_address);
    $delivery_boys          = User::where('city', $order_shipping_address->city)
      ->where('user_type', 'delivery_boy')
      ->get();

    $order->viewed = 1;
    $order->save();
    return view('backend.sales.show', compact('order', 'delivery_boys'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create() {
    //
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param \Illuminate\Http\Request $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request) {

   
    $carts = Cart::where('user_id', Auth::user()->id)->get();
    if ($carts->isEmpty()) {
      flash(translate('Your cart is empty'))->warning();
      return redirect()->route('home');
    }else{
      flash(translate('working!'))->warning();
    }

    $address         = Address::where('id', $carts[0]['address_id'])->first();
    $pincode         = Pincode::where('pincode', $address->postal_code)->first();
    $shippingAddress = [];
    $address_id = null;
    if ($address != null) {
      $address_id = $address->id;
      $shippingAddress['name']         = Auth::user()->name;
      $shippingAddress['company_name'] = Auth::user()->company_name;
      $shippingAddress['gstin']        = Auth::user()->gstin;
      $shippingAddress['email']        = Auth::user()->email;
      $shippingAddress['address']      = $address->address;
      $shippingAddress['country']      = $address->country->name;
      $shippingAddress['state']        = $address->state->name;
      //$shippingAddress['city']         = $address->city->name;
      $shippingAddress['city']         = $pincode->city;
      $shippingAddress['postal_code']  = $address->postal_code;
      $shippingAddress['phone']        = $address->phone; 
      if ($address->latitude || $address->longitude) {
        $shippingAddress['lat_lang'] = $address->latitude . ',' . $address->longitude;
      }
    }

    $combined_order                   = new CombinedOrder;
    $combined_order->user_id          = Auth::user()->id;
    $combined_order->shipping_address = json_encode($shippingAddress);
    $combined_order->save();

    

    

    // $seller_products = array();
    // foreach ($carts as $cartItem) {
    //   $product_ids       = array();
    //   $product           = Product::find($cartItem['product_id']);
    //   $stocks            = $product->stocks;
    //   $user_warehouse_id = Auth::user()->warehouse_id;
    //   $ordered_quantity  = $cartItem['quantity'];
    //   $newitem           = $cartItem->toArray();
      
    //   $newitem['order_type'] = 'warehouse';
    //   if ($ordered_quantity) {
    //     // $warehouse = Warehouse::find($user_warehouse_id);
    //     // foreach ($warehouse->markup as $wamarkup) {
    //     //   $product_ids = array();
    //     //   if ($ordered_quantity <= 0) {
    //     //     break;
    //     //   }
    //     //   $p_stock = $stocks->where('warehouse_id', $wamarkup['warehouse_id'])->first();
    //     //   if ($p_stock && $p_stock->qty) {
    //     //     if ($ordered_quantity <= $p_stock->qty) {
    //     //       $newitem['quantity'] = $ordered_quantity;
    //     //       $ordered_quantity    = 0;
    //     //       if (isset($seller_products[$wamarkup['warehouse_id']])) {
    //     //         $product_ids = $seller_products[$wamarkup['warehouse_id']];
    //     //       }
    //     //       array_push($product_ids, $newitem);
    //     //       $seller_products[$wamarkup['warehouse_id']] = $product_ids;
    //     //     } else {
    //     //       $newitem['quantity'] = $p_stock->qty;
    //     //       $ordered_quantity -= $p_stock->qty;
    //     //       if (isset($seller_products[$wamarkup['warehouse_id']])) {
    //     //         $product_ids = $seller_products[$wamarkup['warehouse_id']];
    //     //       }
    //     //       array_push($product_ids, $newitem);
    //     //       $seller_products[$wamarkup['warehouse_id']] = $product_ids;
    //     //     }
    //     //   }
    //     array_push($product_ids, $newitem);
    //     $seller_products[1] = $product_ids;
    //     // }
    //   }
    //   // $newitem['order_type'] = 'seller';
    //   // if ($ordered_quantity) {
    //   //   if ($same_warehouse_stock) {
    //   //     if ($same_warehouse_stock->seller_stock) {
    //   //       if ($ordered_quantity <= $same_warehouse_stock->seller_stock) {
    //   //         $ordered_quantity = 0;
    //   //         if (isset($seller_products[$user_warehouse_id])) {
    //   //           $product_ids = $seller_products[$user_warehouse_id];
    //   //         }
    //   //         array_push($product_ids, $newitem);
    //   //         $seller_products[$user_warehouse_id] = $product_ids;
    //   //       } else {
    //   //         $newitem['quantity'] = $same_warehouse_stock->seller_stock;
    //   //         $ordered_quantity -= $same_warehouse_stock->seller_stock;
    //   //         if (isset($seller_products[$user_warehouse_id])) {
    //   //           $product_ids = $seller_products[$user_warehouse_id];
    //   //         }
    //   //         array_push($product_ids, $newitem);
    //   //         $seller_products[$user_warehouse_id] = $product_ids;
    //   //       }
    //   //     }
    //   //   }
    //   //   if ($ordered_quantity) {
    //   //     $warehouse = Warehouse::find($user_warehouse_id);
    //   //     foreach ($warehouse->markup as $wamarkup) {
    //   //       $product_ids = array();
    //   //       if ($ordered_quantity <= 0) {
    //   //         break;
    //   //       }
    //   //       $p_stock = $stocks->where('warehouse_id', $wamarkup['warehouse_id'])->first();
    //   //       if ($p_stock && $p_stock->seller_stock) {
    //   //         if ($ordered_quantity <= $p_stock->seller_stock) {
    //   //           $newitem['quantity'] = $ordered_quantity;
    //   //           $ordered_quantity    = 0;
    //   //           if (isset($seller_products[$wamarkup['warehouse_id']])) {
    //   //             $product_ids = $seller_products[$wamarkup['warehouse_id']];
    //   //           }
    //   //           array_push($product_ids, $newitem);
    //   //           $seller_products[$wamarkup['warehouse_id']] = $product_ids;
    //   //         } else {
    //   //           $newitem['quantity'] = $p_stock->seller_stock;
    //   //           $ordered_quantity -= $p_stock->seller_stock;
    //   //           if (isset($seller_products[$wamarkup['warehouse_id']])) {
    //   //             $product_ids = $seller_products[$wamarkup['warehouse_id']];
    //   //           }
    //   //           array_push($product_ids, $newitem);
    //   //           $seller_products[$wamarkup['warehouse_id']] = $product_ids;
    //   //         }
    //   //       }
    //   //     }
    //   //   }
    //   // }

    // }

    // foreach ($seller_products as $warehouse_id => $seller_product) {
    //   $order                    = new Order;
    //   $order->combined_order_id = $combined_order->id;
    //   $order->user_id           = Auth::user()->id;
    //   $order->shipping_address  = $combined_order->shipping_address;

    //   $order->additional_info = $request->additional_info;

    //   //======== Closed By Kiron ==========
    //   // $order->shipping_type = $carts[0]['shipping_type'];
    //   // if ($carts[0]['shipping_type'] == 'pickup_point') {
    //   //     $order->pickup_point_id = $cartItem['pickup_point'];
    //   // }
    //   // if ($carts[0]['shipping_type'] == 'carrier') {
    //   //     $order->carrier_id = $cartItem['carrier_id'];
    //   // }

    //   $order->payment_type          = $request->payment_option;
    //   $order->delivery_viewed       = '0';
    //   $order->payment_status_viewed = '0';
    //   $order->code                  = date('Ymd-His') . rand(10, 99);
    //   $order->date                  = strtotime('now');
    //   $order->save();

    //   $subtotal        = 0;
    //   $tax             = 0;
    //   $shipping        = 0;
    //   $coupon_discount = 0;

    //   //Order Details Storing
    //   foreach ($seller_product as $cartItem) {
    //     $product = Product::find($cartItem['product_id']);
    //     if ($cartItem['is_carton']) {
    //       $subtotal += cart_product_price($cartItem, $product, false, false) * ($cartItem['quantity'] * qty_per_carton($product));
    //       $tax += cart_product_tax($cartItem, $product, false) * ($cartItem['quantity'] * qty_per_carton($product));
    //     } else {
    //       $subtotal += cart_product_price($cartItem, $product, false, false) * $cartItem['quantity'];
    //       $tax += cart_product_tax($cartItem, $product, false) * $cartItem['quantity'];
    //     }
    //     $coupon_discount += $cartItem['discount'];
    //     $product_variation = $cartItem['variation'];

    //     $quantity = $product->stocks->sum('qty') + $product->stocks->sum('seller_stock');
    //     if ($cartItem['quantity'] > $quantity) {
    //       flash(translate('The requested quantity is not available for ') . $product->getTranslation('name'))->warning();
    //       $order->delete();
    //       return redirect()->route('cart')->send();
    //     }
    //     $product_stock = $product->stocks->where('warehouse_id', $warehouse_id)->first();
    //     if ($cartItem['order_type'] == 'warehouse') {
    //       $product_stock->qty -= $cartItem['quantity'];
    //     } else {
    //       $product_stock->seller_stock -= $cartItem['quantity'];
    //     }
    //     $product_stock->save();

    //     $order_detail           = new OrderDetail;
    //     $order_detail->order_id = $order->id;
    //     if ($cartItem['order_type'] == 'warehouse') {
    //       $order_detail->order_type              = 'warehouse';
    //       $order_detail->og_product_warehouse_id = $product_stock->id;
    //       $order_detail->product_warehouse_id    = $product_stock->id;
    //       $order_detail->seller_id               = $product_stock->seller_id;
    //     } else {
    //       $order_detail->order_type              = 'seller';
    //       $order_detail->og_product_warehouse_id = $product_stock->id;
    //       $order_detail->product_warehouse_id    = $product_stock->id;
    //       $order_detail->seller_id               = $order->seller_id               = $product_stock->seller_id;
    //     }
    //     $order_detail->product_id            = $product->id;
    //     $order_detail->variation             = $product_variation;
    //     $order_detail->price                 = cart_product_price($cartItem, $product, false, false) * $cartItem['quantity'];
    //     $order_detail->tax                   = cart_product_tax($cartItem, $product, false) * $cartItem['quantity'];
    //     $order_detail->shipping_type         = $cartItem['shipping_type'];
    //     $order_detail->product_referral_code = $cartItem['product_referral_code'];
    //     $order_detail->shipping_cost         = $cartItem['shipping_cost'];

    //     $shipping += $order_detail->shipping_cost;
    //     //End of storing shipping cost

    //     $order_detail->quantity = $cartItem['quantity'];

    //     if (addon_is_activated('club_point')) {
    //       $order_detail->earn_point = $product->earn_point;
    //     }

    //     $order_detail->save();

    //     $product->num_of_sale += $cartItem['quantity'];
    //     $product->save();

    //     //======== Added By Kiron ==========
    //     $order->shipping_type = $cartItem['shipping_type'];
    //     if ($cartItem['shipping_type'] == 'pickup_point') {
    //       $order->pickup_point_id = $cartItem['pickup_point'];
    //     }
    //     if ($cartItem['shipping_type'] == 'carrier') {
    //       $order->carrier_id = $cartItem['carrier_id'];
    //     }

    //     if ($product->added_by == 'seller' && $product->user->seller != null) {
    //       $seller = $product->user->seller;
    //       $seller->num_of_sale += $cartItem['quantity'];
    //       $seller->save();
    //     }

    //     // if (addon_is_activated('affiliate_system')) {
    //     //   if ($order_detail->product_referral_code) {
    //     //     $referred_by_user = User::where('referral_code', $order_detail->product_referral_code)->first();

    //     //     $affiliateController = new AffiliateController;
    //     //     $affiliateController->processAffiliateStats($referred_by_user->id, 0, $order_detail->quantity, 0, 0);
    //     //   }
    //     // }
    //   }

    //   $order->grand_total = $subtotal + $tax + $shipping;

    //   // if ($seller_product[0]['coupon_code'] != null) {
    //     $order->coupon_discount = $coupon_discount;
    //     $order->grand_total -= $coupon_discount;
    //     $coupon_usage            = new CouponUsage;
    //     $coupon_usage->user_id   = Auth::user()->id;
    //     $coupon_usage->coupon_id = Coupon::where('code', $cartItem[0]['coupon_code'])->first()->id;
    //     $coupon_usage->save();
    //   // }
    //   $combined_order->grand_total += $order->grand_total;
    //   $order->save();
    // }

    $admin_items = array();

    $seller_products = array();
    foreach ($carts as $cartItem) {
        $product_ids = array();
        $product = Product::find($cartItem['product_id']);
        if (isset($seller_products[$product->user_id])) {
            $product_ids = $seller_products[$product->user_id];
        }
        array_push($product_ids, $cartItem);
        $seller_products[$product->user_id] = $product_ids;
    }
    
    foreach ($seller_products as $seller_product) {
      
      $order = new Order;
      $order->combined_order_id = $combined_order->id;
      $order->user_id = Auth::user()->id;
      $order->shipping_address = $combined_order->shipping_address;

      $order->additional_info = $request->additional_info;
      $order->address_id = $address_id;
      // $order->shipping_type = $carts[0]['shipping_type'];
      // if ($carts[0]['shipping_type'] == 'pickup_point') {
      //     $order->pickup_point_id = $cartItem['pickup_point'];
      // }
      // if ($carts[0]['shipping_type'] == 'carrier') {
      //     $order->carrier_id = $cartItem['carrier_id'];
      // }

      $order->payment_type = $request->payment_option;
      $order->delivery_viewed = '0';
      $order->payment_status_viewed = '0';
      $order->code = date('Ymd-His') . rand(10, 99);
      $order->date = strtotime('now');
      $order->save();

      $subtotal = 0;
      $tax = 0;
      $shipping = 0;
      $coupon_discount = 0;

      //Order Details Storing
      foreach ($seller_product as $cartItem) {
          $admin_items_line = array();

          $product = Product::find($cartItem['product_id']);
          if(session()->has('staff_id') AND (session()->get('staff_id')==180 OR session()->get('staff_id')==169 OR session()->get('staff_id')==25606)){
            $subtotal += $cartItem['price'] * $cartItem['quantity'];
            // $tax +=  $cartItem['price'] * $cartItem['quantity'];
            $tax +=  cart_product_tax($cartItem, $product, false, Auth::user()->id) * $cartItem['quantity'];
          }else{
            $subtotal += cart_product_price($cartItem, $product, false, false, Auth::user()->id) * $cartItem['quantity'];
            $tax +=  cart_product_tax($cartItem, $product, false, Auth::user()->id) * $cartItem['quantity'];
          }
          
          $coupon_discount += $cartItem['discount'];

          $product_variation = $cartItem['variation'];
            if($product_variation != ""){
              $product_stock = $product->stocks->where('variant', $product_variation)->first();
            if ($product->digital != 1 && isset($product_stock->qty) && $cartItem['quantity'] > $product_stock->qty && false) {
                flash(translate('The requested quantity is not available for ') . $product->getTranslation('name'))->warning();
                $order->delete();
                return redirect()->route('cart')->send();
            } elseif ($product->digital != 1) {
                // $product_stock->qty -= $cartItem['quantity'];
                $product_stock->save();
            }
          }
          

          $order_detail = new OrderDetail;
          $order_detail->order_id = $order->id;
          $order_detail->seller_id = $product->user_id;
          $order_detail->product_id = $product->id;
          $order_detail->variation = $product_variation;
          if(session()->has('staff_id') AND (session()->get('staff_id')==180 OR session()->get('staff_id')==169 OR session()->get('staff_id')==25606)){
            // $order_detail->tax = $cartItem['price'] * $cartItem['quantity'];
            $order_detail->tax = cart_product_tax($cartItem, $product, false,Auth::user()->id) * $cartItem['quantity'];
            $order_detail->price = $cartItem['price'] * $cartItem['quantity'];
          }else{
            $order_detail->tax = cart_product_tax($cartItem, $product, false,Auth::user()->id) * $cartItem['quantity'];
            $order_detail->price = cart_product_price($cartItem, $product, false, false,Auth::user()->id) * $cartItem['quantity'];
          }
          
          
          $order_detail->shipping_type = $cartItem['shipping_type'];
          $order_detail->product_referral_code = $cartItem['product_referral_code'];
          $order_detail->shipping_cost = $cartItem['shipping_cost'];

          $admin_items_line['name'] = $product->name;
          $admin_items_line['new_part_no'] = $product->alias_name;
          $admin_items_line['part_no'] = $product->part_no;
          if(session()->has('staff_id') AND (session()->get('staff_id')==180 OR session()->get('staff_id')==169 OR session()->get('staff_id')==25606)){
            $admin_items_line['net_price'] = $cartItem['price'];
          }else{
            $admin_items_line['net_price'] = cart_product_price($cartItem, $product, false, false, Auth::user()->id);
          }
          
          $admin_items_line['quantity'] = $cartItem['quantity'];

          $admin_items[] = $admin_items_line;

          $shipping += $order_detail->shipping_cost;
          //End of storing shipping cost

          $order_detail->quantity = $cartItem['quantity'];

          if (addon_is_activated('club_point')) {
              $order_detail->earn_point = $product->earn_point;
          }
          $order_detail->save();
          //echo "<pre>";print_r($order_detail);die;         

          $product->num_of_sale += $cartItem['quantity'];
          $product->save();

          $order->seller_id = $product->user_id;
          $order->shipping_type = $cartItem['shipping_type'];
          
          if ($cartItem['shipping_type'] == 'pickup_point') {
              $order->pickup_point_id = $cartItem['pickup_point'];
          }
          if ($cartItem['shipping_type'] == 'carrier') {
              $order->carrier_id = $cartItem['carrier_id'];
          }

          if ($product->added_by == 'seller' && $product->user->seller != null) {
              $seller = $product->user->seller;
              $seller->num_of_sale += $cartItem['quantity'];
              $seller->save();
          }

          if (addon_is_activated('affiliate_system')) {
              if ($order_detail->product_referral_code) {
                  $referred_by_user = User::where('referral_code', $order_detail->product_referral_code)->first();

                  $affiliateController = new AffiliateController;
                  $affiliateController->processAffiliateStats($referred_by_user->id, 0, $order_detail->quantity, 0, 0);
              }
          }
      }

      $order->grand_total = $subtotal  + $shipping;

      if ($seller_product[0]->coupon_code != null) {
          $order->coupon_discount = $coupon_discount;
          $order->grand_total -= $coupon_discount;

          $coupon_usage = new CouponUsage;
          $coupon_usage->user_id = Auth::user()->id;
          $coupon_usage->coupon_id = Coupon::where('code', $seller_product[0]->coupon_code)->first()->id;
          $coupon_usage->save();
      }

      $combined_order->grand_total += $order->grand_total;

      $order->save();
    }

    $user_mobile = substr(Auth::user()->phone, -10);
    $party_code = Auth::user()->old_party_code;

  

    $combined_order->save();
    
    // $order_detail                 = $order_detail->toArray();
    // $order_detail['product_name'] = Product::where('id', $order_detail['product_id'])->first('name');
    $order                        = Order::findOrFail($order_detail['order_id']);
    $font_family                  = "'Roboto','sans-serif'";
    $direction                    = 'ltr';
    $text_align                   = 'left';
    $not_text_align               = 'right';
    $config                       = [];
    $pdf                          = PDF::loadView('backend.invoices.proformainvoice', [
      'order'          => $order,
      'font_family'    => $font_family,
      'direction'      => $direction,
      'text_align'     => $text_align,
      'not_text_align' => $not_text_align,
    ], [], $config);

    // // Prepare the data for the API request
    //   $data = [
    //     "order_id" => $order->code,
    //     "client" => $user_mobile,
    //     "partycode" => $party_code,
    //     "discount" => "",
    //     "items" => $admin_items
    // ];
  
    // // Send the HTTP request to the API endpoint
    // try {
     
    //   $response = Http::post('https://admin.mazingbusiness.com/api/order.php', $data);
    //   // Handle the response as needed
    //   $responseData = $response->json(); // Assuming the response is JSON
    //   // dd($responseData); // Print the response data for debugging
    // } catch (\Exception $e) {
    //   // Handle exceptions if the request fails
    //   //dd($e->getMessage());
    // }

   
    $data = array();
    try {
      // $response = Http::post('https://mazingbusiness.com/api/?code='.$order->code, $data);    
      // // Handle the response as needed
      // $responseData = $response->json(); // Assuming the response is JSON

      // Push order data to Salezing
      $result=array();
      $result['code']= $order->code;
      $response = Http::withHeaders([
          'Content-Type' => 'application/json',
      ])->post('https://mazingbusiness.com/api/v2/order-push', $result);
      \Log::info('Salzing Order Push From Website Status: '  . json_encode($response->json(), JSON_PRETTY_PRINT));
      

    } catch (\Exception $e) {
      // Handle exceptions if the request fails
      //dd($e->getMessage());
    }
    // Send email
    // Mail::send('emails.order_placed', $order_detail, function ($message) use ($pdf, $order) {
      // $message->to('kburhanuddin12@gmail.com', 'Mazing Business')->subject('New Order has been placed on Mazing Business')->attachData($pdf->output(), 'order-' . $order->code . '.pdf');
      // $message->from(env('MAIL_FROM_ADDRESS'), 'Mazing Business');
    // });
    $request->session()->put('combined_order_id', $combined_order->id);
  }

  // public function store(Request $request)
  //   {
  //       $carts = Cart::where('user_id', Auth::user()->id)
  //           ->get();

  //       if ($carts->isEmpty()) {
  //           flash(translate('Your cart is empty'))->warning();
  //           return redirect()->route('home');
  //       }

  //       $address = Address::where('id', $carts[0]['address_id'])->first();

  //       $shippingAddress = [];
  //       if ($address != null) {
  //           $shippingAddress['name']        = Auth::user()->name;
  //           $shippingAddress['email']       = Auth::user()->email;
  //           $shippingAddress['address']     = $address->address;
  //           $shippingAddress['country']     = $address->country->name;
  //           $shippingAddress['state']       = $address->state->name;
  //           $shippingAddress['city']        = $address->city->name;
  //           $shippingAddress['postal_code'] = $address->postal_code;
  //           $shippingAddress['phone']       = $address->phone;
  //           if ($address->latitude || $address->longitude) {
  //               $shippingAddress['lat_lang'] = $address->latitude . ',' . $address->longitude;
  //           }
  //       }

  //       $combined_order = new CombinedOrder;
  //       $combined_order->user_id = Auth::user()->id;
  //       $combined_order->shipping_address = json_encode($shippingAddress);
  //       $combined_order->save();

  //       $seller_products = array();
  //       foreach ($carts as $cartItem) {
  //           $product_ids = array();
  //           $product = Product::find($cartItem['product_id']);
  //           if (isset($seller_products[$product->user_id])) {
  //               $product_ids = $seller_products[$product->user_id];
  //           }
  //           array_push($product_ids, $cartItem);
  //           $seller_products[$product->user_id] = $product_ids;
  //       }

  //       foreach ($seller_products as $seller_product) {
  //           $order = new Order;
  //           $order->combined_order_id = $combined_order->id;
  //           $order->user_id = Auth::user()->id;
  //           $order->shipping_address = $combined_order->shipping_address;

  //           $order->additional_info = $request->additional_info;

  //           // $order->shipping_type = $carts[0]['shipping_type'];
  //           // if ($carts[0]['shipping_type'] == 'pickup_point') {
  //           //     $order->pickup_point_id = $cartItem['pickup_point'];
  //           // }
  //           // if ($carts[0]['shipping_type'] == 'carrier') {
  //           //     $order->carrier_id = $cartItem['carrier_id'];
  //           // }

  //           $order->payment_type = $request->payment_option;
  //           $order->delivery_viewed = '0';
  //           $order->payment_status_viewed = '0';
  //           $order->code = date('Ymd-His') . rand(10, 99);
  //           $order->date = strtotime('now');
  //           $order->save();

  //           $subtotal = 0;
  //           $tax = 0;
  //           $shipping = 0;
  //           $coupon_discount = 0;

  //           //Order Details Storing
  //           foreach ($seller_product as $cartItem) {
  //               $product = Product::find($cartItem['product_id']);

  //               $subtotal += cart_product_price($cartItem, $product, false, false) * $cartItem['quantity'];
  //               $tax +=  cart_product_tax($cartItem, $product, false) * $cartItem['quantity'];
  //               $coupon_discount += $cartItem['discount'];

  //               $product_variation = $cartItem['variation'];

  //               $product_stock = $product->stocks->where('variant', $product_variation)->first();
  //               if ($product->digital != 1 && $cartItem['quantity'] > $product_stock->qty) {
  //                   flash(translate('The requested quantity is not available for ') . $product->getTranslation('name'))->warning();
  //                   $order->delete();
  //                   return redirect()->route('cart')->send();
  //               } elseif ($product->digital != 1) {
  //                   $product_stock->qty -= $cartItem['quantity'];
  //                   $product_stock->save();
  //               }

  //               $order_detail = new OrderDetail;
  //               $order_detail->order_id = $order->id;
  //               $order_detail->seller_id = $product->user_id;
  //               $order_detail->product_id = $product->id;
  //               $order_detail->variation = $product_variation;
  //               $order_detail->price = cart_product_price($cartItem, $product, false, false) * $cartItem['quantity'];
  //               $order_detail->tax = cart_product_tax($cartItem, $product, false) * $cartItem['quantity'];
  //               $order_detail->shipping_type = $cartItem['shipping_type'];
  //               $order_detail->product_referral_code = $cartItem['product_referral_code'];
  //               $order_detail->shipping_cost = $cartItem['shipping_cost'];

  //               $shipping += $order_detail->shipping_cost;
  //               //End of storing shipping cost

  //               $order_detail->quantity = $cartItem['quantity'];

  //               if (addon_is_activated('club_point')) {
  //                   $order_detail->earn_point = $product->earn_point;
  //               }
                
  //               $order_detail->save();

  //               $product->num_of_sale += $cartItem['quantity'];
  //               $product->save();

  //               $order->seller_id = $product->user_id;
  //               $order->shipping_type = $cartItem['shipping_type'];
                
  //               if ($cartItem['shipping_type'] == 'pickup_point') {
  //                   $order->pickup_point_id = $cartItem['pickup_point'];
  //               }
  //               if ($cartItem['shipping_type'] == 'carrier') {
  //                   $order->carrier_id = $cartItem['carrier_id'];
  //               }

  //               if ($product->added_by == 'seller' && $product->user->seller != null) {
  //                   $seller = $product->user->seller;
  //                   $seller->num_of_sale += $cartItem['quantity'];
  //                   $seller->save();
  //               }

  //               if (addon_is_activated('affiliate_system')) {
  //                   if ($order_detail->product_referral_code) {
  //                       $referred_by_user = User::where('referral_code', $order_detail->product_referral_code)->first();

  //                       $affiliateController = new AffiliateController;
  //                       $affiliateController->processAffiliateStats($referred_by_user->id, 0, $order_detail->quantity, 0, 0);
  //                   }
  //               }
  //           }

  //           $order->grand_total = $subtotal + $tax + $shipping;

  //           if ($seller_product[0]->coupon_code != null) {
  //               $order->coupon_discount = $coupon_discount;
  //               $order->grand_total -= $coupon_discount;

  //               $coupon_usage = new CouponUsage;
  //               $coupon_usage->user_id = Auth::user()->id;
  //               $coupon_usage->coupon_id = Coupon::where('code', $seller_product[0]->coupon_code)->first()->id;
  //               $coupon_usage->save();
  //           }

  //           $combined_order->grand_total += $order->grand_total;

  //           $order->save();
  //       }

  //       $combined_order->save();

  //       foreach($combined_order->orders as $order){
  //           NotificationUtility::sendOrderPlacedNotification($order);
  //       }

  //       $request->session()->put('combined_order_id', $combined_order->id);
  //   }

  /**
   * Display the specified resource.
   *
   * @param int $id
   * @return \Illuminate\Http\Response
   */

  /**
   * Show the form for editing the specified resource.
   *
   * @param int $id
   * @return \Illuminate\Http\Response
   */
  public function edit($id) {
    //
  }

  /**
   * Update the specified resource in storage.
   *
   * @param \Illuminate\Http\Request $request
   * @param int $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id) {
    //
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param int $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id) {
    $order = Order::findOrFail($id);
    if ($order != null) {
      foreach ($order->orderDetails as $key => $orderDetail) {
        try {

          $product_stock = ProductStock::where('product_id', $orderDetail->product_id)->where('variant', $orderDetail->variation)->first();
          if ($product_stock != null) {
            $product_stock->qty += $orderDetail->quantity;
            $product_stock->save();
          }
        } catch (\Exception $e) {
        }

        $orderDetail->delete();
      }
      $order->delete();
      flash(translate('Order has been deleted successfully'))->success();
    } else {
      flash(translate('Something went wrong'))->error();
    }
    return back();
  }

  public function bulk_order_delete(Request $request) {
    if ($request->id) {
      foreach ($request->id as $order_id) {
        $this->destroy($order_id);
      }
    }

    return 1;
  }

  public function order_details(Request $request) {
    $order = Order::findOrFail($request->order_id);
    $order->save();
    return view('seller.order_details_seller', compact('order'));
  }

  public function update_delivery_status(Request $request) {
    $order = Order::findOrFail($request->order_id);
    if ($request->status == 'on_the_way' && !$order->tracking_code) {
      return 0;
    }
    $order->delivery_viewed = '0';
    $order->delivery_status = $request->status;
    $order->save();

    if ($request->status == 'cancelled' && $order->payment_type == 'wallet') {
      $user = User::where('id', $order->user_id)->first();
      $user->balance += $order->grand_total;
      $user->save();
    }

    if (Auth::user()->user_type == 'seller') {
      foreach ($order->orderDetails->where('seller_id', Auth::user()->id) as $key => $orderDetail) {
        $orderDetail->delivery_status = $request->status;
        $orderDetail->save();
        if ($request->status == 'cancelled') {
          $variant = $orderDetail->variation;
          if ($orderDetail->variation == null) {
            $variant = '';
          }
          $product_stock = ProductWarehouse::where('product_id', $orderDetail->product_id)
            ->where('variant', $variant)
            ->first();
          if ($product_stock != null) {
            $product_stock->qty += $orderDetail->quantity;
            $product_stock->save();
          }
        }
      }
    } else {
      foreach ($order->orderDetails as $key => $orderDetail) {
        $orderDetail->delivery_status = $request->status;
        $orderDetail->save();
        if ($request->status == 'cancelled') {
          $variant = $orderDetail->variation;
          if ($orderDetail->variation == null) {
            $variant = '';
          }
          $product_stock = ProductWarehouse::where('product_id', $orderDetail->product_id)
            ->where('variant', $variant)
            ->first();
          if ($product_stock != null) {
            $product_stock->qty += $orderDetail->quantity;
            $product_stock->save();
          }
        }

        if (addon_is_activated('affiliate_system')) {
          if (($request->status == 'delivered' || $request->status == 'cancelled') &&
            $orderDetail->product_referral_code
          ) {

            $no_of_delivered = 0;
            $no_of_canceled  = 0;

            if ($request->status == 'delivered') {
              $no_of_delivered = $orderDetail->quantity;
            }
            if ($request->status == 'cancelled') {
              $no_of_canceled = $orderDetail->quantity;
            }

            $referred_by_user = User::where('referral_code', $orderDetail->product_referral_code)->first();

            $affiliateController = new AffiliateController;
            $affiliateController->processAffiliateStats($referred_by_user->id, 0, 0, $no_of_delivered, $no_of_canceled);
          }
        }
      }
    }
    if (addon_is_activated('otp_system')) {
      if ($order->delivery_status == 'confirmed') {
        WhatsAppUtility::orderConfirmed($order->user, $order);
      } elseif ($order->delivery_status == 'on_the_way') {
        WhatsAppUtility::orderShipped($order->user, $order);
      } elseif ($order->delivery_status == 'cancelled') {
        WhatsAppUtility::orderCancelled($order->user, $order);
      }
    }

    //sends Notifications to user
    NotificationUtility::sendNotification($order, $request->status);
    if (get_setting('google_firebase') == 1 && $order->user->device_token != null) {
      $request->device_token = $order->user->device_token;
      $request->title        = "Order updated !";
      $status                = str_replace("_", "", $order->delivery_status);
      $request->text         = " Your order {$order->code} has been {$status}";

      $request->type    = "order";
      $request->id      = $order->id;
      $request->user_id = $order->user->id;

      NotificationUtility::sendFirebaseNotification($request);
    }

    if (addon_is_activated('delivery_boy')) {
      if (Auth::user()->user_type == 'delivery_boy') {
        $deliveryBoyController = new DeliveryBoyController;
        $deliveryBoyController->store_delivery_history($order);
      }
    }

    return 1;
  }

  public function update_tracking_code(Request $request) {
    $order                = Order::findOrFail($request->order_id);
    $order->tracking_code = $request->tracking_code;
    $order->save();

    return 1;
  }

  public function update_payment_status(Request $request) {
    $order                        = Order::findOrFail($request->order_id);
    $order->payment_status_viewed = '0';
    $order->save();

    if (Auth::user()->user_type == 'seller') {
      foreach ($order->orderDetails->where('seller_id', Auth::user()->id) as $key => $orderDetail) {
        $orderDetail->payment_status = $request->status;
        $orderDetail->save();
      }
    } else {
      foreach ($order->orderDetails as $key => $orderDetail) {
        $orderDetail->payment_status = $request->status;
        $orderDetail->save();
      }
    }

    $order->payment_status = $status = $request->status;
    if ($order->payment_status == 'paid') {
      foreach ($order->orderDetails as $key => $orderDetail) {
        if ($orderDetail->payment_status != 'paid') {
          $status = 'unpaid';
        }
      }
      $latest_confirmed_order = Order::where('code', 'like', 'MZ%')->orderBy('created_at', 'desc')->orderBy('id', 'desc')->first();
      if ($latest_confirmed_order) {
        $code                   = explode('/', $latest_confirmed_order->code);
        $latest_confirmed_order = 'MZ/' . str_pad((((int) $code[1]) + 1), 5, '0', STR_PAD_LEFT) . '/' . (date('m') > 3 ? date('y') . '-' . ((int) date('y') + 1) : (int) date('y') - 1 . '-' . date('y'));
      } else {
        $latest_confirmed_order = 'MZ/00001/' . (date('m') > 3 ? date('y') . '-' . ((int) date('y') + 1) : (int) date('y') - 1 . '-' . date('y'));
      }
      $order->code = $latest_confirmed_order;
    }
    if ($order->payment_status == 'request-details') {
      $status = 'request-details';
    }
    $order->payment_status = $status;
    $order->save();

    if (
      $order->payment_status == 'paid' &&
      $order->commission_calculated == 0
    ) {
      calculateCommissionAffilationClubPoint($order);
    }

    //sends Notifications to user
    NotificationUtility::sendNotification($order, $request->status);
    if (get_setting('google_firebase') == 1 && $order->user->device_token != null && $status == 'paid') {
      $request->device_token = $order->user->device_token;
      $request->title        = "Order updated !";
      $status                = str_replace("_", "", $order->payment_status);
      $request->text         = " Your order {$order->code} has been {$status}";

      $request->type    = "order";
      $request->id      = $order->id;
      $request->user_id = $order->user->id;

      NotificationUtility::sendFirebaseNotification($request);
    }

    if (addon_is_activated('otp_system') && $status == 'paid') {
      WhatsAppUtility::paymentConfirmation($order->user, $order);
    }
    if (addon_is_activated('otp_system') && $order->payment_status == 'request-details') {
      WhatsAppUtility::requestPaymentConfirmation($order->user, $order);
    }
    return 1;
  }

  public function assign_delivery_boy(Request $request) {
    if (addon_is_activated('delivery_boy')) {

      $order                        = Order::findOrFail($request->order_id);
      $order->assign_delivery_boy   = $request->delivery_boy;
      $order->delivery_history_date = date("Y-m-d H:i:s");
      $order->save();

      $delivery_history = \App\Models\DeliveryHistory::where('order_id', $order->id)
        ->where('delivery_status', $order->delivery_status)
        ->first();

      if (empty($delivery_history)) {
        $delivery_history = new \App\Models\DeliveryHistory;

        $delivery_history->order_id        = $order->id;
        $delivery_history->delivery_status = $order->delivery_status;
        $delivery_history->payment_type    = $order->payment_type;
      }
      $delivery_history->delivery_boy_id = $request->delivery_boy;

      $delivery_history->save();

      if (env('MAIL_USERNAME') != null && get_setting('delivery_boy_mail_notification') == '1') {
        $array['view']    = 'emails.invoice';
        $array['subject'] = translate('You are assigned to delivery an order. Order code') . ' - ' . $order->code;
        $array['from']    = env('MAIL_FROM_ADDRESS');
        $array['order']   = $order;

        try {
          Mail::to($order->delivery_boy->email)->queue(new InvoiceEmailManager($array));
        } catch (\Exception $e) {
        }
      }

      if (addon_is_activated('otp_system') && SmsTemplate::where('identifier', 'assign_delivery_boy')->first()->status == 1) {
        try {
          SmsUtility::assign_delivery_boy($order->delivery_boy->phone, $order->code);
        } catch (\Exception $e) {
        }
      }
    }

    return 1;
  }

  public function updateStatus(Request $request)
  {
      // Retrieve input data from the request
      $party_code = $request->input('party_code');
      $code = $request->input('code');
      $status = $request->input('status');
      $details = $request->input('details');
      $timestamp = $request->input('timestamp');

      // Log the input data for debugging
      Log::info('Party Code: ' . $party_code);
      Log::info('Code: ' . $code);
      Log::info('Status: ' . $status);
      Log::info('Details: ' . json_encode($details));
      Log::info('Timestamp: ' . $timestamp);

      // Validate the input data
      $validator = \Validator::make($request->all(), [
          'party_code' => 'required|string',
          'code' => 'required|string',
          'status' => 'required|string',
          'details' => 'required|array',
          'timestamp' => 'required|date_format:Y-m-d H:i:s',
      ]);

      if ($validator->fails()) {
          return response()->json(['status' => 'Error', 'message' => $validator->errors()], 400);
      }

      // Convert details array to JSON string
      $detailsJson = json_encode($details);

      // Insert data into the database
      try {
          DB::table('order_approvals')->insert([
              'party_code' => $party_code,
              'code' => $code,
              'status' => $status,
              'details' => $detailsJson,
              'timestamp' => $timestamp,
          ]);

          return response()->json([
              'status' => 'Success',
              'message' => 'Order status updated successfully',
              'data' => [
                  'party_code' => $party_code,
                  'code' => $code,
                  'status' => $status,
                  'timestamp' => $timestamp,
              ],
          ]);

      } catch (\Exception $e) {
          return response()->json(['status' => 'Error', 'message' => 'Database error: ' . $e->getMessage()], 500);
      }
    }
}