<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Crypt;
use App\Models\Currency;
use App\Models\Language;
use App\Models\Order;
use App\Models\User;
use App\Models\Address;
use App\Models\Staff;
use App\Models\InvoiceOrderDetail;
use App\Models\InvoiceOrder;
use App\Models\OrderLogistic;
use Config;
use Hash;
use PDF;
use Session;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use App\Services\WhatsAppWebService;
use Illuminate\Support\Facades\Auth;
use App\Jobs\SendWhatsAppMessagesJob;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\BillsDataController;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\File;
use CoreComponentRepository;


class OrderLogisticsController extends Controller
{

    private function getManagerPhone($managerId)
    {
        $managerData = DB::table('users')
            ->where('id', $managerId)
            ->select('phone')
            ->first();

        return $managerData->phone ?? 'No Manager Phone';  // Default in case manager phone is not found
    }

   


public function index(Request $request)
{
    $allowedUserIds = [1, 180, 169, 25606];
    $user = auth()->user();
    $staffRoleId = \App\Models\Staff::where('user_id', $user->id)->value('role_id');

    if (!in_array($user->id, $allowedUserIds) && $staffRoleId != 4) {
        return abort(403, 'Unauthorized action.');
    }

    $search = $request->input('search');
    $sortField = $request->input('sort', 'id');
    $sortDirection = $request->input('direction', 'desc');
    $isDate = $search && strtotime($search);

    $cityMap = [
        'MUM' => 'Mumbai',
        'DEL' => 'Delhi',
        'KOL' => 'Kolkata',
    ];
    $cityCode = array_search(ucfirst(strtolower($search)), $cityMap);

    // Prepare subquery for invoice_orders
    $invoiceOrdersSub = DB::table('invoice_orders')
        ->select('id', 'invoice_no', 'created_at');
        

    // Main logistics query
    $logisticsData = DB::table('order_logistics as ol')
        ->join('addresses as addr', 'ol.party_code', '=', 'addr.acc_code')
        ->leftJoinSub($invoiceOrdersSub, 'io', function ($join) {
            $join->on(DB::raw('CONVERT(ol.invoice_no USING utf8mb4)'), '=', DB::raw('CONVERT(io.invoice_no USING utf8mb4)'));
        })
        ->whereIn('ol.id', function ($query) {
            $query->selectRaw('MAX(id)')
                ->from('order_logistics')
                ->groupBy('invoice_no');
        })
        ->select(
            'ol.id',
            'ol.invoice_no',
            'ol.lr_date',
            DB::raw('SUBSTRING_INDEX(ol.lr_no, " - ", 1) as transport_name'),
            'ol.lr_no',
            'ol.no_of_boxes',
            'ol.lr_amount',
            'ol.attachment',
            'addr.company_name',
            'io.created_at as invoice_date',
            'io.created_at as order_date'
        )
        ->whereNotNull('ol.invoice_no')
        ->where('ol.invoice_no', '!=', '')
        ->when($search === '.blank', function ($query) {
            $query->where(function ($subQuery) {
                $subQuery->whereNull('ol.attachment')
                         ->orWhere('ol.attachment', '');
            });
        }, function ($query) use ($search, $isDate, $cityCode) {
            if ($isDate) {
                $query->whereDate('ol.lr_date', $search);
            } elseif ($cityCode) {
                $query->where('ol.invoice_no', 'LIKE', "%{$cityCode}%");
            } elseif (stripos($search, '.pdf') !== false) {
                $query->where('ol.attachment', 'LIKE', '%.pdf%');
            } elseif (stripos($search, '.html') !== false) {
                $query->where('ol.attachment', 'LIKE', '%.html%');
            } elseif ($search) {
                $query->where(function ($subQuery) use ($search) {
                    $subQuery->where('ol.invoice_no', 'LIKE', "%{$search}%")
                             ->orWhere('addr.company_name', 'LIKE', "%{$search}%");
                });
            }
        })
        ->orderBy($sortField === 'invoice_date' ? 'io.created_at' : "ol.$sortField", $sortDirection)
        ->paginate(25)
        ->appends([
            'search' => $search,
            'sort' => $sortField,
            'direction' => $sortDirection
        ]);

    // Optional: Add place_of_dispatch dynamically
    $logisticsData->getCollection()->transform(function ($item) {
        $item->place_of_dispatch = $this->getCityName($item->invoice_no);
        return $item;
    });

    return view('backend.order_logistics.index', compact('logisticsData', 'search', 'sortField', 'sortDirection'));
}


   


    private function getCityName($invoice_id) {
        // Extract the city code from the invoice ID
        preg_match('/[A-Z]{3}/', $invoice_id, $matches);

        // Check if a match was found
        if (!empty($matches)) {
            $cityCode = $matches[0];

            // Map city codes to full city names
            $cityMap = [
                'MUM' => 'Mumbai',
                'DEL' => 'Delhi',
                'KOL' => 'Kolkata',
                // Add more city codes and names here if needed
            ];

            // Return the corresponding city name or a default message
            return $cityMap[$cityCode] ?? 'Unknown City';
        }

        return 'Invalid Dispatch ID';
    }

 public function getInvoicePdfURL($id)
    {
        $invoice = InvoiceOrder::with('invoice_products')->where('invoice_no', $id)->firstOrFail();

        if (is_string($invoice->party_info)) {
            $invoice->party_info = json_decode($invoice->party_info, true);
        }

        $shipping = Address::find($invoice->shipping_address_id);

        // ✅ Fetch transport info from order_logistics
        $logistic = OrderLogistic::where('invoice_no', $id)->orderByDesc('id')->first();


        $billingDetails = (object) [
            'company_name' => $invoice->party_info['company_name'] ?? 'N/A',
            'address' => $invoice->party_info['address'] ?? 'N/A',
            'gstin' => $invoice->party_info['gstin'] ?? 'N/A',
        ];

        $manager_phone = '9999241558';

        $branchMap = [
            1 => 'KOL',
            2 => 'DEL',
            6 => 'MUM'
        ];

        $branchDetailsAll = [
            'KOL' => [
                'gstin' => '19ABACA4198B1ZS',
                'company_name' => 'ACE TOOLS PVT LTD',
                'address_1' => '257B, BIPIN BEHARI GANGULY STREET',
                'address_2' => '2ND FLOOR',
                'address_3' => '',
                'city' => 'KOLKATA',
                'state' => 'WEST BENGAL',
                'postal_code' => '700012',
                'contact_name' => 'Amir Madraswala',
                'phone' => '9709555576',
                'email' => 'acetools505@gmail.com',
            ],
            'MUM' => [
                'gstin' => '27ABACA4198B1ZV',
                'company_name' => 'ACE TOOLS PVT LTD',
                'address_1' => 'HARIHAR COMPLEX F-8, HOUSE NO-10607, ANUR DEPODE ROAD',
                'address_2' => 'GODOWN NO.7, GROUND FLOOR',
                'address_3' => 'BHIWANDI',
                'city' => 'MUMBAI',
                'state' => 'MAHARASHTRA',
                'postal_code' => '421302',
                'contact_name' => 'Hussain',
                'phone' => '9930791952',
                'email' => 'acetools505@gmail.com',
            ],
            'DEL' => [
                'gstin' => '07ABACA4198B1ZX',
                'company_name' => 'ACE TOOLS PVT LTD',
                'address_1' => 'Khasra No. 58/15',
                'address_2' => 'Pal Colony',
                'address_3' => 'Village Rithala',
                'city' => 'New Delhi',
                'state' => 'Delhi',
                'postal_code' => '110085',
                'contact_name' => 'Mustafa Worliwala',
                'phone' => '9730377752',
                'email' => 'acetools505@gmail.com',
            ],
        ];

        $branchCode = $branchMap[$invoice->warehouse_id] ?? 'DEL';
        $branchDetails = $branchDetailsAll[$branchCode] ?? [];

        // ✅ Pass $logistic to the view
        
        $pdf = PDF::loadView('backend.sales.invoice_pdf', compact(
            'invoice',
            'billingDetails',
            'manager_phone',
            'branchDetails',
            'shipping',
            'logistic'
        ));

        // Ensure directory exists
        $pdfDir = public_path('purchase_history_invoice');
        if (!file_exists($pdfDir)) {
            mkdir($pdfDir, 0755, true);
        }

        $fileName = str_replace('/', '_', $invoice->invoice_no) . '.pdf';
        $filePath = $pdfDir . '/' . $fileName;
        $pdf->save($filePath);

        return url('public/purchase_history_invoice/' . $fileName);
    }
    public function create($encrypted_invoice_no)
    {
        // Create Order Logistic view page
        $invoiceNo = Crypt::decrypt($encrypted_invoice_no);
        return view('backend.order_logistics.add', compact('invoiceNo'));
    }

    public function store(Request $request, $encrypted_invoice_no)
    {
        // save order logistic 
        $invoiceNo = Crypt::decrypt($encrypted_invoice_no);

       


         // 🔍 Get party_code from invoice_orders table
        $invoice = DB::table('invoice_orders')->where('invoice_no', $invoiceNo)->first();
        if (!$invoice) {
            return redirect()->back()->with('error', 'Invoice not found.');
        }

        $partyCode = $invoice->party_code ?? null;

        $attachments = [];
        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $fileName = time() . '_' . $file->getClientOriginalName();
                $filePath = public_path('uploads/cw_acetools');
                if (!file_exists($filePath)) {
                    mkdir($filePath, 0755, true);
                }
                $file->move($filePath, $fileName);
                $attachments[] = 'https://mazingbusiness.com/public/uploads/cw_acetools/' . $fileName;
            }
        }

        DB::table('order_logistics')->insert([
            'invoice_no'   => $invoiceNo,
            'party_code'     => $partyCode,
            'order_no'=>$invoiceNo,
            'lr_date'      => $request->input('lr_date'),
            'lr_no'        => $request->input('lr_no'),
            'transport_name' => $request->input('transport_name'),
            'no_of_boxes'  => $request->input('no_of_boxes'),
            'lr_amount'    => $request->input('lr_amount'),
            'attachment'   => implode(',', $attachments),
            'wa_is_processed'=>1,
            'add_status'=>1,
            'created_at'   => now(),
            'updated_at'   => now(),
        ]);

        // 🔽 Send WhatsApp notification (PDF + template)
        $pdfURL = $this->getInvoicePdfURL($invoiceNo);
        $buttonVariable = basename($pdfURL);
        $attachmentURL = $attachments[0] ?? null;

        $isPdf = preg_match('/\.pdf$/i', $attachmentURL);

        $whatsAppWebService=new whatsAppWebService();
        $media_id = $isPdf ? $whatsAppWebService->uploadMedia($attachmentURL) : null;

        $templateName = $isPdf ? 'utility_logistic_fresh_pdfs' : 'utility_logistic_fresh';

        // Fetch user details
        $user = User::where('id', $invoice->user_id)->first();
        $managerPhone = $this->getManagerPhone($user->manager_id);

        $whatsappMessage = [
            'name' => $templateName,
            'language' => 'en_US',
            'components' => [
                [
                    'type' => 'header',
                    'parameters' => $isPdf
                        ? [[
                            'type' => 'document',
                            'document' => [
                                'id' => $media_id['media_id'],
                                'filename' => 'Order Logistic Notification'
                            ]
                        ]]
                        : [[
                            'type' => 'image',
                            'image' => ['link' => $attachmentURL]
                        ]],
                ],
                [
                    'type' => 'body',
                    'parameters' => [
                        ['type' => 'text', 'text' => $user->name ?? 'Customer'],
                        ['type' => 'text', 'text' => $invoiceNo],
                        ['type' => 'text', 'text' => \Carbon\Carbon::parse($invoice->created_at)->format('d-m-Y')],
                        ['type' => 'text', 'text' => $request->transport_name . ' (LR No: ' . $request->lr_no . ')'],
                        ['type' => 'text', 'text' => $request->lr_date],
                        ['type' => 'text', 'text' => $request->no_of_boxes],
                       
                       
                        
                    ],
                ],
                [
                    'type' => 'button',
                    'sub_type' => 'url',
                    'index' => '0',
                    'parameters' => [
                        ['type' => 'text', 'text' => $buttonVariable],
                    ],
                ],
            ],
        ];

       $to = [$user->phone, $managerPhone];
        $responses = [];

        foreach ($to as $recipient) {
            $responses[] = $whatsAppWebService->sendTemplateMessage($recipient, $whatsappMessage);
        }
        //return response()->json($response);

        return redirect()->route('order.logistics')->with('success', 'Logistic record added successfully!');
    }


    public function edit($invoice_id)
    {


      
        $logistic = DB::table('order_logistics')->where('invoice_no',decrypt($invoice_id))->first();


        if (!$logistic) {
            return redirect()->route('order.logistics')->with('error', 'Record not found.');
        }
        // echo "<pre>";
        // print_r($logistic->attachment);
        // die();
        

        return view('backend.order_logistics.edit', compact('logistic'));
    }


    public function update(Request $request, $invoice_no, $id)
    {
        $logistic = DB::table('order_logistics')->where('invoice_no', decrypt($invoice_no))->first();
        if (!$logistic) {
            return redirect()->route('order.logistics')->with('error', 'Logistic record not found.');
        }

        // Get existing attachments and convert them to an array
        $currentAttachments = $logistic->attachment ? explode(',', $logistic->attachment) : [];

        // Handle file removal
        if ($request->filled('remove_indexes')) {
            $removeIndexes = explode(',', $request->input('remove_indexes'));
            foreach ($removeIndexes as $index) {
                unset($currentAttachments[$index]); // Remove selected attachments
            }
            $currentAttachments = array_values($currentAttachments); // Re-index array
        }

        // Handle new file uploads and prepend URLs
        $newAttachments = [];
        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $fileName = time() . '_' . $file->getClientOriginalName();
                $filePath = public_path('uploads/cw_acetools');

                if (!file_exists($filePath)) {
                    mkdir($filePath, 0755, true);
                }

                $file->move($filePath, $fileName);
                $newAttachments[] = 'https://mazingbusiness.com/public/uploads/cw_acetools/' . $fileName;
            }
        }

        // Prepend new attachments to the current attachments
        $updatedAttachments = array_merge($newAttachments, $currentAttachments);

        // Update the record based on decrypted invoice_no and id
        DB::table('order_logistics')
            ->where('invoice_no', decrypt($invoice_no))
            ->where('id', $id)
            ->update([
                'lr_date'      => $request->input('lr_date'),
                'lr_no'        => $request->input('lr_no'),
                'no_of_boxes'  => $request->input('no_of_boxes'),
                'lr_amount'    => $request->input('lr_amount'),
                'attachment'   => implode(',', $updatedAttachments), // Save as comma-separated string
            ]);

        return redirect()->route('order.logistics')->with('success', 'Logistic record updated successfully!');
    }


    public function sendLogisticWhatsapp($invoice_no,$id){

        // echo decrypt($invoice_no)." ". $id;
        // die();
       $this->whatsAppWebService = new WhatsAppWebService();
        $logistics = DB::table('order_logistics')
            ->join('addresses', 'order_logistics.party_code', '=', 'addresses.acc_code')
            ->Join('order_bills', 'order_logistics.invoice_no', '=', 'order_bills.invoice_no') // Join with order_bills table
            ->select(
                'order_logistics.id as order_logistics_id',
                'order_logistics.party_code',
                'order_logistics.order_no',
                'order_logistics.invoice_no',
                'order_logistics.lr_no',
                'order_logistics.lr_date',
                'order_logistics.no_of_boxes',
                'order_logistics.payment_type',
                'order_logistics.lr_amount',
                'order_logistics.attachment',
                DB::raw('SUBSTRING_INDEX(order_logistics.lr_no, " - ", 1) as transport_name'),
                'addresses.company_name',
                'addresses.address',
                'addresses.address_2',
                'addresses.city',
                'addresses.state_id',
                'addresses.country_id',
                'addresses.gstin',
                'addresses.phone',
                'addresses.user_id',
                'order_bills.invoice_date' // Include invoice_date
            )
            ->where('order_logistics.id', $id) // Add table prefix here
            ->where('order_logistics.invoice_no', decrypt($invoice_no)) // Add table prefix here
            ->whereNotNull('order_logistics.lr_no') // Ensure `lr_no` is not null
            ->where('order_logistics.lr_no', '!=', '') // Ensure `lr_no` is not blank
            ->first();

        $billDataController=new BillsDataController();
        $invoice_url= $billDataController->generateBillInvoicePdfURL($invoice_no);
        $buttonVariable=basename($invoice_url);

        //get first attatchment
         $attachments = explode(',', $logistics->attachment);
         $logistics->attachment = $attachments[0] ?? null;
         //pdf+image combine start
         $isPdf = preg_match('/\.pdf$/i', $logistics->attachment);
         $media_id = $isPdf ? $this->whatsAppWebService->uploadMedia($logistics->attachment) : null;
         
         $templateName = $isPdf ? 'utility_logistic_fresh_pdfs' : 'utility_logistic_fresh';
         //pdf+image combine end

        // Prepare WhatsApp message template
        $templateData = [
            'name' => $templateName,
            'language' => 'en_US',
            'components' => [
                
                [
                    'type' => 'header',
                    'parameters' => $isPdf 
                        ? [[
                            'type' => 'document',
                            'document' => [
                                'id' => $media_id['media_id'],
                                'filename' => 'Order Logistic Notification' // Adding filename for PDFs
                            ]
                        ]]
                        : [[
                            'type' => 'image',
                            'image' => ['link' => $logistics->attachment]
                        ]], // Image handling
                ],
                [
                    'type' => 'body',
                    'parameters' => [
                        ['type' => 'text', 'text' => $logistics->company_name ?: 'N/A'], // Customer name
                        ['type' => 'text', 'text' => $logistics->invoice_no ?: 'N/A'], // Invoice 
                        ['type' => 'text', 'text' => $logistics->invoice_date ?: 'N/A'], // Invoice date
                        ['type' => 'text', 'text' => $logistics->transport_name ?: 'N/A'], // Transport name - lr number                           
                        ['type' => 'text', 'text' => $logistics->lr_date ?: 'N/A'], // LR date
                        ['type' => 'text', 'text' => $logistics->no_of_boxes ?: '0.00'], // No. of boxes
                    ],
                ],
                [
                    'type' => 'button',
                    'sub_type' => 'url',
                    'index' => '0',
                    'parameters' => [
                        ['type' => 'text', 'text' => $buttonVariable],
                    ],
                ],
            ],
        ];

        $user = DB::table('users')->where('id', $logistics->user_id)->first();
        $managerPhone = $this->getManagerPhone($user->manager_id);

        $to = [$user->phone,$managerPhone];
        //$to=['7044300330'];
        

        foreach ($to as $recipient) {
            $jsonResponse = $this->whatsAppWebService->sendTemplateMessage($recipient, $templateData);

            // Log the response for debugging
            Log::info('WhatsApp Response', ['recipient' => $recipient, 'response' => $jsonResponse]);

            // Optionally check for errors in the API response
            if (isset($jsonResponse['messages'][0]['message_status']) && $jsonResponse['messages'][0]['message_status'] !== 'accepted') {
                return response()->json([
                    'success' => false,
                    'error' => 'Message was not accepted by WhatsApp API.',
                    'details' => $jsonResponse
                ], 500);
            }
        }
        return response()->json(['success' => true,'message'=>'PDF sent successfully via WhatsApp.']);

    }



    //Temporary Function  start
     public function oldtempAllOrders(Request $request) {
        CoreComponentRepository::instantiateShopRepository();

        $date            = $request->date;
        $sort_search     = null;
        $delivery_status = null;
        $payment_status  = '';

        // Fetch the admin user ID efficiently
        $admin_user_id = User::where('user_type', 'admin')->value('id');

        // Fetch distinct Salezing Order Punch Status responses
        $salzing_statuses = DB::table('salezing_logs')->distinct()->pluck('response');

        // Optimize the update query to avoid large-scale updates
        DB::table('orders')
            ->whereIn('code', function ($query) {
                $query->select('code')->from('order_approvals')->where('status', 'Approved');
            })
            ->update(['delivery_status' => 'Approved']);

        // Start Query Builder
        $orders = Order::query()
            ->select([
                'orders.id',
                'orders.code',
                'orders.combined_order_id',
                'orders.user_id',
                'orders.seller_id',
                'orders.delivery_status',
                'orders.payment_status',
                'orders.created_at',
                'addresses.company_name',
                DB::raw("(SELECT response FROM salezing_logs WHERE BINARY salezing_logs.code = BINARY orders.code LIMIT 1) as salezing_response"),
                DB::raw("(SELECT status FROM salezing_logs WHERE BINARY salezing_logs.code = BINARY orders.code LIMIT 1) as salezing_status"),
                'users.warehouse_id',
                'manager_users.name as manager_name',
                'warehouses.name as warehouse_name'
            ])
            ->join('addresses', 'orders.address_id', '=', 'addresses.id')
            ->join('users', 'orders.user_id', '=', 'users.id')
            ->leftJoin('users as manager_users', 'users.manager_id', '=', 'manager_users.id')
            ->leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id')
            ->orderByDesc('orders.id');

        // Apply permission-based filters early
        if (Route::currentRouteName() === 'inhouse_orders.index' && Auth::user()->can('view_inhouse_orders')) {
            $orders->where('orders.seller_id', $admin_user_id);
        } elseif (Route::currentRouteName() === 'seller_orders.index' && Auth::user()->can('view_seller_orders')) {
            $orders->where('orders.seller_id', '!=', $admin_user_id);
        }

        // Apply search filters efficiently
        if ($request->filled('search')) {
            $orders->where('orders.code', 'like', '%' . $request->search . '%');
        }
        if ($request->filled('payment_status')) {
            $orders->where('orders.payment_status', $request->payment_status);
            $payment_status = $request->payment_status;
        }
        if ($request->filled('delivery_status')) {
            $orders->where('orders.delivery_status', $request->delivery_status);
            $delivery_status = $request->delivery_status;
        }
        if ($request->filled('date')) {
            $dateRange = explode(" to ", $request->date);
            $orders->whereBetween('orders.created_at', [
                date('Y-m-d', strtotime($dateRange[0])) . ' 00:00:00',
                date('Y-m-d', strtotime($dateRange[1])) . ' 23:59:59'
            ]);
        }

        // Optimize filtering Salezing Order Punch Status using subquery
        if ($request->filled('salzing_status')) {
            $orders->whereRaw("(SELECT response FROM salezing_logs WHERE BINARY salezing_logs.code = BINARY orders.code LIMIT 1) = ?", [$request->salzing_status]);
        }

        // Paginate and return the result
        $orders = $orders->paginate(15);
        // echo "<pre>";
        // print_r($orders->toArray());
        // die();

        return view('backend.sales.index', compact('orders', 'sort_search', 'payment_status', 'delivery_status', 'date', 'salzing_statuses'));
    }

  



}
