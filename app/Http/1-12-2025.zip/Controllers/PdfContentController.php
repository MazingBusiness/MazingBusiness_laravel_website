<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PdfContent;
use App\Models\Offer;
use App\Models\Product;
use App\Models\Category;
use App\Models\Brand;

class PdfContentController extends Controller
{
    public function index()
    {
        // Selection lists
        $offers     = Offer::where('status', 1)->orderByDesc('id')->get();
        $categories = Category::orderBy('name')->get();
        $brands     = Brand::orderBy('name')->get();

        // Existing mappings
        $pdfContents = PdfContent::orderByDesc('id')->paginate(25);

        return view('backend.pdf_contents.index', compact(
            'offers',
            'categories',
            'brands',
            'pdfContents'
        ));
    }

    public function store(Request $request)
    {
        $request->validate([
            'pdf_type'       => 'required|string|max:100',
            // 'url'            => 'nullable|string|max:500',
            'placement_type' => 'nullable|in:first,last',
            'content_type'   => 'required|in:offer,product,category,brand',
            'content_ids'    => 'nullable|string',  // comma separated IDs
            'no_of_poster'   => 'nullable|integer|min:0', // ⬅️ NEW
        ]);
        
        // ek pdf_type ke liye sirf ek row — updateOrCreate
        PdfContent::updateOrCreate(
            ['pdf_type' => $request->pdf_type],
            [
                'url'              => $request->url,
                'placement_type'   => $request->placement_type,
                'content_type'     => $request->content_type,
                'content_products' => $request->content_ids,
                'no_of_poster'     => $request->no_of_poster, // ⬅️ NEW
            ]
        );

        return redirect()
            ->route('pdf_contents.index')
            ->with('success', 'PDF content mapping saved/updated successfully.');
    }

    /**
     * Product search by part_no (AJAX)
     */
    public function searchProducts(Request $request)
    {
        $q = trim($request->get('q', ''));

        if ($q === '') {
            return response()->json([
                'success'  => false,
                'message'  => 'Empty query.',
                'products' => [],
            ]);
        }

        $products = Product::where('part_no', 'LIKE', '%' . $q . '%')
            ->orderBy('part_no')
            ->take(10)
            ->get(['id', 'part_no', 'name', 'thumbnail_img']);

        $mapped = $products->map(function ($p) {
            return [
                'id'            => $p->id,
                'part_no'       => $p->part_no,
                'name'          => $p->name,
                'thumbnail_url' => uploaded_asset($p->thumbnail_img),
            ];
        });

        return response()->json([
            'success'  => true,
            'products' => $mapped,
        ]);
    }


    public static function buildPdfContentBlockForType(string $pdfType): ?array
    {
        $content = PdfContent::where('pdf_type', $pdfType)->first();

        if (!$content) {
            return null;
        }

        $ids = collect(explode(',', (string) $content->content_products))
            ->map(fn ($v) => trim($v))
            ->filter()
            ->map('intval')
            ->unique()
            ->values()
            ->all();

        if (empty($ids)) {
            return null;
        }

        $items = collect();

        switch ($content->content_type) {
            case 'product':
                $items = Product::whereIn('id', $ids)
                    ->get(['id', 'name', 'part_no', 'thumbnail_img'])
                    ->map(function ($p) {
                        return [
                            'id'        => $p->id,
                            'name'      => $p->name,
                            'subtitle'  => $p->part_no,
                            'image_url' => $p->thumbnail_img ? uploaded_asset($p->thumbnail_img) : null,
                        ];
                    });
                break;

            case 'category':
                $items = Category::whereIn('id', $ids)
                    ->get(['id', 'name', 'banner'])
                    ->map(function ($c) {
                        return [
                            'id'        => $c->id,
                            'name'      => $c->name,
                            'subtitle'  => null,
                            'image_url' => !empty($c->banner) ? uploaded_asset($c->banner) : null,
                        ];
                    });
                break;

            case 'brand':
                $items = Brand::whereIn('id', $ids)
                    ->get(['id', 'name', 'logo'])
                    ->map(function ($b) {
                        return [
                            'id'        => $b->id,
                            'name'      => $b->name,
                            'subtitle'  => null,
                            'image_url' => !empty($b->logo) ? uploaded_asset($b->logo) : null,
                        ];
                    });
                break;

            case 'offer':
                $items = Offer::whereIn('id', $ids)
                    ->get(['id', 'offer_name', 'offer_id', 'offer_banner'])
                    ->map(function ($o) {
                        return [
                            'id'        => $o->id,
                            'name'      => $o->offer_name ?: $o->offer_id,
                            'subtitle'  => $o->offer_id,
                            'image_url' => !empty($o->offer_banner) ? uploaded_asset($o->offer_banner) : null,
                        ];
                    });
                break;

            default:
                return null;
        }

        if ($items->isEmpty()) {
            return null;
        }

        return [
            'placement'    => $content->placement_type ?: 'last',   // first / last
            'content_type' => $content->content_type,
            'items'        => $items,
        ];
    }
}
