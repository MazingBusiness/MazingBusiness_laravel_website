<?php

namespace App\Http\Controllers;

use App\Models\Currency;
use App\Models\Language;
use App\Models\Order;
use App\Models\User;
use App\Models\Address;
use Config;
use Hash;
use PDF;
use Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use App\Services\WhatsAppWebService;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\PurchaseHistoryController;
use Maatwebsite\Excel\Facades\Excel; // Assuming you're using Laravel Excel for export
use App\Jobs\SendWhatsAppMessagesJob;
use Illuminate\Support\Facades\File;
use Carbon\Carbon; // Make sure to use Carbon for date manipulation

class AdminStatementController extends Controller
{
    //
    protected $whatsAppWebService;

    public function statementPdfDownload(Request $request)
    {
        try {
            $party_code = ($request->party_code); 
        } catch (\Exception $e) {
            Log::error('Decryption error: ' . $e->getMessage());
            return response()->json(['error' => 'Failed to decrypt party code.'], 500);
        }

        $currentDate = date('Y-m-d');
        $currentMonth = date('m');
        $currentYear = date('Y');

        if ($currentMonth >= 4) {
            $form_date = date('Y-04-01'); // Start of financial year
            $to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year
        } else {
            $form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
            $to_date = date('Y-03-31'); // Current year March
        }

        if ($request->has('from_date')) {
            $form_date = $request->from_date; // Use provided date
        }

        if ($request->has('to_date')) {
            $to_date = $request->to_date; // Use provided date
        }

        if ($to_date > $currentDate) {
            $to_date = $currentDate;
        }
        
        $headers = [
            'authtoken' => '65d448afc6f6b',
        ];

        $body = [
            'party_code' => $party_code,
            'from_date' => $form_date,
            'to_date' => $to_date,
        ];

        Log::info('Sending request to API', ['body' => $body]);

        $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);      

        Log::info('Received response from API', ['status' => $response->status(), 'body' => $response->body()]);

        if ($response->successful()) {

            $getData = $response->json();
            $getData = $getData['data'];

            $openingBalance = "0";
            $closingBalance = "0";
            $openDrOrCr = "";
            $closeDrOrCr = "";
            $dueAmount = 0;  // Initialize dueAmount
            $overdueAmount = 0;
            $overdueDrOrCr = 'Dr';
            $userData = User::where('party_code', $party_code)->first();
            $overdueDateFrom = date('Y-m-d', strtotime('-' . $userData->credit_days . ' days'));

            // Process the API data to get opening, closing balances, and calculate due amount
            foreach ($getData as $gKey => $gValue) {
                if ($gValue['ledgername'] == "Opening b/f...") {
                    $openingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
                    $openDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
                } elseif ($gValue['ledgername'] == "closing C/f...") {
                    $closingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
                    $closeDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
                    $dueAmount = $gValue['dramount'] != "0.00" ? $gValue['dramount'] : $gValue['cramount'];  // Calculate due amount
                    $overdueAmount = $closingBalance;
                }
            }

            // Overdue calculation logic
            $getOverdueData = array_reverse($getData);
            $drBalanceBeforeOVDate = 0;
            $crBalanceBeforeOVDate = 0;
            $overDueMark = [];

            foreach($getOverdueData as $ovKey => $ovValue){
                if($ovValue['ledgername'] != 'closing C/f...'){
                    if(strtotime($ovValue['trn_date']) <= strtotime($overdueDateFrom)){
                        $drBalanceBeforeOVDate += $ovValue['dramount'];
                        $crBalanceBeforeOVDate += $ovValue['cramount'];
                    }
                }
            }

            $overdueAmount = $drBalanceBeforeOVDate - $crBalanceBeforeOVDate;

            // Marking overdue transactions
            foreach($getOverdueData as $ovKey => $ovValue){
                if($ovValue['ledgername'] != 'closing C/f...'){
                    if(strtotime($ovValue['trn_date']) < strtotime($overdueDateFrom) && $ovValue['dramount'] > 0){
                        $overDueMark[] = [
                            'trn_no' => $ovValue['trn_no'],
                            'trn_date' => $ovValue['trn_date'],
                            'overdue_status' => ($overdueAmount > 0) ? 'Overdue' : 'Partial Overdue'
                        ];
                    }
                }
            }

            // Adding overdue status to each transaction in getData
            $overDueMarkTrnNos = array_column($overDueMark, 'trn_no');
            $overDueMarkOverdueStaus = array_column($overDueMark, 'overdue_status');

            if (count($overDueMark) > 0) {
                foreach ($getData as $gKey => $gValue) {
                    $key = array_search($gValue['trn_no'], $overDueMarkTrnNos);
                    if ($key !== false) {
                        $getData[$gKey]['overdue_status'] = $overDueMarkOverdueStaus[$key];
                    }
                }
            }

            // Generating PDF with overdue data and due amount
            $randomNumber = str_replace('.', '', microtime(true));
            $fileName = 'statement-' . $party_code . '-' . $randomNumber . '.pdf';
            $userId = Auth::id();
            $pdf = PDF::loadView('backend.invoices.statement_pdf', compact(
                'party_code',
                'getData',
                'openingBalance',
                'openDrOrCr',
                'closingBalance',
                'closeDrOrCr',
                'form_date',
                'to_date',
                'overdueAmount',
                'overdueDrOrCr',
                'overdueDateFrom',
                'overDueMark',
                'dueAmount' ,// Pass dueAmount to the view
                'userId' 
            ))->save(public_path('statements/' . $fileName));

            $publicUrl = url('public/statements/' . $fileName);
            return response()->json(['status' => 'success', 'message' => $publicUrl], $response->status());
        } else {
            return response()->json(['status' => 'failure'], $response->status());
        }
    }




    // public function statementPdfDownload(Request $request)
    // {
        
    //     // return response()->json([
    //     //     'status' => 'failure', 
    //     //     'error' => "Sorry for the inconvenience, but we're working on it."
    //     // ], 500);
       
    //     try {
    //         $party_code = ($request->party_code); 
    //     } catch (\Exception $e) {
    //         Log::error('Decryption error: ' . $e->getMessage());
    //         return response()->json(['error' => 'Failed to decrypt party code.'], 500);
    //     }
        
    //     $currentDate = date('Y-m-d');
    //     $currentMonth = date('m');
    //     $currentYear = date('Y');

    //     if ($currentMonth >= 4) {
    //         $form_date = date('Y-04-01'); // Start of financial year
    //         $to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year
    //     } else {
    //         $form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
    //         $to_date = date('Y-03-31'); // Current year March
    //     }

    //     if ($request->has('from_date')) {
    //         $form_date = $request->from_date; // Use provided date
    //     }

    //     if ($request->has('to_date')) {
    //         $to_date = $request->to_date; // Use provided date
    //     }

    //     if ($to_date > $currentDate) {
    //         $to_date = $currentDate;
    //     }
        
    //     $headers = [
    //         'authtoken' => '65d448afc6f6b',
    //     ];

    //     $body = [
    //         'party_code' => $party_code,
    //         'from_date' => $form_date,
    //         'to_date' => $to_date,
    //     ];

        

    //     Log::info('Sending request to API', ['body' => $body]);

        
        
    //     // Send request to external API
    //     // $response = Http::withHeaders($headers)->post('https://sz.saleszing.co.in/itaapi/getclientstatement.php', $body);
    //     $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);      
        
    //     Log::info('Received response from API', ['status' => $response->status(), 'body' => $response->body()]);

    //     if ($response->successful()) {
    //         $getData = $response->json();
    //         $getData = $getData['data'];

    //         $openingBalance = "0";
    //         $closingBalance = "0";
    //         $openDrOrCr = "";
    //         $closeDrOrCr = "";

    //         // Process the API data to get opening and closing balances
    //         foreach ($getData as $gValue) {
    //             if ($gValue['ledgername'] == "Opening b/f...") {
    //                 $openingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
    //                 $openDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
    //             } elseif ($gValue['ledgername'] == "closing C/f...") {
    //                 $closingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
    //                 $closeDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
    //             }
    //         }

    //         $randomNumber = rand(1000, 9999);
    //     $fileName = 'statement-' . $randomNumber . '.pdf';

    //         // Generate the PDF using the collected data
    //         $pdf = PDF::loadView('backend.invoices.statement_pdf', compact(
    //             'party_code',
    //             'getData',
    //             'openingBalance',
    //             'openDrOrCr',
    //             'closingBalance',
    //             'closeDrOrCr',
    //             'form_date',
    //             'to_date'
    //         ))->save(public_path('statements/' . $fileName));

    //         $publicUrl = url('public/statements/' . $fileName);
    //         return response()->json(['status' => 'success', 'message' => $publicUrl], $response->status());
    //         $message="statement";

    //          $to="6289062983"; 
    //          $phone = Auth::user()->phone;
             
             
    //         $templateData = [
    //             'name' => 'utility_statement_document', // Replace with your template name, 
    //             'language' => 'en_US', // Replace with your desired language code
    //             'components' => [
    //                 // [
    //                 //     'type' => 'header',
    //                 //     'parameters' => [
    //                 //         ['type' => 'document', 'document' => ['link' => $publicUrl,'filename' => $fileName,]],
    //                 //     ],
    //                 // ],
    //                 [
    //                     'type' => 'body',
    //                     'parameters' => [
    //                         ['type' => 'text', 'text' => Auth::user()->company_name],
    //                         ['type' => 'text', 'text' => $message],
    //                     ],
    //                 ],
    //                 [
    //                     'type' => 'button',
    //                     'sub_type' => 'url',
    //                     'index' => '0',
    //                     'parameters' => [
    //                         [
    //                             "type" => "text",
    //                             "text" => $fileName // Replace $button_text with the actual Parameter for the button.
    //                         ],
    //                     ],
    //                 ],
    //             ],
    //         ];

    //         // Send the template message using the WhatsApp web service
    //         $this->whatsAppWebService = new WhatsAppWebService();
    //         $jsonResponse  = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);
    //         // $responseData = json_decode($jsonResponse , true);
           
            
    //         // return $publicUrl;
    //         return response()->json(['status' => 'success', 'message' =>"Statement sent to whatsapp"], $response->status());

    //     } else {
          
    //         return response()->json(['status' => 'faliure'], $response->status());
    //     }
    // }

    
  
    public function getManagersByWarehouse(Request $request)
    {
        // Fetch managers based on the selected warehouse
        $managers = User::join('staff', 'users.id', '=', 'staff.user_id')
        ->where('staff.role_id', 5)
        ->where('users.warehouse_id', $request->warehouse_id)  // Apply condition on users table
        ->select('users.*')
        ->get();

    
        return response()->json($managers); // Return managers as JSON response
    }


public function statement(Request $request)
{
    set_time_limit(-1); // To handle longer execution times

    // Allowed user IDs with full access
    $allowedUserIds = [1, 180, 169, 25606];
     // Get the logged-in user
    $loggedInUser = auth()->user();
    $loggedInUserId = $loggedInUser->id;

    // Fetch all warehouses
    $warehouses = DB::table('warehouses')->get();

    // Fetch managers (staff with role_id 5)
    $managers = User::join('staff', 'users.id', '=', 'staff.user_id')
        ->where('staff.role_id', 5)
        ->select('users.*');

    // If warehouse_id is provided in the request, filter the managers by warehouse
    if ($request->has('warehouse_id') && !empty($request->warehouse_id)) {
        $managers->where('warehouse_id', $request->warehouse_id);
    }

    // Fetch filtered managers
    $managers = $managers->get();

    // Initialize the customers query and join with warehouses and managers for sorting
    $customersQuery = User::leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id')
        ->Join('users as managers', 'users.manager_id', '=', 'managers.id')
        ->Join('addresses', 'users.party_code', '=', 'addresses.acc_code')
        ->where('users.user_type', 'customer')
        ->select('users.*', 'warehouses.name as warehouse_name', 'managers.name as manager_name')
        ->orderBy('warehouses.name', 'asc') // Sort by warehouse name
        ->orderBy('managers.name', 'asc') // Then sort by manager name
        ->orderBy('addresses.city', 'asc') // Then sort by city
        ->groupBy(DB::raw("CONCAT(REPLACE(users.name, ' ', '_'), '_', addresses.acc_code)")); // Group by ledgercode

        // Restrict access for managers not in $allowedUserIds
    if (!in_array($loggedInUserId, $allowedUserIds)) {
        $customersQuery->where('users.manager_id', $loggedInUserId);
    }

    // Apply filters for manager and warehouse
    if ($request->has('manager_id') && !empty($request->manager_id)) {
        $customersQuery->where('users.manager_id', $request->manager_id);
    }

    if ($request->has('warehouse_id') && !empty($request->warehouse_id)) {
        $customersQuery->where('users.warehouse_id', $request->warehouse_id);
    }

    // Apply filter for due and overdue amounts
    if ($request->has('duefilter') && !empty($request->duefilter)) {
        if ($request->duefilter === 'due') {
            $customersQuery->whereExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('addresses')
                    ->whereColumn('addresses.user_id', 'users.id')
                    ->where('addresses.due_amount', '>', 0);
            });
        } elseif ($request->duefilter === 'overdue') {
            $customersQuery->whereExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('addresses')
                    ->whereColumn('addresses.user_id', 'users.id')
                    ->where('addresses.overdue_amount', '>', 0);
            });
        }
    }

    // Apply filter for party_code, name/company_name, or city
    if ($request->has('party_code') && !empty($request->party_code)) {
        $searchTerm = $request->party_code;
        $customersQuery->where(function ($query) use ($searchTerm) {
            $query->where('users.party_code', 'LIKE', '%' . $searchTerm . '%')
                ->orWhere('users.name', 'LIKE', '%' . $searchTerm . '%')
                ->orWhereHas('addresses', function ($q) use ($searchTerm) {
                    $q->where('company_name', 'LIKE', '%' . $searchTerm . '%')
                        ->orWhere('addresses.city', 'LIKE', '%' . $searchTerm . '%');
                });
        });
    }

    // Apply filter for city
    if ($request->has('city_id') && !empty($request->city_id)) {
        $customersQuery->whereHas('addresses', function ($query) use ($request) {
            $query->where('addresses.city', $request->city_id);
        });
    }

    // Fetch all matching customers for total calculation (without pagination)
    $allCustomers = $customersQuery->get();
    $totalCustomerCount = $allCustomers->count(); // Total number of customers

    // Initialize totals
    $totalDueAmount = 0;
    $totalOverdueAmount = 0;
    $uniqueCustomerIds = [];

    // Calculate totals from all matching customers
    foreach ($allCustomers as $userData) {
        $userAddressData = Address::where('user_id', $userData->id)
            ->select('due_amount', 'overdue_amount')
            ->get();

        foreach ($userAddressData as $address) {
            if ($address->due_amount > 0 || $address->overdue_amount > 0) {
                $totalDueAmount += $address->due_amount;
                $totalOverdueAmount += $address->overdue_amount;
                $uniqueCustomerIds[$userData->id] = true; // Track unique customers
            }
        }
    }

    // Count unique customers with due or overdue amounts
    $totalCustomersWithDueOrOverdue = count($uniqueCustomerIds);

    // Fetch paginated customers for display
    $customers = $customersQuery->paginate(250)->appends($request->query());

    // Initialize an array to store the processed data for display
    $processedData = [];

    // Process the paginated customer data for display
    foreach ($customers as $userData) {
        $userAddressData = Address::where('user_id', $userData->id)
            ->select('gstin', 'acc_code', 'due_amount', 'overdue_amount', 'company_name', 'city')
            ->orderBy('city', 'ASC')
            ->get();

        // Fetch manager and warehouse names for display
        $managerName = $userData->manager_name; // Already fetched with the join
        $warehouseName = $userData->warehouse_name; // Already fetched with the join

        foreach ($userAddressData as $address) {
            $processedData[] = [
                'user' => $userData,
                'address' => $address,
                'manager_name' => $managerName,
                'warehouse_name' => $warehouseName
            ];
        }
    }

    // Pass all processed data, totals, customers with pagination, and the list of managers/warehouses to the view
    return view('backend.statement.statement', compact(
        'managers',
        'warehouses',
        'processedData',
        'customers',
        'totalDueAmount',
        'totalOverdueAmount',
        'totalCustomerCount',
        'totalCustomersWithDueOrOverdue'
    ));
}
 public function getManager($manager_id)
{
    
    $manager = DB::table('users')
          ->where('id', $manager_id)
          ->select('phone','name')
          ->first();

    return $manager;
}
public function assignManager(Request $request)
{
    // Validate the request
    $request->validate([
        'user_id' => 'required|exists:users,id',
        'manager_id' => 'required|exists:users,id',
    ]);

    try {
        // Find the user by user_id
        $user = User::findOrFail($request->user_id);

        // Update the manager_id
        $user->manager_id = $request->manager_id;
        $user->credit_days = $request->credit_days;
        $user->credit_limit = $request->credit_limit;

        $user->save();

        // Get manager details
        $manager = $this->getManager($user->manager_id);

        // Return success response with manager details
        return response()->json([
            'success' => true,
            'message' => 'Manager assigned successfully.',
            'manager' => $manager
        ]);
    } catch (\Exception $e) {
        // Log the error for debugging
        \Log::error($e->getMessage());

        // Return error response
        return response()->json([
            'success' => false,
            'message' => 'Failed to assign manager. Please try again.'
        ]);
    }
}
public function backstatement(Request $request)
{

    
    set_time_limit(-1);  // 300 seconds, adjust as needed
    // Fetch all warehouses
    $warehouses = DB::table('warehouses')->get();

    // Fetch managers (staff with role_id 5)
    $managers = User::join('staff', 'users.id', '=', 'staff.user_id')
        ->where('staff.role_id', 5)
        ->select('users.*');

    // If warehouse_id is provided in the request, filter the managers by warehouse
    if ($request->has('warehouse_id') && !empty($request->warehouse_id)) {
        $managers->where('warehouse_id', $request->warehouse_id);
    }

    // Fetch filtered managers
    $managers = $managers->get();

    // Initialize the customers query
    $customersQuery = User::where('user_type', 'customer')
                          ->orderBy('company_name', 'asc');

    // Apply filters for manager and warehouse
    if ($request->has('manager_id') && !empty($request->manager_id)) {
        $customersQuery->where('manager_id', $request->manager_id);
    }

    if ($request->has('warehouse_id') && !empty($request->warehouse_id)) {
        $customersQuery->where('warehouse_id', $request->warehouse_id);
    }

    // Fetch all matching customers for total calculation (without pagination)
    $allCustomers = $customersQuery->get();
    $totalCustomerCount = $allCustomers->count();  // Total number of customers

    // Initialize totals
    $totalDueAmount = 0;
    $totalOverdueAmount = 0;
    $customersWithDueOrOverdue = [];  // Added: Set to track unique customers with due or overdue amounts

    // Iterate over each customer to calculate total dues and overdues
    foreach ($allCustomers as $userData) {
        $userAddressData = Address::where('user_id', $userData->id)
            ->select('due_amount', 'overdue_amount')
            ->groupBy('gstin')
            ->get();

        foreach ($userAddressData as $address) {
            // Apply the "due" filter if it exists
            if ($request->has('duefilter')) {
                if ($request->duefilter == 'due' && $address->due_amount <= 0) {
                    continue;
                }
                if ($request->duefilter == 'overdue' && $address->overdue_amount <= 0) {
                    continue;
                }
                if ($request->duefilter == 'due-overdue' && $address->due_amount <= 0 && $address->overdue_amount <= 0) {
                    continue;
                }
            }

            // Add due and overdue amounts to totals
            $totalDueAmount += $address->due_amount;
            $totalOverdueAmount += $address->overdue_amount;

            // Add the customer ID to the set if they have either due or overdue amounts
            if ($address->due_amount > 0 || $address->overdue_amount > 0) {
                $customersWithDueOrOverdue[$userData->id] = true;  // Use associative array to ensure uniqueness
            }
        }
    }

    // Get the total number of customers with due or overdue amounts
    $totalCustomersWithDueOrOverdue = count($customersWithDueOrOverdue);  // Total unique customers with due/overdue amounts

    // Fetch paginated customers for display (apply pagination now)
    $customers = $customersQuery->paginate(250)->appends($request->query());

    // Initialize an array to store the processed data for display
    $processedData = [];

    // Process the paginated customer data for display
    foreach ($customers as $userData) {
        $userAddressData = Address::where('user_id', $userData->id)
            ->select('gstin', 'acc_code', 'due_amount', 'overdue_amount','company_name','city') 
            ->groupBy('gstin')
            ->orderBy('acc_code', 'ASC')
            ->get();

        // Fetch manager and warehouse names for display
        $managerName = $userData->manager_id ? User::where('id', $userData->manager_id)->value('name') : null;
        $warehouseName = $userData->warehouse_id ? DB::table('warehouses')->where('id', $userData->warehouse_id)->value('name') : null;

        foreach ($userAddressData as $address) {
            $processedData[] = [
                'user' => $userData,
                'address' => $address,
                'manager_name' => $managerName,
                'warehouse_name' => $warehouseName
            ];
        }
    }

    // echo $totalCustomersWithDueOrOverdue;
    // die();

    // Pass all processed data, totals, customers with pagination, and the list of managers/warehouses to the view
    return view('backend.statement.statement', compact('managers', 'warehouses', 'processedData', 'customers', 'totalDueAmount', 'totalOverdueAmount', 'totalCustomerCount', 'totalCustomersWithDueOrOverdue'));
}

    
    public function generateStatementPdf($party_code, $dueAmount, $overdueAmount, $userData)
{
    // Set date range (financial year or custom range)
    $currentDate = date('Y-m-d');
    $currentMonth = date('m');
    $currentYear = date('Y');

    if ($currentMonth >= 4) {
        $form_date = date('Y-04-01'); // Start of financial year
        $to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year
    } else {
        $form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
        $to_date = date('Y-03-31'); // Current year March
    }

    // Override with request date if present
    if (request()->has('from_date')) {
        $form_date = request()->from_date;
    }
    if (request()->has('to_date')) {
        $to_date = request()->to_date;
    }

    // Ensure 'to_date' doesn't exceed current date
    if ($to_date > $currentDate) {
        $to_date = $currentDate;
    }

    // Fetch data from address and user tables
    $userData = DB::table('users')
        ->join('addresses', 'users.id', '=', 'addresses.user_id')
        ->where('addresses.acc_code', $party_code)
        ->select('users.*', 'addresses.statement_data', 'addresses.overdue_amount', 'addresses.due_amount', 'addresses.address', 'addresses.address_2', 'addresses.postal_code','addresses.dueDrOrCr','addresses.overdueDrOrCr')
        ->first();

    if (!$userData) {
        return response()->json(['error' => 'User or address not found'], 404);
    }

    // Parse the statement data from the address table
    $statementData = json_decode($userData->statement_data, true) ?? [];

    // Address details
    $address = $userData->address ?? 'Address not found';
    $address_2 = $userData->address_2 ?? '';
    $postal_code = $userData->postal_code ?? '';

    // Variables to store balances
    $openingBalance = "0";
    $closingBalance = "0";
    $openDrOrCr = "";
    $closeDrOrCr = "";
    $overdueDrOrCr = 'Dr'; // Default to Dr

    // Calculate overdue and closing balances using Atanu's logic
    $overdueDateFrom = date('Y-m-d', strtotime('-' . $userData->credit_days . ' days'));
    $drBalanceBeforeOVDate = 0;
    $crBalanceBeforeOVDate = 0;

    foreach (array_reverse($statementData) as $transaction) {
        if ($transaction['ledgername'] != 'closing C/f...') {
            if (strtotime($transaction['trn_date']) > strtotime($overdueDateFrom)) {
                $crBalanceBeforeOVDate += floatval($transaction['cramount']);
            } else {
                $drBalanceBeforeOVDate += floatval($transaction['dramount']);
                $crBalanceBeforeOVDate += floatval($transaction['cramount']);
            }
        }

        if (isset($transaction['ledgername']) && $transaction['ledgername'] == "Opening b/f...") {
            $openingBalance = ($transaction['dramount'] != "0.00") ? floatval($transaction['dramount']) : floatval($transaction['cramount']);
            $openDrOrCr = ($transaction['dramount'] != "0.00") ? "Dr" : "Cr";
        } elseif (isset($transaction['ledgername']) && $transaction['ledgername'] == "closing C/f...") {
            $closingBalance = ($transaction['dramount'] != "0.00") ? floatval($transaction['dramount']) : floatval($transaction['cramount']);
            $closeDrOrCr = ($transaction['dramount'] != "0.00") ? "Dr" : "Cr";
        }
    }

    // Calculate overdue amount
    $overdueAmount = $drBalanceBeforeOVDate - $crBalanceBeforeOVDate;
    if ($overdueAmount <= 0) {
        $overdueDrOrCr = 'Cr';
        $overdueAmount = 0;
    } else {
        $overdueDrOrCr = 'Dr';
    }

    // Prepare and generate the PDF
    $randomNumber = str_replace('.', '', microtime(true));
    $fileName = 'statement-' . $party_code . '-' . $randomNumber . '.pdf';

    // Load the Blade view for the PDF generation
    $pdf = PDF::loadView('backend.invoices.statement_pdf', compact(
        'userData',
        'party_code',
        'statementData',
        'openingBalance',
        'openDrOrCr',
        'closingBalance',
        'closeDrOrCr',
        'form_date',
        'to_date',
        'overdueAmount',
        'overdueDrOrCr',
        'dueAmount',
        'address',     // Pass address details to the view
        'address_2',
        'postal_code'
    ))->save(public_path('statements/' . $fileName));

    // Return the public URL of the PDF
    return url('public/statements/' . $fileName);
}

    

    

    /**
     * Function to calculate due and overdue amounts for a party code
     */
    private function calculateDueAndOverdueAmounts($party_code, $userData)
{
    $currentDate = date('Y-m-d');
    $currentMonth = date('m');
    $currentYear = date('Y');

    if ($currentMonth >= 4) {
        $form_date = date('Y-04-01'); // Start of financial year
        $to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year
    } else {
        $form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
        $to_date = date('Y-03-31'); // Current year March
    }

    // Adjust the date range if provided
    if (request()->has('from_date')) {
        $form_date = request()->from_date; 
    }

    if (request()->has('to_date')) {
        $to_date = request()->to_date; 
    }

    if ($to_date > $currentDate) {
        $to_date = $currentDate;
    }

    $headers = [
        'authtoken' => '65d448afc6f6b',  // API auth token
    ];

    $body = [
        'party_code' => $party_code,
        'from_date' => $form_date,
        'to_date' => $to_date,
    ];

    // Make API request (or replace this with your data fetching logic)
    $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);      

    if ($response->successful()) {
        // Check if 'data' key exists in the response
        if (isset($response->json()['data'])) {
            $getData = $response->json()['data'];

            $dueAmount = 0;
            $overdueAmount = 0;

            // Calculate due and overdue amounts
            foreach ($getData as $gValue) {
                if ($gValue['ledgername'] == "closing C/f...") {
                    $dueAmount = $gValue['dramount'] != "0.00" ? $gValue['dramount'] : $gValue['cramount'];
                }
            }

            // Overdue calculation logic based on user's credit days
            $overdueDateFrom = date('Y-m-d', strtotime('-' . $userData->credit_days . ' days'));
            $drBalanceBeforeOVDate = 0;
            $crBalanceBeforeOVDate = 0;

            foreach (array_reverse($getData) as $ovValue) {
                if ($ovValue['ledgername'] != 'closing C/f...') {
                    if (strtotime($ovValue['trn_date']) <= strtotime($overdueDateFrom)) {
                        $drBalanceBeforeOVDate += $ovValue['dramount'];
                        $crBalanceBeforeOVDate += $ovValue['cramount'];
                    }
                }
            }

            $overdueAmount = $drBalanceBeforeOVDate - $crBalanceBeforeOVDate;

            // Calculate overdue days
            foreach ($getData as &$gValue) {
                if (strtotime($gValue['trn_date']) < strtotime($overdueDateFrom) && $gValue['dramount'] > 0) {
                    $dateDifference = abs(strtotime($overdueDateFrom) - strtotime($gValue['trn_date']));
                    $daysOverdue = floor($dateDifference / (60 * 60 * 24)); // Convert to days

                    // Assign overdue status and days
                    $gValue['overdue_status'] = $overdueAmount > 0 ? 'Overdue' : 'Partial Overdue';
                    $gValue['overdue_by_day'] = $daysOverdue . ' days';
                }
            }

            return [
                'dueAmount' => $dueAmount,
                'overdueAmount' => $overdueAmount,
            ];
        } else {
            // Log or handle the missing 'data' key case
            return [
                'dueAmount' => 0,
                'overdueAmount' => 0,
            ];
        }
    }

    // Default to zero if the API call fails
    return [
        'dueAmount' => 0,
        'overdueAmount' => 0,
    ];
}
    

    public function createStatementPdf(Request $request)
    {
        $party_code = $request->input('party_code');
        $dueAmount = $request->input('due_amount');
        $overdueAmount = $request->input('overdue_amount');
        $userId = $request->input('user_id');

        $user=User::find($userId);

        // return response()->json([
        //     'success' => true,
        //     'pdf_url' => $overdueAmount
        // ]);

        // Call the method to generate the PDF
        $pdfUrl = $this->generateStatementPdf($party_code, $dueAmount, $overdueAmount, User::find($userId));
        $fileName = basename($pdfUrl);

        $message="statement";
       // $to="7044300330"; 
        $to = $user->phone;
        $templateData = [
            'name' => 'utility_statement_document', // Replace with your template name, 
            'language' => 'en_US', // Replace with your desired language code
            'components' => [
                [
                    'type' => 'header',
                    'parameters' => [
                        ['type' => 'document', 'document' => ['link' => $pdfUrl,'filename' => $fileName,]],
                    ],
                ],
                [
                    'type' => 'body',
                    'parameters' => [
                        ['type' => 'text', 'text' => $user->company_name],
                        ['type' => 'text', 'text' => $message],
                    ],
                ],
                // [
                //     'type' => 'button',
                //     'sub_type' => 'url',
                //     'index' => '0',
                //     'parameters' => [
                //         [
                //             "type" => "text","text" => $fileName // Replace $button_text with the actual Parameter for the button.
                //         ],
                //     ],
                // ],
            ],
        ];

        // Send the template message using the WhatsApp web service
        $this->whatsAppWebService = new WhatsAppWebService();
        $jsonResponse  = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);
               
        if ($pdfUrl) {
            return response()->json([
                'success' => true,
                'pdf_url' => "Statement Sent to whatsapp"
            ]);
        } else {
            return response()->json(['success' => false]);
        }
    }


    public function generateBulkStatements(Request $request)
    {
        $allData = $request->input('all_data');
        $user = User::find($allData[1]['user_id']);

       
        
        // Loop through the data and generate PDFs for each entry
        foreach ($allData as $data) {
            $party_code = $data['party_code'];
            $due_amount = $data['due_amount'];
            $overdue_amount = $data['overdue_amount'];
            $user_id = $data['user_id'];
            
            // Find the user
            $user = User::find($user_id);

            // Assuming you have a method to generate the PDF for each entry
            $pdfUrl = $this->generateStatementPdf($party_code, $due_amount, $overdue_amount, $user);
            $fileName = basename($pdfUrl);
            // Prepare message content
            $message = "Statement " ;
            
            // WhatsApp message sending code
            //$to = "7044300330"; // Replace with recipient's phone number
            $to=$user->phone;
            $templateData = [
                'name' => 'utility_statement_document', // Replace with your template name
                'language' => 'en_US', // Replace with your desired language code
                'components' => [
                    [
                        'type' => 'header',
                        'parameters' => [
                            ['type' => 'document', 'document' => ['link' => $pdfUrl,'filename' => $fileName,]],
                        ],
                    ],
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $user->company_name],
                            ['type' => 'text', 'text' => $message],
                        ],
                    ],
                    // [
                    //     'type' => 'button',
                    //     'sub_type' => 'url',
                    //     'index' => '0',
                    //     'parameters' => [
                    //         [
                    //             'type' => 'text',
                    //             'text' => $fileName // Add PDF download link as button parameter
                    //         ],
                    //     ],
                    // ],
                ],
            ];

            // Send the template message using the WhatsApp web service
            $this->whatsAppWebService = new WhatsAppWebService();
            $jsonResponse = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);
            break;
            // Handle the response or logging if needed
        }
         // Return response as needed
         return response()->json([
            'success' => true,
            'pdf_url' => $user->phone
        ]);
    }


    public function generateStatementPdfChecked(Request $request)
    {
        // Get the selected data from the request
        $selectedData = $request->input('selected_data');

   


        // Check if any data is selected
        if (empty($selectedData)) {
            return response()->json(['success' => false, 'message' => 'No users selected.']);
        }

        // Loop through each selected person and process the WhatsApp message
        foreach ($selectedData as $data) {
            $partyCode = $data['party_code'];
            $dueAmount = $data['due_amount'];
            $overdueAmount = $data['overdue_amount'];
            $userId = $data['user_id'];

            $user = User::find($userId);

            // Implement your logic here to send WhatsApp message
           // Assuming you have a method to generate the PDF for each entry
           $pdfUrl = $this->generateStatementPdf($partyCode, $dueAmount, $overdueAmount, $user);
           $fileName = basename($pdfUrl);
           // Prepare message content
           $message = "Statement " ;
           
           // WhatsApp message sending code
           //$to = "7044300330"; // Replace with recipient's phone number
           $to=$user->phone;

           $templateData = [
               'name' => 'utility_statement_document', // Replace with your template name
               'language' => 'en_US', // Replace with your desired language code
               'components' => [
                    [
                        'type' => 'header',
                        'parameters' => [
                            ['type' => 'document', 'document' => ['link' => $pdfUrl,'filename' => $fileName,]],
                        ],
                    ],
                   [
                       'type' => 'body',
                       'parameters' => [
                           ['type' => 'text', 'text' => $user->company_name],
                           ['type' => 'text', 'text' => $message],
                       ],
                   ],
                //    [
                //        'type' => 'button',
                //        'sub_type' => 'url',
                //        'index' => '0',
                //        'parameters' => [
                //            [
                //                'type' => 'text',
                //                'text' => $fileName // Add PDF download link as button parameter
                //            ],
                //        ],
                //    ],
               ],
           ];

           // Send the template message using the WhatsApp web service
           $this->whatsAppWebService = new WhatsAppWebService();
           $jsonResponse = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);
           break;
            
            // For demonstration, you can log the data
            \Log::info("Sending WhatsApp to Party Code: $partyCode, Due: $dueAmount, Overdue: $overdueAmount, User ID: $userId");
        }

        // Return a success response
        return response()->json(['success' => true, 'message' => 'WhatsApp messages sent to selected persons.']);
    }


    public function syncStatement(Request $request)
    {
        $selectedData = $request->input('selected_data');
    
        // Create an instance of PurchaseHistoryController
        $purchaseHistoryController = new PurchaseHistoryController();
    
        foreach ($selectedData as $data) {
            $party_code = $data['party_code'];
    
            // Call the refreshStatementDetails function from PurchaseHistoryController
            $purchaseHistoryController->refreshStatementDetails(new Request(['party_code' => encrypt($party_code)]));
        }
    
        return response()->json(['success' => true]);
    }

      public function statementExport(Request $request)
{
    // Set up customers query with sorting and filters
    $customersQuery = User::leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id')
        ->Join('users as managers', 'users.manager_id', '=', 'managers.id')
        ->Join('addresses', 'users.party_code', '=', 'addresses.acc_code')
        ->where('users.user_type', 'customer')
        ->select(
            'users.*',
            'warehouses.name as warehouse_name',
            'managers.name as manager_name'
        )
        ->orderBy('warehouses.name', 'asc') // Sort by warehouse name
        ->orderBy('managers.name', 'asc') // Then sort by manager name
        ->orderBy('addresses.city', 'asc') // Then sort by city
        ->groupBy(DB::raw("CONCAT(REPLACE(users.name, ' ', '_'), '_', addresses.acc_code)")); // Group by ledgercode

    // Apply filters for manager and warehouse
    if ($request->has('manager_id') && !empty($request->manager_id)) {
        $customersQuery->where('users.manager_id', $request->manager_id);
    }

    if ($request->has('warehouse_id') && !empty($request->warehouse_id)) {
        $customersQuery->where('users.warehouse_id', $request->warehouse_id);
    }

    // Apply filter for due and overdue amounts
    if ($request->has('duefilter') && !empty($request->duefilter)) {
        if ($request->duefilter === 'due') {
            $customersQuery->whereExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('addresses')
                    ->whereColumn('addresses.user_id', 'users.id')
                    ->where('addresses.due_amount', '>', 0);
            });
        } elseif ($request->duefilter === 'overdue') {
            $customersQuery->whereExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('addresses')
                    ->whereColumn('addresses.user_id', 'users.id')
                    ->where('addresses.overdue_amount', '>', 0);
            });
        }
    }

    // Fetch customers and their respective addresses
    $customers = $customersQuery->get();
    $processedData = [];
    $totalDueAmount = 0;
    $totalOverdueAmount = 0;

    foreach ($customers as $userData) {
        $userAddressData = Address::where('user_id', $userData->id)
            ->select('gstin', 'acc_code', 'due_amount', 'overdue_amount', 'company_name', 'city')
            ->orderBy('city', 'ASC')
            ->get();

        // Fetch manager and warehouse names for export
        $managerName = $userData->manager_name ?? 'N/A';
        $warehouseName = $userData->warehouse_name ?? 'N/A';

        foreach ($userAddressData as $address) {
            // Ensure both due_amount and overdue_amount are greater than zero
            if ($address->due_amount > 0 || $address->overdue_amount > 0) {
                $processedData[] = [
                    'Party Name' => $userData->company_name,
                    'Party Code' => $address->acc_code,
                    'Phone' => $userData->phone,
                    'Manager' => $managerName,
                    'Warehouse' => $warehouseName,
                    'City' => $address->city,
                    'Due Amount' => $address->due_amount,
                    'Overdue Amount' => $address->overdue_amount,
                ];

                // Add to total amounts
                $totalDueAmount += $address->due_amount;
                $totalOverdueAmount += $address->overdue_amount;
            }
        }
    }

    // Add the total row only if there are filtered results
    if (count($processedData) > 0) {
        $processedData[] = [
            'Party Name' => 'TOTAL',
            'Party Code' => '',
            'Phone' => '',
            'Manager' => '',
            'Warehouse' => '',
            'City' => '',
            'Due Amount' => $totalDueAmount,
            'Overdue Amount' => $totalOverdueAmount,
        ];
    }

    // Export the processed data to Excel
    return Excel::download(new \App\Exports\StatementExport($processedData), 'statements.xlsx');
}



    public function generateBulkOrCheckedStatements(Request $request)
    {
        $allData = $request->input('all_data'); 

        // Ensure allData is not empty
        if (empty($allData)) {
            return response()->json(['success' => false, 'message' => 'No data available to send.']);
        }

        // Generate a unique group ID for this batch of messages
        $groupId = uniqid('group_', true);

        // Loop through the data and generate PDFs/WhatsApp messages
        foreach ($allData as $data) {
            $party_code = $data['party_code'];
            $due_amount = $data['due_amount'];
            $overdue_amount = $data['overdue_amount'];
            $user_id = $data['user_id'];

            // Find the user
            $user = User::find($user_id);
            if (!$user) {
                continue; // Skip if the user does not exist
            }

            // Get user, manager, and head manager phone numbers
            $phone = $user->phone;
            $managerPhone = $this->getManagerPhone($user->manager_id);
            $headManagerPhone = $this->getHeadManagerPhone($user->warehouse_id);

            // Generate the PDF statement
            $pdfUrl = $this->generateStatementPdf($party_code, $due_amount, $overdue_amount, $user);
            $fileName = basename($pdfUrl);

            // Generate the payment URL
            $payment_url = $this->generatePaymentUrl($party_code, $payment_for = "custom_amount");
            $payNowBtn = substr($payment_url, strpos($payment_url, "pay-amount/") + strlen("pay-amount/"));
            $button_variable_encode_part = $payNowBtn;

            // Prepare the template data
            $templateData = [
                'name' => 'utility_statement_document',
                'language' => 'en_US',
                'components' => [
                    [
                        'type' => 'header',
                        'parameters' => [
                            ['type' => 'document', 'document' => ['link' => $pdfUrl, 'filename' => $fileName]],
                        ],
                    ],
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $user->company_name ?? 'No Company Name'],
                            ['type' => 'text', 'text' => $due_amount],
                            ['type' => 'text', 'text' => $overdue_amount],
                            ['type' => 'text', 'text' => $managerPhone],
                        ],
                    ],
                    [
                        'type' => 'button',
                        'sub_type' => 'url',
                        'index' => '0',
                        'parameters' => [
                            ["type" => "text", "text" => $button_variable_encode_part],
                        ],
                    ],
                ],
            ];

            // Insert message for the user
            DB::table('wa_sales_queue')->insert([
                'group_id' => $groupId,
                'callback_data' => $templateData['name'],
                'recipient_type' => 'individual',
                'to_number' => $phone,
                'type' => 'template',
                'file_url' => $pdfUrl,
                'file_name' => $party_code,
                'content' => json_encode($templateData),
                'status' => 'pending',
                'response' => '',
                'msg_id' => '',
                'msg_status' => '',
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Insert message for the manager
            // if ($managerPhone) {
            //     DB::table('wa_sales_queue')->insert([
            //         'group_id' => $groupId,
            //         'callback_data' => $templateData['name'],
            //         'recipient_type' => 'individual',
            //         'to_number' => $managerPhone,
            //         'type' => 'template',
            //         'file_url' => $pdfUrl,
            //         'content' => json_encode($templateData),
            //         'status' => 'pending',
            //         'response' => '',
            //         'msg_id' => '',
            //         'msg_status' => '',
            //         'created_at' => now(),
            //         'updated_at' => now()
            //     ]);
            // }

            // Insert message for the head manager
            // if ($headManagerPhone) {
            //     DB::table('wa_sales_queue')->insert([
            //         'group_id' => $groupId,
            //         'callback_data' => $templateData['name'],
            //         'recipient_type' => 'individual',
            //         'to_number' => $headManagerPhone,
            //         'type' => 'template',
            //         'file_url' => $pdfUrl,
            //         'content' => json_encode($templateData),
            //         'status' => 'pending',
            //         'response' => '',
            //         'msg_id' => '',
            //         'msg_status' => '',
            //         'created_at' => now(),
            //         'updated_at' => now()
            //     ]);
            // }
        }

        // Dispatch the job to process WhatsApp messages asynchronously
        SendWhatsAppMessagesJob::dispatch($groupId);

        return response()->json(['success' => true, 'message' => 'WhatsApp messages are queued successfully.']);
    }
    public function ____generateBulkOrCheckedStatements(Request $request)
    {
        $allData = $request->input('all_data');
    
        // Ensure allData is not empty
        if (empty($allData)) {
            return response()->json(['success' => false, 'message' => 'No data available to send.']);
        }
    
        // Loop through the data and generate PDFs/WhatsApp messages
        foreach ($allData as $data) {
            $party_code = $data['party_code'];
            $due_amount = $data['due_amount'];
            $overdue_amount = $data['overdue_amount'];
            $user_id = $data['user_id'];
    
            // Find the user
            $user = User::find($user_id);
            $phone=$user->phone;
    
            // Assuming you have a method to generate the PDF for each entry
            $pdfUrl = $this->generateStatementPdf($party_code, $due_amount, $overdue_amount, $user);
            $fileName = basename($pdfUrl);
    
            // Prepare message content
            $message = "Statement for " . $user->company_name;
            $managerId = $user->manager_id;

            // Check if manager_id exists
              if ($managerId) {
                  // Perform query to fetch manager's phone number from users table
                  $managerData = DB::table('users')
                                  ->where('id', $managerId)
                                  ->select('phone')
                                  ->first();
                  
                  // Check if manager data is found
                  if ($managerData && $managerData->phone) {
                      $managerPhone = $managerData->phone;
                  } else {
                      // Fallback if no manager found or no phone number available
                      $managerPhone = null;
                  }
              }
    
            // WhatsApp message sending code
			$payment_url=$this->generatePaymentUrl($party_code,$payment_for="custom_amount");
              $payNowBtn = substr($payment_url, strpos($payment_url, "pay-amount/") + strlen("pay-amount/"));
          $button_variable_encode_part=$payNowBtn;
			
            $to = $phone; // Replace with recipient's phone number
            $templateData = [
                'name' => 'utility_statement_document',
                'language' => 'en_US',
                'components' => [
                    [
                        'type' => 'header',
                        'parameters' => [
                            ['type' => 'document', 'document' => ['link' => $pdfUrl, 'filename' => $fileName]],
                        ],
                    ],
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $user->company_name],
                             ['type' => 'text', 'text' => $due_amount],
                            ['type' => 'text', 'text' => $overdue_amount],
                            ['type' => 'text', 'text' => $managerPhone],
                        ],
                    ],
					 [
                        'type' => 'button',
                        'sub_type' => 'url',
                        'index' => '0',
                        'parameters' => [
                            [
                                "type" => "text",
                                "text" => $button_variable_encode_part // Replace $button_text with the actual Parameter for the button.
                            ],
                        ],
                   ],
                ],
            ];
    
            // Send the template message using the WhatsApp web service
            $this->whatsAppWebService = new WhatsAppWebService();
            $jsonResponse = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);
        }
    
        return response()->json(['success' => true, 'message' => 'WhatsApp messages sent successfully.']);
    }


    public function notifyManager(Request $request)
    {
        $managerIds = $request->input('manager_ids', []);
        $warehouseId = $request->input('warehouse_id');

        // Fetch managers from selected manager IDs
        $managers = User::whereIn('id', $managerIds)->get();

        if ($managers->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'No managers found for the selected options.'
            ]);
        }

        foreach ($managers as $manager) {
            $customers = User::where('user_type', 'customer')
                              ->where('manager_id', $manager->id)
                              ->orderBy('company_name', 'asc')
                              ->get();

            $processedData = [];
            $totalDueAmount = 0;
            $totalOverdueAmount = 0;

            foreach ($customers as $userData) {
                $userAddressData = Address::where('user_id', $userData->id)
                    ->select('city', 'company_name', 'gstin', 'acc_code', 'due_amount', 'overdue_amount') 
                    ->groupBy('gstin')
                    ->orderBy('acc_code', 'ASC')
                    ->get();

                foreach ($userAddressData as $address) {
                    if ($address->due_amount > 0 || $address->overdue_amount > 0) {
                        $totalDueAmount += $address->due_amount;
                        $totalOverdueAmount += $address->overdue_amount;

                        $processedData[] = [
                            'customer' => ['company_name' => $address->company_name],
                            'address' => $address,
                            'phone' => $userData->phone,
                            'city' => $address->city
                        ];
                    }
                }
            }

            usort($processedData, function ($a, $b) {
                $cityComparison = strcmp($a['city'], $b['city']);
                if ($cityComparison !== 0) {
                    return $cityComparison;
                }
                $companyNameComparison = strcmp($a['customer']['company_name'], $b['customer']['company_name']);
                if ($companyNameComparison !== 0) {
                    return $companyNameComparison;
                }
                return $b['address']->overdue_amount <=> $a['address']->overdue_amount;
            });

            if (!empty($processedData)) {
                $fileName = 'Manager_Report_' . $manager->name . '_' . rand(1000, 9999) . '.pdf';
                $pdf = PDF::loadView('backend.statement.manager-report', [
                    'manager_name' => $manager->name,
                    'processedData' => $processedData,
                    'totalDueAmount' => $totalDueAmount,
                    'totalOverdueAmount' => $totalOverdueAmount
                ])->save(public_path('statements/' . $fileName));

                $publicUrl = url('public/statements/' . $fileName);

                $templateData = [
                    'name' => 'utility_statement_manager_notify',
                    'language' => 'en_US',
                    'components' => [
                        [
                            'type' => 'header',
                            'parameters' => [['type' => 'document', 'document' => ['link' => $publicUrl, 'filename' => $fileName]]],
                        ],
                        [
                            'type' => 'body',
                            'parameters' => [
                                ['type' => 'text', 'text' => $manager->name],
                                ['type' => 'text', 'text' => $totalDueAmount],
                                ['type' => 'text', 'text' => $totalOverdueAmount],
                            ],
                        ],
                    ],
                ];

                $this->whatsAppWebService = new WhatsAppWebService();
                $jsonResponse = $this->whatsAppWebService->sendTemplateMessage($manager->phone, $templateData);
            }
        }

        return response()->json([
            'status' => true,
            'message' => 'Report generated and notification sent successfully.',
        ], 200);
    }



    public function ___notifyManager(Request $request)
    {
        $managerId = $request->input('manager_id');

        // Fetch the manager details from the database using the manager_id
        $manager = User::find($managerId);

        // Check if the manager exists
        if ($manager) {
            // Initialize the customers query for the selected manager
            $customersQuery = User::where('user_type', 'customer')
                                  ->where('manager_id', $managerId)
                                  ->orderBy('company_name', 'asc'); // Sort by company name initially

            // Fetch all customers managed by the manager
            $customers = $customersQuery->get();

            // Initialize an array to store the processed data
            $processedData = [];
            $totalDueAmount = 0;
            $totalOverdueAmount = 0;

            // Iterate over each customer and fetch their due/overdue data from the addresses table
            foreach ($customers as $userData) {
                $userAddressData = Address::where('user_id', $userData->id)
                    ->select('city', 'company_name', 'gstin', 'acc_code', 'due_amount', 'overdue_amount') 
                    ->groupBy('gstin')
                    ->orderBy('acc_code', 'ASC')
                    ->get();

                // If no address data is found, continue to the next iteration
                if ($userAddressData->isEmpty()) {
                    continue;
                }

                // Fetch the phone number from the `users` table
                $phone = $userData->phone;

                // Assign due and overdue amounts from the addresses table
                foreach ($userAddressData as $address) {
                    $city = $address->city;  // City from the addresses table
                    $companyName = $address->company_name;  // Company name from the addresses table

                    // Only include records where due_amount or overdue_amount is greater than 0
                    if ($address->due_amount > 0 || $address->overdue_amount > 0) {
                        // Add due and overdue amounts to the totals
                        $totalDueAmount += $address->due_amount;
                        $totalOverdueAmount += $address->overdue_amount;

                        // Store the processed data
                        $processedData[] = [
                            'customer' => [
                                'company_name' => $companyName
                            ],
                            'address' => $address,
                            'phone' => $phone,
                            'city' => $city
                        ];
                    }
                }
            }

            // Sort the data by city, customer name (from addresses table), and overdue amount
            usort($processedData, function ($a, $b) {
                // Sort by city first
                $cityComparison = strcmp($a['city'], $b['city']);
                if ($cityComparison !== 0) {
                    return $cityComparison;
                }

                // If city is the same, sort by company name (from the addresses table)
                $companyNameComparison = strcmp($a['customer']['company_name'], $b['customer']['company_name']);
                if ($companyNameComparison !== 0) {
                    return $companyNameComparison;
                }

                // If company name is also the same, sort by overdue amount (descending)
                return $b['address']->overdue_amount <=> $a['address']->overdue_amount;
            });

            // Generate a random file name for the PDF
            $randomNumber = rand(1000, 9999);
            $fileName = 'Manager_Report_' . $manager->name . '_' . $randomNumber . '.pdf';

            // Prepare PDF content using Blade template
            $pdf = PDF::loadView('backend.statement.manager-report', [
                'manager_name' => $manager->name,
                'processedData' => $processedData, // Flattened and sorted data
                'totalDueAmount' => $totalDueAmount,
                'totalOverdueAmount' => $totalOverdueAmount
            ])->save(public_path('statements/' . $fileName));

            // Generate the public URL
            $publicUrl = url('public/statements/' . $fileName);

            //whatsapp code start

                    $message="statement";
                   // $to="7044300330"; 
                    //$phone = $manager->phone;
                    $to = '7044300330';
                    $templateData = [
                        'name' => 'utility_statement_manager_notify', // Replace with your template name, 
                        'language' => 'en_US', // Replace with your desired language code
                        'components' => [
                            [
                                'type' => 'header',
                                'parameters' => [
                                    ['type' => 'document', 'document' => ['link' => $publicUrl,'filename' => $fileName,]],
                                ],
                            ],
                            [
                                'type' => 'body',
                                'parameters' => [
                                    ['type' => 'text', 'text' => $manager->name],
                                    ['type' => 'text', 'text' => $totalDueAmount],
                                    ['type' => 'text', 'text' => $totalOverdueAmount],
                                ],
                            ],
                            // [
                            //     'type' => 'button',
                            //     'sub_type' => 'url',
                            //     'index' => '0',
                            //     'parameters' => [
                            //         [
                            //             "type" => "text","text" => $fileName // Replace $button_text with the actual Parameter for the button.
                            //         ],
                            //     ],
                            // ],
                        ],
                    ];

                    // Send the template message using the WhatsApp web service
                    $this->whatsAppWebService = new WhatsAppWebService();
                    $jsonResponse  = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);

                //whatsapp code end

            // Return the public URL as a response
            return response()->json([
                'status' => true,
                'message' => 'Report generated successfully.',
                'url' => $publicUrl
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Manager not found.'
            ]);
        }
    }

    public function submitComment(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'party_code' => 'required|string|exists:addresses,acc_code', // Validate that the party_code exists in the addresses table
            'statement_comment' => 'required|string',
            'statement_comment_date' => 'required|date',
        ]);

        // Update all records matching the acc_code
        $updated = Address::where('acc_code', $request->party_code)
                          ->update([
                              'statement_comment' => $request->statement_comment,
                              'statement_comment_date' => $request->statement_comment_date
                          ]);

        if ($updated) {
            return response()->json(['success' => true, 'message' => 'Comment and date updated successfully']);
        } else {
            return response()->json(['success' => false, 'message' => 'No addresses were updated for this party code']);
        }
    }



   


   /*public function getAllUsersData(Request $request)
    {

        // Increase memory limit and execution time to avoid timeouts
        set_time_limit(-1);  // Set max execution time to 3000 seconds (50 minutes)
        header('Keep-Alive: timeout=86400, max=100');
        header('Cache-Control: no-cache');
        header('Connection: Keep-Alive');
        ini_set('memory_limit', '512M');
        

        $groupId = uniqid('group_', true);  // Generate the same group_id for all users in this "run"
        
        try {
            // Start processing users in the background using chunking
            User::join('addresses', 'users.id', '=', 'addresses.user_id')
                ->select('users.party_code', 'addresses.due_amount', 'addresses.overdue_amount', 'users.id as user_id')
                ->where(function($query) {
                    $query->where('addresses.due_amount', '>', 0)
                          ->orWhere('addresses.overdue_amount', '>', 0);
                })
                ->chunk(300, function ($users) use ($groupId) {
                    try {
                        // Log the start of chunk processing
                        Log::info("Processing a chunk of users", ['group_id' => $groupId, 'user_count' => count($users)]);

                        // Dispatch the job to send WhatsApp messages
                        SendWhatsAppMessagesJob::dispatch($users->toArray(), $groupId);

                        // Log successful dispatch
                        Log::info("Successfully dispatched WhatsApp messages", ['group_id' => $groupId]);

                    } catch (\Exception $e) {
                        // Log the exception if something goes wrong
                        Log::error("Error while processing chunk of users", ['error' => $e->getMessage(), 'group_id' => $groupId]);
                    }
                });
            
            // Log overall success
            Log::info("All chunks have been processed for group", ['group_id' => $groupId]);
        } catch (\Exception $e) {
            // Log the exception if the whole process fails
            Log::error("Error in getAllUsersData function", ['error' => $e->getMessage()]);
        }

        // Return success response immediately after dispatching the job
        return response()->json(['success' => true, 'message' => 'WhatsApp messages are being processed in the background.']);
    }*/
	
public function getAllUsersData(Request $request)
{
    // Increase memory limit and execution time to avoid timeouts
    set_time_limit(-1);  // No timeout
    header('Keep-Alive: timeout=86400, max=100');
    header('Cache-Control: no-cache');
    header('Connection: Keep-Alive');
    ini_set('memory_limit', '512M');
    
    $groupId = uniqid('group_', true);  // Generate a unique group_id

    // Retrieve filter parameters
    $warehouseId = $request->warehouse_id;
    $managerId = $request->manager_id;
    $duefilter = $request->duefilter;

    try {
        $query = User::join('addresses', 'users.id', '=', 'addresses.user_id')
            ->select(
                'users.party_code', 
                'addresses.due_amount', 
                'addresses.overdue_amount', 
                'users.id as user_id', 
                'users.company_name', 
                'users.phone',   // Ensure that phone is selected
                'users.manager_id',  // Ensure manager_id is selected to fetch manager phone later
                'users.warehouse_id'
            )
            ->where(function($query) use ($duefilter) {
                if ($duefilter === 'due') {
                    $query->where('addresses.due_amount', '>', 0);
                } elseif ($duefilter === 'overdue') {
                    $query->where('addresses.overdue_amount', '>', 0);
                } else {
                    $query->where(function ($q) {
                        $q->where('addresses.due_amount', '>', 0)
                          ->orWhere('addresses.overdue_amount', '>', 0);
                    });
                }
            });

        // Apply warehouse and manager filters if provided
        if ($warehouseId) {
            $query->where('users.warehouse_id', $warehouseId);
        }
        if ($managerId) {
            $query->where('users.manager_id', $managerId);
        }

        $query->chunk(300, function ($users) use ($groupId) {
            foreach ($users as $user) {
                try {
                    // Get the manager's phone number
                    $managerPhone = $this->getManagerPhone($user->manager_id);
                    $headManagerPhone = $this->getHeadManagerPhone($user->warehouse_id);

                    // Generate the PDF and get the file URL
                    $pdfUrl = $this->generateStatementPdf($user->party_code, $user->due_amount, $user->overdue_amount, $user);
                    $fileName = basename($pdfUrl);
                    
                    $payment_url = $this->generatePaymentUrl($user->party_code, $payment_for = "custom_amount");
                    $payNowBtn = substr($payment_url, strpos($payment_url, "pay-amount/") + strlen("pay-amount/"));
                    $button_variable_encode_part = $payNowBtn;
                    
                    // Prepare the template data for insertion
                    $templateData = [
                        'name' => 'utility_statement_document',
                        'language' => 'en_US',
                        'components' => [
                            [
                                'type' => 'header',
                                'parameters' => [
                                    ['type' => 'document', 'document' => ['link' => $pdfUrl, 'filename' => $fileName]],
                                ],
                            ],
                            [
                                'type' => 'body',
                                'parameters' => [               
                                    ['type' => 'text', 'text' => $user->company_name ?? 'No Company Name'],
                                    ['type' => 'text', 'text' => $user->due_amount],
                                    ['type' => 'text', 'text' => $user->overdue_amount],
                                    ['type' => 'text', 'text' => $managerPhone]
                                ],
                            ],
                            [
                                'type' => 'button',
                                'sub_type' => 'url',
                                'index' => '0',
                                'parameters' => [
                                    [
                                        "type" => "text",
                                        "text" => $button_variable_encode_part
                                    ],
                                ],
                            ],
                        ],
                    ];

                    // Insert data into wa_sales_queue table
                    DB::table('wa_sales_queue')->insert([
                        'group_id' => $groupId,
                        'callback_data' => $templateData['name'],
                        'recipient_type' => 'individual',
                        'to_number' => $user->phone,
                        'type' => 'template',
                        'file_url' => $pdfUrl,
                        'file_name'=>$user->party_code,
                        'content' => json_encode($templateData),
                        'status' => 'pending',
                        'response' => '',
                        'msg_id' => '',
                        'msg_status' => '',
                        'created_at' => now(),
                        'updated_at' => now()
                    ]);

                    // Insert message for the manager
                        // DB::table('wa_sales_queue')->insert([
                        //     'group_id' => $groupId,
                        //     'callback_data' => $templateData['name'],
                        //     'recipient_type' => 'individual',
                        //     'to_number' => $managerPhone,
                        //     'type' => 'template',
                        //     'file_url' => $pdfUrl,
                        //     'content' => json_encode($templateData),
                        //     'status' => 'pending',
                        //     'response' => '',
                        //     'msg_id' => '',
                        //     'msg_status' => '',
                        //     'created_at' => now(),
                        //     'updated_at' => now()
                        // ]);

                        // Insert message for the head manager
                        // DB::table('wa_sales_queue')->insert([
                        //     'group_id' => $groupId,
                        //     'callback_data' => $templateData['name'],
                        //     'recipient_type' => 'individual',
                        //     'to_number' => $headManagerPhone,
                        //     'type' => 'template',
                        //     'file_url' => $pdfUrl,
                        //     'content' => json_encode($templateData),
                        //     'status' => 'pending',
                        //     'response' => '',
                        //     'msg_id' => '',
                        //     'msg_status' => '',
                        //     'created_at' => now(),
                        //     'updated_at' => now()
                        // ]);

                } catch (\Exception $e) {
                    Log::error("Error processing user ID {$user->user_id}: {$e->getMessage()}");
                    continue;
                }
            }
        });

        // Return the group_id as part of the response
        return response()->json(['success' => true, 'group_id' => $groupId]);

    } catch (\Exception $e) {
        Log::error("Error in getAllUsersData function", ['error' => $e->getMessage()]);
        return response()->json(['success' => false, 'message' => 'Error processing data']);
    }
}






public function processWhatsapp(Request $request)
{
    // Validate the request to ensure 'group_id' is present
    // $request->validate([
    //     'group_id' => 'required'
    // ]);

    // $groupId = $request->input('group_id');
    $groupId = 124;

    

    // Dispatch the job to process WhatsApp messages asynchronously
   SendWhatsAppMessagesJob::dispatch($groupId);

    // Return a response immediately while the job processes in the background
    return response()->json([
        'success' => true,
        'message' => 'WhatsApp messages are being processed',
        'group_id' => $groupId
    ]);
}
public function __processWhatsapp(Request $request)
{
    // Validate the request to ensure 'group_id' is present
    $request->validate([
        'group_id' => 'required'
    ]);

    $groupId = $request->input('group_id');

    // Retrieve users from the wa_sales_queue where group_id matches and status is 'pending'
    $messages = DB::table('wa_sales_queue')
        ->where('group_id', $groupId)
        ->where('status', 'pending')  // Only process 'pending' messages
        ->get();

    foreach ($messages as $message) {
        try {
           

            // Prepare WhatsApp message content from the message record
            $templateData = json_decode($message->content, true);
			  // Return a success response after processing
				
          


            // Send the WhatsApp message using your WhatsApp API service
            $whatsAppWebService = new WhatsAppWebService();
            $jsonResponse = $whatsAppWebService->sendTemplateMessage($message->to_number, $templateData);

            // Extract response details from the WhatsApp API response
            $messageId = $jsonResponse['messages'][0]['id'] ?? '';
		
            $messageStatus = $jsonResponse['messages'][0]['message_status'] ?? 'unknown';

            // Update the wa_sales_queue with the response details
            DB::table('wa_sales_queue')
                ->where('id', $message->id)  // Update by the primary key 'id'
                ->update([
                    'status' => 'sent',  // Mark the message as 'sent'
                    'response' => json_encode($jsonResponse),  // Store the API response
                    'msg_id' => $messageId,  // Store the message ID
                    'msg_status' => $messageStatus,  // Store the message status
                    'updated_at' => now()  // Update the timestamp
                ]);

        } catch (Exception $e) {
            // Log the error and continue with the next message
            Log::error('Error sending WhatsApp message for ID ' . $message->id . ': ' . $e->getMessage());
            continue;  // Continue to the next message even if an error occurs
        }
    }

    // Return a success response after processing
    return response()->json([
        'success' => true,
        'message' => 'WhatsApp messages processed successfully',
        'group_id' => $groupId
    ]);
}


/**
 * Get the manager's phone number.
 */
private function getManagerPhone($managerId)
{
    $managerData = DB::table('users')
        ->where('id', $managerId)
        ->select('phone')
        ->first();

    return $managerData->phone ?? 'No Manager Phone';  // Default in case manager phone is not found
}

public function __getAllUsersData(Request $request)
{
    // Set the maximum execution time to 300 seconds (5 minutes)
     set_time_limit(3000000);
    
    // Fetch users who have either a due amount or an overdue amount greater than 0
    $users = User::join('addresses', 'users.id', '=', 'addresses.user_id')
                 ->select('users.party_code', 'addresses.due_amount', 'addresses.overdue_amount', 'users.id as user_id')
                 ->where(function($query) {
                     $query->where('addresses.due_amount', '>', 0)
                           ->orWhere('addresses.overdue_amount', '>', 0);
                 })
              
                 ->get();

    // Ensure we have users to send WhatsApp messages to
    if ($users->isEmpty()) {
        return response()->json(['success' => false, 'message' => 'No users with due or overdue amounts found.']);
    }

    // Generate the same group_id for all users in this "run"
    $groupId = uniqid('group_', true);

    // Loop through the users and send WhatsApp messages
    foreach ($users as $user) {
        try {
            $party_code = $user->party_code;
            $due_amount = $user->due_amount;
            $overdue_amount = $user->overdue_amount;
            $user_id = $user->user_id;

            // Find the user by ID
            $userData = User::find($user_id);
            if (!$userData) {
                throw new Exception("User not found");
            }

            // Generate the PDF for each user within a try-catch block to handle errors
            try {
                $pdfUrl = $this->generateStatementPdf($party_code, $due_amount, $overdue_amount, $userData);
                $fileName = basename($pdfUrl);
            } catch (Exception $pdfException) {
                \Log::error('Error generating PDF for user ID ' . $user_id . ': ' . $pdfException->getMessage());
                continue; // Skip to the next user if PDF generation fails
            }

            // Prepare message content
            $message = "Statement for " . $userData->company_name;

            $managerId = $userData->manager_id;
              // Check if manager_id exists
              if ($managerId) {
                  // Perform query to fetch manager's phone number from users table
                  $managerData = DB::table('users')
                                  ->where('id', $managerId)
                                  ->select('phone')
                                  ->first();
                  
                  // Check if manager data is found
                  if ($managerData && $managerData->phone) {
                      $managerPhone = $managerData->phone;
                  } else {
                      // Fallback if no manager found or no phone number available
                      $managerPhone = null;
                  }
              }

            // WhatsApp message sending code
            $to = 7044300330; // Replace with the user's phone number
            $templateData = [
                'name' => 'utility_statement_document',
                'language' => 'en_US',
                'components' => [
                    [
                        'type' => 'header',
                        'parameters' => [
                            ['type' => 'document', 'document' => ['link' => $pdfUrl, 'filename' => $fileName]],
                        ],
                    ],
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $userData->company_name],
                             ['type' => 'text', 'text' => $due_amount],
                            ['type' => 'text', 'text' => $overdue_amount],
                            ['type' => 'text', 'text' => $managerPhone],
                        ],
                    ],
                ],
            ];

            // Send the template message using the WhatsApp web service
            $this->whatsAppWebService = new WhatsAppWebService();
            $jsonResponse = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);

            // Check if response is already an array or a string
            $responseData = is_array($jsonResponse) ? $jsonResponse : json_decode($jsonResponse, true);

            if (!is_array($responseData)) {
                throw new Exception("Invalid response format");
            }

            // Extract message ID and message status from the response
            $messageId = $responseData['messages'][0]['id'] ?? null; // Extract message ID
            $messageStatus = $responseData['messages'][0]['message_status'] ?? 'unknown'; // Extract message status

            // Insert into wa_sales_queue table
            DB::table('wa_sales_queue')->insert([
                'group_id' => $groupId, // Use the same group_id for all users
                'callback_data' => $templateData['name'], // Set the callback_data to the template name
                'recipient_type' => 'individual', // Change as needed
                'to_number' => $to,
                'type' => 'template',
                'file_url' => $pdfUrl,
                'content' => json_encode($templateData),
                'status' => 'sent', // Change status based on the response
                'response' => json_encode($jsonResponse), // Log response
                'msg_id' => $messageId, // Insert extracted message ID
                'msg_status' => $messageStatus, // Insert extracted message status
                'created_at' => now(),
                'updated_at' => now()
            ]);

            break;

        } catch (Exception $e) {
            // Log the error and skip this user
            \Log::error('Error processing user ID ' . $user_id . ': ' . $e->getMessage());
            continue; // Skip to the next user in case of error
        }
    }

    return response()->json(['success' => true, 'message' => 'WhatsApp messages sent and data inserted into queue.']);
}





    public function sendRemainderWhatsAppForStatements()
    {
        // Get current date
        $currentDate = date('Y-m-d');
        
        // Fetch users from the address table where statement_comment and statement_comment_date are not blank and match the current date
        $users = DB::table('addresses')
                    ->whereNotNull('statement_comment')
                    ->whereNotNull('statement_comment_date')
                    ->whereDate('statement_comment_date', $currentDate)
                    ->get();

        // Check if any users exist
        if ($users->isEmpty()) {
            return response()->json(['success' => false, 'message' => 'No users with comments to send WhatsApp message today.']);
        }

        foreach ($users as $user) {
            $party_code = $user->acc_code;
            $statement_comment = $user->statement_comment;
            $statement_comment_date = $user->statement_comment_date;
            $due_amount = $user->due_amount; // Assuming you have a due_amount field
            $overdue_amount = $user->overdue_amount; // Assuming you have an overdue_amount field
            
            // Generate the PDF using the generateStatementPdf function
            $pdfUrl = $this->generateStatementPdf($party_code, $due_amount, $overdue_amount, $user);
            $fileName = basename($pdfUrl);

            // Generate the message
            $message = "Statement";
			$managerId = DB::table('users')
				->where('id', $user->user_id)
				->value('manager_id');
			
			

          // Check if manager_id exists
          if ($managerId) {
              // Perform query to fetch manager's phone number from users table
              $managerData = DB::table('users')
                              ->where('id', $managerId)
                              ->select('phone')
                              ->first();
              
              // Check if manager data is found
              if ($managerData && $managerData->phone) {
                  $managerPhone = $managerData->phone;
              } else {
                  // Fallback if no manager found or no phone number available
                  $managerPhone = null;
              }
          }

            // WhatsApp message sending code
            $to = $user->phone; // Replace with recipient's phone number
            $templateData = [
                'name' => 'utility_remainder_statement',
                'language' => 'en_US',
                'components' => [
                    [
                        'type' => 'header',
                        'parameters' => [
                            ['type' => 'document', 'document' => ['link' => $pdfUrl, 'filename' => $fileName]],
                        ],
                    ],
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $user->company_name],
                            ['type' => 'text', 'text' => $due_amount],
                            ['type' => 'text', 'text' => $overdue_amount],
                            ['type' => 'text', 'text' => $managerPhone],
                        ],
                    ],
                ],
            ];

            // Send the template message using the WhatsApp web service
            $this->whatsAppWebService = new WhatsAppWebService();
            $jsonResponse = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);
            // echo "<pre>";
            // print_r($jsonResponse);
            // die(); 
        }

        return response()->json(['success' => true, 'message' => 'WhatsApp messages sent successfully with PDFs.']);
    }


    public function __sendRemainderWhatsAppForStatements()
    {
        // Get current date
        $currentDate = date('Y-m-d');
        
        // Fetch users from the address table where statement_comment and statement_comment_date are not blank and match the current date
        $users = DB::table('addresses')
                    ->whereNotNull('statement_comment')
                    ->whereNotNull('statement_comment_date')
                    ->whereDate('statement_comment_date', $currentDate)
                    ->get();

        // Check if any users exist
        if ($users->isEmpty()) {
            return response()->json(['success' => false, 'message' => 'No users with comments to save WhatsApp data today.']);
        }

        foreach ($users as $user) {
            $party_code = $user->acc_code;
            $statement_comment = $user->statement_comment;
            $statement_comment_date = $user->statement_comment_date;
            $due_amount = $user->due_amount; // Assuming you have a due_amount field
            $overdue_amount = $user->overdue_amount; // Assuming you have an overdue_amount field
            
            // Generate the PDF using the generateStatementPdf function
            $pdfUrl = $this->generateStatementPdf($party_code, $due_amount, $overdue_amount, $user);
            $fileName = basename($pdfUrl);

            // Prepare the template data
            $templateData = [
                'name' => 'utility_remainder_statement',
                'language' => 'en_US',
                'components' => [
                    [
                        'type' => 'header',
                        'parameters' => [
                            ['type' => 'document', 'document' => ['link' => $pdfUrl, 'filename' => $fileName]],
                        ],
                    ],
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $user->company_name],
                            ['type' => 'text', 'text' => $due_amount],
                            ['type' => 'text', 'text' => $overdue_amount],
                        ],
                    ],
                ],
            ];

            // Convert the templateData to JSON format
            $templateDataJson = json_encode($templateData);

            // Get the template name dynamically from templateData
            $templateName = $templateData['name'];

            // Prepare the data for wa_sales_queue table
            $whatsappData = [
                'group_id' => '', // Set to empty string or a valid ID if available
                'callback_data' => $templateName, // Set the template name dynamically in callback_data
                'recipient_type' => 'individual', // Adjust as necessary
                'to_number' => '7044300330', // Replace with recipient's phone number
                'type' => 'template', // Set the type to template
                'file_url' => $pdfUrl, // File URL for the document
                'content' => $templateDataJson, // Save the JSON formatted template data
                'status' => 'pending', // Set the initial status to pending
                'response' => '', // Set an empty string for response instead of null
                'msg_id' => '', // Set an empty string for msg_id instead of null
                'msg_status' => '',
                'created_at' => now(),
                'updated_at' => now(),
            ];

            // Insert into the wa_sales_queue table
            DB::table('wa_sales_queue')->insert($whatsappData);
        }

        return response()->json(['success' => true, 'message' => 'WhatsApp data saved successfully in wa_sales_queue.']);
    }


     public function deletePdfFiles()
    {
        //THis function is for cron
        // Define an array of folder names
        $folders = ['statements', 'pdfs']; // Add more folder names if needed

        $pdfDeleted = false;
        $resultMessages = [];

        // Loop through each folder in the array
        foreach ($folders as $folderName) {
            // Dynamic path based on folder name
            $path = public_path($folderName);

            // Check if the folder exists
            if (File::exists($path)) {
                // Get all files in the folder
                $pdfFiles = File::files($path);

                $folderHasPdfToDelete = false;

                foreach ($pdfFiles as $file) {
                    // Check if the file has a .pdf extension
                    if (File::extension($file) == 'pdf') {
                        // Get the last modified time of the file
                        $lastModified = Carbon::createFromTimestamp(File::lastModified($file));

                        // Delete files older than 2 days, excluding today's files
                        if ($lastModified->lt(Carbon::now()->subDays(2))) {
                            File::delete($file);
                            $pdfDeleted = true;
                            $folderHasPdfToDelete = true;
                        }
                    }
                }

                // Add result messages based on whether files were deleted or not
                if ($folderHasPdfToDelete) {
                    $resultMessages[] = "Great! PDF files older than 2 days have been deleted from the {$folderName} folder.";
                } else {
                    $resultMessages[] = "No PDF files older than 2 days found to delete in the {$folderName} folder.";
                }
            } else {
                $resultMessages[] = "The {$folderName} folder does not exist.";
            }
        }

        // Return all the result messages as a JSON response
        return response()->json(['messages' => $resultMessages], 200, [], JSON_UNESCAPED_UNICODE);
    }

  private function generatePaymentUrl($party_code, $payment_for)
  {
      $client = new \GuzzleHttp\Client();
      $response = $client->post('https://mazingbusiness.com/api/v2/payment/generate-url', [
          'json' => [
              'party_code' => $party_code,
              'payment_for' => $payment_for
          ]
      ]);

      $data = json_decode($response->getBody(), true);
      return $data['url'] ?? '';  // Return the generated URL or an empty string if it fails
  }


    public function __paymentPendingRemainder() {
        
        $pendingPayments = DB::table('payment_histories')
                            ->join('addresses', DB::raw('payment_histories.party_code COLLATE utf8mb3_unicode_ci'), '=', DB::raw('addresses.acc_code COLLATE utf8mb3_unicode_ci'))
                            ->where('payment_histories.status', 'PENDING')
                            ->whereNotNull('payment_histories.payment_for') // Ensure payment_for is not NULL
                            ->where('payment_histories.payment_for', '!=', '') // Ensure payment_for is not empty
                            ->select('payment_histories.*', 'addresses.*') // Select all columns from both tables
                            ->first();

        // Return the result or do further processing
    
       $customer_name=$pendingPayments->company_name;
       $payment_url=$this->generatePaymentUrl($pendingPayments->party_code, $pendingPayments->payment_for);
       $payment_amt=$pendingPayments->amount;
       // Extract the part after 'pay-amount/'
       $fileName = substr($payment_url, strpos($payment_url, "pay-amount/") + strlen("pay-amount/"));
       $button_variable_encode_part=$fileName;

       $user = DB::table('users')->where('id', $pendingPayments->user_id)->first();
       $manager = DB::table('users')->where('id', $user->manager_id)->first();
       $manager_phone = $manager->phone;
       $pdf_url=$this->generateStatementPdf($pendingPayments->party_code, $pendingPayments->due_amount, $pendingPayments->overdue_amount, $user);
       $fileName1 = basename($pdf_url);
       $button_variable_pdf_filename=$fileName1;
          
       $templateData = [
                'name' => 'utility_payment_pending_remainder', // Don't change this template name
                'language' => 'en_US', 
                'components' => [
                    
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $customer_name],
                            ['type' => 'text', 'text' => $payment_amt],
                            ['type' => 'text', 'text' => $manager_phone],
                            
                            
                        ],
                    ],

                    [
                        'type' => 'button',
                        'sub_type' => 'url',
                        'index' => '0',
                        'parameters' => [
                            [
                                "type" => "text",
                                "text" => $button_variable_encode_part // Replace $button_text with the actual Parameter for the button.
                            ],
                        ],
                    ],
                    [
                        'type' => 'button',
                        'sub_type' => 'url',
                        'index' => '1',
                        'parameters' => [
                            [
                                "type" => "text",
                                "text" => $button_variable_pdf_filename // Replace $button_text with the actual Parameter for the button.
                            ],
                        ],
                    ],
                ],
            ];


            // Convert template data to JSON for logging
            $jsonTemplateData = json_encode($templateData, JSON_PRETTY_PRINT);

            // Step 8: Send the WhatsApp message
            $this->whatsAppWebService = new WhatsAppWebService();
           // $jsonResponse = $this->whatsAppWebService->sendTemplateMessage(7044300330, $templateData);

            // echo "<pre>";
            // print_r($jsonResponse);
            // die();

            // Log the JSON request for debugging purposes
            \Log::info('WhatsApp message sent:', ['request' => $jsonResponse]);
    }


    public function paymentPendingRemainder() {
        
        $pendingPayments = DB::table('payment_histories')
                            ->join('addresses', DB::raw('payment_histories.party_code COLLATE utf8mb3_unicode_ci'), '=', DB::raw('addresses.acc_code COLLATE utf8mb3_unicode_ci'))
                            ->where('payment_histories.status', 'PENDING')
                            ->whereNotNull('payment_histories.payment_for') // Ensure payment_for is not NULL
                            ->where('payment_histories.payment_for', '!=', '') // Ensure payment_for is not empty
                            ->select('payment_histories.*', 'addresses.*') // Select all columns from both tables
                            ->get(); // Use get() to fetch all pending payments instead of first()

        foreach ($pendingPayments as $pendingPayment) {
            $customer_name = $pendingPayment->company_name;
            $payment_url = $this->generatePaymentUrl($pendingPayment->party_code, $pendingPayment->payment_for);
            $payment_amt = $pendingPayment->amount;

            // Extract the part after 'pay-amount/'
            $fileName = substr($payment_url, strpos($payment_url, "pay-amount/") + strlen("pay-amount/"));
            $button_variable_encode_part = $fileName;

            $user = DB::table('users')->where('id', $pendingPayment->user_id)->first();
            $manager = DB::table('users')->where('id', $user->manager_id)->first();
            $manager_phone = $manager->phone;

            $pdf_url = $this->generateStatementPdf($pendingPayment->party_code, $pendingPayment->due_amount, $pendingPayment->overdue_amount, $user);
            $fileName1 = basename($pdf_url);
            $button_variable_pdf_filename = $fileName1;

            $templateData = [
                'name' => 'utility_payment_pending_remainder', // Don't change this template name
                'language' => 'en_US',
                'components' => [
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $customer_name],
                            ['type' => 'text', 'text' => $payment_amt],
                            ['type' => 'text', 'text' => $manager_phone],
                        ],
                    ],
                    [
                        'type' => 'button',
                        'sub_type' => 'url',
                        'index' => '0',
                        'parameters' => [
                            [
                                'type' => 'text',
                                'text' => $button_variable_encode_part, // Replace $button_text with the actual Parameter for the button.
                            ],
                        ],
                    ],
                    [
                        'type' => 'button',
                        'sub_type' => 'url',
                        'index' => '1',
                        'parameters' => [
                            [
                                'type' => 'text',
                                'text' => $button_variable_pdf_filename, // Replace $button_text with the actual Parameter for the button.
                            ],
                        ],
                    ],
                ],
            ];

            // Convert template data to JSON for logging
            // $jsonTemplateData = json_encode($templateData, JSON_PRETTY_PRINT);

            // Step 8: Send the WhatsApp message
            $this->whatsAppWebService = new WhatsAppWebService();
            $jsonResponse = $this->whatsAppWebService->sendTemplateMessage($user->phone, $templateData);

            // Log the JSON request for debugging purposes
            \Log::info('WhatsApp message sent:', ['request' => $jsonResponse]);
        }
    }

    public function sendOverdueStatements(Request $request)
    {
        // Retrieve only 20 users with overdue amounts
        $customersQuery = User::where('user_type', 'customer')
            ->orderBy('company_name', 'asc');
            //->take(20);

        if ($request->has('manager_id') && !empty($request->manager_id)) {
            $customersQuery->where('manager_id', $request->manager_id);
        }

        if ($request->has('warehouse_id') && !empty($request->warehouse_id)) {
            $customersQuery->where('warehouse_id', $request->warehouse_id);
        }

        $customers = $customersQuery->get();
        $groupId = uniqid('group_', true); // Generate a unique group ID for this batch

        foreach ($customers as $userData) {
            $userAddressData = Address::where('user_id', $userData->id)
                ->select('gstin', 'acc_code', 'due_amount', 'overdue_amount')
                ->groupBy('gstin')
                ->orderBy('acc_code', 'ASC')
                ->get();

            foreach ($userAddressData as $address) {
                // Only proceed if overdue amount is greater than zero
                if ($address->overdue_amount > 0) {
                    // Generate PDF statement for the user
                    $pdfUrl = $this->generateStatementPdf($address->acc_code, $address->due_amount, $address->overdue_amount, $userData);
                    $fileName = basename($pdfUrl);

                    // Get phone numbers for user, manager, and head manager
                    $userPhone = $userData->phone;
                    $managerPhone = $this->getManagerPhone($userData->manager_id);
                    $headManagerPhone = $this->getHeadManagerPhone($userData->warehouse_id);

                    // Generate the payment URL
                    $payment_url = $this->generatePaymentUrl($address->acc_code, $payment_for = "overdue_amount");
                    $payNowBtn = substr($payment_url, strpos($payment_url, "pay-amount/") + strlen("pay-amount/"));
                    $button_variable_encode_part = $payNowBtn;

                    // Prepare the template data
                    $templateData = [
                        'name' => 'utility_statement_document',
                        'language' => 'en_US',
                        'components' => [
                            [
                                'type' => 'header',
                                'parameters' => [
                                    ['type' => 'document', 'document' => ['link' => $pdfUrl, 'filename' => $fileName]],
                                ],
                            ],
                            [
                                'type' => 'body',
                                'parameters' => [
                                    ['type' => 'text', 'text' => $userData->company_name],
                                    ['type' => 'text', 'text' => $address->due_amount],
                                    ['type' => 'text', 'text' => $address->overdue_amount],
                                    ['type' => 'text', 'text' => $managerPhone],
                                ],
                            ],
                            [
                                'type' => 'button',
                                'sub_type' => 'url',
                                'index' => '0',
                                'parameters' => [
                                    ["type" => "text", "text" => $button_variable_encode_part],
                                ],
                            ],
                        ],
                    ];

                    // Insert message for the user
                    DB::table('wa_sales_queue')->insert([
                        'group_id' => $groupId,
                        'callback_data' => $templateData['name'],
                        'recipient_type' => 'individual',
                        'to_number' => $userPhone,
                        'type' => 'template',
                        'file_url' => $pdfUrl,
                        'file_name'=>$address->acc_code,
                        'content' => json_encode($templateData),
                        'status' => 'pending',
                        'response' => '',
                        'msg_id' => '',
                        'msg_status' => '',
                        'created_at' => now(),
                        'updated_at' => now()
                    ]);

                    // Insert message for the manager
                    // if ($managerPhone) {
                    //     DB::table('wa_sales_queue')->insert([
                    //         'group_id' => $groupId,
                    //         'callback_data' => $templateData['name'],
                    //         'recipient_type' => 'individual',
                    //         'to_number' => $managerPhone,
                    //         'type' => 'template',
                    //         'file_url' => $pdfUrl,
                    //         'content' => json_encode($templateData),
                    //         'status' => 'pending',
                    //         'response' => '',
                    //         'msg_id' => '',
                    //         'msg_status' => '',
                    //         'created_at' => now(),
                    //         'updated_at' => now()
                    //     ]);
                    // }

                    // Insert message for the head manager
                    // if ($headManagerPhone) {
                    //     DB::table('wa_sales_queue')->insert([
                    //         'group_id' => $groupId,
                    //         'callback_data' => $templateData['name'],
                    //         'recipient_type' => 'individual',
                    //         'to_number' => $headManagerPhone,
                    //         'type' => 'template',
                    //         'file_url' => $pdfUrl,
                    //         'content' => json_encode($templateData),
                    //         'status' => 'pending',
                    //         'response' => '',
                    //         'msg_id' => '',
                    //         'msg_status' => '',
                    //         'created_at' => now(),
                    //         'updated_at' => now()
                    //     ]);
                    // }
                }
            }
        }

        // Dispatch the job to process WhatsApp messages asynchronously
        SendWhatsAppMessagesJob::dispatch($groupId);

        return response()->json(['success' => true, 'message' => 'Overdue WhatsApp notifications queued successfully.']);
    }


    public function ___sendOverdueStatements(Request $request)
    {
        // Retrieve only 5 users with overdue amounts
        $customersQuery = User::where('user_type', 'customer')
            ->orderBy('company_name', 'asc')
            ->take(20); // Limit to 5 records

        if ($request->has('manager_id') && !empty($request->manager_id)) {
            $customersQuery->where('manager_id', $request->manager_id);
        }

        if ($request->has('warehouse_id') && !empty($request->warehouse_id)) {
            $customersQuery->where('warehouse_id', $request->warehouse_id);
        }

        $customers = $customersQuery->get();

        foreach ($customers as $userData) {
            $userAddressData = Address::where('user_id', $userData->id)
                ->select('gstin', 'acc_code', 'due_amount', 'overdue_amount')
                ->groupBy('gstin')
                ->orderBy('acc_code', 'ASC')
                ->get();
               

               
            foreach ($userAddressData as $address) {
                
                // Only proceed if overdue amount is greater than zero
                if ($address->overdue_amount > 0) {
                    // Generate PDF statement for the user
                    $pdfUrl = $this->generateStatementPdf($address->acc_code, $address->due_amount, $address->overdue_amount, $userData);
                    $fileName = basename($pdfUrl);

                    // Prepare WhatsApp message content using template
                    $to = "7044300330";
                     //$to = $userData->phone; // Dynamically set the customer's phone number

                    // Get manager's phone number if available
                    $managerPhone = null;
                    if ($userData->manager_id) {
                        $managerData = DB::table('users')
                            ->where('id', $userData->manager_id)
                            ->select('phone')
                            ->first();
                        
                        $managerPhone = $managerData->phone ?? null;
                    }
                    $headManagerPhone = $this->getHeadManagerPhone($userData->warehouse_id);
                    echo $headManagerPhone;
                    die();


                    $payment_url = $this->generatePaymentUrl($address->acc_code, $payment_for = "custom_amount");
                    $payNowBtn = substr($payment_url, strpos($payment_url, "pay-amount/") + strlen("pay-amount/"));
                    $button_variable_encode_part = $payNowBtn;

                    $templateData = [
                        'name' => 'utility_statement_document',
                        'language' => 'en_US',
                        'components' => [
                            [
                                'type' => 'header',
                                'parameters' => [
                                    ['type' => 'document', 'document' => ['link' => $pdfUrl, 'filename' => $fileName]],
                                ],
                            ],
                            [
                                'type' => 'body',
                                'parameters' => [
                                    ['type' => 'text', 'text' => $userData->company_name],
                                    ['type' => 'text', 'text' => $address->due_amount],
                                    ['type' => 'text', 'text' => $address->overdue_amount],
                                    ['type' => 'text', 'text' => $managerPhone ?? 'N/A'],
                                ],
                            ],
                            [
                                'type' => 'button',
                                'sub_type' => 'url',
                                'index' => '0',
                                'parameters' => [
                                    [
                                        "type" => "text",
                                        "text" => $button_variable_encode_part
                                    ],
                                ],
                            ],
                        ],
                    ];

                    // Send the message using WhatsApp web service
                    $this->whatsAppWebService = new WhatsAppWebService();
                    $resp = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);
                    // echo "<pre>";
                    // print_r($resp);
                   
                }
               
            }
           
        }

        return response()->json(['success' => true, 'message' => 'Overdue WhatsApp notifications sent successfully.']);
    }





    //statement sendwhatsapp all using cron
  


    public function apiStatementSendWhatsappAll(Request $request)
    {
        // Increase memory limit and execution time to avoid timeouts
        set_time_limit(-1);
        header('Keep-Alive: timeout=86400, max=100');
        header('Cache-Control: no-cache');
        header('Connection: Keep-Alive');
        ini_set('memory_limit', '512M');
        
        // Generate a unique group_id
        $groupId = uniqid('group_', true);

        try {
            // Query the addresses table for records with due or overdue amounts
            $addresses = Address::where('due_amount', '>', 0)
                ->orWhere('overdue_amount', '>', 0)
                ->select('user_id', 'due_amount', 'overdue_amount', 'gstin', 'acc_code')
                ->groupBy('user_id')
                ->get();

            foreach ($addresses as $address) {
                $user = User::where('id', $address->user_id)
                    ->select('party_code', 'company_name', 'phone', 'manager_id', 'warehouse_id')
                    ->first();

                if (!$user) {
                    continue; // Skip if the user does not exist
                }

                try {
                    // Get manager and head manager phone numbers
                    $managerPhone = $this->getManagerPhone($user->manager_id);
                    $headManagerPhone = $this->getHeadManagerPhone($user->warehouse_id);

                    // Generate the PDF statement
                    $pdfUrl = $this->generateStatementPdf($user->party_code, $address->due_amount, $address->overdue_amount, $user);
                    $fileName = basename($pdfUrl);

                    // Generate the payment URL
                    $payment_url = $this->generatePaymentUrl($user->party_code, $payment_for = "custom_amount");
                    $payNowBtn = substr($payment_url, strpos($payment_url, "pay-amount/") + strlen("pay-amount/"));
                    $button_variable_encode_part = $payNowBtn;

                    // Prepare the template data
                    $templateData = [
                        'name' => 'utility_statement_document',
                        'language' => 'en_US',
                        'components' => [
                            [
                                'type' => 'header',
                                'parameters' => [
                                    ['type' => 'document', 'document' => ['link' => $pdfUrl, 'filename' => $fileName]],
                                ],
                            ],
                            [
                                'type' => 'body',
                                'parameters' => [
                                    ['type' => 'text', 'text' => $user->company_name ?? 'No Company Name'],
                                    ['type' => 'text', 'text' => $address->due_amount],
                                    ['type' => 'text', 'text' => $address->overdue_amount],
                                    ['type' => 'text', 'text' => $managerPhone]
                                ],
                            ],
                            [
                                'type' => 'button',
                                'sub_type' => 'url',
                                'index' => '0',
                                'parameters' => [
                                    ["type" => "text", "text" => $button_variable_encode_part],
                                ],
                            ],
                        ],
                    ];

                    // Insert message for the user
                    DB::table('wa_sales_queue')->insert([
                        'group_id' => $groupId,
                        'callback_data' => $templateData['name'],
                        'recipient_type' => 'individual',
                        'to_number' => $user->phone,
                        'type' => 'template',
                        'file_url' => $pdfUrl,
                        'file_name'=>$user->party_code,
                        'content' => json_encode($templateData),
                        'status' => 'pending',
                        'response' => '',
                        'msg_id' => '',
                        'msg_status' => '',
                        'created_at' => now(),
                        'updated_at' => now()
                    ]);

                    // Insert message for the manager
                    // DB::table('wa_sales_queue')->insert([
                    //     'group_id' => $groupId,
                    //     'callback_data' => $templateData['name'],
                    //     'recipient_type' => 'individual',
                    //     'to_number' => $managerPhone,
                    //     'type' => 'template',
                    //     'file_url' => $pdfUrl,
                    //     'content' => json_encode($templateData),
                    //     'status' => 'pending',
                    //     'response' => '',
                    //     'msg_id' => '',
                    //     'msg_status' => '',
                    //     'created_at' => now(),
                    //     'updated_at' => now()
                    // ]);

                    // Insert message for the head manager
                    // DB::table('wa_sales_queue')->insert([
                    //     'group_id' => $groupId,
                    //     'callback_data' => $templateData['name'],
                    //     'recipient_type' => 'individual',
                    //     'to_number' => $headManagerPhone,
                    //     'type' => 'template',
                    //     'file_url' => $pdfUrl,
                    //     'content' => json_encode($templateData),
                    //     'status' => 'pending',
                    //     'response' => '',
                    //     'msg_id' => '',
                    //     'msg_status' => '',
                    //     'created_at' => now(),
                    //     'updated_at' => now()
                    // ]);

                } catch (\Exception $e) {
                    Log::error("Error processing user ID {$user->id}: {$e->getMessage()}");
                    continue;
                }
            }

            // Dispatch the job to process WhatsApp messages asynchronously
            SendWhatsAppMessagesJob::dispatch($groupId);

            // Return the group_id as part of the response
            return response()->json([
                'success' => true,
                'message' => 'WhatsApp messages are being processed',
                'group_id' => $groupId
            ]);

        } catch (\Exception $e) {
            Log::error("Error in apiStatementSendWhatsappAll function", ['error' => $e->getMessage()]);
            return response()->json(['success' => false, 'message' => 'Error processing data']);
        }
    }

    // Helper function to get head manager phone number based on warehouse location
    private function getHeadManagerPhone($warehouseId)
    {
        switch ($warehouseId) {
            case 1: // Kolkata
                return $this->getManagerPhone(180);
            case 2: // Delhi
                return $this->getManagerPhone(25606);
            case 6: // Mumbai
                return $this->getManagerPhone(169);
            default:
                return null; // Default case if warehouse does not match
        }
    }

  

    public function generateUserStatementPDF($user_id)
    {
        // Fetch the user data
        $user = DB::table('addresses')
			->where('acc_code', $user_id)
			->first();

        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }

        // Fetch the due amount and overdue amount from the address table
        $addressData = DB::table('addresses')
            ->where('acc_code', $user_id)
            ->select('due_amount', 'overdue_amount', 'acc_code')
            ->first();

        if (!$addressData) {
            return response()->json(['error' => 'No address data found for the user'], 404);
        }

        // Generate PDF and get the URL
        $pdfUrl = $this->generateStatementPdf(
            $addressData->acc_code, 
            $addressData->due_amount, 
            $addressData->overdue_amount, 
            $user
        );

        // Return the PDF URL as JSON response
        return response()->json(['pdf_url' =>$pdfUrl]);
    }


    public function generateInvoice($invoice_no)
      {
          // Fetch bills data using the invoice number
          $billsData = DB::table('bills_data')
              ->where('invoice_no', decrypt($invoice_no))
              ->select(
                  'dispatch_id',
                  'part_no',
                  'item_name',
                  'hsn',
                  'billed_qty',
                  'rate',
                  'bill_amount',
                  'invoice_no',
                  'invoice_amount',
                  'invoice_date',
                  'billing_company',
                  'product_id',

                  DB::raw('SUM(invoice_amount) OVER () as total_invoice_amount')
              )
              ->get();

          $totalInvoiceAmount = $billsData->first()->invoice_amount ?? 0;
        

          // Check if the invoice exists
          if ($billsData->isEmpty()) {
              return response()->json(['info' => 'Invoice not found'], 404);
          }

          // Fetch the billing company details from the addresses table
          $billingCompany = $billsData->first()->billing_company;
          $billingDetails = DB::table('addresses')
              ->where('acc_code', $billingCompany)
              ->select('company_name', 'address', 'address_2', 'city', 'postal_code', 'gstin', 'due_amount','dueDrOrCr','overdue_amount','overdueDrOrCr','user_id')
              ->first();

          if (!$billingDetails) {
              return response()->json(['info' => 'Billing details not found'], 404);
          }

            // Fetch manager_id from the users table based on user_id
          $managerId = DB::table('users')
              ->where('id', $billingDetails->user_id)
              ->value('manager_id');
          $manager_phone= $this->getManagerPhone($managerId);


          // Fetch the logistic data from the order_logistics table
          
          $logisticsDetails = DB::table('order_logistics')
          ->where('invoice_no', decrypt($invoice_no))
          ->select('lr_no', 'lr_date', 'no_of_boxes', 'attachment')
          ->first();

          if (!$logisticsDetails) {
              // Set default values
              $logisticsDetails = (object) [
                  'lr_no' => '',
                  'lr_date' => '',
                  'no_of_boxes' => '',
                  'attachment' => '#', // Default link when no attachment is available
              ];
          }



          // Extract place of supply from invoice number
          $placePrefix = strtoupper(substr(decrypt($invoice_no), 0, 3));

          // Example data from the Excel
          $branchDetails = [
              'KOL' => [
                  'gstin' => '19ABACA4198B1ZS',
                  'company_name' => 'ACE TOOLS PVT LTD',
                  'address_1' => '257B, BIPIN BEHARI GANGULY STREET',
                  'address_2' => '2ND FLOOR',
                  'address_3' => '',
                  'city' => 'KOLKATA',
                  'state' => 'WEST BENGAL',
                  'postal_code' => '700012',
                  'contact_name' => 'Amir Madraswala',
                  'phone' => '9709555576',
                  'email' => 'acetools505@gmail.com',
              ],
              'MUM' => [
                  'gstin' => '27ABACA4198B1ZV',
                  'company_name' => 'ACE TOOLS PVT LTD',
                  'address_1' => 'HARIHAR COMPLEX F-8, HOUSE NO-10607, ANUR DEPODE ROAD',
                  'address_2' => 'GODOWN NO.7, GROUND FLOOR',
                  'address_3' => 'BHIWANDI',
                  'city' => 'MUMBAI',
                  'state' => 'MAHARASHTRA',
                  'postal_code' => '421302',
                  'contact_name' => 'Hussain',
                  'phone' => '9730377752',
                  'email' => 'acetools505@gmail.com',
              ],
              'DEL' => [
                  'gstin' => '07ABACA4198B1ZX',
                  'company_name' => 'ACE TOOLS PVT LTD',
                  'address_1' => 'Ground Floor, Plot No 220/219 & 220 Kh No 58/2',
                  'address_2' => 'Rithala Road',
                  'address_3' => 'Rithala',
                  'city' => 'New Delhi',
                  'state' => 'Delhi',
                  'postal_code' => '110085',
                  'contact_name' => 'Mustafa Worliwala',
                  'phone' => '9871165253',
                  'email' => 'acetools505@gmail.com',
              ],
          ];

          $branchData = $branchDetails[$placePrefix] ?? null;
          if (!$branchData) {
              return response()->json(['error' => 'Branch details not found for the given invoice'], 404);
          }

          // Get the invoice date from the first record
          $invoiceDate = $billsData->first()->invoice_date;

          // Configuration for PDF (optional)
          $config = [
              'format' => 'A4',
              'orientation' => 'portrait',
              'margin_top' => 10,
              'margin_bottom' => 0,
          ];

          // Generate the PDF
          $pdf = PDF::loadView('backend.invoices.product_invoiced', [
              'billsData' => $billsData,
              'invoice_no' => $invoice_no,
              'totalInvoiceAmount' => $totalInvoiceAmount,
              'placeOfSupply' => $placePrefix,
              'invoiceDate' => $invoiceDate,
              'billingDetails' => $billingDetails,
              'logisticsDetails' => $logisticsDetails,
              'branchDetails' => $branchData, // Pass the branch details to the view
              'manager_phone'=>$manager_phone,
          ], [], $config);

          // Define the file name and path
          $fileName = 'invoice-' . str_replace('/', '-', decrypt($invoice_no)) . '-' . uniqid() . '.pdf';
          $filePath = public_path('purchase_history_invoice/' . $fileName);

          // Save the PDF to the public/statements directory
          $pdf->save($filePath);

          // Generate the public URL
          $publicUrl = url('public/purchase_history_invoice/' . $fileName);

          return $publicUrl;
         
      }


   public function getOrderLogisticsDetails()
{
    // Generate a unique group ID for this batch of messages
    $groupId = uniqid('group_', true);

    // Fetch and join `order_logistics` and `addresses` tables
    $results = DB::table('order_logistics')
        ->join('addresses', 'order_logistics.party_code', '=', 'addresses.acc_code')
		->join('order_bills', 'order_logistics.invoice_no', '=', 'order_bills.invoice_no') // Join with order_bills table
        ->select(
            'order_logistics.id as order_logistics_id',
            'order_logistics.party_code',
            'order_logistics.order_no',
            'order_logistics.invoice_no',
            'order_logistics.lr_no',
            'order_logistics.lr_date',
            'order_logistics.no_of_boxes',
            'order_logistics.payment_type',
            'order_logistics.lr_amount',
            'order_logistics.attachment',
            'addresses.company_name',
            'addresses.address',
            'addresses.address_2',
            'addresses.city',
            'addresses.state_id',
            'addresses.country_id',
            'addresses.gstin',
            'addresses.phone',
            'addresses.user_id',
			'order_bills.invoice_date' // Include invoice_date
        )
        ->whereNotNull('order_logistics.lr_no') // Ensure `lr_no` is not null
        ->where('order_logistics.lr_no', '!=', '') // Ensure `lr_no` is not blank
        ->where('order_logistics.wa_is_processed', false) // Only unprocessed records
        ->get();

        // echo "<pre>";
        // print_r($results);
        // die();

    // Process and send WhatsApp messages
    $results->each(function ($item) use ($groupId) {
        // Extract `transport_name` and refine `lr_no`
        if (!empty($item->lr_no)) {
			//$lrParts = explode('-', trim($item->lr_no));
			$item->transport_name = $item->lr_no; // Extract and trim transport name
			//$item->lr_no = isset($lrParts[1]) ? trim($lrParts[1]) : $item->lr_no; // Extract or retain trimmed `lr_no`
		} else {
			$item->transport_name = null;
			$item->lr_no = null;
		}

        //get first attatchment addition added code start date 18/12/2024
         $attachments = explode(',', $item->attachment);
         $item->attachment = $attachments[0] ?? null;
        //additional added code end

        // Generate file name using `lr_no` and `invoice_no`
        $lrNo = preg_replace('/[^A-Za-z0-9]/', '_', $item->lr_no); // Replace invalid characters
        $invoiceNo = preg_replace('/[^A-Za-z0-9]/', '_', $item->invoice_no); // Replace invalid characters
        $fileName = "{$lrNo}_{$invoiceNo}." . pathinfo($item->attachment, PATHINFO_EXTENSION);

        // Define the storage path
        $storagePath = 'uploads/cw_acetools';
        $publicFilePath = public_path($storagePath . '/' . $fileName);

        try {
            // Ensure the directory exists
            if (!file_exists(public_path($storagePath))) {
                mkdir(public_path($storagePath), 0777, true);
            }

            // Check if the attachment is valid before fetching
            if (!empty($item->attachment)) {
                // Use Laravel's Http client to fetch the file
                $response = Http::get($item->attachment);

                if ($response->successful()) {
                    // Save the file to the public folder
                    file_put_contents($publicFilePath, $response->body());

                    // Assign the public URL for WhatsApp message
                    $item->attachment_url = url('public/' . $storagePath . '/' . $fileName);
                } else {
                    $item->attachment_url = asset('public/uploads/cw_acetools/default_image.jpg'); // Fallback URL
                }
            } else {
                // Log a warning if attachment is missing
                Log::warning("Attachment is null for order logistics ID: {$item->order_logistics_id}");
                $item->attachment_url = asset('public/uploads/cw_acetools/default_image.jpg'); // Fallback URL
            }
        } catch (\Exception $e) {
            // Handle errors during file download
            Log::error('Error downloading file: ' . $e->getMessage());
            $item->attachment_url = asset('public/uploads/cw_acetools/default_image.jpg'); // Fallback URL
        }

        $invoice_url=$this->generateInvoice(encrypt($item->invoice_no));
        $buttonVariable=basename($invoice_url);


        // Prepare WhatsApp message template
        $whatsappMessage = [
            'name' => 'utility_logistic_fresh',
            'language' => 'en_US',
            'components' => [
                [
                    'type' => 'header',
                    'parameters' => [
                        ['type' => 'image', 'image' => ['link' => $item->attachment_url]], // Use the downloaded file URL
                    ],
                ],
                [
                    'type' => 'body',
                    'parameters' => [
                        ['type' => 'text', 'text' => $item->company_name ?: 'N/A'], // Customer name
                        ['type' => 'text', 'text' => $item->invoice_no ?: 'N/A'], // Invoice 
						['type' => 'text', 'text' => $item->invoice_date ?: 'N/A'], // Invoice date
                        ['type' => 'text', 'text' => $item->transport_name ?: 'N/A'], // Transport name - lr number                           
                        ['type' => 'text', 'text' => $item->lr_date ?: 'N/A'], // LR date
                        ['type' => 'text', 'text' => $item->no_of_boxes ?: '0.00'], // No. of boxes
                    ],
                ],
                [
                    'type' => 'button',
                    'sub_type' => 'url',
                    'index' => '0',
                    'parameters' => [
                        ['type' => 'text', 'text' => $buttonVariable],
                    ],
                ],
            ],
        ];

        $phone = $item->phone ?? 'N/A'; // Placeholder recipient phone number

        $user = DB::table('users')->where('id', $item->user_id)->first();
        $managerPhone = $this->getManagerPhone($user->manager_id);

        // Insert message for the user
        DB::table('wa_sales_queue')->insert([
            'group_id' => $groupId,
            'callback_data' => $whatsappMessage['name'],
            'recipient_type' => 'individual',
            'to_number' => $user->phone,
            'type' => 'template',
            'file_url' => $item->attachment_url ?: 'N/A',
            'content' => json_encode($whatsappMessage),
            'status' => 'pending',
            'response' => '',
            'msg_id' => '',
            'msg_status' => '',
            'created_at' => now(),
            'updated_at' => now()
        ]);

        DB::table('wa_sales_queue')->insert([
            'group_id' => $groupId,
            'callback_data' => $whatsappMessage['name'],
            'recipient_type' => 'individual',
            'to_number' => $managerPhone,
            'type' => 'template',
            'file_url' => $item->attachment_url ?: 'N/A',
            'content' => json_encode($whatsappMessage),
            'status' => 'pending',
            'response' => '',
            'msg_id' => '',
            'msg_status' => '',
            'created_at' => now(),
            'updated_at' => now()
        ]);
		
		// DB::table('wa_sales_queue')->insert([
        //     'group_id' => $groupId,
        //     'callback_data' => $whatsappMessage['name'],
        //     'recipient_type' => 'individual',
        //     'to_number' => '9894753728',
        //     'type' => 'template',
        //     'file_url' => $item->attachment_url ?: 'N/A',
        //     'content' => json_encode($whatsappMessage),
        //     'status' => 'pending',
        //     'response' => '',
        //     'msg_id' => '',
        //     'msg_status' => '',
        //     'created_at' => now(),
        //     'updated_at' => now()
        // ]);

        // Mark the record as processed
        DB::table('order_logistics')
            ->where('id', $item->order_logistics_id)
            ->update(['wa_is_processed' => true]);
    });

  
        // No data was retrieved
       SendWhatsAppMessagesJob::dispatch($groupId);
   

    // Return the processed results
    return response()->json($results);
}



  public function getOrderDetailsByApprovalCode()
{
    // Fetch the specific code from the order_approvals table
    $approvalCodes = DB::table('order_approvals')
       //  ->where('code', '20241119-15110371') // Add where condition for specific code
        ->select('code')
        ->get();

    // Check if any codes are found
    if ($approvalCodes->isEmpty()) {
        echo "No codes found in the order_approvals table matching the condition.";
        die();
    }

    foreach ($approvalCodes as $approval) {
        $code = $approval->code;

        // Fetch data from the orders table for the current code
        $orderData = DB::table('orders')
            ->select('orders.*')
            ->where('orders.code', $code)
            ->first();

        // Skip if no order data exists for the current code
        if (!$orderData) {
            echo "No order found for the code: $code\n";
            continue;
        }

        // Fetch the details JSON data from order_approvals table for the current code
        $approvalData = DB::table('order_approvals')
            ->select('details')
            ->where('code', $code)
            ->first();

        if (!$approvalData) {
            echo "No approval data found for the code: $code\n";
            continue;
        }

        // Fix and decode the JSON details
        $detailsJson = $this->fixJson($approvalData->details);
        $details = json_decode($detailsJson, true);

        if (empty($details) || !is_array($details)) {
            echo "No valid details found or invalid JSON for code: $code\n";
            continue;
        }

        // Fetch data from the order_details table joined with the products table
        $orderDetailsData = DB::table('order_details')
            ->join('products', 'order_details.product_id', '=', 'products.id')
            ->select('order_details.*', 'products.part_no') // Include part_no from products
            ->where('order_details.order_id', $orderData->id)
            ->get();

        if ($orderDetailsData->isEmpty()) {
            echo "No order details found for Order ID: " . $orderData->id . "\n";
            continue;
        }

        // Match the part_no and update the approved_quantity and approved_rate
        foreach ($orderDetailsData as $detail) {
            foreach ($details as $item) {
                // Validate item structure and part_no key
                if (!is_array($item) || !isset($item['part_no'])) {
                    echo "Invalid structure or missing 'part_no' for item in code: $code\n";
                    continue;
                }

                if ($detail->part_no === $item['part_no']) {
                    // Safely retrieve other fields
                    $baseRate = isset($item['Rate']) && is_numeric($item['Rate']) ? floatval($item['Rate']) : 0;
                    $approvedQuantity = isset($item['order_qty']) && is_numeric($item['order_qty']) ? floatval($item['order_qty']) : 0;

                    // Calculate rates and amounts
                    $approvedRateWithGst = $baseRate + ($baseRate * 0.18); // Add 18% GST
                    $approvedRateFormatted = $approvedRateWithGst <= 50 ? number_format($approvedRateWithGst, 2) : round($approvedRateWithGst);
                    $finalAmount = $approvedQuantity * $approvedRateFormatted;

                    // Update the database
                    DB::table('order_details')
                        ->where('id', $detail->id)
                        ->update([
                            'approved_quantity' => $approvedQuantity,
                            'approved_rate' => $approvedRateFormatted,
                            'final_amount' => $finalAmount,
                        ]);

                    echo "Updated approved_quantity to {$approvedQuantity} and approved_rate to {$approvedRateFormatted} for Part No: {$item['part_no']} (Code: $code)\n";
                }
            }
        }
    }

    echo "Processing of the codes completed.";
}




 public function processOrderBills()
{
    // Fetch all records from the order_bills table
    $orderBillsData = DB::table('order_bills')
->where('code', '20241119-15110371') // Add where condition for specific code
    ->get();

    // Check if any data is found
    if ($orderBillsData->isEmpty()) {
        echo "No data found in the order_bills table matching the condition.";
        die();
    }

    // Process each bill record
    foreach ($orderBillsData as $billData) {
        // Fix and decode the JSON details from the details column
        $detailsJson = $this->fixJson($billData->details);
        $details = json_decode($detailsJson, true);

        // Ensure $details is a valid array
        if (!is_array($details)) {
            echo "No valid details found or invalid JSON for code: {$billData->code}\n";
            continue;
        }

        // Extract the place of dispatch from invoice_no
        $invoiceNoParts = explode('/', $billData->invoice_no); // Split the invoice_no by '/'
        $placeOfDispatch = $invoiceNoParts[0] ?? 'N/A'; // Default to 'N/A'

        // Process each part_no in the bill details
        foreach ($details as $item) {
            // Validate item structure and required keys
            if (!is_array($item) || !isset($item['part_no'], $item['billed_qty'])) {
                echo "Invalid structure or missing keys in bill details for code: {$billData->code}\n";
                continue;
            }

            // Fetch product ID using part_no
            $productData = DB::table('products')
                ->where('part_no', $item['part_no'])
                ->first();

            if (!$productData) {
                echo "No product found for Part No: {$item['part_no']}\n";
                continue;
            }

            // Fetch the corresponding order detail record from the order_details table
            $orderDetail = DB::table('order_details')
                ->where('product_id', $productData->id)
                ->where('dispatch_id', $billData->dispatch_id)
                ->first();

            if ($orderDetail) {
                // Calculate the final amount (billed_quantity * approved_rate)
                $billedQuantity = is_numeric($item['billed_qty']) ? (float)$item['billed_qty'] : 0;
                $approvedRate = is_numeric($orderDetail->approved_rate) ? (float)$orderDetail->approved_rate : 0;
                $finalAmount = $billedQuantity * $approvedRate;

                // Update the existing record with billed_quantity, billed_invoice_no, and place_of_dispatch
                DB::table('order_details')
                    ->where('id', $orderDetail->id)
                    ->update([
                        'billed_quantity' => $billedQuantity,
                        'billed_invoice_no' => $billData->invoice_no,
                        'place_of_dispatch' => $placeOfDispatch,
                        'final_amount' => $finalAmount,
                    ]);

                echo "Updated row for Part No: {$item['part_no']}, Order Detail ID: {$orderDetail->id}, Place of Dispatch: {$placeOfDispatch}\n";
            } else {
                echo "No matching order detail found for Product ID: {$productData->id}, Part No: {$item['part_no']}, Dispatch ID: {$billData->dispatch_id}\n";
            }
        }
    }

    echo "Processing of all bill records completed.";
}
  private function fixJson($jsonString)
{
    $jsonString = preg_replace('/[\r\n\t]+/', ' ', $jsonString);
    $decodedArray = json_decode($jsonString, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        return $this->processAndFixJson($jsonString);
    }

    return json_encode($decodedArray, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

/**
 * Process and fix invalid JSON string by handling each object separately.
 *
 * @param string $jsonString
 * @return string|null
 */
private function processAndFixJson($jsonString)
{
    preg_match_all('/\{.*?\}/', $jsonString, $matches);
    $fixedArray = [];

    foreach ($matches[0] as $index => $jsonPart) {
        $decoded = json_decode($jsonPart, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            $decoded = $this->createValidObject($jsonPart);
        }

        $fixedArray[] = $decoded ?: new \stdClass();
    }

    return json_encode($fixedArray, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

/**
 * Create a valid JSON object from invalid JSON part.
 *
 * @param string $jsonPart
 * @return array
 */
private function createValidObject($jsonPart)
{
    $jsonPart = preg_replace('/[^a-zA-Z0-9:{},"\[\]\s]+/', '', $jsonPart);
    $decoded = json_decode($jsonPart, true);

    return $decoded ?: ['invalid_data' => true];
}



    public function notifyManagerAPI(Request $request)
    {
        // Fetch managers using the statementWhatsappManagers logic
        $managers = User::join('staff', 'users.id', '=', 'staff.user_id')
            ->where('staff.role_id', 5) // Ensure it fetches managers only
            ->select('users.*')
            ->get();

        if ($managers->isEmpty()) {
            return response()->json([
                'success' => false,
                'message' => 'No managers found for the selected options.'
            ]);
        }

        foreach ($managers as $manager) {
            $customers = User::where('user_type', 'customer')
                              ->where('manager_id', $manager->id)
                              ->orderBy('company_name', 'asc')
                              ->get();

            $processedData = [];
            $totalDueAmount = 0;
            $totalOverdueAmount = 0;

            foreach ($customers as $userData) {
                $userAddressData = Address::where('user_id', $userData->id)
                    ->select('city', 'company_name', 'gstin', 'acc_code', 'due_amount', 'overdue_amount') 
                    ->groupBy('gstin')
                    ->orderBy('acc_code', 'ASC')
                    ->get();

                foreach ($userAddressData as $address) {
                    if ($address->due_amount > 0 || $address->overdue_amount > 0) {
                        $totalDueAmount += $address->due_amount;
                        $totalOverdueAmount += $address->overdue_amount;

                        $processedData[] = [
                            'customer' => ['company_name' => $address->company_name],
                            'address' => $address,
                            'phone' => $userData->phone,
                            'city' => $address->city
                        ];
                    }
                }
            }

            // Sort processed data
            usort($processedData, function ($a, $b) {
                $cityComparison = strcmp($a['city'], $b['city']);
                if ($cityComparison !== 0) {
                    return $cityComparison;
                }
                $companyNameComparison = strcmp($a['customer']['company_name'], $b['customer']['company_name']);
                return $companyNameComparison !== 0 ? $companyNameComparison : $b['address']->overdue_amount <=> $a['address']->overdue_amount;
            });

            // Generate PDF if data is available
            if (!empty($processedData)) {
                $fileName = 'Manager_Report_' . $manager->name . '_' . rand(1000, 9999) . '.pdf';
                $pdf = PDF::loadView('backend.statement.manager-report', [
                    'manager_name' => $manager->name,
                    'processedData' => $processedData,
                    'totalDueAmount' => $totalDueAmount,
                    'totalOverdueAmount' => $totalOverdueAmount
                ])->save(public_path('statements/' . $fileName));

                $publicUrl = url('public/statements/' . $fileName);

                // WhatsApp template message
                $templateData = [
                    'name' => 'utility_statement_manager_notify',
                    'language' => 'en_US',
                    'components' => [
                        [
                            'type' => 'header',
                            'parameters' => [['type' => 'document', 'document' => ['link' => $publicUrl, 'filename' => $fileName]]],
                        ],
                        [
                            'type' => 'body',
                            'parameters' => [
                                ['type' => 'text', 'text' => $manager->name],
                                ['type' => 'text', 'text' => $totalDueAmount],
                                ['type' => 'text', 'text' => $totalOverdueAmount],
                            ],
                        ],
                    ],
                ];

                $this->whatsAppWebService = new WhatsAppWebService();
                $this->whatsAppWebService->sendTemplateMessage($manager->phone, $templateData);
               // $this->whatsAppWebService->sendTemplateMessage('7044300330', $templateData);
            }
        }

        return response()->json([
            'status' => true,
            'message' => 'Reports generated and notifications sent successfully.',
        ], 200);
    }


}
