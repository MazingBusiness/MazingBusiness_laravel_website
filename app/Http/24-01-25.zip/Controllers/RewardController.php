<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\GoogleSheetsService;
use App\Models\User;
use App\Models\Address;
use App\Models\Warehouse;
use App\Models\RewardUser;
use App\Models\RewardPointsOfUser;
use App\Models\RewardRemainderEarlyPayment;
use App\Http\Controllers\InvoiceController;
use Maatwebsite\Excel\Facades\Excel; // Assuming you're using Laravel Excel for export
use App\Imports\ImportRewardsCreditNotes;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use PDF;
use App\Services\WhatsAppWebService;
use Illuminate\Support\Facades\Crypt;
use App\Jobs\SendWhatsAppMessagesJob;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class RewardController extends Controller
{
    protected $sheetsService;
    public function __construct(GoogleSheetsService $sheetsService){
        $this->sheetsService = $sheetsService;
    }

    public function rewardUserList(Request $request){
        $city = $request->city ? $request->city : "";
        $assigned_warehouse = $request->assigned_warehouse ? $request->assigned_warehouse : "";
        $manager = $request->manager ? $request->manager : "";
        $search_text = $request->search_text ? $request->search_text : "";

        $userList = RewardUser::with([
                'warehouse:id,name',
                'user_data:id,party_code,company_name,name,phone,manager_id',
                'user_data.getManager:id,name'
            ])
            ->when(!empty($city), function ($query) use ($city) {
                $query->where('city', $city);
            })
            ->when(!empty($assigned_warehouse), function ($query) use ($assigned_warehouse) {
                $query->where('assigned_warehouse', $assigned_warehouse);
            })
            ->when(!empty($search_text), function ($query) use ($search_text) {
                $query->whereRaw('party_code COLLATE utf8mb3_unicode_ci LIKE ?', ["%$search_text%"])
                    ->orWhereHas('user_data', function ($subQuery) use ($search_text) {
                        $subQuery->whereRaw('company_name COLLATE utf8mb3_unicode_ci LIKE ?', ["%$search_text%"]);
                    });
            })
            ->get()->groupBy('user_data.party_code')
            ->map(function ($group) use ($manager) {
                $firstUser = $group->first(); // Get the first user in the group
                
                // Safely handle null `user_data`
                $userData = $firstUser->user_data; // Access as an object

                if ($manager != "" && ($userData && $userData->getManager && $userData->getManager->id != $manager)) {
                    return null; // Exclude non-matching records
                }

                return [
                    'user_id' => $userData ? $userData->id : null,
                    'party_code' => $userData ? $userData->party_code : 'N/A',
                    'company_name' => $userData ? $userData->company_name : 'N/A',
                    'name' => $userData ? $userData->name : 'N/A',
                    'phone' => $userData ? $userData->phone : 'N/A',
                    'assigned_warehouse' => $firstUser->assigned_warehouse ?? 'N/A', // Access assigned_warehouse from RewardUser
                    'city' => $firstUser->city ?? 'N/A', // Access city from RewardUser
                    'managerName' => $userData && $userData->getManager ? $userData->getManager->name : 'N/A', // Access manager name
                    'warehouses' => $group->map(function ($item) {
                        return [
                            'reward_id' => $item->id,
                            'warehouse_id' => $item->warehouse ? $item->warehouse->id : null, // Handle null cases
                            'warehouse_name' => $item->warehouse ? $item->warehouse->name : 'N/A',
                            'preference' => $item->preference,
                            'rewards_percentage' => $item->rewards_percentage
                        ];
                    })->values()->toArray(),
                ];
            })
            ->filter(function ($item) {
                return !is_null($item); // Filter out null items
            })
            ->values();
        // echo "<pre>"; print_r($userList);exit;
        $userList = $userList->paginate(15);
        
        $cityList = RewardUser::select('city')->groupBy('city')->orderBy('city','ASC')->get();
        $assignedWarehouseList = RewardUser::select('assigned_warehouse')->groupBy('assigned_warehouse')->orderBy('assigned_warehouse','ASC')->get();

        $managerList = RewardUser::with([
            'user_data:id,party_code,company_name,manager_id',
            'user_data.manager:id,name'
        ])
        ->get()
        ->filter(function ($item) {
            return isset($item->user_data->manager);
        })
        ->groupBy('user_data.party_code')
        ->map(function ($group) {
            $firstItem = $group->first();
            return [
                'manager_id' => $firstItem->user_data->manager->id,
                'manager_name' => $firstItem->user_data->manager->name,
            ];
        })->values();

        // echo "<pre>"; print_r($assignedWarehouseList); exit;
        return view('backend.reward.index', compact('userList','cityList','assignedWarehouseList','managerList','city','assigned_warehouse','manager','search_text'));
    }

    public function updatePreferance(Request $request)
    {
        $rewardData = RewardUser::where('id',$request->id)->first();
        $rewardData->preference = $request->status;        
        if($rewardData->rewards_percentage == "" AND $request->status == '1'){
            $rewardData->rewards_percentage = '1';
        }
        if($rewardData->save()){
            return response()->json(['status' => 1, 'preference' => $rewardData->preference, 'rewards_percentage' => $rewardData->rewards_percentage]);
        }
        return response()->json(['status' => 0]);
    }

    public function updateReward(Request $request)
    {
        $rewardData = RewardUser::where('id',$request->id)->first();
        $rewardData->rewards_percentage = $request->rewards_percentage;  
        if($rewardData->preference == '1'){
            $rewardData->save();
            return response()->json(['status' => 1, 'preference' => $rewardData->preference, 'rewards_percentage' => $rewardData->rewards_percentage]);
        }else{
            return response()->json(['status' => 0]);
        }
    }
    

    public function pullPartyCodeIntoGoogleSheet(Request $request){

        $userList = RewardUser::with(['warehouse:id,name', 'user_data:id,party_code,company_name,name,phone,warehouse_id', 'user_data.user_warehouse:id,name', 'address_with_party_code:id,user_id,acc_code,city'])
            ->get()
            ->filter(function ($item) {
                return $item->user_data !== null; // Exclude records without user_data
            })
            ->groupBy('user_data.party_code')
            ->map(function ($group) {
                $firstUser = $group->first();
                return [
                    'party_code' => $firstUser->user_data['party_code'],
                    'company_name' => $firstUser->user_data['company_name'],
                    'city' => isset($firstUser->address_with_party_code->city) ? ucfirst($firstUser->address_with_party_code->city): 'N/A', // Correct access to city
                    'user_warehouse' => $firstUser->user_data->user_warehouse->name ?? 'N/A', // Access warehouse name correctly
                    'warehouses' => $group->map(function ($item) {
                        return [
                            'reward_id' => $item->id,
                            'warehouse_id' => $item->warehouse['id'] ?? null,
                            'warehouse_name' => $item->warehouse['name'] ?? '',
                            'preference' => $item->preference,
                            'rewards_percentage' => $item->rewards_percentage,
                        ];
                    })->values()->toArray(),
                ];
            })->values();
            $values = $userList->map(function ($user) {
                return [
                    $user['company_name'] ?? '',
                    $user['party_code'] ?? '',
                    $user['city'] ?? '',
                    $user['user_warehouse'] ?? '',
                    $user['warehouses'][0]['preference'] ?? 0,
                    $user['warehouses'][0]['rewards_percentage'] ?? 0,
                    $user['warehouses'][1]['preference'] ?? 0,
                    $user['warehouses'][1]['rewards_percentage'] ?? 0,
                    $user['warehouses'][2]['preference'] ?? 0,
                    $user['warehouses'][2]['rewards_percentage'] ?? 0,
                    $user['warehouses'][3]['preference'] ?? 0,
                    $user['warehouses'][3]['rewards_percentage'] ?? 0,
                    $user['warehouses'][4]['preference'] ?? 0,
                    $user['warehouses'][4]['rewards_percentage'] ?? 0,
                ];
            })->toArray();
        // echo "<pre>"; print_r($values);exit;
        // Clear previous data
        $range = config('sheets.get_rewards');
        $this->sheetsService->clearData($range);

        // // Append data to Google Sheets
        $this->sheetsService->appendData($range, $values);

        $userNotInRewards = User::with(['address_with_party_code:id,user_id,acc_code,city', 'warehouse:id,name'])
            ->whereNotIn('id', function ($query) {
                $query->select('user_id')->from('reward_users');
            })
            ->where('party_code', '!=', '')
            ->orderBy('id', 'ASC')
            ->get();

        // Map the user data into the desired format
        $values = $userNotInRewards->map(function ($user) {
            $address = $user->address_with_party_code->first(); // Get the first address
            return [
                $user->company_name ?? '',
                $user->party_code ?? '',
                $address ? ucfirst($address->city) : 'N/A',
                $user->warehouse ? $user->warehouse->name : 'N/A',
            ];
        })->toArray();

        // Clear previous data
        // $clearRange = config('sheets.get_rewards');
        // $this->sheetsService->clearData($clearRange);

        $range = config('sheets.range_rewards');
        $this->sheetsService->appendData($range, $values);

        return response()->json(['status' => 'success','userData'=>$values]);
    }

    public function insertDataFromGoogleSheet(Request $request){
        // Specify the range of data you want to fetch from the Google Sheet
        $range = config('sheets.get_rewards'); // e.g., 'Sheet1!A2:M' to fetch from A2 to M

        // Fetch data from Google Sheets
        $rows = $this->sheetsService->getData($range);
        foreach ($rows as $row) {
            $company_name =  $row[0] ?? ''; 
            $party_code =  $row[1] ?? '';            
            $city =  ucfirst($row[2]) ?? '';
            $assigned_warehouse =  $row[3] ?? '';
            $kolkata = $row[4] ?? '';
            $kr = $row[5] ?? '';
            $delhi = $row[6] ?? '';
            $dr = $row[7] ?? '';
            $mumbai = $row[8] ?? '';
            $mr = $row[9] ?? '';
            $chennai = $row[10] ?? '';
            $cr = $row[11] ?? '';
            $pune = $row[12] ?? '';
            $pr = $row[13] ?? '';
            
            $getUserData=User::select('id','party_code')->where('party_code',$party_code)->first();
            // echo "<pre>"; print_r($getUserData);
            // For Kolkata
            $rewardsData = RewardUser::where('party_code', $party_code)->where('warehouse_id', '1')->first();
            if ($rewardsData) {                
                $rewardsData->update([
                    'preference' => $kolkata,
                    'company_name' => $company_name,
                    'rewards_percentage' => $kr,
                    'assigned_warehouse' => $assigned_warehouse,
                    'city' => $city,
                ]);
            }else{
                $data = [
                    'user_id' => $getUserData->id,
                    'company_name' => $company_name,
                    'party_code' => $getUserData->party_code,                    
                    'warehouse_id' => '1',
                    'warehouse_name' => 'Kolkata',
                    'preference' => $kolkata,
                    'rewards_percentage' => $kr,
                    'assigned_warehouse' => $assigned_warehouse,
                    'city' => $city,
                ];
                RewardUser::create($data);
            }
            // For Delhi
            $rewardsData = RewardUser::where('party_code', $party_code)->where('warehouse_id', '2')->first();
            if ($rewardsData) {                
                $rewardsData->update([
                    'preference' => $delhi,
                    'company_name' => $company_name,
                    'rewards_percentage' => $dr,
                    'assigned_warehouse' => $assigned_warehouse,
                    'city' => $city,
                ]);
            }else{
                $data = [
                    'user_id' => $getUserData->id,
                    'company_name' => $company_name,
                    'party_code' => $getUserData->party_code,
                    'warehouse_id' => '2',
                    'warehouse_name' => 'Delhi',
                    'preference' => $delhi,
                    'rewards_percentage' => $dr,
                    'assigned_warehouse' => $assigned_warehouse,
                    'city' => $city,
                ];
                RewardUser::create($data);
            }
            // For Chennai
            $rewardsData = RewardUser::where('party_code', $party_code)->where('warehouse_id', '3')->first();
            if ($rewardsData) {                
                $rewardsData->update([
                    'preference' => $chennai,
                    'company_name' => $company_name,
                    'rewards_percentage' => $cr,
                    'assigned_warehouse' => $assigned_warehouse,
                    'city' => $city,
                ]);
            }else{
                $data = [
                    'user_id' => $getUserData->id,
                    'company_name' => $company_name,
                    'party_code' => $getUserData->party_code,
                    'warehouse_id' => '3',
                    'warehouse_name' => 'Chennai',
                    'preference' => $chennai,
                    'rewards_percentage' => $cr,
                    'assigned_warehouse' => $assigned_warehouse,
                    'city' => $city,
                ];
                RewardUser::create($data);
            }
             // For Pune
             $rewardsData = RewardUser::where('party_code', $party_code)->where('warehouse_id', '5')->first();
             if ($rewardsData) {                
                 $rewardsData->update([
                    'preference' => $pune,
                    'company_name' => $company_name,
                    'rewards_percentage' => $pr,
                    'assigned_warehouse' => $assigned_warehouse,
                    'city' => $city,
                 ]);
             }else{
                 $data = [
                    'user_id' => $getUserData->id,
                    'company_name' => $company_name,
                    'party_code' => $getUserData->party_code,
                    'warehouse_id' => '5',
                    'warehouse_name' => 'Pune',
                    'preference' => $pune,
                    'rewards_percentage' => $pr,
                    'assigned_warehouse' => $assigned_warehouse,
                    'city' => $city,
                 ];
                 RewardUser::create($data);
             }
             // For Mumbai
             $rewardsData = RewardUser::where('party_code', $party_code)->where('warehouse_id', '6')->first();
             if ($rewardsData) {                
                 $rewardsData->update([
                    'preference' => $mumbai,
                    'company_name' => $company_name,
                    'rewards_percentage' => $mr,
                    'assigned_warehouse' => $assigned_warehouse,
                    'city' => $city,
                 ]);
             }else{
                 $data = [
                    'user_id' => $getUserData->id,
                    'company_name' => $company_name,
                    'party_code' => $getUserData->party_code,
                    'warehouse_id' => '6',
                    'warehouse_name' => 'Mumbai',
                    'preference' => $mumbai,
                    'rewards_percentage' => $mr,
                    'assigned_warehouse' => $assigned_warehouse,
                    'city' => $city,
                 ];
                 RewardUser::create($data);
             }
        }
        return 1;
    }

    public function syncNewUser(Request $request){
        
        // $getUserId = User::where('user_type','customer')->pluck('id')->toArray();;
        // $getRewardsUserId = RewardUser::groupBy('user_id')->pluck('user_id')->toArray();;
        // // Find user IDs that are in $getUserId but not in $getRewardsUserId
        // $usersNotInRewards = array_diff($getUserId, $getRewardsUserId);

        $userNotInRewards = User::with(['address_with_party_code:id,user_id,acc_code,city', 'warehouse:id,name'])
            ->whereNotIn('id', function ($query) {
                $query->select('user_id')->from('reward_users');
            })
            ->where('party_code', '!=', '')
            ->where('user_type', 'customer')
            ->orderBy('id', 'ASC')
            ->get();
        $newRecord = $userNotInRewards->count();
        // Output the result
        // print_r($userNotInRewards);die;
        // print_r($getRewardsUserId); die;
        foreach ($userNotInRewards as $key=>$value) {
            if(isset($value->address_with_party_code[0])){
                // For Kolkata
                $data = [
                    'user_id' => $value->id,
                    'company_name' => $value->company_name,
                    'party_code' => $value->party_code,                    
                    'warehouse_id' => '1',
                    'warehouse_name' => 'Kolkata',
                    'preference' => 0,
                    'rewards_percentage' => 0,
                    'assigned_warehouse' => $value->warehouse->name,
                    'city' => $value->address_with_party_code[0]->city,
                ];
                RewardUser::create($data);
                
                // For Delhi
                $data = [
                    'user_id' => $value->id,
                    'company_name' => $value->company_name,
                    'party_code' => $value->party_code,
                    'warehouse_id' => '2',
                    'warehouse_name' => 'Delhi',
                    'preference' => 0,
                    'rewards_percentage' => 0,
                    'assigned_warehouse' => $value->warehouse->name,
                    'city' => $value->address_with_party_code[0]->city,
                ];
                RewardUser::create($data);            

                // For Chennai
                $data = [
                    'user_id' => $value->id,
                    'company_name' => $value->company_name,
                    'party_code' => $value->party_code,
                    'warehouse_id' => '3',
                    'warehouse_name' => 'Chennai',
                    'preference' => 0,
                    'rewards_percentage' => 0,
                    'assigned_warehouse' => $value->warehouse->name,
                    'city' => $value->address_with_party_code[0]->city,
                ];
                RewardUser::create($data);

                // For Pune
                $data = [
                    'user_id' => $value->id,
                    'company_name' => $value->company_name,
                    'party_code' => $value->party_code,
                    'warehouse_id' => '5',
                    'warehouse_name' => 'Pune',
                    'preference' => 0,
                    'rewards_percentage' => 0,
                    'assigned_warehouse' => $value->warehouse->name,
                    'city' => $value->address_with_party_code[0]->city,
                ];
                RewardUser::create($data);

                // For Mumbai
                $data = [
                    'user_id' => $value->id,
                    'company_name' => $value->company_name,
                    'party_code' => $value->party_code,
                    'warehouse_id' => '6',
                    'warehouse_name' => 'Mumbai',
                    'preference' => 0,
                    'rewards_percentage' => 0,
                    'assigned_warehouse' => $value->warehouse->name,
                    'city' => $value->address_with_party_code[0]->city,
                ];
                RewardUser::create($data);
            }else{
                $newRecord = $newRecord - 1;
            }
            
        }

        return $newRecord;
    }

    public function exportDataFromDatabase(Request $request){

        $userList = RewardUser::with(['warehouse:id,name', 'user_data:id,party_code,company_name,name,phone,warehouse_id', 'user_data.user_warehouse:id,name', 'address_with_party_code:id,user_id,acc_code,city'])
            ->get()
            ->filter(function ($item) {
                return $item->user_data !== null; // Exclude records without user_data
            })
            ->groupBy('user_data.party_code')
            ->map(function ($group) {
                $firstUser = $group->first();
                return [
                    'party_code' => $firstUser->user_data['party_code'],
                    'company_name' => $firstUser->user_data['company_name'],
                    'city' => isset($firstUser->address_with_party_code->city) ? ucfirst($firstUser->address_with_party_code->city): 'N/A', // Correct access to city
                    'user_warehouse' => $firstUser->user_data->user_warehouse->name ?? 'N/A', // Access warehouse name correctly
                    'warehouses' => $group->map(function ($item) {
                        return [
                            'reward_id' => $item->id,
                            'warehouse_id' => $item->warehouse['id'] ?? null,
                            'warehouse_name' => $item->warehouse['name'] ?? '',
                            'preference' => $item->preference,
                            'rewards_percentage' => $item->rewards_percentage,
                        ];
                    })->values()->toArray(),
                ];
            })->values();
            $values = $userList->map(function ($user) {
                return [
                    $user['company_name'] ?? '',
                    $user['party_code'] ?? '',
                    $user['city'] ?? '',
                    $user['user_warehouse'] ?? '',
                    $user['warehouses'][0]['preference'] ?? 0,
                    $user['warehouses'][0]['rewards_percentage'] ?? 0,
                    $user['warehouses'][1]['preference'] ?? 0,
                    $user['warehouses'][1]['rewards_percentage'] ?? 0,
                    $user['warehouses'][2]['preference'] ?? 0,
                    $user['warehouses'][2]['rewards_percentage'] ?? 0,
                    $user['warehouses'][3]['preference'] ?? 0,
                    $user['warehouses'][3]['rewards_percentage'] ?? 0,
                    $user['warehouses'][4]['preference'] ?? 0,
                    $user['warehouses'][4]['rewards_percentage'] ?? 0,
                ];
            })->toArray();
        // echo "<pre>"; print_r($values);exit;
        // Clear previous data
        $range = config('sheets.get_rewards');
        $this->sheetsService->clearData($range);

        // // Append data to Google Sheets
        $this->sheetsService->appendData($range, $values);
        return 1;
    }


    public function usersRewardsPoints(Request $request){
        $city = $request->city ? $request->city : "";
        $assigned_warehouse = $request->assigned_warehouse ? $request->assigned_warehouse : "";
        $manager = $request->manager ? $request->manager : "";
        $search_text = $request->search_text ? $request->search_text : "";
        $userList = RewardPointsOfUser::with([
            'warehouse:id,name',
            'user_data:id,party_code,company_name,name,phone,manager_id,city',
            'user_data.getManager:id,name',
            'get_user_addresses:id,user_id,acc_code,city'
        ])
        ->when(!empty($city), function ($query) use ($city) {
            $query->where('city', $city);
        })
        ->when(!empty($assigned_warehouse), function ($query) use ($assigned_warehouse) {
            $query->where('assigned_warehouse', $assigned_warehouse);
        })
        ->when(!empty($search_text), function ($query) use ($search_text) {
            $query->where('party_code', 'LIKE', "%$search_text%");
        })
        ->selectRaw('
            id,party_code,warehouse_id,
            SUM(CASE WHEN dr_or_cr = "dr" THEN rewards ELSE 0 END) as total_dr_rewards,
            SUM(CASE WHEN dr_or_cr = "cr" THEN rewards ELSE 0 END) as total_cr_rewards
        ')
        ->groupBy('party_code')
        ->get();
        $userList = $userList->paginate(15);
        
        $cityList = RewardUser::select('city')->groupBy('city')->orderBy('city','ASC')->get();
        $assignedWarehouseList = RewardUser::select('assigned_warehouse')->groupBy('assigned_warehouse')->orderBy('assigned_warehouse','ASC')->get();

        $managerList = RewardUser::with([
            'user_data:id,party_code,company_name,manager_id',
            'user_data.manager:id,name'
        ])
        ->get()
        ->filter(function ($item) {
            return isset($item->user_data->manager);
        })
        ->groupBy('user_data.party_code')
        ->map(function ($group) {
            $firstItem = $group->first();
            return [
                'manager_id' => $firstItem->user_data->manager->id,
                'manager_name' => $firstItem->user_data->manager->name,
            ];
        })->values();

        // echo "<pre>"; print_r($userList); exit;
        return view('backend.reward.users_rewards_points', compact('userList','cityList','assignedWarehouseList','managerList','city','assigned_warehouse','manager','search_text'));
    }

    public function exportRewards(Request $request){
        $processedData = [];
        $totalRewareds = 0;
        $userList = RewardPointsOfUser::with([
            'warehouse:id,name',
            'user_data:id,party_code,company_name,name,phone,manager_id,city',
            'user_data.getManager:id,name',
            'get_user_addresses:id,user_id,acc_code,city'
        ])
        ->where('dr_or_cr','dr')
        ->whereNull('credit_rewards')
        ->selectRaw('
            id,party_code,rewards_from,rewards,invoice_no
        ')
        ->get()->toarray();
        foreach($userList as $key=>$values){
            $processedData[] = [
                'Party Code' => $values['party_code'],
                'Company Name' => $values['user_data']['company_name'],
                'Invoice No' => $values['invoice_no'],
                'Rewards From' => $values['rewards_from'],
                'Rewards' => $values['rewards']
            ];
            $totalRewareds +=$values['rewards'];
        }
        
        if (count($processedData) > 0) {
            $processedData[] = [
                'Party Code' => 'TOTAL',
                'Company Name' => '',
                'Invoice No' => '',
                'Rewards From' => '',
                'Rewards' => $totalRewareds
            ];
        }
        // Export the processed data to Excel
        return Excel::download(new \App\Exports\RewardsExport($processedData), 'rewardsPoint.xlsx');
    }

    public function importCreditNoteRewards(Request $request){
        // Validate the incoming request
        $request->validate([
            'excel_file' => 'required|file|mimes:xls,xlsx'
        ], ['excel_file' => "File is required"]);

        // Get the real path of the uploaded file
        $filePath = $request->file('excel_file');

        $tableName = 'reward_points_of_users';

        try {
            // Attempt to import the file
            Excel::import(new ImportRewardsCreditNotes($tableName), $filePath);

            // If no exception occurs, consider it a success
            return redirect()->back()->with('success', 'Data imported successfully!');
        } catch (Exception $e) {
            // If an exception occurs, handle it and return an error message
            return redirect()->back()->with('error', 'Data import failed: ' . $e->getMessage());
        }
    }


    public function manualRewardPoint(Request $request)
    {
        $sort_search = $request->input('search', null);
        $filter = $request->input('filter', null);
        $user = Auth::user();

        // Fetch staff users (managers)
        $staffUsers = User::whereHas('roles', function ($query) {
            $query->where('role_id', 5); // Assuming role_id 5 is for managers
        })->select('id', 'name')->get();

        // Fetch warehouses using DB::table
        $warehouses = Warehouse::whereIn('id', [1, 2, 6])->get();

        $query = User::query()
            ->with(['warehouse:id,name', 'manager:id,name', 'addresses:id,city,user_id,due_amount,overdue_amount'])
            ->whereIn('user_type', ['customer', 'warehouse'])
            ->whereNotNull('email_verified_at');

        // Apply user-specific logic
        if (in_array($user->id, ['180', '25606', '169'])) {
            // Head managers see all users
        } elseif ($user->user_type != 'admin') {
            $query->where('manager_id', $user->id);
        }

        // Apply search filter
        if ($sort_search) {
            $query->where(function ($q) use ($sort_search) {
                $q->where('party_code', 'like', "%$sort_search%")
                    ->orWhere('phone', 'like', "%$sort_search%")
                    ->orWhere('name', 'like', "%$sort_search%")
                    ->orWhere('gstin', 'like', "%$sort_search%")
                    ->orWhere('company_name', 'like', "%$sort_search%")
                    ->orWhereHas('warehouse', function ($subQuery) use ($sort_search) {
                        $subQuery->where('name', 'like', "%$sort_search%");
                    })
                    ->orWhereHas('manager', function ($subQuery) use ($sort_search) {
                        $subQuery->where('name', 'like', "%$sort_search%");
                    })
                    ->orWhereHas('addresses', function ($subQuery) use ($sort_search) {
                        $subQuery->where('city', 'like', "%$sort_search%");
                    });
            });
        }

        // Apply manager filter
        if ($request->filled('manager')) {
            $query->whereIn('manager_id', $request->input('manager'));
        }

        // Apply warehouse filter
        if ($request->filled('warehouse')) {
            $query->whereIn('warehouse_id', $request->input('warehouse'));
        }

        // Apply additional filters
        if ($filter) {
            $query->when($filter === 'approved', fn($q) => $q->where('banned', '0'))
                ->when($filter === 'un_approved', fn($q) => $q->where('banned', '1'));
        }

        // Sorting logic
        $sort_by = $request->input('sort_by', 'company_name');
        $sort_order = $request->input('sort_order', 'asc');
        $query->when($sort_by === 'manager_name', fn($q) => $q->orderBy('manager.name', $sort_order))
            ->when($sort_by === 'warehouse_name', fn($q) => $q->orderBy('warehouse.name', $sort_order))
            ->orderBy($sort_by, $sort_order);

        // Paginate results
        $users = $query->paginate(15);

        return view('backend.reward.manual_rewards_point', compact(
            'users', 'sort_search', 'filter', 'sort_by', 'sort_order', 'staffUsers', 'warehouses'
        ));
    }


   public function updateRewardPoint(Request $request)
    {
        // Validate the input
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'reward_points' => 'required|integer|min:0',
            'note' => 'nullable|string|max:255', // Allow note as an optional field
        ]);

        // Fetch the user and associated data
        $user = User::with('warehouse')->findOrFail($validated['user_id']);

        // Create a new record in the RewardPointsOfUser model
        RewardPointsOfUser::create([
            'party_code' => $user->party_code,
            'rewards_from' => 'Manual', // Default value
            'warehouse_id' => $user->warehouse->id ?? null,
            'warehouse_name' => $user->warehouse->name ?? null,
            'rewards' => $validated['reward_points'],
            'dr_or_cr' => 'dr', // Default value
            'notes' => $validated['note'], // Save the note
        ]);

        return redirect()->back()->with('success', 'Reward points added successfully.');
    }


    public function getRewardPdfURL($party_code)
    {
        // Fetch rewards data
        $getData = RewardPointsOfUser::where('party_code', $party_code)
            ->whereNull('cancel_reason')
            ->get();

        // Process rewards data to add narration
        foreach ($getData as $reward) {
            if ($reward->rewards_from === 'Logistic' && !empty($reward->invoice_no)) {
                $billData = DB::table('bills_data')->where('invoice_no', $reward->invoice_no)->first();
                $reward->narration = $billData ? $billData->invoice_amount : 'N/A';
            } elseif ($reward->rewards_from === 'Manual') {
                $reward->narration = !empty($reward->notes) ? $reward->notes : '-';
            } else {
                $reward->narration = '-';
            }
        }

        // Exclude 'Total' and 'Closing Balance' rows from calculations
        $rewardRows = $getData->filter(function ($reward) {
            return !in_array($reward->rewards_from, ['Total', 'Closing Balance']);
        });

        // Calculate reward amount
        $rewardAmount = $rewardRows->sum('rewards');

        // Get the last valid row before totals for closing balance
        $lastRow = $rewardRows->last();
        $closing_balance = $lastRow ? $lastRow->rewards : 0;
        $last_dr_or_cr = $lastRow ? strtolower($lastRow->dr_or_cr) : null;

        // Adjust the closing balance based on Dr/Cr logic
        if ($last_dr_or_cr === 'dr') {
            $closing_balance = $rewardAmount;
        } else {
            $closing_balance = -$rewardAmount;
        }

        // User data
        $userData = Auth::user();

        // File name and path
        $fileName = 'reward_statement_' . $party_code . '_' . time() . '.pdf';
        $filePath = public_path('reward_pdf/' . $fileName);
        $publicUrl = url('public/reward_pdf/' . $fileName);

        // Generate and save the PDF
        PDF::loadView('backend.invoices.rewards_pdf', compact(
            'userData',
            'party_code',
            'getData',
            'rewardAmount',
            'closing_balance',
            'last_dr_or_cr'
        ))->save($filePath);

        // Return the public URL
        return $publicUrl;
    }



    public function whatsappRewardAssign()
    {
        // Fetch data using the RewardPointsOfUser model where rewards are unprocessed
        $rewardsData = RewardPointsOfUser::where('is_processed', 0)
            ->whereIn('rewards_from', ['Logistic', 'Early Payment', 'Manual'])
           // ->where('invoice_no', 'DEL/1657/24-25')
           // ->where('id', '9')
            ->get();

           
        if ($rewardsData->isEmpty()) {
            return response()->json(['error' => 'No rewards data found.'], 400);
        }

        $groupId = 'group_' . uniqid(); // Generate a unique group ID if needed

        foreach ($rewardsData as $reward) {
            $imageUrl = "https://mazingbusiness.com/public/reward_pdf/reward_image.jpg";

            // Generate reward URL
            $rewardURL = $this->getRewardPdfURL($reward->party_code);
            $rewardBaseFileName = basename($rewardURL);

            // Check if reward type is manual to skip statement URL generation
            if ($reward->rewards_from !== 'Manual') {
                $statementURL = (new InvoiceController)->getStatementPdfURL(request()->merge(['party_code' => encrypt($reward->party_code)]));
                $statementBaseFileName = basename($statementURL);
            } else {
                $statementURL = null;
                $statementBaseFileName = null;
            }

            // Fetch corresponding bill data using party_code and invoice_no
            $billData = DB::table('bills_data')
                ->where('billing_company', $reward->party_code)
                ->where('invoice_no', $reward->invoice_no)
                ->first();

            if (!$billData && $reward->rewards_from !== 'Manual') {
                Log::warning("No matching bill data found for party_code: {$reward->party_code}, invoice_no: {$reward->invoice_no}");
                continue; // Skip if no matching record found for non-manual reward
            }

            // Fetch company name from addresses table using model
            $addressData = Address::where('acc_code', $reward->party_code)->first();

            if (!$addressData) {
                Log::warning("No address found for party_code: {$reward->party_code}");
                continue; // Skip if no matching address found
            }

            // Prepare necessary data from bills_data table
            $company_name = $addressData->company_name;
            $invoice_no = $billData->invoice_no ?? '';
            $invoice_date = $billData->invoice_date ?? '';
            $invoice_amount = $billData->invoice_amount ?? '';

            // Determine the appropriate WhatsApp message template based on reward type
            if ($reward->rewards_from === 'Manual') {
                // Message template for manual rewards (with only reward button)
                $templateData = [
                    'name' => 'utility_manual_reward_whatsapp', // Template name for manual reward
                    'language' => 'en_US', // Language code
                    'components' => [
                        [
                            'type' => 'header',
                            'parameters' => [
                                ['type' => 'image', 'image' => ['link' => $imageUrl]],
                            ],
                        ],
                        [
                            'type' => 'body',
                            'parameters' => [
                                ['type' => 'text', 'text' => $company_name],
                                ['type' => 'text', 'text' => $reward->rewards],
                            ],
                        ],
                        [
                            'type' => 'button', 'sub_type' => 'url', 'index' => '0',
                            'parameters' => [
                                ['type' => 'text', 'text' => $rewardBaseFileName],
                            ],
                        ],
                    ],
                ];

            } else {
                // Message template for non-manual rewards (with invoice details and statement link)
                $templateData = [
                    'name' => 'utility_rewards_whatsapp', // Template name for regular rewards
                    'language' => 'en_US', // Language code
                    'components' => [
                        [
                            'type' => 'header',
                            'parameters' => [
                                ['type' => 'image', 'image' => ['link' => $imageUrl]],
                            ],
                        ],
                        [
                            'type' => 'body',
                            'parameters' => [
                                ['type' => 'text', 'text' => $company_name],
                                ['type' => 'text', 'text' => $reward->rewards],
                                ['type' => 'text', 'text' => $invoice_no],
                                ['type' => 'text', 'text' => $invoice_date],
                                ['type' => 'text', 'text' => $invoice_amount],
                                ['type' => 'text', 'text' => $reward->rewards_from],
                            ],
                        ],
                        [
                            'type' => 'button', 'sub_type' => 'url', 'index' => '0',
                            'parameters' => [
                                ['type' => 'text', 'text' => $rewardBaseFileName],
                            ],
                        ],
                        [
                            'type' => 'button', 'sub_type' => 'url', 'index' => '1',
                            'parameters' => [
                                ['type' => 'text', 'text' => $statementBaseFileName],
                            ],
                        ],
                    ],
                ];
            }

            // Insert WhatsApp message data into the wa_sales_queue table
            $publicUrl = $statementURL ?? ''; // Assigning the statement URL to the file_url field

            DB::table('wa_sales_queue')->insert([
                'group_id' => $groupId,
                'callback_data' => $templateData['name'],
                'recipient_type' => 'individual',
                'to_number' => $addressData->phone,  // Fallback to test number
                'type' => 'template',
                'file_url' => $publicUrl,
                'content' => json_encode($templateData),
                'status' => 'pending',
                'response' => '',
                'msg_id' => '',
                'msg_status' => '',
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Update the reward status to processed
            $reward->update(['is_processed' => 1]);
        }

        // Dispatch the job to process WhatsApp messages
        SendWhatsAppMessagesJob::dispatch($groupId);

        return response()->json(['message' => 'Reward statements have been queued for sending via WhatsApp.']);
    }



    public function __earlyPaymentRemainderWhatsapp()
{
    // Fetch all party codes from the addresses table
    $addresses = Address::select('acc_code', 'statement_data', 'phone')
                          ->where('acc_code', 'OPEL0100100')
                          ->get();

    if ($addresses->isEmpty()) {
        Log::warning("No party codes found in the addresses table.");
        return response()->json(['message' => 'No party codes found.'], 404);
    }

    // Define the start date filter (1st January 2025)
    $startDate = Carbon::parse('2025-01-01');
    $currentDate = Carbon::now()->format('Y-m-d'); // Current date formatted to Y-m-d

    foreach ($addresses as $address) {
        $partyCode = $address->acc_code;

        // Decode the JSON data from the statement_data column
        $statementData = json_decode($address->statement_data, true);

        if (!$statementData || !is_array($statementData)) {
            Log::warning("Invalid statement data for party_code: $partyCode");
            continue; // Skip this party_code if statement data is invalid
        }

        // Fetch invoices that already have "early_payment" rewards
        $invoicesWithEarlyPayment = RewardPointsOfUser::where('rewards_from', 'Early Payment')
            ->pluck('invoice_no')
            ->toArray();

        foreach ($statementData as $data) {
            // Convert trn_date to Carbon for comparison
            $transactionDate = Carbon::parse($data['trn_date']);

            // Process only invoices from 2025 onwards and not already rewarded
            if (
                $transactionDate->greaterThanOrEqualTo($startDate) &&
                $data['vouchertypebasename'] === 'Sales' &&
                !empty($data['trn_no']) &&
                !empty($data['dramount']) &&
                !in_array($data['trn_no'], $invoicesWithEarlyPayment)
            ) {
                // Check if invoice already exists in the database
                $existingRecord = RewardRemainderEarlyPayment::where('invoice_no', $data['trn_no'])->first();

                // Calculate reminder dates and format properly
                $firstReminderDate = $transactionDate->copy()->addDays(14)->format('Y-m-d');
                $secondReminderDate = $transactionDate->copy()->addDays(39)->format('Y-m-d');

                $reminderSent = $existingRecord ? $existingRecord->reminder_sent : 0;
                $isProcessed = $existingRecord ? $existingRecord->is_processed : 0;

                // Handle first reminder logic
                if ($currentDate == $firstReminderDate && $reminderSent == 0) {
                    $this->sendWhatsAppReminder($address->phone, $data['trn_no'], $data['dramount'], 1);
                    $reminderSent = 1;
                    $isProcessed = 1; // Set processed to 1 after first reminder
                }

                // Handle second reminder logic
                if ($currentDate == $secondReminderDate && $reminderSent == 1) {
                    $isProcessed = 0;  // Reset processed to 0 before sending the second reminder
                    RewardRemainderEarlyPayment::where('invoice_no', $data['trn_no'])->update(['is_processed' => 0]);

                    $this->sendWhatsAppReminder($address->phone, $data['trn_no'], $data['dramount'], 2);
                    $reminderSent = 2;
                    $isProcessed = 1; // Set processed to 1 after second reminder
                }

                // Insert or update invoice details
                RewardRemainderEarlyPayment::updateOrCreate(
                    [
                        'invoice_no' => $data['trn_no'], // Condition to check if the record exists
                    ],
                    [
                        'party_code'     => $partyCode,
                        'invoice_no'     => $data['trn_no'],
                        'invoice_date'   => $data['trn_date'],
                        'invoice_amount' => $data['dramount'],
                        'reminder_sent'  => $reminderSent,
                        'is_processed'   => $isProcessed,
                    ]
                );

                Log::info("Processed invoice {$data['trn_no']} for party_code: $partyCode with reminder_sent status: $reminderSent and is_processed status: $isProcessed");
            } else {
                Log::info("Skipped invoice {$data['trn_no']} for party_code: $partyCode - Already processed or has early payment reward.");
            }
        }
    }

    return response()->json(['message' => 'Early payment reminders processed successfully for all parties.'], 200);
}


private function generatePaymentUrl($party_code, $payment_for)
{
    $client = new \GuzzleHttp\Client();
    $response = $client->post('https://mazingbusiness.com/api/v2/payment/generate-url', [
        'json' => [
            'party_code' => $party_code,
            'payment_for' => $payment_for
        ]
    ]);
    $data = json_decode($response->getBody(), true);
    return $data['url'] ?? '';  // Return the generated URL or an empty string if it fails
}



//  Functions start for cron job for early payment

    public function insertEarlyPaymentRemainders()
    {
        // Fetch all party codes from the addresses table
        $addresses = Address::select('acc_code', 'statement_data', 'phone')
                                 ->where('acc_code','OPEL0100100')
                              ->get();

        if ($addresses->isEmpty()) {
            Log::warning("No party codes found in the addresses table.");
            return response()->json(['message' => 'No party codes found.'], 404);
        }

        // Define the start date filter (1st January 2025)
        $startDate = Carbon::parse('2025-01-01');

        foreach ($addresses as $address) {
            $partyCode = $address->acc_code;

            // Decode the JSON data from the statement_data column
            $statementData = json_decode($address->statement_data, true);

            if (!$statementData || !is_array($statementData)) {
                Log::warning("Invalid statement data for party_code: $partyCode");
                continue; // Skip this party_code if statement data is invalid
            }

            // Fetch invoices that already have "early_payment" rewards
            $invoicesWithEarlyPayment = RewardPointsOfUser::where('rewards_from', 'Early Payment')
                ->pluck('invoice_no')
                ->toArray();

            foreach ($statementData as $data) {
                // Convert trn_date to Carbon for comparison
                $transactionDate = Carbon::parse($data['trn_date']);

                // Process only invoices from 2025 onwards and not already rewarded
                if (
                    $transactionDate->greaterThanOrEqualTo($startDate) &&
                    $data['vouchertypebasename'] === 'Sales' &&
                    !empty($data['trn_no']) &&
                    !empty($data['dramount']) &&
                    !in_array($data['trn_no'], $invoicesWithEarlyPayment)
                ) {
                    // Insert or update invoice details
                    RewardRemainderEarlyPayment::updateOrCreate(
                        [
                            'invoice_no' => $data['trn_no'], // Condition to check if the record exists
                        ],
                        [
                            'party_code'     => $partyCode,
                            'invoice_no'     => $data['trn_no'],
                            'invoice_date'   => $data['trn_date'],
                            'invoice_amount' => $data['dramount'],
                            'reminder_sent'  => 0,
                            'is_processed'   => 0,
                        ]
                    );

                    Log::info("Inserted/Updated invoice {$data['trn_no']} for party_code: $partyCode");
                } else {
                    Log::info("Skipped invoice {$data['trn_no']} for party_code: $partyCode - Already processed or has early payment reward.");
                }
            }
        }

        return response()->json(['message' => 'Early payment reminders data inserted successfully.'], 200);
    }

    public function sendEarlyPaymentWhatsApp()
    {
         $groupId = 'group_' . uniqid();  // Generate a unique group ID
        $currentDate = Carbon::now()->format('Y-m-d');



        // Fetch all records where reminders need to be sent
        $reminders = RewardRemainderEarlyPayment::get();

        

        if ($reminders->isEmpty()) {
            Log::warning("No pending reminders found.");
            return response()->json(['message' => 'No pending reminders found.'], 404);
        }

        foreach ($reminders as $reminder) {
            
            
            // $fileName = substr($payment_url, strpos($payment_url, "pay-amount/") + strlen("pay-amount/"));
            // $button_variable_encode_part=$fileName;
            // echo $payment_url .'<p>';
            // echo $button_variable_encode_part;
            // die();

            //Log::info('Payment URL: ' . $payment_url);

           
            $transactionDate = Carbon::parse($reminder->invoice_date);

            $firstReminderDate = $transactionDate->copy()->addDays(14)->format('Y-m-d');
            
            $secondReminderDate = $transactionDate->copy()->addDays(39)->format('Y-m-d');

             // echo $firstReminderDate;
             // die();
             $currentDate="2025-01-28";

            if ($currentDate == $firstReminderDate && $reminder->reminder_sent == 0) {
                $payment_url=$this->generatePaymentUrl($reminder->party_code, $payment_for="payable_amount");
                $discountLastDate = $transactionDate->copy()->addDays(20)->format('Y-m-d'); 
                $this->sendWhatsAppReminder($reminder->invoice_no, $reminder->invoice_amount, 1,$discountLastDate,$groupId,$payment_url);
                $reminder->update(['reminder_sent' => 1, 'is_processed' => 1]);
            }

            if ($currentDate == $secondReminderDate && $reminder->reminder_sent == 1) {
                $payment_url=$this->generatePaymentUrl($reminder->party_code, $payment_for="payable_amount");
                $discountLastDate = $transactionDate->copy()->addDays(45)->format('Y-m-d'); 
                $reminder->update(['is_processed' => 0]);  // Reset before sending the second reminder

                $this->sendWhatsAppReminder($reminder->invoice_no, $reminder->invoice_amount, 2,$discountLastDate,$payment_url);
                $reminder->update(['reminder_sent' => 2, 'is_processed' => 1]);
            }
            
        }
        SendWhatsAppMessagesJob::dispatch($groupId);

        return response()->json(['message' => 'WhatsApp reminders sent successfully.'], 200);
    }



    private function sendWhatsAppReminder($invoiceNo, $amount, $reminderType,$lastDate,$groupId,$payment_url)
    {
        $imageUrl = "https://mazingbusiness.com/public/reward_pdf/reward_image.jpg";

       Log::info('Payment URL: ' . trim($payment_url));

         $fileName = substr($payment_url, strpos($payment_url, "pay-amount/") + strlen("pay-amount/"));
         $button_variable_encode_part=$fileName;

        // Determine the discount message based on the reminder type
        $discountMessage = $reminderType == 1
            ? "First Reminder: Pay by {$lastDate} to avail a 2% discount."
            : "Final Reminder: Pay by {$lastDate} to avail a 1% discount.";

        // Prepare WhatsApp template data

              $templateData = [
                    'name' => 'test_early_payment_remainder',//  early_payment_reminders
                    'language' => 'en_US',
                    'components' => [
                        [
                            'type' => 'header',
                            'parameters' => [
                                ['type' => 'image', 'image' => ['link' => $imageUrl]],
                            ],
                        ],
                        [
                            'type' => 'body',
                            'parameters' => [
                                ['type' => 'text', 'text' => $invoiceNo],   // Invoice No
                                ['type' => 'text', 'text' => '₹' . number_format($amount, 2)],  // Invoice Amount formatted
                                ['type' => 'text', 'text' => $discountMessage],  // Discount message based on reminder type
                            ],
                        ],

                        [
                            'type' => 'button', 'sub_type' => 'url', 'index' => '0',
                            'parameters' => [
                                ['type' => 'text', 'text' => $button_variable_encode_part],
                            ],
                        ],
                    ],
                ];

        $whatsappNumbers = ['7044300330']; // Placeholder, replace with actual phone numbers

       
        $publicUrl = $payment_url;  // Set to actual URL if needed

        // Insert WhatsApp message data into the wa_sales_queue table
        DB::table('wa_sales_queue')->insert([
            'group_id'       => $groupId,
            'callback_data'  => $templateData['name'],
            'recipient_type' => 'individual',
            'to_number'      => '7044300330',
            'type'           => 'template',
            'file_url'       => $publicUrl,
            'content'        => json_encode($templateData),
            'status'         => 'pending',
            'response'       => '',
            'msg_id'         => '',
            'msg_status'     => '',
            'created_at'     => now(),
            'updated_at'     => now()
        ]);

        $this->whatsAppWebService = new WhatsAppWebService();

        // foreach ($whatsappNumbers as $number) {
        //     if (!empty($number)) {
        //         $jsonResponse = $this->whatsAppWebService->sendTemplateMessage($number, $templateData);
               

        //         // Check response and update status
        //         if (isset($jsonResponse['messages'][0]['message_status']) && $jsonResponse['messages'][0]['message_status'] === 'accepted') {
        //             Log::info("WhatsApp reminder sent successfully for Invoice No: {$invoiceNo}");
        //         } else {
        //             $error = $jsonResponse['messages'][0]['message_status'] ?? 'unknown';
        //             Log::error("Failed to send WhatsApp reminder for Invoice No: {$invoiceNo}. Status: $error");
        //         }
        //     }
        // }


    }
//  Functions start for cron job for early payment
    
}
