<?php

namespace App\Http\Controllers;

use App\Http\Controllers\AffiliateController;
use App\Mail\InvoiceEmailManager;
use App\Models\Address;
use App\Models\Cart;
use App\Models\CombinedOrder;
use App\Models\Coupon;
use App\Models\CouponUsage;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\Product;
use App\Models\Pincode;
use App\Models\ProductWarehouse;
use App\Models\SmsTemplate;
use App\Models\User;
use App\Models\Warehouse;
use App\Models\RewardPointsOfUser;

use App\Models\OwnBrandCategoryGroup;
use App\Models\OwnBrandCategory;
use App\Models\OwnBrandProduct;
use App\Models\OwnBrandOrder;
use App\Models\OwnBrandOrderDetail;

use App\Utility\NotificationUtility;
use App\Utility\SmsUtility;
use App\Utility\WhatsAppUtility;
use Auth;
use CoreComponentRepository;

use Illuminate\Support\Facades\Route;
use Mail;
use PDF;
use Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
// use App\Services\StatementCalculationService;

class OrderController extends Controller {
  // protected $statementCalculationService;
  // public function __construct(StatementCalculationService $statementCalculationService) {
  public function __construct() {  
    // Staff Permission Check
    $this->middleware(['permission:view_all_orders|view_inhouse_orders|view_seller_orders|view_pickup_point_orders'])->only('all_orders');
    // $this->middleware(['permission:view_order_details'])->only('show');
    $this->middleware(['permission:delete_order'])->only('destroy');
    // Inject the service
    // $this->statementCalculationService = $statementCalculationService;
  }

  // All Orders
  public function all_orders(Request $request) {

    CoreComponentRepository::instantiateShopRepository();

    $date            = $request->date;
    $sort_search     = null;
    $delivery_status = null;
    $payment_status  = '';

    $admin_user_id = User::where('user_type', 'admin')->first()->id;

    // Get distinct Salezing Order Punch Status responses
    $salzing_statuses = DB::table('salezing_logs')->distinct()->pluck('response');

    // Update the orders table where the related code in order_approvals is approved
    DB::table('orders')
        ->join('order_approvals', 'orders.code', '=', 'order_approvals.code')
        ->where('order_approvals.status', 'Approved')
        ->update(['orders.delivery_status' => 'Approved']);

     // Call the updateOrderDetails function to handle updating order details
    //  $result = $this->updateOrderDetails();

    // Start building the query with the necessary joins
    $orders = Order::select(
      'orders.*', 
      'addresses.company_name', 
      'salezing_logs.response', 
      'salezing_logs.status', 
      'users.warehouse_id', 
      'manager_users.name as manager_name', 
      'warehouses.name as warehouse_name' // Select warehouse name and alias it as warehouse_name
    )
    ->join('addresses', 'orders.address_id', '=', 'addresses.id')
    ->leftJoin('salezing_logs', DB::raw('CAST(orders.code AS CHAR CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci)'), '=', 'salezing_logs.code')
    ->join('users', 'orders.user_id', '=', 'users.id') // Join users table
    ->leftJoin('users as manager_users', 'users.manager_id', '=', 'manager_users.id') // Join for manager details
    ->leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id') // Join warehouses table to get warehouse name
    ->orderBy('orders.id', 'desc');

    // Apply filters based on the current route and user permissions
    if (Route::currentRouteName() == 'inhouse_orders.index' && Auth::user()->can('view_inhouse_orders')) {
        $orders = $orders->where('orders.seller_id', '=', $admin_user_id);
    } else if (Route::currentRouteName() == 'seller_orders.index' && Auth::user()->can('view_seller_orders')) {
        $orders = $orders->where('orders.seller_id', '!=', $admin_user_id);
    }

    // Apply search filters
    if ($request->search) {
        $sort_search = $request->search;
        $orders = $orders->where('orders.code', 'like', '%' . $sort_search . '%');
    }
    if ($request->payment_status != null) {
        $orders = $orders->where('orders.payment_status', $request->payment_status);
        $payment_status = $request->payment_status;
    }
    if ($request->delivery_status != null) {
        $orders = $orders->where('orders.delivery_status', $request->delivery_status);
        $delivery_status = $request->delivery_status;
    }
    if ($date != null) {
        $orders = $orders->whereBetween('orders.created_at', [
            date('Y-m-d', strtotime(explode(" to ", $date)[0])) . ' 00:00:00',
            date('Y-m-d', strtotime(explode(" to ", $date)[1])) . ' 23:59:59'
        ]);
    }

    // Apply Salzing Order Punch Status filter if selected
    if ($request->salzing_status != null) {
        $orders = $orders->where('salezing_logs.response', $request->salzing_status);
    }

    // Paginate and return the view with the orders and additional filters
    $orders = $orders->paginate(15);
    
    return view('backend.sales.index', compact('orders', 'sort_search', 'payment_status', 'delivery_status', 'date', 'salzing_statuses'));
  }

  public function all_unpushed_orders(Request $request) {

    CoreComponentRepository::instantiateShopRepository();

    $date            = $request->date;
    $sort_search     = null;
    $delivery_status = null;
    $payment_status  = '';

    $admin_user_id = User::where('user_type', 'admin')->first()->id;

    // Get distinct Salezing Order Punch Status responses
    $salzing_statuses = DB::table('salezing_logs')->distinct()->pluck('response');

    // // Update the orders table where the related code in order_approvals is approved
    // DB::table('orders')
    //     ->join('order_approvals', 'orders.code', '=', 'order_approvals.code')
    //     ->where('order_approvals.status', 'Approved')
    //     ->update(['orders.delivery_status' => 'Approved']);

    //  // Call the updateOrderDetails function to handle updating order details
    // //  $result = $this->updateOrderDetails();

    // // Start building the query with the necessary joins
    // $orders = Order::select(
    //   'orders.*', 
    //   'addresses.company_name', 
    //   'salezing_logs.response', 
    //   'salezing_logs.status', 
    //   'users.warehouse_id', 
    //   'manager_users.name as manager_name', 
    //   'warehouses.name as warehouse_name' // Select warehouse name and alias it as warehouse_name
    // )
    // ->join('addresses', 'orders.address_id', '=', 'addresses.id')
    // ->rightJoin('salezing_logs', DB::raw('CAST(orders.code AS CHAR CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci)'), '=', 'salezing_logs.code')
    // ->join('users', 'orders.user_id', '=', 'users.id') // Join users table
    // ->leftJoin('users as manager_users', 'users.manager_id', '=', 'manager_users.id') // Join for manager details
    // ->leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id') // Join warehouses table to get warehouse name
    // ->orderBy('orders.id', 'desc')->get()->toArray();

    $orders = Order::with('user:id,manager_id,warehouse_id,company_name','user.getManager:id,name','user.user_warehouse:id,name','order_approval:id,code,party_code,status')->where('payment_gateway_status','0')->orderBy('orders.id', 'desc');

    

    // Apply filters based on the current route and user permissions
    if (Route::currentRouteName() == 'inhouse_orders.index' && Auth::user()->can('view_inhouse_orders')) {
        $orders = $orders->where('orders.seller_id', '=', $admin_user_id);
    } else if (Route::currentRouteName() == 'seller_orders.index' && Auth::user()->can('view_seller_orders')) {
        $orders = $orders->where('orders.seller_id', '!=', $admin_user_id);
    }

    // Apply search filters
    if ($request->search) {
        $sort_search = $request->search;
        $orders = $orders->where('orders.code', 'like', '%' . $sort_search . '%');
    }
    if ($request->payment_status != null) {
        $orders = $orders->where('orders.payment_status', $request->payment_status);
        $payment_status = $request->payment_status;
    }
    if ($request->delivery_status != null) {
        $orders = $orders->where('orders.delivery_status', $request->delivery_status);
        $delivery_status = $request->delivery_status;
    }
    if ($date != null) {
        $orders = $orders->whereBetween('orders.created_at', [
            date('Y-m-d', strtotime(explode(" to ", $date)[0])) . ' 00:00:00',
            date('Y-m-d', strtotime(explode(" to ", $date)[1])) . ' 23:59:59'
        ]);
    }

    // Apply Salzing Order Punch Status filter if selected
    if ($request->salzing_status != null) {
        $orders = $orders->where('salezing_logs.response', $request->salzing_status);
    }

    // Paginate and return the view with the orders and additional filters
    $orders = $orders->paginate(15);
    
    return view('backend.sales.unpushed_orders', compact('orders', 'sort_search', 'payment_status', 'delivery_status', 'date', 'salzing_statuses'));
  }

  public function bulkOrderPushToSalezing(Request $request) {
    // print_r($request->selectedIds);
    foreach($request->selectedIds as $key=>$value){
      $this->pushOrderToSalzing($value);
    }
    return true;
  }

  public function pushOrderToSalzing($id)
  {
      // Fetch order data based on combined_order_id
      $orderData = DB::table('orders')->where('combined_order_id', $id)->first();

      if ($orderData) {
          // Check if a record exists in salezing_logs with the same order code
          $existingLog = DB::table('salezing_logs')->where('code', $orderData->code)->first();

          // If a record exists, delete it
          if ($existingLog) {
              DB::table('salezing_logs')->where('code', $orderData->code)->delete();
          }

          // Prepare the data to be pushed to the Salezing API
          $result = array();
          $result['code'] = $orderData->code;

          // Push order data to Salezing API
          $response = Http::withHeaders([
              'Content-Type' => 'application/json',
          ])->post('https://mazingbusiness.com/api/v2/order-push', $result);

          // Handle the response from the API
          if ($response->successful()) {

            $orderData->payment_gateway_status = '2';
            $orderData->save();
            // Set a success message
            return true;
              
          } else {
              // Set a failure message
              return false;
          }
      }else {
          // If no order data found, set an error message
          session()->flash('error', 'Order not found.');
      }
  }

  public function updateOrderDetails($code = '20240926-10392357') {
    // Step 1: Fetch data from `order_approvals` using the provided code
    $orderApproval = DB::table('order_approvals')
        ->where('code', $code)
        ->first();

    if (!$orderApproval) {
        return ['error' => 'Order not found'];
    }

    // Step 2: Get the JSON details from the `order_approvals` table
    $details = json_decode($orderApproval->details, true);

    // Step 3: Get the order ID from the `orders` table using the `code`
    $order = DB::table('orders')
        ->where('code', $orderApproval->code)
        ->first();

    if (!$order) {
        return ['error' => 'Order ID not found'];
    }

    $orderId = $order->id;

    // Step 4: Loop through the JSON details and search for each `part_no` in the `products` table
    foreach ($details as $item) {
        $partNo = $item['part_no'];
        $quantity = $item['order_qty'];
        $billAmount = $item['bill_amount']; // Use the bill_amount as price directly

        // Step 5: Get the product ID from the `products` table using `part_no`
        $product = DB::table('products')
            ->where('part_no', $partNo)
            ->first();

        if ($product) {
            // Step 6: Update the `quantity` and `price` (using `bill_amount`) in the `order_details` table
            DB::table('order_details')
                ->where('order_id', $orderId)
                ->where('product_id', $product->id)
                ->update([
                    'approved_quantity' => (int)$quantity,
                    'sz_bill_amount' => $billAmount // Directly use the `bill_amount` as the price
                ]);
        }
    }

    return ['success' => 'Order details updated successfully'];
  }

  public function show($id) {
    
    $order                  = Order::findOrFail(decrypt($id));
    $order_shipping_address = json_decode($order->shipping_address);
    $delivery_boys          = User::where('city', $order_shipping_address->city)
      ->where('user_type', 'delivery_boy')
      ->get();

    $order->viewed = 1;
    $order->save();

    // echo "<pre>";
    // print_r($order->orderDetails->toArray());
    // die();

    return view('backend.sales.show', compact('order', 'delivery_boys'));
  }


  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create() {
    //
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param \Illuminate\Http\Request $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request) {

   
    $carts = Cart::where('user_id', Auth::user()->id)->get();
    if ($carts->isEmpty()) {
      flash(translate('Your cart is empty'))->warning();
      return redirect()->route('home');
    }else{
      flash(translate('working!'))->warning();
    }

    $address         = Address::where('id', $carts[0]['address_id'])->first();
    $pincode         = Pincode::where('pincode', $address->postal_code)->first();
    $shippingAddress = [];
    $address_id = null;
    if ($address != null) {
      $address_id = $address->id;
      $shippingAddress['name']         = Auth::user()->name;
      $shippingAddress['company_name'] = Auth::user()->company_name;
      $shippingAddress['gstin']        = Auth::user()->gstin;
      $shippingAddress['email']        = Auth::user()->email;
      $shippingAddress['address']      = $address->address;
      $shippingAddress['country']      = $address->country->name;
      $shippingAddress['state']        = $address->state->name;
      //$shippingAddress['city']         = $address->city->name;
      $shippingAddress['city']         = $pincode->city;
      $shippingAddress['postal_code']  = $address->postal_code;
      $shippingAddress['phone']        = $address->phone; 
      if ($address->latitude || $address->longitude) {
        $shippingAddress['lat_lang'] = $address->latitude . ',' . $address->longitude;
      }
    }

    $combined_order                   = new CombinedOrder;
    $combined_order->user_id          = Auth::user()->id;
    $combined_order->shipping_address = json_encode($shippingAddress);
    $combined_order->save();

    $admin_items = array();

    $seller_products = array();
    foreach ($carts as $cartItem) {
        $product_ids = array();
        $product = Product::find($cartItem['product_id']);
        if (isset($seller_products[$product->user_id])) {
            $product_ids = $seller_products[$product->user_id];
        }
        array_push($product_ids, $cartItem);
        $seller_products[$product->user_id] = $product_ids;
    }
    
    $no_credit_item_flag = 0;
    $cash_and_carry_item_subtotal = 0;
    $rewardsValue = 0;
    foreach ($seller_products as $seller_product) {
      
      $order = new Order;
      $order->combined_order_id = $combined_order->id;
      $order->user_id = Auth::user()->id;
      $order->shipping_address = $combined_order->shipping_address;

      $order->additional_info = $request->additional_info;
      $order->address_id = $address_id;
      // $order->shipping_type = $carts[0]['shipping_type'];
      // if ($carts[0]['shipping_type'] == 'pickup_point') {
      //     $order->pickup_point_id = $cartItem['pickup_point'];
      // }
      // if ($carts[0]['shipping_type'] == 'carrier') {
      //     $order->carrier_id = $cartItem['carrier_id'];
      // }

      $order->payment_type = $request->payment_option;
      $order->delivery_viewed = '0';
      $order->payment_status_viewed = '0';
      $order->payment_gateway_status = '0';
      $order->payable_amount = $request->payable_amount;
      $order->code = date('Ymd-His') . rand(10, 99);
      $order->date = strtotime('now');
      $order->payment_gateway_status = '0';
      $order->order_from = 'website';
      $order->save();

      $subtotal = 0;
      $tax = 0;
      $shipping = 0;
      $coupon_discount = 0;

      //Order Details Storing
      foreach ($seller_product as $cartItem) {
          $admin_items_line = array();

          $product = Product::find($cartItem['product_id']);
          if(session()->has('staff_id') AND (session()->get('staff_id')==180 OR session()->get('staff_id')==169 OR session()->get('staff_id')==25606)){
            $subtotal += $cartItem['price'] * $cartItem['quantity'];
            // $tax +=  $cartItem['price'] * $cartItem['quantity'];
            $tax +=  cart_product_tax($cartItem, $product, false, Auth::user()->id) * $cartItem['quantity'];
          }else{
            $subtotal += cart_product_price($cartItem, $product, false, false, Auth::user()->id) * $cartItem['quantity'];
            $tax +=  cart_product_tax($cartItem, $product, false, Auth::user()->id) * $cartItem['quantity'];
          }
          
          $coupon_discount += $cartItem['discount'];

          $product_variation = $cartItem['variation'];
          if($product_variation != ""){
              // $product_stock = $product->stocks->where('variant', $product_variation)->first();
              $product_stock = $product->stocks->where('product_id', $cartItem['product_id'])->first();
              // echo "<pre>...";print_r($cartItem);print_r($product_stock);die;
            if ($product->digital != 1 && isset($product_stock->qty) && $cartItem['quantity'] > $product_stock->qty && false) {
                flash(translate('The requested quantity is not available for ') . $product->getTranslation('name'))->warning();
                $order->delete();
                return redirect()->route('cart')->send();
            } elseif ($product->digital != 1) {
                // $product_stock->qty -= $cartItem['quantity'];
                $product_stock->save();
            }
          }
          

          $order_detail = new OrderDetail;
          $order_detail->order_id = $order->id;
          $order_detail->seller_id = $product->user_id;
          $order_detail->product_id = $product->id;
          $order_detail->variation = $product_variation;
          if(session()->has('staff_id') AND (session()->get('staff_id')==180 OR session()->get('staff_id')==169 OR session()->get('staff_id')==25606)){
            // $order_detail->tax = $cartItem['price'] * $cartItem['quantity'];
            $order_detail->tax = cart_product_tax($cartItem, $product, false,Auth::user()->id) * $cartItem['quantity'];
            $order_detail->price = $cartItem['price'] * $cartItem['quantity'];
          }else{
            $order_detail->tax = cart_product_tax($cartItem, $product, false,Auth::user()->id) * $cartItem['quantity'];
            // $order_detail->price = cart_product_price($cartItem, $product, false, false,Auth::user()->id) * $cartItem['quantity'];
            $order_detail->price = $cartItem['price'] * $cartItem['quantity'];
          }
          
          
          $order_detail->shipping_type = $cartItem['shipping_type'];
          $order_detail->product_referral_code = $cartItem['product_referral_code'];
          $order_detail->shipping_cost = $cartItem['shipping_cost'];
          $order_detail->cash_and_carry_item = $cartItem['cash_and_carry_item'];
          if($cartItem['cash_and_carry_item'] == 1){
            $no_credit_item_flag = 1;
            $cash_and_carry_item_subtotal += $cartItem['price'] * $cartItem['quantity'];
          }
          $admin_items_line['name'] = $product->name;
          $admin_items_line['new_part_no'] = $product->alias_name;
          $admin_items_line['part_no'] = $product->part_no;
          if(session()->has('staff_id') AND (session()->get('staff_id')==180 OR session()->get('staff_id')==169 OR session()->get('staff_id')==25606)){
            $admin_items_line['net_price'] = $cartItem['price'];
          }else{
            $admin_items_line['net_price'] = cart_product_price($cartItem, $product, false, false, Auth::user()->id);
          }
          
          $admin_items_line['quantity'] = $cartItem['quantity'];

          $admin_items[] = $admin_items_line;

          $shipping += $order_detail->shipping_cost;
          //End of storing shipping cost

          $order_detail->quantity = $cartItem['quantity'];
          $order_detail->applied_offer_id = $cartItem['applied_offer_id'];
          $order_detail->complementary_item = $cartItem['complementary_item'];
          $order_detail->offer_rewards = $cartItem['offer_rewards'];
          if($rewardsValue == 0 AND $cartItem['offer_rewards'] != ""){
            $rewardsValue = $cartItem['offer_rewards'];
          }
          if (addon_is_activated('club_point')) {
              $order_detail->earn_point = $product->earn_point;
          }
          $order_detail->save();
          //echo "<pre>";print_r($order_detail);die;

          $product->num_of_sale += $cartItem['quantity'];
          $product->save();

          $order->seller_id = $product->user_id;
          $order->shipping_type = $cartItem['shipping_type'];
          
          if ($cartItem['shipping_type'] == 'pickup_point') {
              $order->pickup_point_id = $cartItem['pickup_point'];
          }
          if ($cartItem['shipping_type'] == 'carrier') {
              $order->carrier_id = $cartItem['carrier_id'];
          }

          if ($product->added_by == 'seller' && $product->user->seller != null) {
              $seller = $product->user->seller;
              $seller->num_of_sale += $cartItem['quantity'];
              $seller->save();
          }

          if (addon_is_activated('affiliate_system')) {
              if ($order_detail->product_referral_code) {
                  $referred_by_user = User::where('referral_code', $order_detail->product_referral_code)->first();

                  $affiliateController = new AffiliateController;
                  $affiliateController->processAffiliateStats($referred_by_user->id, 0, $order_detail->quantity, 0, 0);
              }
          }
      }

      $order->grand_total = $subtotal  + $shipping;

      if ($seller_product[0]->coupon_code != null) {
          $order->coupon_discount = $coupon_discount;
          $order->grand_total -= $coupon_discount;

          $coupon_usage = new CouponUsage;
          $coupon_usage->user_id = Auth::user()->id;
          $coupon_usage->coupon_id = Coupon::where('code', $seller_product[0]->coupon_code)->first()->id;
          $coupon_usage->save();
      }

      $total = $combined_order->grand_total += $order->grand_total;

      $order->save();

    }

    $user_mobile = substr(Auth::user()->phone, -10);
    $party_code = Auth::user()->old_party_code;  

    $combined_order->save();

    // Rewards Offer submit in rewards table
    if($rewardsValue != 0){
      $user =  // Fetch the user and associated data
      $user = User::with('warehouse')->findOrFail(Auth::user()->id);

      // Create a new record in the RewardPointsOfUser model
      RewardPointsOfUser::create([
          'party_code' => $user->party_code,
          'rewards_from' => 'Offer', // Default value
          'warehouse_id' => $user->warehouse->id ?? null,
          'warehouse_name' => $user->warehouse->name ?? null,
          'rewards' => $rewardsValue,
          'dr_or_cr' => 'dr', // Default value
      ]);
    }
    
    // $order_detail                 = $order_detail->toArray();
    // $order_detail['product_name'] = Product::where('id', $order_detail['product_id'])->first('name');
    $order                        = Order::findOrFail($order_detail['order_id']);
    $font_family                  = "'Roboto','sans-serif'";
    $direction                    = 'ltr';
    $text_align                   = 'left';
    $not_text_align               = 'right';
    $config                       = [];
    $pdf                          = PDF::loadView('backend.invoices.proformainvoice', [
      'order'          => $order,
      'font_family'    => $font_family,
      'direction'      => $direction,
      'text_align'     => $text_align,
      'not_text_align' => $not_text_align,
    ], [], $config);

    // // Prepare the data for the API request
    //   $data = [
    //     "order_id" => $order->code,
    //     "client" => $user_mobile,
    //     "partycode" => $party_code,
    //     "discount" => "",
    //     "items" => $admin_items
    // ];
  
    // // Send the HTTP request to the API endpoint
    // try {
     
    //   $response = Http::post('https://admin.mazingbusiness.com/api/order.php', $data);
    //   // Handle the response as needed
    //   $responseData = $response->json(); // Assuming the response is JSON
    //   // dd($responseData); // Print the response data for debugging
    // } catch (\Exception $e) {
    //   // Handle exceptions if the request fails
    //   //dd($e->getMessage());
    // }

   
    $data = array();    
    //------------ Calculation for pass the order to salzing or not end
    try {
      if(Auth::user()->id != '24185'){
        // Push order data to Salezing
        $result=array();
        $result['code']= $order->code;
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('https://mazingbusiness.com/api/v2/order-push', $result);
        \Log::info('Salzing Order Push From Website Status: '  . json_encode($response->json(), JSON_PRETTY_PRINT));
      }else{
        // //------------ Calculation for pass the order to salzing or not start 
        // $calculationResponse = $this->statementCalculationService->calculateForOneCompany(Auth::user()->id, 'live');
        // // Decode the JSON response to an array
        // $calculationResponse = $calculationResponse->getData(true);

        // $overdueAmount = $calculationResponse['overdueAmount'];
        // $dueAmount = $calculationResponse['dueAmount'];

        // $credit_limit = Auth::user()->credit_limit;
        // $current_limit = $dueAmount - $overdueAmount;
        // $currentAvailableCreditLimit = $credit_limit - $current_limit;
        // $exceededAmount = ($total - $currentAvailableCreditLimit) + $overdueAmount;
        // //-------------------------- This is for case 2 ------------------------------
        // if($current_limit == 0){        
        //     if($total > $currentAvailableCreditLimit){
        //         $exceededAmount = ($total - $currentAvailableCreditLimit) + $overdueAmount;
        //     }else{
        //         $exceededAmount = $overdueAmount;
        //     }

        // }else{
        //     if($total > $currentAvailableCreditLimit)
        //     {
        //         $exceededAmount = ($total - $currentAvailableCreditLimit) + $overdueAmount;
        //     }else{
        //         $exceededAmount = $overdueAmount;
        //     }
        // }
        // //----------------------------------------------------------------------------
        // $payableAmount = $exceededAmount + $cash_and_carry_item_subtotal;
      }

    } catch (\Exception $e) {
      // Handle exceptions if the request fails
      //dd($e->getMessage());
    }
    // Send email
    // Mail::send('emails.order_placed', $order_detail, function ($message) use ($pdf, $order) {
      // $message->to('kburhanuddin12@gmail.com', 'Mazing Business')->subject('New Order has been placed on Mazing Business')->attachData($pdf->output(), 'order-' . $order->code . '.pdf');
      // $message->from(env('MAIL_FROM_ADDRESS'), 'Mazing Business');
    // });
    $request->session()->put('combined_order_id', $combined_order->id);
  }

  

  /**
   * Display the specified resource.
   *
   * @param int $id
   * @return \Illuminate\Http\Response
   */

  /**
   * Show the form for editing the specified resource.
   *
   * @param int $id
   * @return \Illuminate\Http\Response
   */
  public function edit($id) {
    //
  }

  /**
   * Update the specified resource in storage.
   *
   * @param \Illuminate\Http\Request $request
   * @param int $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id) {
    //
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param int $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id) {
    $order = Order::findOrFail($id);
    if ($order != null) {
      foreach ($order->orderDetails as $key => $orderDetail) {
        try {

          $product_stock = ProductStock::where('product_id', $orderDetail->product_id)->where('variant', $orderDetail->variation)->first();
          if ($product_stock != null) {
            $product_stock->qty += $orderDetail->quantity;
            $product_stock->save();
          }
        } catch (\Exception $e) {
        }

        $orderDetail->delete();
      }
      $order->delete();
      flash(translate('Order has been deleted successfully'))->success();
    } else {
      flash(translate('Something went wrong'))->error();
    }
    return back();
  }

  public function bulk_order_delete(Request $request) {
    if ($request->id) {
      foreach ($request->id as $order_id) {
        $this->destroy($order_id);
      }
    }

    return 1;
  }

  public function order_details(Request $request) {
    $order = Order::findOrFail($request->order_id);
    $order->save();
    return view('seller.order_details_seller', compact('order'));
  }

  public function update_delivery_status(Request $request) {
    $order = Order::findOrFail($request->order_id);
    if ($request->status == 'on_the_way' && !$order->tracking_code) {
      return 0;
    }
    $order->delivery_viewed = '0';
    $order->delivery_status = $request->status;
    $order->save();

    if ($request->status == 'cancelled' && $order->payment_type == 'wallet') {
      $user = User::where('id', $order->user_id)->first();
      $user->balance += $order->grand_total;
      $user->save();
    }

    if (Auth::user()->user_type == 'seller') {
      foreach ($order->orderDetails->where('seller_id', Auth::user()->id) as $key => $orderDetail) {
        $orderDetail->delivery_status = $request->status;
        $orderDetail->save();
        if ($request->status == 'cancelled') {
          $variant = $orderDetail->variation;
          if ($orderDetail->variation == null) {
            $variant = '';
          }
          $product_stock = ProductWarehouse::where('product_id', $orderDetail->product_id)
            ->where('variant', $variant)
            ->first();
          if ($product_stock != null) {
            $product_stock->qty += $orderDetail->quantity;
            $product_stock->save();
          }
        }
      }
    } else {
      foreach ($order->orderDetails as $key => $orderDetail) {
        $orderDetail->delivery_status = $request->status;
        $orderDetail->save();
        if ($request->status == 'cancelled') {
          $variant = $orderDetail->variation;
          if ($orderDetail->variation == null) {
            $variant = '';
          }
          $product_stock = ProductWarehouse::where('product_id', $orderDetail->product_id)
            ->where('variant', $variant)
            ->first();
          if ($product_stock != null) {
            $product_stock->qty += $orderDetail->quantity;
            $product_stock->save();
          }
        }

        if (addon_is_activated('affiliate_system')) {
          if (($request->status == 'delivered' || $request->status == 'cancelled') &&
            $orderDetail->product_referral_code
          ) {

            $no_of_delivered = 0;
            $no_of_canceled  = 0;

            if ($request->status == 'delivered') {
              $no_of_delivered = $orderDetail->quantity;
            }
            if ($request->status == 'cancelled') {
              $no_of_canceled = $orderDetail->quantity;
            }

            $referred_by_user = User::where('referral_code', $orderDetail->product_referral_code)->first();

            $affiliateController = new AffiliateController;
            $affiliateController->processAffiliateStats($referred_by_user->id, 0, 0, $no_of_delivered, $no_of_canceled);
          }
        }
      }
    }
    if (addon_is_activated('otp_system')) {
      if ($order->delivery_status == 'confirmed') {
        WhatsAppUtility::orderConfirmed($order->user, $order);
      } elseif ($order->delivery_status == 'on_the_way') {
        WhatsAppUtility::orderShipped($order->user, $order);
      } elseif ($order->delivery_status == 'cancelled') {
        WhatsAppUtility::orderCancelled($order->user, $order);
      }
    }

    //sends Notifications to user
    NotificationUtility::sendNotification($order, $request->status);
    if (get_setting('google_firebase') == 1 && $order->user->device_token != null) {
      $request->device_token = $order->user->device_token;
      $request->title        = "Order updated !";
      $status                = str_replace("_", "", $order->delivery_status);
      $request->text         = " Your order {$order->code} has been {$status}";

      $request->type    = "order";
      $request->id      = $order->id;
      $request->user_id = $order->user->id;

      NotificationUtility::sendFirebaseNotification($request);
    }

    if (addon_is_activated('delivery_boy')) {
      if (Auth::user()->user_type == 'delivery_boy') {
        $deliveryBoyController = new DeliveryBoyController;
        $deliveryBoyController->store_delivery_history($order);
      }
    }

    return 1;
  }

  public function update_tracking_code(Request $request) {
    $order                = Order::findOrFail($request->order_id);
    $order->tracking_code = $request->tracking_code;
    $order->save();

    return 1;
  }

  public function update_payment_status(Request $request) {
    $order                        = Order::findOrFail($request->order_id);
    $order->payment_status_viewed = '0';
    $order->save();

    if (Auth::user()->user_type == 'seller') {
      foreach ($order->orderDetails->where('seller_id', Auth::user()->id) as $key => $orderDetail) {
        $orderDetail->payment_status = $request->status;
        $orderDetail->save();
      }
    } else {
      foreach ($order->orderDetails as $key => $orderDetail) {
        $orderDetail->payment_status = $request->status;
        $orderDetail->save();
      }
    }

    $order->payment_status = $status = $request->status;
    if ($order->payment_status == 'paid') {
      foreach ($order->orderDetails as $key => $orderDetail) {
        if ($orderDetail->payment_status != 'paid') {
          $status = 'unpaid';
        }
      }
      $latest_confirmed_order = Order::where('code', 'like', 'MZ%')->orderBy('created_at', 'desc')->orderBy('id', 'desc')->first();
      if ($latest_confirmed_order) {
        $code                   = explode('/', $latest_confirmed_order->code);
        $latest_confirmed_order = 'MZ/' . str_pad((((int) $code[1]) + 1), 5, '0', STR_PAD_LEFT) . '/' . (date('m') > 3 ? date('y') . '-' . ((int) date('y') + 1) : (int) date('y') - 1 . '-' . date('y'));
      } else {
        $latest_confirmed_order = 'MZ/00001/' . (date('m') > 3 ? date('y') . '-' . ((int) date('y') + 1) : (int) date('y') - 1 . '-' . date('y'));
      }
      $order->code = $latest_confirmed_order;
    }
    if ($order->payment_status == 'request-details') {
      $status = 'request-details';
    }
    $order->payment_status = $status;
    $order->save();

    if (
      $order->payment_status == 'paid' &&
      $order->commission_calculated == 0
    ) {
      calculateCommissionAffilationClubPoint($order);
    }

    //sends Notifications to user
    NotificationUtility::sendNotification($order, $request->status);
    if (get_setting('google_firebase') == 1 && $order->user->device_token != null && $status == 'paid') {
      $request->device_token = $order->user->device_token;
      $request->title        = "Order updated !";
      $status                = str_replace("_", "", $order->payment_status);
      $request->text         = " Your order {$order->code} has been {$status}";

      $request->type    = "order";
      $request->id      = $order->id;
      $request->user_id = $order->user->id;

      NotificationUtility::sendFirebaseNotification($request);
    }

    if (addon_is_activated('otp_system') && $status == 'paid') {
      WhatsAppUtility::paymentConfirmation($order->user, $order);
    }
    if (addon_is_activated('otp_system') && $order->payment_status == 'request-details') {
      WhatsAppUtility::requestPaymentConfirmation($order->user, $order);
    }
    return 1;
  }

  public function assign_delivery_boy(Request $request) {
    if (addon_is_activated('delivery_boy')) {

      $order                        = Order::findOrFail($request->order_id);
      $order->assign_delivery_boy   = $request->delivery_boy;
      $order->delivery_history_date = date("Y-m-d H:i:s");
      $order->save();

      $delivery_history = \App\Models\DeliveryHistory::where('order_id', $order->id)
        ->where('delivery_status', $order->delivery_status)
        ->first();

      if (empty($delivery_history)) {
        $delivery_history = new \App\Models\DeliveryHistory;

        $delivery_history->order_id        = $order->id;
        $delivery_history->delivery_status = $order->delivery_status;
        $delivery_history->payment_type    = $order->payment_type;
      }
      $delivery_history->delivery_boy_id = $request->delivery_boy;

      $delivery_history->save();

      if (env('MAIL_USERNAME') != null && get_setting('delivery_boy_mail_notification') == '1') {
        $array['view']    = 'emails.invoice';
        $array['subject'] = translate('You are assigned to delivery an order. Order code') . ' - ' . $order->code;
        $array['from']    = env('MAIL_FROM_ADDRESS');
        $array['order']   = $order;

        try {
          Mail::to($order->delivery_boy->email)->queue(new InvoiceEmailManager($array));
        } catch (\Exception $e) {
        }
      }

      if (addon_is_activated('otp_system') && SmsTemplate::where('identifier', 'assign_delivery_boy')->first()->status == 1) {
        try {
          SmsUtility::assign_delivery_boy($order->delivery_boy->phone, $order->code);
        } catch (\Exception $e) {
        }
      }
    }

    return 1;
  }

  public function updateStatus(Request $request)
  {
      // Retrieve input data from the request
      $party_code = $request->input('party_code');
      $code = $request->input('code');
      $status = $request->input('status');
      $details = $request->input('details');
      $timestamp = $request->input('timestamp');

      // Log the input data for debugging
      Log::info('Party Code: ' . $party_code);
      Log::info('Code: ' . $code);
      Log::info('Status: ' . $status);
      Log::info('Details: ' . json_encode($details));
      Log::info('Timestamp: ' . $timestamp);

      // Validate the input data
      $validator = \Validator::make($request->all(), [
          'party_code' => 'required|string',
          'code' => 'required|string',
          'status' => 'required|string',
          'details' => 'required|array',
          'timestamp' => 'required|date_format:Y-m-d H:i:s',
      ]);

      if ($validator->fails()) {
          return response()->json(['status' => 'Error', 'message' => $validator->errors()], 400);
      }

      // Convert details array to JSON string
      $detailsJson = json_encode($details);

      // Insert data into the database
      try {
          DB::table('order_approvals')->insert([
              'party_code' => $party_code,
              'code' => $code,
              'status' => $status,
              'details' => $detailsJson,
              'timestamp' => $timestamp,
          ]);

          return response()->json([
              'status' => 'Success',
              'message' => 'Order status updated successfully',
              'data' => [
                  'party_code' => $party_code,
                  'code' => $code,
                  'status' => $status,
                  'timestamp' => $timestamp,
              ],
          ]);

      } catch (\Exception $e) {
          return response()->json(['status' => 'Error', 'message' => 'Database error: ' . $e->getMessage()], 500);
      }
  }

  public function all_international_orders(Request $request) {

    $date            = $request->date;
    $sort_search     = null;
    $delivery_status = null;
    $payment_status  = '';

    $admin_user_id = User::where('user_type', 'admin')->first()->id;

    // Start building the query with the necessary joins
    $orders = OwnBrandOrder::select(
      'own_brand_orders.*',
      'users.company_name as customer_company_name', 
      'users.name as customer_name'
    )
    ->join('users', 'own_brand_orders.customer_id', '=', 'users.id') // Join users table
    ->where('own_brand_orders.delivery_status','pending')
    ->with('orderDetails')
    ->orderBy('own_brand_orders.id', 'DESC');


    // Apply search filters
    if ($request->search) {
        $sort_search = $request->search;
        $orders = $orders->where('orders.code', 'like', '%' . $sort_search . '%');
    }
    if ($request->payment_status != null) {
        $orders = $orders->where('orders.payment_status', $request->payment_status);
        $payment_status = $request->payment_status;
    }
    if ($request->delivery_status != null) {
        $orders = $orders->where('orders.delivery_status', $request->delivery_status);
        $delivery_status = $request->delivery_status;
    }
    if ($date != null) {
        $orders = $orders->whereBetween('orders.created_at', [
            date('Y-m-d', strtotime(explode(" to ", $date)[0])) . ' 00:00:00',
            date('Y-m-d', strtotime(explode(" to ", $date)[1])) . ' 23:59:59'
        ]);
    }

    // Paginate and return the view with the orders and additional filters
    $orders = $orders->paginate(15);
    
    return view('backend.sales.all_international_orders', compact('orders', 'sort_search', 'payment_status', 'delivery_status', 'date'));
  }

  public function all_international_in_review_orders(Request $request) {

    $date            = $request->date;
    $sort_search     = null;
    $delivery_status = null;
    $payment_status  = '';

    $admin_user_id = User::where('user_type', 'admin')->first()->id;

    // Start building the query with the necessary joins
    $orders = OwnBrandOrder::select(
      'own_brand_orders.*',
      'users.company_name as customer_company_name', 
      'users.name as customer_name'
    )
    ->join('users', 'own_brand_orders.customer_id', '=', 'users.id') // Join users table
    ->where('own_brand_orders.delivery_status','in_review')
    ->with('orderDetails')
    ->orderBy('own_brand_orders.id', 'DESC');


    // Apply search filters
    if ($request->search) {
        $sort_search = $request->search;
        $orders = $orders->where('orders.code', 'like', '%' . $sort_search . '%');
    }
    if ($request->payment_status != null) {
        $orders = $orders->where('orders.payment_status', $request->payment_status);
        $payment_status = $request->payment_status;
    }
    if ($request->delivery_status != null) {
        $orders = $orders->where('orders.delivery_status', $request->delivery_status);
        $delivery_status = $request->delivery_status;
    }
    if ($date != null) {
        $orders = $orders->whereBetween('orders.created_at', [
            date('Y-m-d', strtotime(explode(" to ", $date)[0])) . ' 00:00:00',
            date('Y-m-d', strtotime(explode(" to ", $date)[1])) . ' 23:59:59'
        ]);
    }

    // Paginate and return the view with the orders and additional filters
    $orders = $orders->paginate(15);
    
    return view('backend.sales.all_international_in_review_orders', compact('orders', 'sort_search', 'payment_status', 'delivery_status', 'date'));
  }

  public function all_international_approved_orders(Request $request) {

    $date            = $request->date;
    $sort_search     = null;
    $delivery_status = null;
    $payment_status  = '';

    $admin_user_id = User::where('user_type', 'admin')->first()->id;

    // Start building the query with the necessary joins
    $orders = OwnBrandOrder::select(
      'own_brand_orders.*',
      'users.company_name as customer_company_name', 
      'users.name as customer_name'
    )
    ->join('users', 'own_brand_orders.customer_id', '=', 'users.id') // Join users table
    ->where('own_brand_orders.delivery_status','confirm')
    ->with('orderDetails')
    ->orderBy('own_brand_orders.id', 'DESC');


    // Apply search filters
    if ($request->search) {
        $sort_search = $request->search;
        $orders = $orders->where('orders.code', 'like', '%' . $sort_search . '%');
    }
    if ($request->payment_status != null) {
        $orders = $orders->where('orders.payment_status', $request->payment_status);
        $payment_status = $request->payment_status;
    }
    if ($request->delivery_status != null) {
        $orders = $orders->where('orders.delivery_status', $request->delivery_status);
        $delivery_status = $request->delivery_status;
    }
    if ($date != null) {
        $orders = $orders->whereBetween('orders.created_at', [
            date('Y-m-d', strtotime(explode(" to ", $date)[0])) . ' 00:00:00',
            date('Y-m-d', strtotime(explode(" to ", $date)[1])) . ' 23:59:59'
        ]);
    }

    // Paginate and return the view with the orders and additional filters
    $orders = $orders->paginate(15);
    
    return view('backend.sales.all_international_approved_orders', compact('orders', 'sort_search', 'payment_status', 'delivery_status', 'date'));
  }

  public function international_pending_order_details($id) {

    $order = OwnBrandOrder::with(['orderDetails' => function($query) {
        $query->whereNull('deleted_at');
    },'product'])->findOrFail(decrypt($id));

    $deleteOrderProduct = OwnBrandOrder::with(['orderDetails' => function($query) {
        $query->onlyTrashed(); // Use onlyTrashed() to get soft-deleted order details
    },'product'])->findOrFail(decrypt($id));
    return view('backend.sales.international_pending_order_details', compact('order','deleteOrderProduct'));
  }

  public function international_confirm_order_details($id) {

    $order = OwnBrandOrder::with(['orderDetails' => function($query) {
        $query->whereNull('deleted_at');
    },'product'])->findOrFail(decrypt($id));

    $deleteOrderProduct = OwnBrandOrder::with(['orderDetails' => function($query) {
        $query->onlyTrashed(); // Use onlyTrashed() to get soft-deleted order details
    },'product'])->findOrFail(decrypt($id));
    return view('backend.sales.international_confirm_order_details', compact('order','deleteOrderProduct'));
  }

  public function international_order_update_delivery_status(Request $request) {
    $order = OwnBrandOrder::findOrFail($request->order_id);
    $order->delivery_status = $request->status;
    $order->save();
    $uodateArray = array();
    $uodateArray['delivery_status'] = $request->status;
    $order = OwnBrandOrderDetail::where('order_id',$request->order_id)->update($uodateArray);
    return true;
  }

  public function international_order_update_confirm_status(Request $request) {
    $order = OwnBrandOrder::findOrFail($request->order_id);
    $order->delivery_status = 'confirm';
    $order->advance_amount = $request->advance_amount;
    $order->save();
    $uodateArray = array();
    $uodateArray['delivery_status'] = $request->status;
    $order = OwnBrandOrderDetail::where('order_id',$request->order_id)->update($uodateArray);
    return true;
  }

  public function international_order_update_payment_status(Request $request) {

    $order = OwnBrandOrder::findOrFail($request->order_id);
    $order->payment_status = $request->status;
    $order->save();
    $uodateArray = array();
    $uodateArray['payment_status'] = $request->status;
    $order = OwnBrandOrderDetail::where('order_id',$request->order_id)->update($uodateArray); 
    return true;
  }

  public function international_order_update_qty(Request $request) {
    $orderDetails = OwnBrandOrderDetail::findOrFail($request->order_detail_id);
    $order = OwnBrandOrder::where('id',$orderDetails->order_id)->first();
    $subtotal = $orderDetails->unit_price * $request->qty;
    $orderDetails->total_price = $orderDetails->unit_price * $request->qty;
    $orderDetails->quantity = $request->qty;
    $orderDetails->save();

    $grand_total = OwnBrandOrderDetail::where('order_id', $orderDetails->order_id)->sum('total_price');
    $updateArray = array();
    $updateArray['grand_total'] = $grand_total;
    OwnBrandOrder::where('id',$orderDetails->order_id)->update($updateArray);

    return response()->json([
        'subtotal' => $subtotal,
        'grandTotal' => $grand_total,
        'currency' => $order->currency
    ], 200);

  }

  public function international_order_update_unit_price(Request $request) {
    $orderDetails = OwnBrandOrderDetail::findOrFail($request->order_detail_id);
    $order = OwnBrandOrder::where('id',$orderDetails->order_id)->first();
    $subtotal = $orderDetails->quantity * $request->unit_price;
    $orderDetails->total_price = $orderDetails->quantity * $request->unit_price;
    $orderDetails->unit_price = $request->unit_price;
    $orderDetails->save();

    $grand_total = OwnBrandOrderDetail::where('order_id', $orderDetails->order_id)->sum('total_price');
    $updateArray = array();
    $updateArray['grand_total'] = $grand_total;
    OwnBrandOrder::where('id',$orderDetails->order_id)->update($updateArray);

    return response()->json([
        'subtotal' => $subtotal,
        'grandTotal' => $grand_total,
        'currency' => $order->currency
    ], 200);
  }

  public function international_order_update_brand(Request $request) {
    $orderDetails = OwnBrandOrderDetail::findOrFail($request->order_detail_id);    
    $orderDetails->brand_name = $request->brand_name;
    $orderDetails->brand = $request->brand;
    $orderDetails->save();

    return response()->json([
        'brand' => $request->brand,
        'brand_name' => $request->brand_name,
        'order_detail_id' => $request->order_detail_id
    ], 200);
  }

  public function international_order_add_or_update_comment_and_days_of_delivery(Request $request) {
    $orderDetails = OwnBrandOrderDetail::findOrFail($request->order_detail_id);    
    $orderDetails->comment = $request->comment;
    $orderDetails->days_of_delivery = $request->days_of_delivery;
    $orderDetails->save();

    return response()->json([
        'comment' => $request->comment,
        'days_of_delivery' => $request->days_of_delivery,
        'order_detail_id' => $request->order_detail_id
    ], 200);
  }

  public function international_order_delete_product(Request $request) {
    $orderDetails = OwnBrandOrderDetail::findOrFail($request->order_detail_id);
    $order_id = $orderDetails->order_id;
    $orderDetails->delete();

    $grandTotal = OwnBrandOrderDetail::where('order_id', $order_id)->sum('total_price');
    $updateArray = array();
    $updateArray['grand_total'] = $grandTotal;
    OwnBrandOrder::where('id',$order_id)->update($updateArray);
    $order = OwnBrandOrder::where('id',$order_id)->first();
    $deleteOrderProduct = OwnBrandOrder::with(['orderDetails' => function($query) {
          $query->onlyTrashed(); // Use onlyTrashed() to get soft-deleted order details
      },'product'])->findOrFail($order_id);
    $html = "";
    $html .= '<table class="table-bordered invoice-summary table"><thead><tr class="bg-trans-dark"><th data-breakpoints="lg" class="min-col">#</th><th width="10%">Photo</th><th class="text-uppercase">Description</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Qty</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Unit Price</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Total</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Action</th></tr></thead><tbody>';
    foreach ($deleteOrderProduct->orderDetails as $key => $orderDetail){
      $html .= '<tr id="tr_reverse_'.$orderDetail->id.'"><td>'. ($key + 1) .'</td><td>';
      // Display product image or "N/A"
      if ($orderDetail->product != null) {
          $html .= '<a href="#" target="_blank"><img height="50" src="'. uploaded_asset($orderDetail->product->thumbnail_img) .'"></a>';
      } else {
          $html .= '<strong>'. translate('N/A') .'</strong>';
      }
      $html .= '</td><td>';

      // Display product name, brand, and part number
      if ($orderDetail->product != null) { 
          $html .= '<strong><a href="#" target="_blank" class="text-muted">' . $orderDetail->product->name . '</a></strong><br><small id="small_brand_'.$orderDetail->id.'">';
          if ($orderDetail->brand_name != "" || $orderDetail->brand_name != null) {
              $html .= $orderDetail->brand . ' : ' . $orderDetail->brand_name;
          } else {
              $html .= $orderDetail->brand;
          }
          $html .= '</small><br><small>'. translate('Part No.') .': ' . $orderDetail->product->part_no . '</small>';
      } else {
          $html .= '<strong>'. translate('Product Unavailable') .'</strong>';
      }

      $html .= '</td><td class="text-center" style="justify-content: center; align-items: center;">';
      // Quantity input with readonly attribute
      $html .= '<input type="text" value="'. $orderDetail->quantity .'" name="quantity_'. $orderDetail->id .'" id="quantity_'. $orderDetail->id .'" class="form-control" style="width: 100px; text-align: center; margin: auto;" oninput="updateQty(this.value, '. $orderDetail->id .')" readonly>';
      $html .= '</td><td class="text-center">';

      // Unit price input with currency on the left
      $html .= '<div style="position: relative; display: inline-flex; align-items: center;">';
      $html .= '<span style="position: absolute; left: 10px; padding-right: 5px; color: #888;">'. $order->currency .'</span>';
      $html .= '<input type="text" value="'. $orderDetail->unit_price .'" name="unit_price" id="unit_price" class="form-control" style="padding-left: 30px; width: 100px; text-align: left; margin: auto;" oninput="updateUnitPrice(this.value, '. $orderDetail->id .')" readonly>';
      $html .= '</div>';

      $html .= '</td><td class="text-center">';
      // Display total price with currency symbol
      $html .= '<span id="spanTotalPrice_'. $orderDetail->id .'">'. $order->currency .' '. $orderDetail->total_price .'</span>';
      $html .= '</td><td class="text-center">';
      // Display green arrow icon
      $html .= '<i class="las la-arrow-circle-up" style="color: green; font-size: 24px; cursor:pointer;" onclick="productReverse('.$orderDetail->id.')"></i>';
      $html .= '</td></tr>';
    }
    $html .= '</tbody></table>';
    return response()->json([
        'grandTotal' => $grandTotal,
        'currency' => $order->currency,
        'html' => $html
    ], 200);
  }

  public function international_order_reverse_product(Request $request) {
    $orderDetails = OwnBrandOrderDetail::withTrashed()->findOrFail($request->order_detail_id);
    $order_id = $orderDetails->order_id;
    $orderDetails->restore();

    $grandTotal = OwnBrandOrderDetail::where('order_id', $order_id)->sum('total_price');
    $updateArray = array();
    $updateArray['grand_total'] = $grandTotal;
    OwnBrandOrder::where('id',$order_id)->update($updateArray);
    
    $order = OwnBrandOrder::with(['orderDetails' => function($query) {
      $query->whereNull('deleted_at');
      },'product'])->findOrFail($order_id);
    $html = "";
    $html .= '<table class="table-bordered invoice-summary table"><thead><tr class="bg-trans-dark"><th data-breakpoints="lg" class="min-col">#</th><th width="10%">Photo</th><th class="text-uppercase">Description</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Brand</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Comment <br/> and <br/>Days of Delivery</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Qty</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Unit Price</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Total</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Action</th></tr></thead><tbody>';
    foreach ($order->orderDetails as $key => $orderDetail){
      $html .= '<tr id="tr_'.$orderDetail->id.'"><td>'. ($key + 1) .'</td><td>';
      // Display product image or "N/A"
      if ($orderDetail->product != null) {
          $html .= '<a href="#" target="_blank"><img height="50" src="'. uploaded_asset($orderDetail->product->thumbnail_img) .'"></a>';
      } else {
          $html .= '<strong>'. translate('N/A') .'</strong>';
      }
      $html .= '</td><td>';

      // Display product name, brand, and part number
      if ($orderDetail->product != null) { 
          $html .= '<strong><a href="#" target="_blank" class="text-muted">' . $orderDetail->product->name . '</a></strong><br><small id="small_brand_'.$orderDetail->id.'">';
          if ($orderDetail->brand_name != "" || $orderDetail->brand_name != null) {
              $html .= $orderDetail->brand . ' : ' . $orderDetail->brand_name;
          } else {
              $html .= $orderDetail->brand;
          }
          $html .= '</small><br><small>'. translate('Part No.') .': ' . $orderDetail->product->part_no . '</small>';
      } else {
          $html .= '<strong>'. translate('Product Unavailable') .'</strong>';
      }
      $html .= '<td class="text-center" style="justify-content: center; align-items: center;" id="trBrand_{{$orderDetail->id}}">';
      $html .= '<i class="las la-highlighter" style="color: green; font-size: 24px; cursor:pointer;" data-brand="'.$orderDetail->brand.'" data-brand-name="'.$orderDetail->brand_name.'" data-orderdetails-id="'.$orderDetail->id.'" onclick="openModal(this)"></i>';
      $html .= '</td>';
      $html .= '<td class="text-center" style="justify-content: center; align-items: center;" id="trBrand_{{$orderDetail->id}}">';
      $html .= '<i class="las la-comment" style="color: #25bcf1; font-size: 24px; cursor:pointer;" data-comment="'.$orderDetail->comment.'"  data-days-of-delivery="'.$orderDetail->days_of_delivery.'" data-orderdetails-id="'.$orderDetail->id.'" onclick="openCommentModal(this)"></i>';
      $html .= '</td>';
      $html .= '</td><td class="text-center" style="justify-content: center; align-items: center;">';
      // Quantity input with readonly attribute
      $html .= '<input type="text" value="'. $orderDetail->quantity .'" name="quantity_'. $orderDetail->id .'" id="quantity_'. $orderDetail->id .'" class="form-control" style="width: 100px; text-align: center; margin: auto;" oninput="updateQty(this.value, '. $orderDetail->id .')">';
      $html .= '</td><td class="text-center">';

      // Unit price input with currency on the left
      $html .= '<div style="position: relative; display: inline-flex; align-items: center;">';
      $html .= '<span style="position: absolute; left: 10px; padding-right: 5px; color: #888;">'. $order->currency .'</span>';
      $html .= '<input type="text" value="'. $orderDetail->unit_price .'" name="unit_price" id="unit_price" class="form-control" style="padding-left: 30px; width: 100px; text-align: left; margin: auto;" oninput="updateUnitPrice(this.value, '. $orderDetail->id .')">';
      $html .= '</div>';

      $html .= '</td><td class="text-center">';
      // Display total price with currency symbol
      $html .= '<span id="spanTotalPrice_'. $orderDetail->id .'">'. $order->currency .' '. $orderDetail->total_price .'</span>';
      $html .= '</td><td class="text-center">';
      $html .= '<i class="las la-trash" style="color: red; font-size: 24px; cursor:pointer;" onclick="productDelete('.$orderDetail->id.')"></i>';
      $html .= '</td></tr>';
    }
    $html .= '</tbody></table>';
    return response()->json([
        'grandTotal' => $grandTotal,
        'currency' => $order->currency,
        'html' => $html
    ], 200);
  }

  public function getOwnBrandProductList(Request $request){
    $orderId = $request->input('order_id');
    $order = OwnBrandOrder::where('id',$orderId)->first();
    
    // $products = OwnBrandProduct::all(); // Fetch all products (adjust if needed)
    $category_group    = $categories    = $brands    = $selected_brands    = $selected_categories   = $products    = [];
    $products = OwnBrandProduct::query();
    $products = Cache::remember('all_product_items', 5, function () use ($categories) {
        // Build the query
        $productQuery = OwnBrandProduct::query()
            ->join('own_brand_categories', 'own_brand_products.category_id', '=', 'own_brand_categories.id')
            ->join('own_brand_category_groups', 'own_brand_categories.category_group_id', '=', 'own_brand_category_groups.id');
        
        // Select columns and apply sorting
        $productQuery->select(
                'own_brand_products.id',
                'own_brand_category_groups.name AS group_name',
                'own_brand_categories.name AS category_name',
                'group_id',
                'category_id',
                'own_brand_products.name',
                'thumbnail_img',
                'own_brand_products.slug',
                'own_brand_products.dollar_purchase_price',
                'own_brand_products.inr_bronze',
                'own_brand_products.inr_silver',
                'own_brand_products.inr_gold',
                'own_brand_products.doller_bronze',
                'own_brand_products.doller_silver',
                'own_brand_products.doller_gold'             
            )
            ->where('published', true)
            ->where('approved', true)
            ->orderBy('own_brand_category_groups.name', 'asc')
            ->orderBy('own_brand_categories.name', 'asc');
        
        // Apply pagination directly on the query and return paginated result
        return $productQuery->paginate(50);  // Cache the paginated query result
    });
    // echo "<pre>";print_r($products);die;
    $products = $this->processProducts($products,$order->user->id);

    // Apply pagination directly on the query and return paginated result
    // return $productQuery->paginate(50);  // Cache the paginated query result
    // dd($products);
    return view('backend.sales.international_product_list', compact('products'));
  }

  private function processProducts($products,$user_id) {
    foreach ($products as $product) {
        $price = 0;
        $markup = 1;     
        // Log a message to the browser console    
        $user = User::where('id',$user_id)->first();    
        $price = $product->dollar_purchase_price;
        $userPhone = $user->phone;
        $firstTwoChars = substr($userPhone, 0, 3);
        if($firstTwoChars == "+91"){
            if($user->profile_type == 'Bronze'){
                $markup = $product->inr_bronze;
            }elseif($user->profile_type == 'Silver'){
                $markup = $product->inr_silver;
            }elseif($user->profile_type == 'Gold'){
                $markup = $product->inr_gold;
            }
            $price = '₹'.round(($price*$markup));
        }else{
            if($user->profile_type == 'Bronze'){
                $markup = $product->doller_bronze;
            }elseif($user->profile_type == 'Silver'){
                $markup = $product->doller_silver;
            }elseif($user->profile_type == 'Gold'){
                $markup = $product->doller_gold;
            }
            // echo $markup; die;
            $price = '$'.number_format($price+(($price*$markup)/100),2);
        }
        $product->convertPrice = $price;
    }
    return $products;
  }

  public function international_order_add_product(Request $request) {
      $orderId = $request->order_id;
      $order = OwnBrandOrder::where('id',$orderId)->first();
      $grandtotal = $order->grand_total;
      $user = $order->user;
      $userPhone = $user->phone;
      $firstTwoChars = substr($userPhone, 0, 3);
      if($firstTwoChars == "+91"){
          $currency = '₹';
      }else{
          $currency = '$';
      }    
      $product = OwnBrandProduct::find($request->product_id);
      if($currency == "₹"){
          if($user->profile_type == 'Bronze'){
              $markup = $product->inr_bronze;
          }elseif($user->profile_type == 'Silver'){
              $markup = $product->inr_silver;
          }elseif($user->profile_type == 'Gold'){
              $markup = $product->inr_gold;
          }
          $unitPrice = round(($product->dollar_purchase_price*$markup));
      }elseif($currency == '$'){
          if($user->profile_type == 'Bronze'){
              $markup = $product->doller_bronze;
          }elseif($user->profile_type == 'Silver'){
              $markup = $product->doller_silver;
          }elseif($user->profile_type == 'Gold'){
              $markup = $product->doller_gold;
          }
          $unitPrice = number_format($product->dollar_purchase_price+(($product->dollar_purchase_price*$markup)/100),2);
      }
      
      $addFlag = 0;
      $ownBrandOrderDetailData = OwnBrandOrderDetail::where('product_id',$request->product_id)->where('order_id',$orderId)->first();
      if($ownBrandOrderDetailData === NULL){
        $product = OwnBrandProduct::find($request->product_id);
        $orderDetails = array();
        $orderDetails['order_id'] = $orderId;
        $orderDetails['order_code'] = $order->order_code;
        $orderDetails['product_id'] = $request->product_id;
        $orderDetails['name'] = $product->name;
        $orderDetails['slug'] = $product->slug;
        $orderDetails['brand'] = 'Our Brand - OPEL';
        // $orderDetails['brand_name'] = $key->brand_name;
        $orderDetails['unit_price'] = $unitPrice;
        // $orderDetails['tax'] = $key->tax;
        $orderDetails['quantity'] = $product->min_order_qty_1;
        $orderDetails['total_price'] = $product->min_order_qty_1 * $unitPrice;
        $orderDetails['purchase_time_unit_price'] = $unitPrice;
        $orderDetails['purchase_time_quantity'] = $product->min_order_qty_1;
        $orderDetails['purchase_time_brand'] = 'Our Brand - OPEL';
        $orderDetailsData = OwnBrandOrderDetail::create($orderDetails);

        $updateArray = array();
        $updateArray['grand_total'] = $grandtotal = $order->grand_total + ($product->min_order_qty_1 * $unitPrice);
        $orderDetails = OwnBrandOrder::where('order_code', $order->order_code)->update($updateArray);
        $addFlag = 1;
      }

      // echo "<pre>"; print_r($updateArray);die;

      $order = OwnBrandOrder::with(['orderDetails' => function($query) {
        $query->whereNull('deleted_at');
        },'product'])->findOrFail($orderId);
      $html = "";
      $html .= '<table class="table-bordered invoice-summary table"><thead><tr class="bg-trans-dark"><th data-breakpoints="lg" class="min-col">#</th><th width="10%">Photo</th><th class="text-uppercase">Description</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Brand</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Comment <br/> and <br/>Days of Delivery</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Qty</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Unit Price</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Total</th><th data-breakpoints="lg" class="min-col text-uppercase text-center">Action</th></tr></thead><tbody>';
      foreach ($order->orderDetails as $key => $orderDetail){
        $html .= '<tr id="tr_'.$orderDetail->id.'"><td>'. ($key + 1) .'</td><td>';
        // Display product image or "N/A"
        if ($orderDetail->product != null) {
            $html .= '<a href="#" target="_blank"><img height="50" src="'. uploaded_asset($orderDetail->product->thumbnail_img) .'"></a>';
        } else {
            $html .= '<strong>'. translate('N/A') .'</strong>';
        }
        $html .= '</td><td>';
  
        // Display product name, brand, and part number
        if ($orderDetail->product != null) { 
            $html .= '<strong><a href="#" target="_blank" class="text-muted">' . $orderDetail->product->name . '</a></strong><br><small id="small_brand_'.$orderDetail->id.'">';
            if ($orderDetail->brand_name != "" || $orderDetail->brand_name != null) {
                $html .= $orderDetail->brand . ' : ' . $orderDetail->brand_name;
            } else {
                $html .= $orderDetail->brand;
            }
            $html .= '</small><br><small>'. translate('Part No.') .': ' . $orderDetail->product->part_no . '</small>';
        } else {
            $html .= '<strong>'. translate('Product Unavailable') .'</strong>';
        }
        $html .= '<td class="text-center" style="justify-content: center; align-items: center;" id="trBrand_{{$orderDetail->id}}">';
        $html .= '<i class="las la-highlighter" style="color: green; font-size: 24px; cursor:pointer;" data-brand="'.$orderDetail->brand.'" data-brand-name="'.$orderDetail->brand_name.'" data-orderdetails-id="'.$orderDetail->id.'" onclick="openModal(this)"></i>';
        $html .= '</td>';
        $html .= '<td class="text-center" style="justify-content: center; align-items: center;" id="trBrand_{{$orderDetail->id}}">';
        $html .= '<i class="las la-comment" style="color: #25bcf1; font-size: 24px; cursor:pointer;" data-comment="'.$orderDetail->comment.'"  data-days-of-delivery="'.$orderDetail->days_of_delivery.'" data-orderdetails-id="'.$orderDetail->id.'" onclick="openCommentModal(this)"></i>';
        $html .= '</td>';
        $html .= '</td><td class="text-center" style="justify-content: center; align-items: center;">';
        // Quantity input with readonly attribute
        $html .= '<input type="text" value="'. $orderDetail->quantity .'" name="quantity_'. $orderDetail->id .'" id="quantity_'. $orderDetail->id .'" class="form-control" style="width: 100px; text-align: center; margin: auto;" oninput="updateQty(this.value, '. $orderDetail->id .')">';
        $html .= '</td><td class="text-center">';
  
        // Unit price input with currency on the left
        $html .= '<div style="position: relative; display: inline-flex; align-items: center;">';
        $html .= '<span style="position: absolute; left: 10px; padding-right: 5px; color: #888;">'. $order->currency .'</span>';
        $html .= '<input type="text" value="'. $orderDetail->unit_price .'" name="unit_price" id="unit_price" class="form-control" style="padding-left: 30px; width: 100px; text-align: left; margin: auto;" oninput="updateUnitPrice(this.value, '. $orderDetail->id .')">';
        $html .= '</div>';
  
        $html .= '</td><td class="text-center">';
        // Display total price with currency symbol
        $html .= '<span id="spanTotalPrice_'. $orderDetail->id .'">'. $order->currency .' '. $orderDetail->total_price .'</span>';
        $html .= '</td><td class="text-center">';
        $html .= '<i class="las la-trash" style="color: red; font-size: 24px; cursor:pointer;" onclick="productDelete('.$orderDetail->id.')"></i>';
        $html .= '</td></tr>';
      }
      $html .= '</tbody></table>';

      return response()->json([
          'grandTotal' => $grandtotal,
          'currency' => $order->currency,
          'addFlag' => $addFlag,
          'html' => $html
      ], 200);
  }

}