<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use App\Models\User;
use App\Models\Address;
use App\Models\Order;
use App\Models\OrderApproval;
use App\Models\Upload;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class PurchaseHistoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $orders = Order::where('user_id', Auth::user()->id)->orderBy('code', 'desc')->paginate(9);
        foreach ($orders as $key => $value) {            
            $ordersApprovalCount = OrderApproval::where('code', $value->code)->count();
            if ($ordersApprovalCount > 0) {
                $ordersApproval = OrderApproval::where('code', $value->code)->first();
                $value->approved = true;
                $details = $ordersApproval->details;
                if (substr($details, 0, 1) !== '[') {
                    $details = '[' . $details;
                }
                if (substr($details, -1) !== ']') {
                    $details = $details . ']';
                }                
                $detailsData = json_decode($details, true);
                $bill_amount = 0.0;
                // foreach($detailsData as $odKey=>$odValue){
                //     $bill_amount = $bill_amount + (float)$odValue['bill_amount'];
                // }                
                $value->bill_amount = $bill_amount;
                $value->order_details = $detailsData;
            } else {
                $value->approved = false;
                $value->bill_amount = "";
                $value->order_details = "";
            }
        }
        // echo "<pre>";print_r($orders);die;
        return view('frontend.user.purchase_history', compact('orders'));
    }

    public function digital_index()
    {
        $orders = DB::table('orders')
                        ->orderBy('code', 'desc')
                        ->join('order_details', 'orders.id', '=', 'order_details.order_id')
                        ->join('products', 'order_details.product_id', '=', 'products.id')
                        ->where('orders.user_id', Auth::user()->id)
                        ->where('products.digital', '1')
                        ->where('order_details.payment_status', 'paid')
                        ->select('order_details.id')
                        ->paginate(15);
        return view('frontend.user.digital_purchase_history', compact('orders'));
    }

    function correct_json($json) {
        // 1. Escape double quotes inside strings
        $json = preg_replace('/"([^"]*?)"/', '"$1\""$2"', $json);
        
        // 2. Remove unescaped double quotes at the end of a string
        $json = preg_replace('/\"([^-]+?)\"/', '\"$1\"', $json);
        
        // 3. Ensure that there are no trailing commas
        $json = preg_replace('/,\s*([\]}])/', '$1', $json);
        
        return $json;
    }

    public function purchase_history_details($id)
    {
        $order = Order::findOrFail(decrypt($id));
        $order->delivery_viewed = 1;
        $order->payment_status_viewed = 1;
        $order->save();
    
        // Fetch the count of order approvals with the same code
        $ordersApprovalCount = OrderApproval::where('code', $order->code)->count();
    
        if ($ordersApprovalCount > 0) {
            // Get the order approval record
            $ordersApproval = OrderApproval::where('code', $order->code)->first();
            $details = $ordersApproval->details;
    
            // Preprocess the details JSON string to escape inner quotes inside item_name
            $details = preg_replace_callback(
                '/"item_name":"(.*?)"/',
                function ($matches) {
                    // Escape double quotes inside item_name
                    $cleaned_value = addslashes($matches[1]); 
                    return '"item_name":"' . $cleaned_value . '"';
                },
                $details
            );
    
            // Debugging: Print the fixed JSON string to verify correctness
            echo "<pre>Fixed JSON string (with properly escaped quotes inside item_name):\n";
            print_r($details);
            echo "</pre>";
    
            // Now decode the fixed JSON data
            $detailsData = json_decode($details, true);
    
            // Debugging: Check if json_decode is successful
            if (json_last_error() !== JSON_ERROR_NONE) {
                echo "<pre>JSON decode error: " . json_last_error_msg() . "</pre>";
                die();
            }
    
            // Check if JSON is an array after decoding
            if (is_array($detailsData)) {
                $bill_amount = 0.0;
    
                // Iterate through the details data
                foreach ($detailsData as $odKey => $odValue) {
                    $bill_amount += (float)$odValue['bill_amount'];
    
                    // Fetch the product details based on the part number
                    $productDetails = Product::where('part_no', $odValue['part_no'])->first();
    
                    // Ensure the product details exist before assigning slug and product_id
                    if ($productDetails) {
                        $detailsData[$odKey]['slug'] = $productDetails->slug;
                        $detailsData[$odKey]['product_id'] = $productDetails->id;
                    }
                }
    
                // Assign the computed bill amount and the modified details data to the order
                $order->bill_amount = $bill_amount;
                $order->order_details = $detailsData;
            } else {
                // Handle invalid JSON or an empty array
                \Log::error('Invalid JSON in order approval details: ' . json_last_error_msg());
                $order->bill_amount = "";
                $order->order_details = array();
            }
        } else {
            // No approval found, set default values
            $order->bill_amount = "";
            $order->order_details = array();
        }
    
        // Return the view with the order data
        return view('frontend.user.order_details_customer', compact('order'));
    }
    
    


    public function download(Request $request)
    {
        $product = Product::findOrFail(decrypt($request->id));
        $downloadable = false;
        foreach (Auth::user()->orders as $key => $order) {
            foreach ($order->orderDetails as $key => $orderDetail) {
                if ($orderDetail->product_id == $product->id && $orderDetail->payment_status == 'paid') {
                    $downloadable = true;
                    break;
                }
            }
        }
        if ($downloadable) {
            $upload = Upload::findOrFail($product->file_name);
            if (env('FILESYSTEM_DRIVER') == "s3") {
                return \Storage::disk('s3')->download($upload->file_name, $upload->file_original_name . "." . $upload->extension);
            } else {
                if (file_exists(base_path('public/' . $upload->file_name))) {
                    return response()->download(base_path('public/' . $upload->file_name));
                }
            }
        } else {
            flash(translate('You cannot download this product at this product.'))->success();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function order_cancel($id)
    {
        $order = Order::where('id', $id)->where('user_id', auth()->user()->id)->first();
        if($order && ($order->delivery_status == 'pending' && $order->payment_status == 'unpaid')) {
            $order->delivery_status = 'cancelled';
            $order->save();

            foreach ($order->orderDetails as $key => $orderDetail) {
                $orderDetail->delivery_status = 'cancelled';
                $orderDetail->save();
                product_restock($orderDetail);
            }

            flash(translate('Order has been canceled successfully'))->success();
        } else {
            flash(translate('Something went wrong'))->error();
        }

        return back();
    }

    // Statement

    public function statement()
    {
        // echo Auth::user()->id; die;
        // $orders = Order::where('user_id', Auth::user()->id)->orderBy('code', 'desc')->paginate(9);
        $userData = User::where('id', Auth::user()->id)->first();
        $userAddressData = Address::where('user_id', Auth::user()->id)->groupBy('gstin')->orderBy('acc_code','ASC')->get();
        return view('frontend.user.statement', compact('userData','userAddressData'));
    }
    public function statement_details($party_code = "", $form_date = "", $to_date = "")
    {
        $party_code = decrypt($party_code);
        // Overdue Calculation Start
        $overdueAmount = "0";
        $currentDate = date('Y-m-d');
        $currentMonth = date('m');
        $currentYear = date('Y');
        if ($currentMonth >= 4) {
            $fy_form_date = date('Y-04-01'); // Start of financial year
            $fy_to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year (next year)
        } else {
            $fy_form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
            $fy_to_date = date('Y-03-31'); // Current year March
        }
        $headers = [
            'authtoken' => '65d448afc6f6b',
        ];        
        $body = [
            'party_code' => $party_code,
            'from_date' => $fy_form_date,
            'to_date' =>  $fy_to_date,
        ];
        \Log::info('Sending request to API For Overdue', [
            'url' => 'https://saleszing.co.in/itaapi/getclientstatement.php',
            'headers' => $headers,
            'body' => $body
        ]);        
        $overdue_response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);        
        \Log::info('Received response from API For Overdue', [
            'status' => $overdue_response->status(),
            'body' => $overdue_response->body()
        ]);
        $getOverdueData = $overdue_response->json();
        $getOverdueData = $getOverdueData['data'];

        $closingBalanceResult = array_filter($getOverdueData, function ($entry) {
            return isset($entry['ledgername']) && $entry['ledgername'] === 'closing C/f...';
        });
        $closingEntry = reset($closingBalanceResult);
        $cloasingDrAmount = $closingEntry['dramount'];
        $cloasingCrAmount = $closingEntry['cramount'];
        $userData = User::where('party_code', $party_code)->first();           
        $overdueDateFrom = date('Y-m-d', strtotime('-' . $userData->credit_days . ' days'));
        if($cloasingCrAmount > 0){
            $drBalanceBeforeOVDate = 0;
            $crBalanceBeforeOVDate = 0;
            $getOverdueData = array_reverse($getOverdueData);
            foreach($getOverdueData as $ovKey=>$ovValue){
                if($ovValue['ledgername'] != 'closing C/f...'){
                    if(strtotime($ovValue['trn_date']) > strtotime($overdueDateFrom)){
                        // $drBalanceBeforeOVDate += $ovValue['dramount'];
                        $crBalanceBeforeOVDate += $ovValue['cramount'];
                    }else{
                        $drBalanceBeforeOVDate += $ovValue['dramount'];
                        $crBalanceBeforeOVDate += $ovValue['cramount'];
                    }
                }
            }
            $overdueAmount = $temOverDueBalance = $drBalanceBeforeOVDate - $crBalanceBeforeOVDate;
            $overDueMark = array();
            foreach($getOverdueData as $ovKey=>$ovValue){
                if($ovValue['ledgername'] != 'closing C/f...'){
                    if(strtotime($ovValue['trn_date']) > strtotime($overdueDateFrom)){
                        // $drBalanceBeforeOVDate += $ovValue['dramount'];
                        // $crBalanceBeforeOVDate += $ovValue['cramount'];
                    }elseif(strtotime($ovValue['trn_date']) < strtotime($overdueDateFrom) AND $temOverDueBalance > 0 AND $ovValue['dramount'] != '0.00'){
                        $temOverDueBalance -= $ovValue['dramount'];
                        $date1 = $ovValue['trn_date'];
                        $date2 = $overdueDateFrom;

                        $diff = abs(strtotime($date2) - strtotime($date1));

                        $years = floor($diff / (365*60*60*24));
                        $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                        $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24) / (60*60*24));

                        // Initialize an empty array to store non-zero date parts
                        $dateParts = [];

                        if ($years > 0) {
                            $dateParts[] = "$years years";
                        }
                        if ($months > 0) {
                            $dateParts[] = "$months months";
                        }
                        if ($days > 0) {
                            $dateParts[] = "$days days";
                        }
                        // Combine the date parts into a string
                        $dateDifference = implode(', ', $dateParts);
                        if($temOverDueBalance >= 0){
                            $overDueMark[] = [
                                'trn_no' => $ovValue['trn_no'],
                                'trn_date' => $ovValue['trn_date'],
                                'overdue_by_day' => $dateDifference,
                                'overdue_staus' => 'Overdue'
                            ];
                        }else{
                            $overDueMark[] = [
                                'trn_no' => $ovValue['trn_no'],
                                'trn_date' => $ovValue['trn_date'],
                                'overdue_by_day' => $dateDifference,
                                'overdue_staus' => 'Pertial Overdue'
                            ];
                        }
                        
                        
                    }
                }
            }
        }
        if($overdueAmount <= 0){
            $overdueDrOrCr = 'Dr';
            $overdueAmount = 0;
        }else{
            $overdueDrOrCr = 'Cr';
        }

        // Overdue Calculation End

        $currentDate = date('Y-m-d');
        $currentMonth = date('m');
        $currentYear = date('Y');
        if ($currentMonth >= 4) {
            $form_date = date('Y-04-01'); // Start of financial year
            $to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year (next year)
        } else {
            $form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
            $to_date = date('Y-03-31'); // Current year March
        }
        if ($to_date > $currentDate) {
            $to_date = $currentDate;
        }
        $headers = [
            'authtoken' => '65d448afc6f6b',
        ];        
        $body = [
            'party_code' => $party_code,
            'from_date' => $form_date,
            'to_date' =>  $to_date,
        ];
        \Log::info('Sending request to API', [
            'url' => 'https://saleszing.co.in/itaapi/getclientstatement.php',
            'headers' => $headers,
            'body' => $body
        ]);        
        $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);        
        \Log::info('Received response from API', [
            'status' => $response->status(),
            'body' => $response->body()
        ]);

        if ($response->successful()) {
            $getData = $response->json();
            $getData = $getData['data'];
            
            $openingBalance = "0";
            $closingBalance = "0";
            $openDrOrCr = "";
            $drBalance = "0";
            $crBalance = "0";
            $dueAmount = "0";
            $overDueMarkTrnNos = array_column($overDueMark, 'trn_no'); 
            $overDueMarkOverdueStaus = array_column($overDueMark, 'overdue_staus');
            $overDueMarkByDay = array_column($overDueMark, 'overdue_by_day');
            // echo "<pre>"; print_r($overDueMarkTrnNos); die();
            foreach($getData as $gKey=>$gValue){
                //echo "<pre>";print_r($gValue);
                if($gValue['ledgername'] == "Opening b/f..."){
                    if($gValue['dramount'] != "0.00"){
                        $openingBalance = $gValue['dramount'];
                        $openDrOrCr = "Dr";
                    }else{
                        $openingBalance = $gValue['cramount'];
                        $openDrOrCr = "Cr";
                    }
                }else if($gValue['ledgername'] == "closing C/f..."){
                    if($gValue['dramount'] != "0.00"){
                        $closingBalance = $gValue['dramount'];
                        $dueAmount = $gValue['dramount'];
                        $closeDrOrCr = "Dr";
                    }else{
                        $closingBalance = $gValue['cramount'];
                        $closeDrOrCr = "Cr";
                        $dueAmount = $gValue['cramount'];
                    }
                }
                if(count($overDueMark) > 0) {
                    $key = array_search($gValue['trn_no'], $overDueMarkTrnNos);
                    if ($key !== false) {
                        $getData[$gKey]['overdue_status'] = $overDueMarkOverdueStaus[$key];
                        $getData[$gKey]['overdue_by_day'] = $overDueMarkByDay[$key];
                    }
                }
            }
            // echo "<pre>"; print_r($getData);die;
            return view('frontend.user.statement_details', compact('party_code','getData','openingBalance','openDrOrCr','closingBalance','closeDrOrCr','dueAmount','overdueDateFrom','overdueAmount','overdueDrOrCr'));
        } else {
            return response()->json(['error' => 'Failed to fetch data'], $response->status());
        }
    }

    public function searchStatementDetails(Request $request){
        $party_code = $request->input('party_code');

        // Overdue Calculation Start
        $overdueAmount = "0";
        $currentDate = date('Y-m-d');
        $currentMonth = date('m');
        $currentYear = date('Y');
        if ($currentMonth >= 4) {
            $fy_form_date = date('Y-04-01'); // Start of financial year
            $fy_to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year (next year)
        } else {
            $fy_form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
            $fy_to_date = date('Y-03-31'); // Current year March
        }
        $headers = [
            'authtoken' => '65d448afc6f6b',
        ];        
        $body = [
            'party_code' => $party_code,
            'from_date' => $fy_form_date,
            'to_date' =>  $fy_to_date,
        ];
        \Log::info('Sending request to API For Overdue', [
            'url' => 'https://saleszing.co.in/itaapi/getclientstatement.php',
            'headers' => $headers,
            'body' => $body
        ]);        
        $overdue_response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);        
        \Log::info('Received response from API For Overdue', [
            'status' => $overdue_response->status(),
            'body' => $overdue_response->body()
        ]);
        $getOverdueData = $overdue_response->json();
        $getOverdueData = $getOverdueData['data'];

        $closingBalanceResult = array_filter($getOverdueData, function ($entry) {
            return isset($entry['ledgername']) && $entry['ledgername'] === 'closing C/f...';
        });
        $closingEntry = reset($closingBalanceResult);
        $cloasingDrAmount = $closingEntry['dramount'];
        $cloasingCrAmount = $closingEntry['cramount'];
        $userData = User::where('party_code', $party_code)->first();           
        $overdueDateFrom = date('Y-m-d', strtotime('-' . $userData->credit_days . ' days'));
        if($cloasingCrAmount > 0){
            $drBalanceBeforeOVDate = 0;
            $crBalanceBeforeOVDate = 0;
            $getOverdueData = array_reverse($getOverdueData);
            foreach($getOverdueData as $ovKey=>$ovValue){
                if($ovValue['ledgername'] != 'closing C/f...'){
                    if(strtotime($ovValue['trn_date']) > strtotime($overdueDateFrom)){
                        // $drBalanceBeforeOVDate += $ovValue['dramount'];
                        $crBalanceBeforeOVDate += $ovValue['cramount'];
                    }else{
                        $drBalanceBeforeOVDate += $ovValue['dramount'];
                        $crBalanceBeforeOVDate += $ovValue['cramount'];
                    }
                }
            }
            $overdueAmount = $temOverDueBalance = $drBalanceBeforeOVDate - $crBalanceBeforeOVDate;
            $overDueMark = array();
            foreach($getOverdueData as $ovKey=>$ovValue){
                if($ovValue['ledgername'] != 'closing C/f...'){
                    if(strtotime($ovValue['trn_date']) > strtotime($overdueDateFrom)){
                        // $drBalanceBeforeOVDate += $ovValue['dramount'];
                        // $crBalanceBeforeOVDate += $ovValue['cramount'];
                    }elseif(strtotime($ovValue['trn_date']) < strtotime($overdueDateFrom) AND $temOverDueBalance > 0 AND $ovValue['dramount'] != '0.00'){
                        $temOverDueBalance -= $ovValue['dramount'];
                        $date1 = $ovValue['trn_date'];
                        $date2 = $overdueDateFrom;

                        $diff = abs(strtotime($date2) - strtotime($date1));

                        $years = floor($diff / (365*60*60*24));
                        $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                        $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24) / (60*60*24));

                        // Initialize an empty array to store non-zero date parts
                        $dateParts = [];

                        if ($years > 0) {
                            $dateParts[] = "$years years";
                        }
                        if ($months > 0) {
                            $dateParts[] = "$months months";
                        }
                        if ($days > 0) {
                            $dateParts[] = "$days days";
                        }
                        // Combine the date parts into a string
                        $dateDifference = implode(', ', $dateParts);
                        if($temOverDueBalance >= 0){
                            $overDueMark[] = [
                                'trn_no' => $ovValue['trn_no'],
                                'trn_date' => $ovValue['trn_date'],
                                'overdue_by_day' => $dateDifference,
                                'overdue_staus' => 'Overdue'
                            ];
                        }else{
                            $overDueMark[] = [
                                'trn_no' => $ovValue['trn_no'],
                                'trn_date' => $ovValue['trn_date'],
                                'overdue_by_day' => $dateDifference,
                                'overdue_staus' => 'Pertial Overdue'
                            ];
                        }
                        
                        
                    }
                }
            }
        }
        if($overdueAmount <= 0){
            $overdueDrOrCr = 'Dr';
            $overdueAmount = 0;
        }else{
            $overdueDrOrCr = 'Cr';
        }

        // Overdue Calculation End


        $from_date = $request->input('from_date');
        $to_date = $request->input('to_date');

        // $currentDate = date('Y-m-d');
        // $currentMonth = date('m');
        // $currentYear = date('Y');
        // if ($currentMonth >= 4) {
        //     $from_date = date('Y-04-01'); // Start of financial year
        //     $to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year (next year)
        // } else {
        //     $from_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
        //     $to_date = date('Y-03-31'); // Current year March
        // }
        // if ($to_date > $currentDate) {
        //     $to_date = $currentDate;
        // }
        $headers = [
            'authtoken' => '65d448afc6f6b',
        ];        
        $body = [
            'party_code' => $party_code,
            'from_date' => $from_date,
            'to_date' =>  $to_date,
        ];
        \Log::info('Sending request to API', [
            'url' => 'https://saleszing.co.in/itaapi/getclientstatement.php',
            'headers' => $headers,
            'body' => $body
        ]);        
        $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);        
        \Log::info('Received response from API', [
            'status' => $response->status(),
            'body' => $response->body()
        ]);
        if ($response->successful()) {
            $getData = $response->json();
            $getData = $getData['data'];
            
            $openingBalance = 0;
            $closingBalance = 0;
            $openDrOrCr = "";
            $drBalance = 0;
            $crBalance = 0;
            $closeDrOrCr="";
            $overDueMarkTrnNos = array_column($overDueMark, 'trn_no'); 
            $overDueMarkOverdueStaus = array_column($overDueMark, 'overdue_staus');
            $overDueMarkByDay = array_column($overDueMark, 'overdue_by_day');
            foreach($getData as $gKey=>$gValue){
                if($gValue['ledgername'] == "Opening b/f..."){
                    if($gValue['dramount'] != "0.00"){
                        $openingBalance = $gValue['dramount'];
                        $openDrOrCr = "Dr";
                    }else{
                        $openingBalance = $gValue['cramount'];
                        $openDrOrCr = "Cr";
                    }
                }else if($gValue['ledgername'] == "closing C/f..."){
                    if($gValue['dramount'] != "0.00"){
                        $closingBalance = $gValue['dramount'];
                        $closeDrOrCr = "Dr";
                    }else{
                        $closingBalance = $gValue['cramount'];
                        $closeDrOrCr = "Cr";
                    }
                }
                if(count($overDueMark) > 0) {
                    $key = array_search($gValue['trn_no'], $overDueMarkTrnNos);
                    if ($key !== false) {
                        $getData[$gKey]['overdue_status'] = $overDueMarkOverdueStaus[$key];
                        $getData[$gKey]['overdue_by_day'] = $overDueMarkByDay[$key];
                    }
                }
            }
            $html = view('frontend.partials._table_rows', [
                'data' => $getData,
                'openingBalance' => $openingBalance,
                'closeDrOrCr' => $closeDrOrCr,
                'closingBalance' => $closingBalance
            ])->render();

            return response()->json(['html' => $html, 'openingBalance' => $openingBalance, 'closingBalance'=>$closingBalance]);
            // return response()->json(['data' => $getData, 'openingBalance' => $openingBalance, 'closingBalance'=>$closingBalance]);
        }

    }


    public function downloadStatementPdf(Request $request)
    {
        $invoiceController = new InvoiceController();
    
        // Capture the JSON response from the statementPdfDownload method
        $response = $invoiceController->statementPdfDownload($request);
        return $response;
    
        // Decode the JSON response (response()->json returns an instance of Illuminate\Http\JsonResponse)
        // $responseData = json_decode($response->getContent(), true); 

        // if ($responseData['status'] === 'success') {
          
        //     $pdf_url = $responseData['message'];
        //     return response()->json(['status' => 'success', 'message' => $pdf_url]);
        // } else {
        //     return response()->json(['status' => 'error', 'message' => 'PDF generation failed'], 500);
        // }
    
        
    }

}
