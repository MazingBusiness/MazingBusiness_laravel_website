<?php

namespace App\Http\Controllers;

use App\Models\Currency;
use App\Models\Language;
use App\Models\Order;
use App\Models\User;
use App\Models\Address;
use Config;
use Hash;
use PDF;
use Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use App\Services\WhatsAppWebService;
use Illuminate\Support\Facades\Auth;



class InvoiceController extends Controller {
  protected $whatsAppWebService;

  public function open_invoice_download($hash) {
    $hash = base64_decode($hash);
    parse_str($hash, $params);
    if (Session::has('currency_code')) {
      $currency_code = Session::get('currency_code');
    } else {
      $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
    }
    $language_code = Session::get('locale', Config::get('app.locale'));

    if (Language::where('code', $language_code)->first()->rtl == 1) {
      $direction      = 'rtl';
      $text_align     = 'right';
      $not_text_align = 'left';
    } else {
      $direction      = 'ltr';
      $text_align     = 'left';
      $not_text_align = 'right';
    }

    if ($currency_code == 'BDT' || $language_code == 'bd') {
      // bengali font
      $font_family = "'Hind Siliguri','sans-serif'";
    } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
      // khmer font
      $font_family = "'Hanuman','sans-serif'";
    } elseif ($currency_code == 'AMD') {
      // Armenia font
      $font_family = "'arnamu','sans-serif'";
      // }elseif($currency_code == 'ILS'){
      //     // Israeli font
      //     $font_family = "'Varela Round','sans-serif'";
    } elseif ($currency_code == 'AED' || $currency_code == 'EGP' || $language_code == 'sa' || $currency_code == 'IQD' || $language_code == 'ir' || $language_code == 'om' || $currency_code == 'ROM' || $currency_code == 'SDG' || $currency_code == 'ILS' || $language_code == 'jo') {
      // middle east/arabic/Israeli font
      $font_family = "'Baloo Bhaijaan 2','sans-serif'";
    } elseif ($currency_code == 'THB') {
      // thai font
      $font_family = "'Kanit','sans-serif'";
    } else {
      // general for all
      $font_family = "'Roboto','sans-serif'";
    }

    // $config = ['instanceConfigurator' => function($mpdf) {
    //     $mpdf->showImageErrors = true;
    // }];
    // mpdf config will be used in 4th params of loadview

    $config = [];

    $order = Order::findOrFail($params['id']);
    if (Hash::check($params['hash'], Hash::make($order['combined_order_id'] . $order['user_id']))) {
      if (mb_substr($order->code, 0, 3) == 'MZ/') {
        return PDF::loadView('backend.invoices.invoice', [
          'order'          => $order,
          'font_family'    => $font_family,
          'direction'      => $direction,
          'text_align'     => $text_align,
          'not_text_align' => $not_text_align,
        ], [], $config)->download('order-' . $order->code . '.pdf');
      } else {
        return PDF::loadView('backend.invoices.proformainvoice', [
          'order'          => $order,
          'font_family'    => $font_family,
          'direction'      => $direction,
          'text_align'     => $text_align,
          'not_text_align' => $not_text_align,
        ], [], $config)->download('order-' . $order->code . '.pdf');
      }
    } else {}
  }
  //download invoice
  public function invoice_download($id) {
    if (Session::has('currency_code')) {
      $currency_code = Session::get('currency_code');
    } else {
      $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
    }
    $language_code = Session::get('locale', Config::get('app.locale'));

    if (Language::where('code', $language_code)->first()->rtl == 1) {
      $direction      = 'rtl';
      $text_align     = 'right';
      $not_text_align = 'left';
    } else {
      $direction      = 'ltr';
      $text_align     = 'left';
      $not_text_align = 'right';
    }

    if ($currency_code == 'BDT' || $language_code == 'bd') {
      // bengali font
      $font_family = "'Hind Siliguri','sans-serif'";
    } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
      // khmer font
      $font_family = "'Hanuman','sans-serif'";
    } elseif ($currency_code == 'AMD') {
      // Armenia font
      $font_family = "'arnamu','sans-serif'";
      // }elseif($currency_code == 'ILS'){
      //     // Israeli font
      //     $font_family = "'Varela Round','sans-serif'";
    } elseif ($currency_code == 'AED' || $currency_code == 'EGP' || $language_code == 'sa' || $currency_code == 'IQD' || $language_code == 'ir' || $language_code == 'om' || $currency_code == 'ROM' || $currency_code == 'SDG' || $currency_code == 'ILS' || $language_code == 'jo') {
      // middle east/arabic/Israeli font
      $font_family = "'Baloo Bhaijaan 2','sans-serif'";
    } elseif ($currency_code == 'THB') {
      // thai font
      $font_family = "'Kanit','sans-serif'";
    } else {
      // general for all
      $font_family = "'Roboto','sans-serif'";
    }

    // $config = ['instanceConfigurator' => function($mpdf) {
    //     $mpdf->showImageErrors = true;
    // }];
    // mpdf config will be used in 4th params of loadview

    $config = [];

    $order = Order::findOrFail($id);
    if (mb_substr($order->code, 0, 3) == 'MZ/') {
      return PDF::loadView('backend.invoices.invoice', [
        'order'          => $order,
        'font_family'    => $font_family,
        'direction'      => $direction,
        'text_align'     => $text_align,
        'not_text_align' => $not_text_align,
      ], [], $config)->download('order-' . $order->code . '.pdf');
    } else {
      return PDF::loadView('backend.invoices.proformainvoice', [
        'order'          => $order,
        'font_family'    => $font_family,
        'direction'      => $direction,
        'text_align'     => $text_align,
        'not_text_align' => $not_text_align,
      ], [], $config)->download('order-' . $order->code . '.pdf');
    }
  }



  //new invoice _file_path function created on 06 - aug- 2024
  public function invoice_file_path($id) {
    if (Session::has('currency_code')) {
      $currency_code = Session::get('currency_code');
    } else {
        $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
    }
    $language_code = Session::get('locale', Config::get('app.locale'));

    if (Language::where('code', $language_code)->first()->rtl == 1) {
        $direction      = 'rtl';
        $text_align     = 'right';
        $not_text_align = 'left';
    } else {
        $direction      = 'ltr';
        $text_align     = 'left';
        $not_text_align = 'right';
    }

    if ($currency_code == 'BDT' || $language_code == 'bd') {
        $font_family = "'Hind Siliguri','sans-serif'";
    } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
        $font_family = "'Hanuman','sans-serif'";
    } elseif ($currency_code == 'AMD') {
        $font_family = "'arnamu','sans-serif'";
    } elseif (in_array($currency_code, ['AED', 'EGP', 'IQD', 'ROM', 'SDG', 'ILS']) || in_array($language_code, ['sa', 'ir', 'om', 'jo'])) {
        $font_family = "'Baloo Bhaijaan 2','sans-serif'";
    } elseif ($currency_code == 'THB') {
        $font_family = "'Kanit','sans-serif'";
    } else {
        $font_family = "'Roboto','sans-serif'";
    }

    $config = [];

    $order = Order::findOrFail($id);

    $client_address = DB::table('addresses')
    ->where('id', $order->address_id)
    ->first();

    $view = mb_substr($order->code, 0, 3) == 'MZ/' ? 'backend.invoices.invoice' : 'backend.invoices.proformainvoice';
    $pdf = PDF::loadView($view, [
        'order'          => $order,
        'client_address' => $client_address,
        'font_family'    => $font_family,
        'direction'      => $direction,
        'text_align'     => $text_align,
        'not_text_align' => $not_text_align,
    ], [], $config);

    $fileName = 'order-' . $order->code . '.pdf';
    $filePath = public_path('pdfs/' . $fileName);
    $pdf->save($filePath);

    $publicUrl = url('public/pdfs/' . $fileName);

    return $publicUrl;
  }



  //new invoice _file_path for cart_quotations function created on 14 - aug- 2024
  public function invoice_file_path_cart_quotations($id,$newQuotationId) {
    
    if (Session::has('currency_code')) {
      $currency_code = Session::get('currency_code');
    } else {
        $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
    }
    $language_code = Session::get('locale', Config::get('app.locale'));
   

    if (Language::where('code', $language_code)->first()->rtl == 1) {
        $direction      = 'rtl';
        $text_align     = 'right';
        $not_text_align = 'left';
    } else {
        $direction      = 'ltr';
        $text_align     = 'left';
        $not_text_align = 'right';
    }
    

    if ($currency_code == 'BDT' || $language_code == 'bd') {
        $font_family = "'Hind Siliguri','sans-serif'";
    } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
        $font_family = "'Hanuman','sans-serif'";
    } elseif ($currency_code == 'AMD') {
        $font_family = "'arnamu','sans-serif'";
    } elseif (in_array($currency_code, ['AED', 'EGP', 'IQD', 'ROM', 'SDG', 'ILS']) || in_array($language_code, ['sa', 'ir', 'om', 'jo'])) {
        $font_family = "'Baloo Bhaijaan 2','sans-serif'";
    } elseif ($currency_code == 'THB') {
        $font_family = "'Kanit','sans-serif'";
    } else {
        $font_family = "'Roboto','sans-serif'";
    }

    $config = [];
    

    $cartItems = DB::table('users')
    ->leftJoin('carts', 'users.id', '=', 'carts.user_id')
    ->leftJoin('products', 'carts.product_id', '=', 'products.id')
    ->leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id')
    ->leftJoin('addresses', 'carts.address_id', '=', 'addresses.id')
    ->leftJoin('uploads', 'products.photos', '=', 'uploads.id') // Join uploads with products based on thumbnail_img
    ->select(
        'users.company_name',
        'users.phone',
        'users.manager_id',
        'users.party_code',
        'users.credit_days',
        'users.credit_limit',
        'products.part_no',
        'products.name as product_name',
        'warehouses.name as warehouse_name',
        'carts.created_at',
        'carts.quantity',
        'carts.address_id',
        'carts.price',
        'carts.user_id',
        'carts.product_id',
        'addresses.address',
        'addresses.address_2',
        'addresses.city',
        'carts.id as cart_id',
        DB::raw('carts.quantity * carts.price as total'),
        'uploads.file_name as thumbnail' // Select the file_name from uploads
    )
    ->where('carts.user_id', $id)
    ->get();

    $cartItemAddress = DB::table('users')
        ->join('carts', 'users.id', '=', 'carts.user_id')
        ->join('addresses', 'carts.address_id', '=', 'addresses.id') // Join with the addresses table
        ->where('carts.user_id', $id)  // Add the where condition
        ->select('carts.address_id', 'addresses.address', 'addresses.address_2') // Select specific columns
        ->first(); // Retrieve the first matching record

   // $logo="https://storage.googleapis.com/mazing/uploads/all/PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png";   
   $logo = env('UPLOADS_BASE_URL') . '/' . 'PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png';
      
    $view = 'backend.invoices.cart_quotations';
    $pdf = PDF::loadView($view, [
        'cart_items'          => $cartItems,
        'client_address' => $cartItemAddress,
        'quotation_id'=>$newQuotationId,
        'logo'=>$logo,
        'font_family'    => $font_family,
        'direction'      => $direction,
        'text_align'     => $text_align,
        'not_text_align' => $not_text_align,
    ], [], $config);

    $fileName = 'quotations-' . $newQuotationId . '.pdf';
    $filePath = public_path('pdfs/' . $fileName);
    $pdf->save($filePath);

    $publicUrl = url('public/pdfs/' . $fileName);

    return $publicUrl;
  }

    //new invoice _file_path for cart_quotations function created on 14 - aug- 2024
    public function invoice_file_path_abandoned_cart($id,$random_number) {
    
      if (Session::has('currency_code')) {
        $currency_code = Session::get('currency_code');
      } else {
          $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
      }
      $language_code = Session::get('locale', Config::get('app.locale'));
     
  
      if (Language::where('code', $language_code)->first()->rtl == 1) {
          $direction      = 'rtl';
          $text_align     = 'right';
          $not_text_align = 'left';
      } else {
          $direction      = 'ltr';
          $text_align     = 'left';
          $not_text_align = 'right';
      }
      
  
      if ($currency_code == 'BDT' || $language_code == 'bd') {
          $font_family = "'Hind Siliguri','sans-serif'";
      } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
          $font_family = "'Hanuman','sans-serif'";
      } elseif ($currency_code == 'AMD') {
          $font_family = "'arnamu','sans-serif'";
      } elseif (in_array($currency_code, ['AED', 'EGP', 'IQD', 'ROM', 'SDG', 'ILS']) || in_array($language_code, ['sa', 'ir', 'om', 'jo'])) {
          $font_family = "'Baloo Bhaijaan 2','sans-serif'";
      } elseif ($currency_code == 'THB') {
          $font_family = "'Kanit','sans-serif'";
      } else {
          $font_family = "'Roboto','sans-serif'";
      }
  
      $config = [];
      
      $cartItems = DB::table('users')
    ->leftJoin('carts', 'users.id', '=', 'carts.user_id')
    ->leftJoin('products', 'carts.product_id', '=', 'products.id')
    ->leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id')
    ->leftJoin('addresses', 'carts.address_id', '=', 'addresses.id')
	->leftJoin('uploads', 'products.thumbnail_img', '=', 'uploads.id')
    ->select(
        'users.company_name',
        'users.phone',
        'users.manager_id',
        'users.party_code',
        'products.name as product_name',
        'warehouses.name as warehouse_name',
        'carts.created_at',
        'carts.quantity',
        'carts.address_id',
        'carts.price',
        'carts.user_id',
        'carts.product_id',
        'addresses.address',
        'addresses.address_2',
        'addresses.city',
        'carts.id as cart_id',
        DB::raw('carts.quantity * carts.price as total')
    )
    ->where('carts.user_id', $id)
    ->get();

              // echo $cartItems->count();
              // die();
  
      $cartItemAddress = DB::table('users')
          ->join('carts', 'users.id', '=', 'carts.user_id')
          ->join('addresses', 'carts.address_id', '=', 'addresses.id') // Join with the addresses table
          ->where('carts.user_id', $id)  // Add the where condition
          ->select('carts.address_id', 'addresses.address', 'addresses.address_2') // Select specific columns
          ->first(); // Retrieve the first matching record
  
     // $logo="https://storage.googleapis.com/mazing/uploads/all/PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png";       
     $logo = env('UPLOADS_BASE_URL') . '/' . 'PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png';
  
      $view = 'backend.invoices.unfilled_order';
      $pdf = PDF::loadView($view, [
          'cart_items'          => $cartItems,
          'client_address' => $cartItemAddress,
          
          'logo'=>$logo,
          'font_family'    => $font_family,
          'direction'      => $direction,
          'text_align'     => $text_align,
          'not_text_align' => $not_text_align,
      ], [], $config);
      
      $hashCode = substr(md5(uniqid($random_number, true)), 0, 8);
      $fileName = 'abandoned_cart-' . '-' . $hashCode . '.pdf';
      // $fileName = 'quotations-' . $newQuotationId . '.pdf';
      $filePath = public_path('abandoned_cart_pdf/' . $fileName);
      $pdf->save($filePath);
  
      $publicUrl = url('public/abandoned_cart_pdf/' . $fileName);
  
      return $publicUrl;
    }


    


    //purchase order pdf generation (save & continuee)
    public function purchase_order_pdf_invoice($purchase_order_no) {
      if (Session::has('currency_code')) {
          $currency_code = Session::get('currency_code');
      } else {
          $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
      }
      $language_code = Session::get('locale', Config::get('app.locale'));
  
      if (Language::where('code', $language_code)->first()->rtl == 1) {
          $direction      = 'rtl';
          $text_align     = 'right';
          $not_text_align = 'left';
      } else {
          $direction      = 'ltr';
          $text_align     = 'left';
          $not_text_align = 'right';
      }
  
      if ($currency_code == 'BDT' || $language_code == 'bd') {
          $font_family = "'Hind Siliguri','sans-serif'";
      } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
          $font_family = "'Hanuman','sans-serif'";
      } elseif ($currency_code == 'AMD') {
          $font_family = "'arnamu','sans-serif'";
      } elseif (in_array($currency_code, ['AED', 'EGP', 'IQD', 'ROM', 'SDG', 'ILS']) || in_array($language_code, ['sa', 'ir', 'om', 'jo'])) {
          $font_family = "'Baloo Bhaijaan 2','sans-serif'";
      } elseif ($currency_code == 'THB') {
          $font_family = "'Kanit','sans-serif'";
      } else {
          $font_family = "'Roboto','sans-serif'";
      }
  
      // Fetch the purchase order details
      $order = DB::table('final_purchase_order')
          ->where('purchase_order_no', $purchase_order_no)
          ->select('final_purchase_order.*')
          ->first();
  
      // Decode the seller_info JSON
      $sellerInfo = json_decode($order->seller_info, true);
  
      // Decode the product_info JSON
      $productInfo = json_decode($order->product_invoice, true);
  
      // Fetch product details (purchase_price, hsncode, product_name) for each part number
      foreach ($productInfo as &$product) {
          $productDetails = DB::table('products')
              ->where('part_no', $product['part_no'])
              ->select('name as product_name', 'purchase_price', 'hsncode', 'part_no')
              ->first();
  
          $product['product_name'] = $productDetails->product_name ?? 'Unknown';
          $product['purchase_price'] = $productDetails->purchase_price ?? 0;
          $product['hsncode'] = $productDetails->hsncode ?? 'N/A';
          $product['subtotal'] = $product['qty'] * $product['purchase_price'];
      }
  
      // $logo = "https://storage.googleapis.com/mazing/uploads/all/PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png";
      $logo = env('UPLOADS_BASE_URL') . '/' . 'PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png';

      $view = 'backend.invoices.purchase_order_pdf';
  
      $randomNumber = rand(1000, 9999);
      $fileName = 'purchase_order-' . $randomNumber . '.pdf';
  
      $pdf = PDF::loadView($view, [
          'logo' => $logo,
          'font_family' => $font_family,
          'direction' => $direction,
          'text_align' => $text_align,
          'not_text_align' => $not_text_align,
          'order' => $order,
          'sellerInfo' => $sellerInfo,  // Pass the decoded seller information
          'productInfo' => $productInfo
      ], [], []);
  
      $filePath = public_path('purchase_order_pdf/' . $fileName);
      $pdf->save($filePath);
  
      $publicUrl = url('public/purchase_order_pdf/' . $fileName);
      return $publicUrl;
  }
  

      //purchase order pdf generation (save & continuee)
      public function packing_list_pdf_invoice($purchase_order_no) {
        if (Session::has('currency_code')) {
            $currency_code = Session::get('currency_code');
        } else {
            $currency_code = Currency::findOrFail(get_setting('system_default_currency'))->code;
        }
        $language_code = Session::get('locale', Config::get('app.locale'));

        if (Language::where('code', $language_code)->first()->rtl == 1) {
            $direction      = 'rtl';
            $text_align     = 'right';
            $not_text_align = 'left';
        } else {
            $direction      = 'ltr';
            $text_align     = 'left';
            $not_text_align = 'right';
        }

        if ($currency_code == 'BDT' || $language_code == 'bd') {
            $font_family = "'Hind Siliguri','sans-serif'";
        } elseif ($currency_code == 'KHR' || $language_code == 'kh') {
            $font_family = "'Hanuman','sans-serif'";
        } elseif ($currency_code == 'AMD') {
            $font_family = "'arnamu','sans-serif'";
        } elseif (in_array($currency_code, ['AED', 'EGP', 'IQD', 'ROM', 'SDG', 'ILS']) || in_array($language_code, ['sa', 'ir', 'om', 'jo'])) {
            $font_family = "'Baloo Bhaijaan 2','sans-serif'";
        } elseif ($currency_code == 'THB') {
            $font_family = "'Kanit','sans-serif'";
        } else {
            $font_family = "'Roboto','sans-serif'";
        }

        // Fetch the purchase order details
        $order = DB::table('final_purchase_order')
            ->join('sellers', 'final_purchase_order.seller_id', '=', 'sellers.id')
            ->join('shops', 'sellers.id', '=', 'shops.seller_id')
            ->where('final_purchase_order.purchase_order_no', $purchase_order_no)
            ->select(
                'final_purchase_order.*',
                'shops.name as seller_company_name',
                'shops.address as seller_address',
                'sellers.gstin as seller_gstin',
                'shops.phone as seller_phone'
            )
            ->first();
          
        // Decode the product_info JSON
        $productInfo = json_decode($order->product_invoice, true);

        // Fetch product details (purchase_price, hsncode, product_name) for each part number
        foreach ($productInfo as &$product) {
            $productDetails = DB::table('products')
                ->where('part_no', $product['part_no'])
                ->select('name as product_name', 'purchase_price', 'hsncode', 'part_no')
                ->first();

            $product['product_name'] = $productDetails->product_name ?? 'Unknown';
            $product['purchase_price'] = $productDetails->purchase_price ?? 0;
            $product['hsncode'] = $productDetails->hsncode ?? 'N/A';
            $product['subtotal'] = $product['qty'] * $product['purchase_price'];
        }
        $sellerName = DB::table('final_purchase_order')
              ->where('purchase_order_no', $purchase_order_no)
              ->value(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(seller_info, '$.seller_name'))"));

        // $logo = "https://storage.googleapis.com/mazing/uploads/all/PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png";   
        $logo = env('UPLOADS_BASE_URL') . '/' . 'PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png';
      
        $view = 'backend.invoices.packing_list';


        $randomNumber = rand(1000, 9999);
        $fileName = 'packing_list-' . $randomNumber . '.pdf';

        $pdf = PDF::loadView($view, [
            'logo' => $logo,
            'font_family' => $font_family,
            'direction' => $direction,
            'text_align' => $text_align,
            'not_text_align' => $not_text_align,
            'order' => $order,
            'seller_name'=>$sellerName,
            'productInfo' => $productInfo
        ])->save(public_path('packing_list_pdf/' . $fileName));

        $publicUrl = url('public/packing_list_pdf/' . $fileName);
        return $publicUrl;
    }

    public function statementPdfDownload(Request $request)
    {
        try {
            $party_code = ($request->party_code); 
        } catch (\Exception $e) {
            Log::error('Decryption error: ' . $e->getMessage());
            return response()->json(['error' => 'Failed to decrypt party code.'], 500);
        }

        $currentDate = date('Y-m-d');
        $currentMonth = date('m');
        $currentYear = date('Y');

        if ($currentMonth >= 4) {
            $form_date = date('Y-04-01'); // Start of financial year
            $to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year
        } else {
            $form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
            $to_date = date('Y-03-31'); // Current year March
        }

        if ($request->has('from_date')) {
            $form_date = $request->from_date; // Use provided date
        }

        if ($request->has('to_date')) {
            $to_date = $request->to_date; // Use provided date
        }

        if ($to_date > $currentDate) {
            $to_date = $currentDate;
        }
        
        $headers = [
            'authtoken' => '65d448afc6f6b',
        ];

        $body = [
            'party_code' => $party_code,
            'from_date' => $form_date,
            'to_date' => $to_date,
        ];

        Log::info('Sending request to API', ['body' => $body]);

        $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);      

        Log::info('Received response from API', ['status' => $response->status(), 'body' => $response->body()]);

        if ($response->successful()) {

            $getData = $response->json();
            $getData = $getData['data'];

            $openingBalance = "0";
            $closingBalance = "0";
            $openDrOrCr = "";
            $closeDrOrCr = "";
            $dueAmount = 0;  // Initialize dueAmount
            $overdueAmount = 0;
            $overdueDrOrCr = 'Dr';
            $userData = User::where('party_code', $party_code)->first();
            $overdueDateFrom = date('Y-m-d', strtotime('-' . $userData->credit_days . ' days'));

            // Process the API data to get opening, closing balances, and calculate due amount
            foreach ($getData as $gKey => $gValue) {
                if ($gValue['ledgername'] == "Opening b/f...") {
                    $openingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
                    $openDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
                } elseif ($gValue['ledgername'] == "closing C/f...") {
                    $closingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
                    $closeDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
                    $dueAmount = $gValue['dramount'] != "0.00" ? $gValue['dramount'] : $gValue['cramount'];  // Calculate due amount
                    $overdueAmount = $closingBalance;
                }
            }

            // Overdue calculation logic
            $getOverdueData = array_reverse($getData);
            $drBalanceBeforeOVDate = 0;
            $crBalanceBeforeOVDate = 0;
            $overDueMark = [];

            foreach($getOverdueData as $ovKey => $ovValue){
                if($ovValue['ledgername'] != 'closing C/f...'){
                    if(strtotime($ovValue['trn_date']) <= strtotime($overdueDateFrom)){
                        $drBalanceBeforeOVDate += $ovValue['dramount'];
                        $crBalanceBeforeOVDate += $ovValue['cramount'];
                    }
                }
            }

            $overdueAmount = $drBalanceBeforeOVDate - $crBalanceBeforeOVDate;

            // Marking overdue transactions
            foreach($getOverdueData as $ovKey => $ovValue){
                if($ovValue['ledgername'] != 'closing C/f...'){
                    if(strtotime($ovValue['trn_date']) < strtotime($overdueDateFrom) && $ovValue['dramount'] > 0){
                        $overDueMark[] = [
                            'trn_no' => $ovValue['trn_no'],
                            'trn_date' => $ovValue['trn_date'],
                            'overdue_status' => ($overdueAmount > 0) ? 'Overdue' : 'Partial Overdue'
                        ];
                    }
                }
            }

            // Adding overdue status to each transaction in getData
            $overDueMarkTrnNos = array_column($overDueMark, 'trn_no');
            $overDueMarkOverdueStaus = array_column($overDueMark, 'overdue_status');

            if (count($overDueMark) > 0) {
                foreach ($getData as $gKey => $gValue) {
                    $key = array_search($gValue['trn_no'], $overDueMarkTrnNos);
                    if ($key !== false) {
                        $getData[$gKey]['overdue_status'] = $overDueMarkOverdueStaus[$key];
                    }
                }
            }

            // Generating PDF with overdue data and due amount
            $randomNumber = rand(1000, 9999);
            $fileName = 'statement-' . $randomNumber . '.pdf';
            $userId = Auth::id();
            $pdf = PDF::loadView('backend.invoices.statement_pdf', compact(
                'party_code',
                'getData',
                'openingBalance',
                'openDrOrCr',
                'closingBalance',
                'closeDrOrCr',
                'form_date',
                'to_date',
                'overdueAmount',
                'overdueDrOrCr',
                'overdueDateFrom',
                'overDueMark',
                'dueAmount' ,// Pass dueAmount to the view
                'userId' 
            ))->save(public_path('statements/' . $fileName));

            $publicUrl = url('public/statements/' . $fileName);


            $user = Auth::user();
            $message="statement";
            //$to="7044300330"; 
            $phone = $user->phone;
            $templateData = [
                'name' => 'utility_statement_document', // Replace with your template name, 
                'language' => 'en_US', // Replace with your desired language code
                'components' => [
                    // [
                    //     'type' => 'header',
                    //     'parameters' => [
                    //         ['type' => 'document', 'document' => ['link' => $publicUrl,'filename' => $fileName,]],
                    //     ],
                    // ],
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $user->company_name],
                            ['type' => 'text', 'text' => $message],
                        ],
                    ],
                    [
                        'type' => 'button',
                        'sub_type' => 'url',
                        'index' => '0',
                        'parameters' => [
                            [
                                "type" => "text","text" => $fileName // Replace $button_text with the actual Parameter for the button.
                            ],
                        ],
                    ],
                ],
            ];

            // Send the template message using the WhatsApp web service
            $this->whatsAppWebService = new WhatsAppWebService();
            $jsonResponse  = $this->whatsAppWebService->sendTemplateMessage($phone, $templateData);

            return response()->json(['status' => 'success', 'message' => "Statement sent to whatsapp."], $response->status());
        } else {
            return response()->json(['status' => 'failure'], $response->status());
        }
    }



  
  
}
