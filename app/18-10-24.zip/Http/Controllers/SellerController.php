<?php

namespace App\Http\Controllers;

use App\Models\City;
use App\Models\Country;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\Product;
use App\Models\Seller;
use App\Models\Shop;
use App\Models\State;
use App\Models\User;
use Cache;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class SellerController extends Controller {
  public function __construct() {
    // Staff Permission Check
    $this->middleware(['permission:view_all_seller'])->only('index');
    $this->middleware(['permission:view_seller_profile'])->only('profile_modal');
    $this->middleware(['permission:login_as_seller'])->only('login');
    $this->middleware(['permission:pay_to_seller'])->only('payment_modal');
    $this->middleware(['permission:edit_seller'])->only('edit');
    $this->middleware(['permission:delete_seller'])->only('destroy');
    $this->middleware(['permission:ban_seller'])->only('ban');
  }

  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request) {
    $sort_search = null;
    $approved    = null;
    $sellers     = Seller::with('user','warehouseProducts')->latest();
    if ($request->has('search')) {
      $sort_search = $request->search;
      $user_ids    = User::where(function ($user) use ($sort_search) {
        $user->where('name', 'like', '%' . $sort_search . '%')->orWhere('email', 'like', '%' . $sort_search . '%');
      })->pluck('id')->toArray();
      $sellers = $sellers->where(function ($sellers) use ($user_ids) {
        $sellers->whereIn('user_id', $user_ids);
      });
    }
    if ($request->approved_status != null) {
      $approved = $request->approved_status;
      $sellers  = $sellers->where('verification_status', $approved);
    }
    $sellers = $sellers->paginate(15);
    return view('backend.sellers.index', compact('sellers', 'sort_search', 'approved'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create() {
    return view('backend.sellers.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request) {
    if (User::where('email', $request->email)->first() != null) {
      flash(translate('Seller already exists!'))->error();
      return back();
    }
    $user                    = new User;
    $user->name              = $request->name;
    $user->warehouse_id      = $request->warehouse_id;
    $user->email             = $request->email;
    $user->address           = $request->address;
    $user->country           = Country::find($request->country_id)->name;
    $user->state             = State::find($request->state_id)->name;
    $user->city              = City::find($request->city_id)->name;
    $user->postal_code       = $request->postal_code;
    $user->phone             = $request->phone;
    $user->user_type         = "seller";
    $user->password          = Hash::make($request->password);
    $user->email_verified_at = date('Y-m-d H:m:s');

    if ($user->save()) {
      $seller                      = new Seller;
      $seller->user_id             = $user->id;
      $seller->verification_status = 1;
      $seller->gstin               = $request->gstin;
      $seller->bank_name           = $request->bank_name;
      $seller->bank_acc_name       = $request->bank_acc_name;
      $seller->bank_acc_no         = $request->bank_acc_no;
      $seller->bank_ifsc_code      = $request->bank_ifsc_code;
      if ($request->has('bank_acc_no')) {
        $seller->bank_payment_status = 1;
      }
      if ($seller->save()) {
        $shop            = new Shop;
        $shop->seller_id = $seller->id;
        $shop->name      = $request->shop_name;
        $shop->phone     = $request->phone;
        $shop->address   = $request->address . ', ' . $user->city . ' - ' . $user->postal_code . ', ' . $user->state . ', ' . $user->country;
        $shop->save();
        flash(translate('Seller has been inserted successfully'))->success();
        return redirect()->route('sellers.index');
      }
    }
    flash(translate('Something went wrong'))->error();
    return back();
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id) {
    //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function edit($id) {
    $seller = Seller::findOrFail(decrypt($id));
    return view('backend.sellers.edit', compact('seller'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id) {
    $seller             = Seller::findOrFail($id);
    $user               = $seller->user;
    $user->name         = $request->name;
    $user->warehouse_id = $request->warehouse_id;
    $user->email        = $request->email;
    $user->address      = $request->address;
    $user->country      = Country::find($request->country_id)->name;
    $user->state        = State::find($request->state_id)->name;
    $user->city         = City::find($request->city_id)->name;
    $user->postal_code  = $request->postal_code;
    $user->phone        = $request->phone;
    $user->password     = Hash::make($request->password);
    if ($user->save()) {
      $seller->gstin          = $request->gstin;
      $seller->bank_name      = $request->bank_name;
      $seller->bank_acc_name  = $request->bank_acc_name;
      $seller->bank_acc_no    = $request->bank_acc_no;
      $seller->bank_ifsc_code = $request->bank_ifsc_code;
      if ($request->has('bank_acc_no')) {
        $seller->bank_payment_status = 1;
      } else {
        $seller->bank_payment_status = 0;
      }
      if ($seller->save()) {
        $shop          = $seller->shop;
        $shop->name    = $request->shop_name;
        $shop->phone   = $request->phone;
        $shop->address = $request->address . ', ' . $user->city . ' - ' . $user->postal_code . ', ' . $user->state . ', ' . $user->country;
        $shop->save();
        flash(translate('Seller has been updated successfully'))->success();
        return redirect()->route('sellers.index');
      }
    }
    flash(translate('Something went wrong'))->error();
    return back();
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id) {
    $seller = Seller::findOrFail($id);
    Product::where('user_id', $seller->user_id)->delete();
    $orders = Order::where('user_id', $seller->user_id)->get();

    foreach ($orders as $key => $order) {
      OrderDetail::where('order_id', $order->id)->delete();
    }
    Order::where('user_id', $seller->user_id)->delete();
    Shop::where('seller_id', $id)->delete();
    User::destroy($seller->user->id);

    if (Seller::destroy($id)) {
      flash(translate('Seller has been deleted successfully'))->success();
      return redirect()->route('sellers.index');
    } else {
      flash(translate('Something went wrong'))->error();
      return back();
    }
  }

  public function bulk_seller_delete(Request $request) {
    if ($request->id) {
      foreach ($request->id as $seller_id) {
        $this->destroy($seller_id);
      }
    }
    return 1;
  }

  public function show_verification_request($id) {
    $shop = Shop::findOrFail($id);
    return view('backend.sellers.verification', compact('shop'));
  }

  public function approve_seller($id) {
    $shop                      = Shop::findOrFail($id);
    $shop->verification_status = 1;
    if ($shop->save()) {
      Cache::forget('verified_sellers_id');
      flash(translate('Seller has been approved successfully'))->success();
      return redirect()->route('sellers.index');
    }
    flash(translate('Something went wrong'))->error();
    return back();
  }

  public function reject_seller($id) {
    $shop                      = Shop::findOrFail($id);
    $shop->verification_status = 0;
    $shop->verification_info   = null;
    if ($shop->save()) {
      Cache::forget('verified_sellers_id');
      flash(translate('Seller verification request has been rejected successfully'))->success();
      return redirect()->route('sellers.index');
    }
    flash(translate('Something went wrong'))->error();
    return back();
  }

  public function payment_modal(Request $request) {
    $shop = shop::findOrFail($request->id);
    return view('backend.sellers.payment_modal', compact('shop'));
  }

  public function profile_modal(Request $request) {
    $seller = Seller::findOrFail($request->id);
    return view('backend.sellers.profile_modal', compact('seller'));
  }

  public function updateApproved(Request $request) {
    $seller                      = Seller::findOrFail($request->id);
    $seller->verification_status = $request->status;
    if ($seller->save()) {
      Cache::forget('verified_sellers_id');
      return 1;
    }
    return 0;
  }

  public function login($id) {
    $seller = Seller::findOrFail(decrypt($id));
    $user   = $seller->user;
    auth()->login($user, true);
    return redirect()->route('seller.dashboard');
  }

  public function ban($id) {
    $seller = Seller::findOrFail($id);

    if ($seller->user->banned == 1) {
      $seller->user->banned = 0;
      flash(translate('Seller has been unbanned successfully'))->success();
    } else {
      $seller->user->banned = 1;
      flash(translate('Seller has been banned successfully'))->success();
    }

    $seller->user->save();
    return back();
  }
}
