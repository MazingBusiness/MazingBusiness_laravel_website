<?php

namespace App\Http\Controllers;

use App\Http\Resources\V2\ProductDetailCollection;
use App\Models\Cart;
use App\Models\Product;
use App\Models\Warehouse;
use App\Models\User;
use Auth;
use Cookie;
use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\Services\WhatsAppWebService;
use App\Exports\AbandonedCartExport;
use App\Imports\ExternalPurchaseOrder;
use App\Exports\FinalPurchaseExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Http;
use Exception;
use Illuminate\Support\Facades\Log;



class CartController extends Controller {
  protected $WhatsAppWebService;
  public function index(Request $request) {
    if (auth()->user() != null) {
      $user_id = Auth::user()->id;
      if ($request->session()->get('temp_user_id')) {
        Cart::where('temp_user_id', $request->session()->get('temp_user_id'))
          ->update(
            [
              'user_id'      => $user_id,
              'temp_user_id' => null,
            ]
          );

        Session::forget('temp_user_id');
      }
      $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
    } else {
      $temp_user_id = $request->session()->get('temp_user_id');
      // $carts = Cart::where('temp_user_id', $temp_user_id)->get();
      $carts = ($temp_user_id != null) ? Cart::where('temp_user_id', $temp_user_id)->get() : [];
    }

    return view('frontend.view_cart', compact('carts'));
  }

  public function updateCartPrice(Request $request) {
    try {
        $user_id = Auth::user()->id;        
        $cart_id = $request->has('cart_id')? $request->cart_id : '';
        $update_price = $request->has('update_price')? $request->update_price : '0';

        $cartItem = Cart::findOrFail($cart_id);        
        $cartItem['price'] = $update_price;
        $cartItem->save();
        
        $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
        $view = view('frontend.updateCartPrice', compact('carts'))->render();
        return response()->json(['html' => $view]);

    } catch (\Exception $e) {
        // Log any other exceptions
        \Log::error('An error occurred: ' . $e->getMessage());
        return response()->json([
            'status' => 'Error',
            'message' => 'An unexpected error occurred.',
        ], 500);
    }

  }

  public function showCartModal(Request $request) {
    

    $product = Product::find($request->id);
   
  
   
    return view('frontend.partials.addToCart', compact('product'));
  }

  public function addToCart(Request $request) {

  //  return "test";
   
    $product = Product::find($request->id);
    $carts   = array();
    $data    = array();

    if (auth()->user() != null) {
      $user_id         = Auth::user()->id;
      $data['user_id'] = $user_id;
      $carts           = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
    } else {
      if ($request->session()->get('temp_user_id')) {
        $temp_user_id = $request->session()->get('temp_user_id');
      } else {
        $temp_user_id = bin2hex(random_bytes(10));
        $request->session()->put('temp_user_id', $temp_user_id);
      }
      $data['temp_user_id'] = $temp_user_id;
      $carts                = Cart::where('temp_user_id', $temp_user_id)->get();
    }

    $data['product_id'] = $product->id;
    $data['owner_id']   = $product->user_id;

    $str     = '';
    $tax     = $ctax     = $price     = $carton_price     = 0;
    $wmarkup = 0;
    if ($product->digital != 1 && $request->quantity < $product->min_qty) {
      return array(
        'status'        => 0,
        'cart_count'    => count($carts),
        'modal_view'    => view('frontend.partials.minQtyNotSatisfied', ['min_qty' => $product->min_qty])->render(),
        'nav_cart_view' => view('frontend.partials.cart')->render(),
      );
    }

    //check the color enabled or disabled for the product
    if ($request->has('color')) {
      $str = $request['color'];
    }

    if ($product->digital != 1) {
      //Gets all the choice values of customer choice option and generate a string like Black-S-Cotton
      if(is_countable(json_decode(Product::find($request->id)->choice_options))){
        foreach (json_decode(Product::find($request->id)->choice_options) as $key => $choice) {
          if ($str != null) {
            $str .= '_' . str_replace(' ', '', strtolower($request['attribute_id_' . $choice->attribute_id]));
          } else {
            $str .= str_replace(' ', '', strtolower($request['attribute_id_' . $choice->attribute_id]));
          }
        }
      }
      
    }
    $str = $product->slug;
    $data['variation'] = $str;

    $product_stock = $product->stocks->where('variant', $str);
    
    $user = Auth::user();

    $discount = 0;

    if ($user) {
        $discount = $user->discount;
    }

    if(!is_numeric($discount) || $discount == 0) {
      $discount = 20;
    }

    $product_mrp = Product::where('id', $product->id)->select('mrp')->first();
    if ($product_mrp) {
      $price = $product_mrp->mrp;
    } else {
      $price = 0;
    }
    
    if (!is_numeric($price)) {
      $price = 0;
    }
    $price = $price * ((100 - $discount) / 100);
    $price = ceil($price);

    // return array(
    //   'status'        => 0,
    //   'cart_count'    => count($carts),
    //   'modal_view'    => view('frontend.partials.outOfStockCart')->render(),
    //   'nav_cart_view' => view('frontend.partials.cart')->render(),
    // );

    //discount calculation
    $discount_applicable = false;

    if ($product->discount_start_date == null) {
      $discount_applicable = true;
    } elseif (strtotime(date('d-m-Y H:i:s')) >= $product->discount_start_date &&
      strtotime(date('d-m-Y H:i:s')) <= $product->discount_end_date) {
      $discount_applicable = true;
    }

    if ($discount_applicable) {
      if ($product->discount_type == 'percent') {
        $price -= ($price * $product->discount) / 100;
      } elseif ($product->discount_type == 'amount') {
        $price -= $product->discount;
      }
    }

    //calculation of taxes
    foreach ($product->taxes as $product_tax) {
      if ($product_tax->tax_type == 'percent') {
        $tax += ($price * $product_tax->tax) / 100;
      } elseif ($product_tax->tax_type == 'amount') {
        $tax += $product_tax->tax;
      }
    }

    $data['quantity']  = $request['quantity'];
    $data['price']     = $price;
    $data['tax']       = $tax;
    //$data['shipping'] = 0;
    $data['shipping_cost']         = 0;
    $data['product_referral_code'] = null;
    $data['cash_on_delivery']      = $product->cash_on_delivery;
    $data['digital']               = $product->digital;

    if ($request['quantity'] == null) {
      $data['quantity'] = 1;
    }

    if (Cookie::has('referred_product_id') && Cookie::get('referred_product_id') == $product->id) {
      $data['product_referral_code'] = Cookie::get('product_referral_code');
    }

    if ($carts && count($carts) > 0) {
      $foundInCart = false;
      foreach ($carts as $key => $cartItem) {
        $cart_product = Product::where('id', $cartItem['product_id'])->first();
        if ($cartItem['product_id'] == $request->id) {
          if ($cartItem['is_carton'] != $request['is_carton']) {
            $deleteCartRequest = new Request();
            $deleteCartRequest->replace(['id' => $cartItem['id']]);
            $this->removeFromCart($deleteCartRequest);
          }
          $product_stock = $cart_product->stocks->where('variant', $str);

          // $quantity = 1000;
          
          // if ($quantity < ($cartItem['quantity'] + $request['quantity'])) {
          //   return array(
          //     'status'        => 0,
          //     'cart_count'    => count($carts),
          //     'modal_view'    => view('frontend.partials.outOfStockCart')->render(),
          //     'nav_cart_view' => view('frontend.partials.cart')->render(),
          //   );
          // }
          if (($str != null && $cartItem['variation'] == $str) || $str == null) {
            $foundInCart = true;
              $cartItem['quantity'] += $request['quantity'];
              $cartItem['price'] = $price;
              $cartItem->save();
          }
        }
      }
      if (!$foundInCart) {
        Cart::create($data);
      }
    } else {
      Cart::create($data);
    }

    if (auth()->user() != null) {
      $user_id = Auth::user()->id;
      $carts   = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
    } else {
      $temp_user_id = $request->session()->get('temp_user_id');
      $carts        = Cart::where('temp_user_id', $temp_user_id)->get();
    }
   
    return array(
      'status'        => 1,
      'cart_count'    => count($carts),
      'modal_view'    => view('frontend.partials.addedToCart', compact('product', 'data'))->render(),
      'nav_cart_view' => view('frontend.partials.cart')->render(),
    );
  }

  //removes from Cart
  public function removeFromCart(Request $request) {
    Cart::destroy($request->id);
    if (auth()->user() != null) {
      $user_id = Auth::user()->id;
      $carts   = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
    } else {
      $temp_user_id = $request->session()->get('temp_user_id');
      $carts        = Cart::where('temp_user_id', $temp_user_id)->get();
    }

    return array(
      'cart_count'    => count($carts),
      'cart_view'     => view('frontend.partials.cart_details', compact('carts'))->render(),
      'nav_cart_view' => view('frontend.partials.cart')->render(),
    );
  }

  //updated the quantity for a cart item
  public function updateQuantity(Request $request) {
    $cartItem = Cart::findOrFail($request->id);

    if ($cartItem['id'] == $request->id) {
      $product       = Product::find($cartItem['product_id']);
      $product_stock = $product->stocks->where('variant', $cartItem['variation'])->first();
      $quantity      = $product_stock->qty;
      $price         = $product_stock->price;

      //discount calculation
      $discount_applicable = false;

      if ($product->discount_start_date == null) {
        $discount_applicable = true;
      } elseif (strtotime(date('d-m-Y H:i:s')) >= $product->discount_start_date &&
        strtotime(date('d-m-Y H:i:s')) <= $product->discount_end_date) {
        $discount_applicable = true;
      }

      if ($discount_applicable) {
        if ($product->discount_type == 'percent') {
          $price -= ($price * $product->discount) / 100;
        } elseif ($product->discount_type == 'amount') {
          $price -= $product->discount;
        }
      }

      if ($quantity >= $request->quantity) {
        if ($request->quantity >= $product->min_qty) {
          $cartItem['quantity'] = $request->quantity;
        }
      }

      if ($product->wholesale_product) {
        $wholesalePrice = $product_stock->wholesalePrices->where('min_qty', '<=', $request->quantity)->where('max_qty', '>=', $request->quantity)->first();
        if ($wholesalePrice) {
          $price = $wholesalePrice->price;
        }
      }

      $cartItem['price'] = $price;
      $cartItem->save();
    }

    if (auth()->user() != null) {
      $user_id = Auth::user()->id;
      $carts   = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
    } else {
      $temp_user_id = $request->session()->get('temp_user_id');
      $carts        = Cart::where('temp_user_id', $temp_user_id)->get();
    }

    return array(
      'cart_count'    => count($carts),
      'cart_view'     => view('frontend.partials.cart_details', compact('carts'))->render(),
      'nav_cart_view' => view('frontend.partials.cart')->render(),
    );
  }

  // public function productDetails($id)
  // {
  //   $cart = Cart::where('id',$id)->with('product')->first();
  //   return [
  //     'cart' => $cart,
  //     'product' => $cart['product'],
  //     'brand' => $cart['product']['brand'],
  //     'category' => $cart['product']['category'],
  //     'stocks' => $cart['product']['stocks']->first(),
  //   ];
  // }

  public function productDetails($id)
  {
    try {
        $cart = Cart::where('id', $id)->with('product')->first();

        if (!$cart) {
            return response()->json(['error' => 'Cart not found'], 404);
        }

        $product = $cart->product;

        if (!$product) {
            return response()->json(['error' => 'Product not found in cart'], 404);
        }

        $brand = $product->brand;
        $category = $product->category;
        $stocks = $product->stocks->first();

        return [
            'cart' => $cart,
            'product' => $product,
            'brand' => $brand,
            'category' => $category,
            'stocks' => $stocks,
        ];
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500);
    }
  }


  // ABANDONED CART CODE START


  public function sendBulkWhatsApp(Request $request)
  {

    // send whatsapp button
  
      $userIds = $request->input('selected_carts');

      if ($userIds) {
          foreach ($userIds as $userId) {
            $user = DB::table('users')
            ->join('carts', 'users.id', '=', 'carts.user_id')
            ->select('users.company_name', 'users.phone','users.manager_id')
            ->where('users.id', $userId)
            ->first();

            if (!$user) {
              return response()->json(['error' => 'User not found'], 404);
            }
             // Retrieve manager's information
             $manager = DB::table('users')
             ->select('name', 'phone')
             ->where('id', $user->manager_id)
             ->first();

              // Example of sending WhatsApp messages
              $cartItems = DB::table('carts')
              ->join('products', 'carts.product_id', '=', 'products.id')
              ->select('products.name as product_name', 'carts.quantity')
              ->where('carts.user_id', $userId)
              ->get();
  
              $itemCount = $cartItems->count();
            
                  $name = $user->company_name;
                 
                  $invoice=new InvoiceController();
                  $randomNumber = rand(1000, 9999); // Generates a random number between 1000 and 9999

                  $file_url=$invoice->invoice_file_path_abandoned_cart($userId,$randomNumber);
                  $file_name="Abandoned Cart";
                  $multipleItems = [
                    'name' => 'utility_abandoned_cart', // Replace with your template name, e.g., 'abandoned_cart_template'
                    'language' => 'en_US', // Replace with your desired language code
                    'components' => [
                        [
                            'type' => 'header',
                            'parameters' => [
                                ['type' => 'document', 'document' => ['link' => $file_url,'filename' => $file_name,]],
                            ],
                        ],
                        [
                            'type' => 'body',
                            'parameters' => [
                                ['type' => 'text', 'text' => $name],
                                ['type' => 'text', 'text' => $itemCount], // Second variable (Total Count)
                            ],
                        ],
                    ],
                ];

                 $this->WhatsAppWebService = new WhatsAppWebService();
                 $response = $this->WhatsAppWebService->sendTemplateMessage($user->phone, $multipleItems);
                  $response1 = $this->WhatsAppWebService->sendTemplateMessage($manager->phone, $multipleItems);
                  //$response2 = $this->WhatsAppWebService->sendTemplateMessage('+919894753728', $multipleItems);
                 return redirect()->back()->with('status', 'WhatsApp messages sent successfully!');
             
          }

          return redirect()->back()->with('status', 'WhatsApp messages sent successfully!')->withInput($request->all());
      }

      return redirect()->back()->with('status', 'No carts selected')->withInput($request->all());
  }


  public function abandoned_cart_send_single_whatsapp($cart_id)
  {

        // $userId = $user_id;
        $user = DB::table('users')
            ->join('carts', 'users.id', '=', 'carts.user_id')
            ->select('users.company_name', 'users.phone','users.manager_id','carts.user_id')
            ->where('carts.id', $cart_id)
            ->first();
       
        
        $userId = $user->user_id;
           
        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }

        // Retrieve manager's information
        $manager = DB::table('users')
        ->select('name', 'phone')
        ->where('id', $user->manager_id)
        ->first();

        $cartItems = DB::table('carts')
        ->join('products', 'carts.product_id', '=', 'products.id')
        ->select('products.name as product_name', 'carts.quantity')
        ->where('carts.user_id', $userId)
        ->get();
       


        $itemCount = $cartItems->count();

            // $itemCount = $cartItems->count();

        // $name = $user->company_name;
        // $item1 = $cartItems->product_name ?? 'N/A';
        // $qty1 = $cartItems->quantity ?? '0';

       

        $name = $user->company_name;
                 
        $invoice=new InvoiceController();
        $randomNumber = rand(1000, 9999); // Generates a random number between 1000 and 9999

        $file_url=$invoice->invoice_file_path_abandoned_cart($userId,$randomNumber);
        $file_name="Abandoned Cart";
        $multipleItems = [
          'name' => 'utility_abandoned_cart', // Replace with your template name, e.g., 'abandoned_cart_template'
          'language' => 'en_US', // Replace with your desired language code
          'components' => [
              [
                  'type' => 'header',
                  'parameters' => [
                      ['type' => 'document', 'document' => ['link' => $file_url,'filename' => $file_name,]],
                  ],
              ],
              [
                  'type' => 'body',
                  'parameters' => [
                      ['type' => 'text', 'text' => $name],
                      ['type' => 'text', 'text' => $itemCount], // Second variable (Total Count)
                  ],
              ],
          ],
      ];

        $this->WhatsAppWebService = new WhatsAppWebService();
         $response = $this->WhatsAppWebService->sendTemplateMessage($user->phone, $multipleItems);
         $response1 = $this->WhatsAppWebService->sendTemplateMessage($manager->phone, $multipleItems);
        //$response2 = $this->WhatsAppWebService->sendTemplateMessage('+916289062983', $multipleItems);

        return redirect()->back()->with('status', 'WhatsApp messages sent successfully!');
        
  }

  public function abandoned_cart_send_whatsapp(Request $request)
  {

    // whatsapp all
    set_time_limit(3000); 
    
      $distinctUser = DB::table('users')
          ->join('carts', 'users.id', '=', 'carts.user_id')
          ->join('products', 'carts.product_id', '=', 'products.id')
          ->select('users.company_name', 'users.phone', 'carts.user_id','users.manager_id')
          //  ->where('carts.user_id', 24185)
          ->groupBy('carts.user_id', 'users.name')
          ->get();
  
      $responses = [];
  
      foreach ($distinctUser as $user) {

         // Retrieve manager's information
          $manager = DB::table('users')
          ->select('name', 'phone')
          ->where('id', $user->manager_id)
          ->first();

          $cartItems = DB::table('carts')
              ->join('products', 'carts.product_id', '=', 'products.id')
              ->select('products.name as product_name', 'carts.quantity')
              ->where('carts.user_id', $user->user_id)
              ->get();
  
             $itemCount = $cartItems->count();
  
              $name = $user->company_name;

              $invoice=new InvoiceController();
              $randomNumber = rand(1000, 9999); // Generates a random number between 1000 and 9999

              $file_url=$invoice->invoice_file_path_abandoned_cart($user->user_id,$randomNumber);
              $file_name="Abandoned Cart";

              $multipleItems = [
                'name' => 'utility_abandoned_cart', // Replace with your template name, e.g., 'abandoned_cart_template'
                'language' => 'en_US', // Replace with your desired language code
                'components' => [
                    [
                        'type' => 'header',
                        'parameters' => [
                            ['type' => 'document', 'document' => ['link' => $file_url,'filename' => $file_name,]],
                        ],
                    ],
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $name],
                            ['type' => 'text', 'text' => $itemCount], // Second variable (Total Count)
                        ],
                    ],
                ],
            ];
  
              $this->WhatsAppWebService = new WhatsAppWebService();
              $response = $this->WhatsAppWebService->sendTemplateMessage($user->phone, $multipleItems);
              $response1 = $this->WhatsAppWebService->sendTemplateMessage($manager->phone, $multipleItems);
              $response2 = $this->WhatsAppWebService->sendTemplateMessage('+919894753728', $multipleItems);
              $responses[] = $response;
         
      }
  
      return redirect()->back()->with('status', 'WhatsApp messages sent to all successfully!');
  }
  
  public function abandoned_cart_list(Request $request)
{

  
    // Retrieve the filters and sorting options from the request
    $searchDate = $request->input('searchDate');
    $searchManagers = $request->input('searchManager', []); // Accept multiple manager IDs
    // $searchPartyCodes = $request->input('searchPartyCode', []); // Accept multiple party codes
    $searchCompanyNames = $request->input('searchCompanyName', []); // Accept multiple company names
    $sortField = $request->input('sortField', 'carts.created_at'); // Default sort field
    $sortDirection = $request->input('sortDirection', 'desc'); // Default sort direction

    $currentUserId = auth()->user()->id;

    // Determine if the current user should see all data or only data related to their manager_id
    $isSuperManager = in_array($currentUserId, [180, 169, 25606, 1]);

    // Get distinct managers based on the current user role
    $distinctManagersQuery = DB::table('users')
        ->join('carts', 'users.id', '=', 'carts.user_id')
        ->select('users.manager_id')
        ->groupBy('users.manager_id');

    if (!$isSuperManager) {
        $distinctManagersQuery->where('users.manager_id', '=', $currentUserId);
    }

    $distinctManagers = $distinctManagersQuery->get();

    // Get distinct party codes for the dropdown
    $distinctPartyCodes = DB::table('users')
        ->join('carts', 'users.id', '=', 'carts.user_id')
        ->select('users.party_code')
        ->groupBy('users.party_code')
        ->get();

    // Get distinct company names for the dropdown
    $distinctCompanyNames = DB::table('users')
        ->join('carts', 'users.id', '=', 'carts.user_id')
        ->select('users.company_name')
        ->groupBy('users.company_name')
        ->get();

    // Start building the main query
    $query = DB::table('users as u1')
        ->join('carts', 'u1.id', '=', 'carts.user_id')
        ->join('products', 'carts.product_id', '=', 'products.id')
        ->join('users as u2', 'u1.manager_id', '=', 'u2.id') // Join to get the manager's name
        ->select(
            'u1.company_name',
            'u1.phone',
            'u1.manager_id',
            'u1.party_code',
            'u2.name as manager_name', // Select manager's name
            'products.name as product_name',
            'carts.created_at',
            'carts.quantity',
            'carts.price',
            'carts.user_id',
            'carts.product_id',
            'carts.id as cart_id',
            DB::raw('carts.quantity * carts.price as total') // Calculate total per item
        );

    // Apply manager filter
    if ($isSuperManager) {
        if (!empty($searchManagers)) {
            $query->whereIn('u1.manager_id', $searchManagers);
        }
    } else {
        $query->where('u1.manager_id', '=', $currentUserId);
    }

    // Apply party code filter
    // if (!empty($searchPartyCodes)) {
    //     $query->whereIn('u1.party_code', $searchPartyCodes);
    // }

    // Apply company name filter
    if (!empty($searchCompanyNames)) {
        $query->whereIn('u1.company_name', $searchCompanyNames);
    }

    // Apply the date filter if it exists
    if ($searchDate) {
        $query->whereDate('carts.created_at', '=', $searchDate);
    }

    // Get the total sum of all items
    $totalSum = $query->sum(DB::raw('carts.quantity * carts.price'));

    // Apply sorting
    $abandonedCart = $query->orderBy($sortField, $sortDirection)
        ->paginate(50)
        ->appends($request->all());


        
        

    return view('backend.abandoned_cart.abandoned_cart_list', compact('abandonedCart', 'distinctManagers', 'distinctPartyCodes', 'distinctCompanyNames', 'totalSum'));
}

public function clearCart(Request $request)
{
    $userIds = $request->input('user_ids');

    if (empty($userIds)) {
        return response()->json(['success' => false, 'message' => 'No carts selected.']);
    }

    // Use query builder to delete all cart items for the selected user_ids
    DB::table('carts')->whereIn('user_id', $userIds)->delete();

    return response()->json(['success' => true, 'message' => 'All items for the selected users have been cleared successfully.']);
}


public function deleteCartItem(Request $request)
{
    // Get the user ID
    $userId = $request->input('user_id');

    // Validate that the user ID is provided
    if (!$userId) {
        return response()->json(['success' => false, 'message' => 'User ID is required']);
    }

    // Find the cart items for the user
    $cartItems = Cart::where('user_id', $userId);

    // Check if the cart exists for the user
    if ($cartItems->count() > 0) {
        // Delete all the items in the cart for that user
        $cartItems->delete();

        // Return success response
        return response()->json(['success' => true, 'message' => 'Cart has been cleared for the user.']);
    }

    // If no items are found
    return response()->json(['success' => false, 'message' => 'No cart items found for the specified user.']);
}






public function abandonedCartExportList(Request $request){
  $searchDate = $request->input('searchDate');
  $searchManagers = $request->input('searchManager', []);
  $searchCompanyNames = $request->input('searchCompanyName', []);

  $currentUserId = auth()->user()->id;
  $isSuperManager = in_array($currentUserId, [180, 169, 25606, 1]);

  $query = DB::table('users as u1')
      ->join('carts', 'u1.id', '=', 'carts.user_id')
      ->join('products', 'carts.product_id', '=', 'products.id')
      ->join('users as u2', 'u1.manager_id', '=', 'u2.id')
      ->select(
          'u1.company_name',
          'u1.phone',
          'u1.manager_id',
          'u1.party_code',
          'u2.name as manager_name',
          'products.name as product_name',
          'carts.created_at',
          'carts.quantity',
          'carts.price',
          DB::raw('carts.quantity * carts.price as total')
      );

  // Apply filters based on the request
  if ($isSuperManager) {
      if (!empty($searchManagers)) {
          $query->whereIn('u1.manager_id', $searchManagers);
      }
  } else {
      $query->where('u1.manager_id', '=', $currentUserId);
  }

  if (!empty($searchCompanyNames)) {
      $query->whereIn('u1.company_name', $searchCompanyNames);
  }

  if ($searchDate) {
      $query->whereDate('carts.created_at', '=', $searchDate);
  }

  $abandonedCartData = $query->get();

  // Export the data to Excel
  return Excel::download(new AbandonedCartExport($abandonedCartData), 'abandoned_carts.xlsx');
}
    


  



  public function abandoned_cart_save_remark(Request $request){
    // return response()->json(['success' => true, 'message' => 'Remark saved successfully!']);
    // Validate the incoming request data
        $request->validate([
          'remark' => 'required'
          
      ]);

      // Insert the data into the remarks table
      DB::table('remarks')->insert([
          'remark_description' => $request->input('remark'),
          'created_at' => now(),
          'updated_at' => now(),
          'user_id' => $request->input('user_id'),
          'cart_id' => $request->input('cart_id'),
      ]);

      // Return a JSON response indicating success
      return response()->json([
          'success' => true,
          'message' => 'Remark saved successfully!',
      ]);
  }

  public function viewRemark($cart_id)
    {
        // Fetch the remark based on the cart_id
      
        $remarks = DB::table('remarks')
        ->join('users', 'remarks.user_id', '=', 'users.id')
        ->join('carts', 'remarks.cart_id', '=', 'carts.id')
        ->join('products', 'carts.product_id', '=', 'products.id')
        ->select(
            'remarks.remark_description',
            'remarks.created_at',
            'users.name as user_name',
            'carts.quantity',
            'carts.price',
            'products.name as product_name'
        )
        ->where('remarks.cart_id', $cart_id)
        ->get();

        // Pass the remark data to the view
        return view('backend.abandoned_cart.view_remark', compact('remarks'));
    }

    public function getRemarks(Request $request)
    {
        $cart_id = $request->input('cart_id');
    
        $remarks = DB::table('remarks')
            ->join('users', 'remarks.user_id', '=', 'users.id')
            ->select('remarks.remark_description', 'remarks.created_at', 'users.name as user_name')
            ->where('remarks.cart_id', $cart_id)
            ->orderBy('remarks.created_at', 'desc')
            ->get();
    
        if ($remarks->isNotEmpty()) {
            return response()->json([
                'success' => true,
                'remarks' => $remarks
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No remarks found for the selected cart.'
            ]);
        }
    }


    public function send_quotations(Request $request) {
      $user_id = Auth::user()->id;

      // Retrieve manager's information
      $manager = DB::table('users')
      ->select('name', 'phone')
      ->where('id', Auth::user()->manager_id)
      ->first();

      // Retrieve all cart items related to the user, including the warehouse name
      $cartItems = DB::table('users')
          ->leftJoin('carts', 'users.id', '=', 'carts.user_id')
          ->leftJoin('products', 'carts.product_id', '=', 'products.id')
          ->leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id') // Join with warehouses table via users table
          ->leftJoin('addresses', 'carts.address_id', '=', 'addresses.id')
          ->select(
              'users.company_name',
              'users.phone',
              'users.manager_id',
              'users.party_code',
              'products.name as product_name',
              'warehouses.name as warehouse_name', // Get the warehouse name with alias
              'carts.created_at',
              'carts.quantity',
              'carts.address_id',
              'carts.price',
              'carts.user_id',
              'carts.product_id',
              'carts.id as cart_id',
              DB::raw('carts.quantity * carts.price as total') // Calculate total per item
          )
          ->where('carts.user_id', $user_id)  // Add the where condition
          ->get();
  
      // Get the warehouse name of the user
      $warehouse_name = strtoupper(substr($cartItems->first()->warehouse_name, 0, 3)); // Extract the first 3 letters and convert to uppercase
  
      // Generate the new quotation_id
      $maxQuotationId = DB::table('quotations')
          ->where('quotation_id', 'LIKE', $warehouse_name . '-%')
          ->orderBy('quotation_id', 'desc')
          ->value('quotation_id');
  
      if ($maxQuotationId) {
          $lastNumber = (int)substr($maxQuotationId, strlen($warehouse_name) + 1);
          $newNumber = $lastNumber + 1;
      } else {
          $newNumber = 1;
      }
  
      $newQuotationId = $warehouse_name . '-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
      
      foreach ($cartItems as $item) {
          DB::table('quotations')->insert([
              'cart_id' => $item->cart_id,
              'user_id' => $user_id,
              'quotation_id' => $newQuotationId, // Use the new quotation ID
              'status' => '0', // Set the initial status
              'created_at' => now(),
              'updated_at' => now(),
          ]);
      }
      
      $invoice=new InvoiceController();
      $file_url=$invoice->invoice_file_path_cart_quotations($user_id,$newQuotationId);
     
      $file_name="Quotations";
     // $to=['+916289062983'];
      $to=[Auth::user()->phone,$manager->phone,'+919894753728'];

      $templateData = [
        'name' => 'utility_quotation',
        'language' => 'en', 
        'components' => [
            [
                'type' => 'header',
                'parameters' => [
                    [
                        'type' => 'document', // Use 'image', 'video', etc. as needed
                        'document' => [
                            'link' => $file_url,
                            'filename' => $file_name,
                        ]
                    ]
                ]
            ],
            [
                'type' => 'body',
                'parameters' => [
                    ['type' => 'text', 'text' => $newQuotationId],
                ],
            ],
        ],
    ];
    

      $this->WhatsAppWebService=new WhatsAppWebService();
      foreach($to as $person_to_send){
        $response = $this->WhatsAppWebService->sendTemplateMessage($person_to_send, $templateData);
      }

      return response()->json(['status' => 'Quotation Sent to whatsapp!']);
  }
  
  

  // ABANDONED CART CODE END


      //purchase order code start
      //negative stock inventory
      public function purchase_order(Request $request) {
       
        // Retrieve the list of sellers for the dropdown
        $sellers = DB::table('users')
            ->join('sellers', 'users.id', '=', 'sellers.user_id')
            ->select('users.id', 'users.name')
            ->orderBy('users.name', 'asc')
            ->get();
    
       // Start query for purchase orders
        $query = DB::table('purchase_order')
        ->leftJoin('products', 'purchase_order.part_no', '=', 'products.part_no')
        ->leftJoin('sellers', 'products.seller_id', '=', 'sellers.id')
        ->leftJoin('users', 'sellers.user_id', '=', 'users.id')
        ->leftJoin('shops', 'sellers.id', '=', 'shops.seller_id') // Join sellers with shops
        ->select(
            'purchase_order.*',
            'products.seller_id',
            'sellers.user_id',
            'users.name as seller_name',
            'shops.name as seller_company_name' // Retrieve name as seller_company_name
        )
        // Add the condition to exclude records where delete_status is 1
        ->where('purchase_order.delete_status', '!=', 1);
    
        // Apply seller name filter if provided
        if ($request->filled('sellerName')) {
            $query->where('users.id', '=', $request->sellerName);
        }
    
        // Apply sorting if provided
        if ($request->filled('sort') && $request->filled('direction')) {
            $query->orderBy($request->sort, $request->direction);
        } else {
            $query->orderBy('purchase_order.id', 'asc'); // Default sorting
        }
    
        // Get paginated results
        $purchaseOrders = $query->paginate(100)->appends($request->all());
        // echo "<pre>";
        // print_r($purchaseOrders);
        // die();
    
        return view('backend.purchase_order.purchase_order', compact('purchaseOrders', 'sellers'));
    }

    public function purchaseOrderDeleteItems($id, Request $request)
    {
        // Validate the ID exists
        $order = DB::table('purchase_order')->where('id', $id)->first();
       
        
        if (!$order) {
            return redirect()->back()->with('status', 'Purchase order not found!');
        }

        // Get the order_id from the $order object
        $orderId = $order->order_no; // Assuming 'order_id' is the correct field name

        // Delete the purchase order
        // DB::table('purchase_order')->where('id', $id)->delete();
         // Update the delete_status to 1 instead of deleting the purchase order
        DB::table('purchase_order')
        ->where('id', $id)
        ->update(['delete_status' => 1]);

        // Redirect back with a success message, including the order_id
        return redirect()->back()->with('status', "Purchase order with Order ID $orderId deleted successfully!")->withInput($request->all());
    }

    


    public function showSelected(Request $request)
    {
      
        // Get the selected orders' IDs
        $selectedOrders = $request->input('selectedOrders', []);
        
        // Fetch the selected orders from the database, grouping by part_no and combining order_no and quantities
        $orders = DB::table('purchase_order')
            ->whereIn('purchase_order.id', $selectedOrders)
            ->leftJoin('products', 'purchase_order.part_no', '=', 'products.part_no')
            ->leftJoin('sellers', 'products.seller_id', '=', 'sellers.id')
            ->leftJoin('shops', 'sellers.id', '=', 'shops.seller_id')
            ->select(
                'purchase_order.part_no',
                'purchase_order.item',
                DB::raw('GROUP_CONCAT(DISTINCT purchase_order.order_no ORDER BY purchase_order.order_no ASC SEPARATOR ", ") as order_no'),
                DB::raw('GROUP_CONCAT(DISTINCT purchase_order.age ORDER BY purchase_order.age ASC SEPARATOR ", ") as age'),
                DB::raw('GROUP_CONCAT(DISTINCT DATE_FORMAT(purchase_order.order_date, "%d/%m/%y") ORDER BY purchase_order.order_date ASC SEPARATOR ", ") as order_date'),
                DB::raw('SUM(purchase_order.to_be_ordered) as total_quantity'),
                'products.seller_id',
                'products.purchase_price',
                'shops.name as seller_company_name',
                'shops.address as seller_address',
                'sellers.gstin as seller_gstin',
                'shops.phone as seller_phone'
            )
            ->groupBy('purchase_order.part_no', 'purchase_order.item', 'products.seller_id', 'products.purchase_price', 'shops.name', 'shops.address', 'sellers.gstin', 'shops.phone')
            ->get();

        // Check if $orders is empty
        // Ensure $orders is not null
        if ($orders->isEmpty()) {
          $orders = collect(); // This will make $orders an empty collection
      }
      
      return view('backend.purchase_order.selected_orders', compact('orders'));
    }

   // Function to get the message status by ID
    public function getMessageStatusById($messageId)
    {
        // Set up the database connection dynamically within the function
        config([
            'database.connections.dynamic_mazingbusiness' => [
                'driver' => 'mysql',
                'host' => 'localhost',  // Replace with your cloud database host
                'port' => '3306',  // Replace with your cloud database port
                'database' => 'mazingbusiness',  // The database name is 'mazingbusiness'
                'username' => 'mazingbusiness',   // Replace with your database username
                'password' => 'Gd6de243%',   // Replace with your database password
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'prefix' => '',
                'strict' => true,
                'engine' => null,
            ]
        ]);

        // Fetch the message data from the cloud_response database
        $cloudResponseData = DB::connection('dynamic_mazingbusiness')
            ->table('cloud_response')
            ->where('msg_id', $messageId)
            ->first();

        return $cloudResponseData->status;
    }

    

    public function saveSelected(Request $request)
    {
        // Validate the input data
        $validatedData = $request->validate([
            'orders.*.quantity' => 'required|integer|min:0',
            'orders.*.purchase_price' => 'required|numeric|min:0',
            'orders.*.order_no' => 'required|string',
            'seller_info.seller_name' => 'required|string|max:255',
            'seller_info.seller_phone' => 'required|string|max:15',
        ], [
            'orders.*.quantity.required' => 'Quantity is required for each item.',
            'orders.*.quantity.integer' => 'Quantity must be a valid number.',
            'orders.*.purchase_price.required' => 'Purchase price is required for each item.',
            'orders.*.purchase_price.numeric' => 'Purchase price must be a valid number.',
            'orders.*.order_no.required' => 'Order number is required.',
            'seller_info.seller_name.required' => 'Seller name is required.',
            'seller_info.seller_phone.required' => 'Seller phone is required.',
        ]);

        $sellerId = null;
        $productInfo = [];
        $orderNumbers = [];
        $productInfoWithOutZeroQty = [];

        foreach ($request->input('orders') as $orderId => $orderData) {
            $partNo = $orderData['part_no'];
            $quantity = $orderData['quantity'];
            $purchasePrice = $orderData['purchase_price'];
            $currentSellerId = $orderData['seller_id'];
            $orderNo = $orderData['order_no'];
            $orderDate =  $orderData['order_date'];
            $age =  $orderData['age'];

            if (!$sellerId) {
                $sellerId = $currentSellerId;
            }

            DB::table('products')
                ->where('part_no', $partNo)
                ->update(['purchase_price' => $purchasePrice]);

            $orderNoWithDate = $orderNo . " ($orderDate)";

            $productInfo[] = [
                'part_no' => $partNo,
                'qty' => $quantity,
                'order_no' => $orderNoWithDate,
                'age' => $age
            ];

            if ($quantity != 0) {
                $productInfoWithOutZeroQty[] = [
                    'part_no' => $partNo,
                    'qty' => $quantity,
                    'order_no' => $orderNoWithDate,
                    'age' => $age,
                ];

                DB::table('purchase_order')
                ->where('part_no', $partNo)
                ->where('order_no', $orderNo)
                ->update(['delete_status' => 1]);
            }

            $orderNumbers[] = $orderNoWithDate;
        }

        $lastOrder = DB::table('final_purchase_order')
            ->orderBy('id', 'desc')
            ->first();

        if ($lastOrder) {
            $lastOrderNumber = intval(substr($lastOrder->purchase_order_no, 3));
            $newOrderNumber = $lastOrderNumber + 1;
        } else {
            $newOrderNumber = 1;
        }

        $purchaseOrderNo = 'po-' . str_pad($newOrderNumber, 3, '0', STR_PAD_LEFT);

        $orderNumbersString = implode(',', array_unique($orderNumbers));

        $sellerInfo = [
            'seller_name' => $request->input('seller_info.seller_name'),
            'seller_address' => $request->input('seller_info.seller_address'),
            'seller_gstin' => $request->input('seller_info.seller_gstin'),
            'seller_phone' => $request->input('seller_info.seller_phone'),
        ];

        $data = [
            'purchase_order_no' => $purchaseOrderNo,
            'order_no' => $orderNumbersString,
            'date' => now()->format('Y-m-d'),
            'seller_id' => $sellerId,
            'product_info' => json_encode($productInfoWithOutZeroQty),
            'product_invoice' => json_encode($productInfoWithOutZeroQty),
            'seller_info' => json_encode($sellerInfo),
            'created_at' => now(),
            'updated_at' => now(),
        ];

        DB::table('final_purchase_order')->insert($data);

        $seller_warehouse = DB::table('final_purchase_order as fpo')
        ->join('sellers as s', 'fpo.seller_id', '=', 's.id')
        ->join('users as u', 's.user_id', '=', 'u.id')
        ->where('fpo.purchase_order_no', $purchaseOrderNo)
        ->value('u.warehouse_id');

        $invoiceController = new InvoiceController();
        $fileUrls = [
            $invoiceController->purchase_order_pdf_invoice($purchaseOrderNo),
            $invoiceController->packing_list_pdf_invoice($purchaseOrderNo)
        ];

        $fileNames = ["Purchase Order", "Packing List"];

        $sellerPhone = DB::table('final_purchase_order')
            ->where('purchase_order_no', $purchaseOrderNo)
            ->value(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(seller_info, '$.seller_phone'))"));

        // List of phone numbers to send the message to
        $toNumbers = [
            // $sellerPhone,  // Original seller phone number from the database
            '+919930791952' , // Additional phone number 1
            // '9730377752'   // Additional phone number 2
            '+919894753728'
            
        ];

        // Manager phone numbers based on seller_warehouse condition
        if ($seller_warehouse == 2) {
            $toNumbers[] = '+919999241558';  // Manager 1 (m1) //delhi
        } elseif ($seller_warehouse == 6) {
            $toNumbers[] = '+919860433981';  // Manager 2 (m2) mumbai
        }

        // Loop through each phone number and send the WhatsApp message with retry logic
        foreach ($toNumbers as $to) {
            foreach ($fileUrls as $index => $fileUrl) {
                $templateData = [
                    'name' => 'utility_purchase_order',
                    'language' => 'en_US',
                    'components' => [
                        [
                            'type' => 'header',
                            'parameters' => [
                                [
                                    'type' => 'document',
                                    'document' => [
                                        'link' => $fileUrl,
                                        'filename' => $fileNames[$index],
                                    ],
                                ],
                            ],
                        ],
                        [
                            'type' => 'body',
                            'parameters' => [
                                ['type' => 'text', 'text' =>$purchaseOrderNo],
                            ],
                        ],
                    ],
                ];

                // Retry mechanism
                $retryCount = 0;
                $maxRetries = 1;
                $messageSent = false;

                while ($retryCount < $maxRetries && !$messageSent) {
                    try {
                        $this->WhatsAppWebService = new WhatsAppWebService();
                        $response1 = $this->WhatsAppWebService->sendTemplateMessage($to, $templateData);

                        if (isset($response1['messages'][0]['id'])) {
                            $messageId = $response1['messages'][0]['id'];

                            sleep(2); // Delay for 1 second before checking the status
                            // Call the function to get the message status
                            $messageStatus = $this->getMessageStatusById($messageId);

                            if ($messageStatus === 'sent') {
                                $messageSent = true;  // Mark as sent
                                break;  // Break out of the retry loop
                            } else {
                                throw new Exception("Message sending failed");
                            }
                        } else {
                            throw new Exception("Message ID not found in the response");
                        }
                    } catch (Exception $e) {
                        $retryCount++;
                        if ($retryCount >= $maxRetries) {
                            // Log or handle failure after 3 retries
                            Log::error("Failed to send message to $to after $maxRetries attempts. Error: " . $e->getMessage());
                            // Optionally, you can notify admin via email or other methods
                        } else {
                            // You may introduce a short delay before retrying (optional)
                            sleep(2); // Delay for 2 seconds before retrying
                        }
                    }
                }
            }
        }

        return redirect()->route('admin.purchase_order')->with('status', 'Purchase order saved successfully!');
    }

    
    public function showFinalizedOrders()
    {
        // Fetch orders where the purchase order is not yet converted and is_closed is 0
        $orders = DB::table('final_purchase_order')
            ->join('sellers', 'final_purchase_order.seller_id', '=', 'sellers.id')
            ->join('users', 'sellers.user_id', '=', 'users.id')
            ->select(
                'final_purchase_order.*',
                'users.name as seller_name',
                'final_purchase_order.force_closed'
            )
            ->where('is_closed', '=', 0) // Check if is_closed is 0
            ->get();

        // Iterate through each order to filter products and decode seller_info
        foreach ($orders as $order) {
            // Decode the product_info JSON
            $productInfo = json_decode($order->product_info, true);

            // Decode the seller_info JSON
            $sellerInfo = json_decode($order->seller_info, true);

            // Check the convert_to_purchase_status and filter accordingly
            if ($order->convert_to_purchase_status == 1) {
                // Filter only products with quantity zero for converted orders
                $filteredProducts = array_filter($productInfo, function ($product) {
                    return $product['qty'] == 0;
                });
            } else {
                // For orders not yet converted, show all products
                $filteredProducts = $productInfo;
            }

            // Fetch product names and attach them to the products
            foreach ($filteredProducts as &$product) {
                $productName = DB::table('products')
                    ->where('part_no', $product['part_no'])
                    ->value('name');
                $product['product_name'] = $productName;
            }

            // Assign the filtered product info back to the order
            $order->product_info = $filteredProducts;

            // Add the seller info to the order object for easy access in the view
            $order->seller_name = $sellerInfo['seller_name'];
            $order->seller_address = $sellerInfo['seller_address'];
            $order->seller_gstin = $sellerInfo['seller_gstin'];
            $order->seller_phone = $sellerInfo['seller_phone'];


        }

      

        // Return the view with the orders
        return view('backend.purchase_order.finalized_purchase_order_listing', compact('orders'));
    }

    public function forceClose($id)
{
    // Fetch the purchase order by ID
    $purchaseOrder = DB::table('final_purchase_order')->where('id', $id)->first();

    if (!$purchaseOrder) {
        // Redirect with an error message if the purchase order doesn't exist
        return redirect()->back()->with('status', 'Purchase order not found.');
    }

    // Decode the product_info field
    $productInfo = json_decode($purchaseOrder->product_info);

    foreach ($productInfo as $product) {
        $partNo = $product->part_no; // Use object notation
        $orderNosWithDates = explode(',', $product->order_no); // Split in case of multiple order numbers
        $qty = $product->qty; // Quantity for the entire entry

        foreach ($orderNosWithDates as $orderNoWithDate) {
            // Extract the order number without the date part
            if (preg_match('/(SO\/[^ ]+)/', trim($orderNoWithDate), $matches)) {
                $orderNo = trim($matches[1]);

                // Update the purchase_order table where part_no and order_no match
                DB::table('purchase_order')
                    ->where('part_no', $partNo)
                    ->where('order_no', $orderNo)
                    ->update(['delete_status' => 1]);
            }
        }
    }

    // Mark the purchase order as closed by updating the 'force_closed' field
    DB::table('final_purchase_order')
        ->where('id', $id)
        ->update([
            'force_closed' => 1,
            'updated_at' => now(), // Update the updated_at timestamp
        ]);

    // Redirect with a success message after closing the order
    return redirect()->back()->with('status', 'Purchase order has been force closed successfully.');
}






    public function showProductInfo($id)
    {
        // Fetch the purchase order by ID
        $order = DB::table('final_purchase_order')
            ->where('id', $id)
            ->first();

        // Decode the product info JSON
        $productInfo = json_decode($order->product_info, true);

        // Decode the seller info JSON
        $sellerInfo = json_decode($order->seller_info, true);

        $purchaseNo = "";
        $finalPurchase = null; // Initialize $finalPurchase to null

        // Check the convert_to_purchase_status
        if ($order->convert_to_purchase_status == 1) {
            // If status is 1, filter only products with quantity zero
            $finalPurchase = DB::table('final_purchase')
                ->where('purchase_order_no', $order->purchase_order_no)
                ->first();

            if ($finalPurchase) {
                $purchaseNo = $finalPurchase->purchase_no;
            }

            $productInfo = array_filter($productInfo, function ($product) {
                return $product['qty'] == 0;
            });
        }

        // Fetch the product details for each part number
        foreach ($productInfo as &$product) {
            $productDetails = DB::table('products')
                ->where('part_no', $product['part_no'])
                ->select('name', 'purchase_price', 'hsncode')
                ->first();

            $product['product_name'] = $productDetails->name ?? 'Unknown';
            $product['purchase_price'] = $productDetails->purchase_price ?? 'N/A';
            $product['hsncode'] = $productDetails->hsncode ?? 'N/A';
        }
        

        // Pass the seller information and product information to the view
        return view('backend.purchase_order.product_info', compact('order', 'productInfo', 'sellerInfo', 'purchaseNo', 'finalPurchase'));
    }

    
    public function viewProducts($purchaseOrderNo)
    {
        // Retrieve the purchase order based on the purchase_order_no
        $order = DB::table('final_purchase')
            ->where('purchase_no', $purchaseOrderNo)
            ->first();
            // echo "<pre>";
            // print_r($order);
            // die();
    
        // Decode the product info JSON
        $productInfo = json_decode($order->product_info, true);
    
        // Filter the product info to include only those products with qty != 0
        $filteredProductInfo = array_filter($productInfo, function($product) {
            return $product['qty'] != 0;
        });
    
        // Fetch additional product details if needed
        foreach ($filteredProductInfo as &$product) {
            $productDetails = DB::table('products')
                ->where('part_no', $product['part_no'])
                ->select('name', 'purchase_price', 'hsncode') // Adjust fields as needed
                ->first();
    
            $product['product_name'] = $productDetails->name ?? 'Unknown';
            $product['purchase_price'] = $productDetails->purchase_price ?? 'N/A';
            $product['hsncode'] = $productDetails->hsncode ?? 'N/A';
        }
    
        return view('backend.purchase_order.final_product_info', compact('order', 'filteredProductInfo'));
    }
    

    

   public function convertToPurchase(Request $request, $id)
   {
      

      $validatedData = $request->validate([
        'seller_invoice_no' => 'required|string|max:255',
        'seller_invoice_date' => 'required|date',
        'products.*.hsncode' => 'required|string|max:255',
        'products.*.qty' => 'required|integer|min:0',
        'products.*.purchase_price' => 'required|numeric|min:0',
    ], [
        'seller_invoice_no.required' => "Seller Invoice Number is required.",
        'seller_invoice_date.required' => "Seller Invoice Date is required.",
        'products.*.hsncode.required' => "HSN Code is required for each product.",
        'products.*.qty.required' => "Quantity is required for each product.",
        'products.*.qty.integer' => "Quantity must be an integer.",
        'products.*.purchase_price.required' => "Purchase Price is required for each product.",
        'products.*.purchase_price.numeric' => "Purchase Price must be a valid number.",
    ]);
    


      
      // Get the product_info from the final_purchase_order table
      $order = DB::table('final_purchase_order')->where('id', $id)->first();
      $productInfo = json_decode($order->product_info, true);

      $isClosed = 1; // Assume the purchase order will be closed unless a product has zero qty

      

      // Initialize an array to collect updated product information
      $updatedProductInfo = [];

      // Iterate over the products from the request to update the product table and collect updated information
      foreach ($request->input('products') as $productData) {
          $partNo = $productData['part_no'];
          $qty = $productData['qty'];
          if($qty == 0){
            $isClosed=0;
          }
          $hsncode = $productData['hsncode'];
          $purchasePrice = $productData['purchase_price'];
          $orderNo = $productData['order_no']; // Get the order number
          $age = $productData['age']; // Get the age

          $sellerId = $request->input('seller_id');
          $purchaseOrderNo = $request->input('purchase_order_no');

          // Update the product table with the new HSN code and purchase price
          DB::table('products')
              ->where('part_no', $partNo)
              ->update([
                  'hsncode' => $hsncode,
                  'purchase_price' => $purchasePrice,
              ]);

          // Update the existing product info in the array
          foreach ($productInfo as &$existingProduct) {
              if ($existingProduct['part_no'] === $partNo) {
                  $existingProduct['qty'] = $qty;
                  $existingProduct['hsncode'] = $hsncode;
                  $existingProduct['order_no'] = $orderNo;
                  $existingProduct['age'] = $age;
                  break;
              }
          }

          // Collect updated product information
          $updatedProductInfo[] = [
              'part_no' => $partNo,
              'qty' => $qty,
              'order_no' => $orderNo, // Include the order number in the product info
              'age' => $age // Include the age in the product info
          ];

          // Push only the part_no to Salezing API if the quantity is not zero
        // if ($qty != 0) {
            //   $result = [
            //       'part_no' => $partNo
            //   ];
            $result=array();
            $result['part_no']= $partNo;

            $salzingResponse = Http::withHeaders([
                'Content-Type' => 'application/json',
            ])->post('https://mazingbusiness.com/api/v2/item-push', $result);

            \Log::info('Salezing Item Push Status: ' . json_encode($salzingResponse->json(), JSON_PRETTY_PRINT));
        //   }
       
      }
     

      
      // Check if purchase_no is provided; if not, generate a new one
  
      $lastPurchase = DB::table('final_purchase')
      ->orderBy('id', 'desc')
      ->first();

      if ($lastPurchase) {
          // Extract the number from the last purchase_no
          $lastPurchaseNumber = intval(substr($lastPurchase->purchase_no, 3));
          $newPurchaseNumber = $lastPurchaseNumber + 1;
      } else {
          // Start from 1 if no purchase records exist
          $newPurchaseNumber = 1;
      }
      // Format the new purchase_no with leading zeros (e.g., pn-001)
      $purchaseNo = 'pn-' . str_pad($newPurchaseNumber, 3, '0', STR_PAD_LEFT);
    
      
      // $sellerInfo = json_decode($order->seller_info, true);
      // Prepare the seller_info array
      $sellerInfo = [
        'seller_name' => $request->input('seller_info.seller_name'),
        'seller_address' => $request->input('seller_info.seller_address'),
        'seller_gstin' => $request->input('seller_info.seller_gstin'),
        'seller_phone' => $request->input('seller_info.seller_phone'),
    ];

    

      // Prepare data to be inserted into the final_purchase table
      $data = [
          'purchase_no' => $purchaseNo,
          'purchase_order_no' => $purchaseOrderNo,
          'seller_id' => $sellerId,
          'seller_invoice_no' => $request->input('seller_invoice_no'),  // Use the provided seller invoice number
          'seller_invoice_date' => $request->input('seller_invoice_date'), // Use the provided seller invoice date
          'seller_info' => json_encode($sellerInfo), // Insert seller info
          'product_info' => json_encode($updatedProductInfo), // Insert updated product info
          'created_at' => now(),
          'updated_at' => now(),
      ];

      // Use updateOrInsert to update the final_purchase table
      DB::table('final_purchase')->insert(
        
          $data // Data to update or insert
      );

      // Update the final_purchase_order table with the updated product information and convert_to_purchase_status
      DB::table('final_purchase_order')
          ->where('id', $id)
          ->update([
              'convert_to_purchase_status' => 1, // Mark as closed only if no qty is zero
              'seller_info' => json_encode($sellerInfo),
              'product_info' => json_encode($productInfo), // Update product info in final_purchase_order table as well
              'is_closed' => $isClosed, // Update the is_closed column based on the status
          ]);
      
      // Iterate through productInfo to delete items from purchase_order table
    //   foreach ($productInfo as &$product) {
    //       $partNo = $product['part_no'];
    //       $orderNosWithDates = explode(',', $product['order_no']); // Split in case of multiple order numbers
    //       $qty = $product['qty']; // Quantity for the entire entry

    //       // If any product has qty 0, do not close the purchase order
    //       if ($qty == 0) {
    //           $isClosed = 0;
    //           continue; // Skip deletion for this product
    //       }

    //       foreach ($orderNosWithDates as $orderNoWithDate) {
    //           // Extract the order number without the date part
    //           if (preg_match('/(SO\/[^ ]+)/', trim($orderNoWithDate), $matches)) {
    //               $orderNo = trim($matches[1]);

    //               // Perform the deletion for the specific order_no and part_no
    //               DB::table('purchase_order')
    //                   ->where('order_no', $orderNo)
    //                   ->where('part_no', $partNo)
    //                   ->delete();

               
    //           }
    //       }
    //   }

      // Return success message
      return redirect()->route('finalized.purchase.orders')->with('status', 'Purchase order converted successfully!');
  }



    public function showFinalizedPurchaseOrders()
    {
      
      $purchases = DB::table('final_purchase')
      ->join('final_purchase_order', 'final_purchase.purchase_order_no', '=', 'final_purchase_order.purchase_order_no')
      ->join('sellers', 'final_purchase.seller_id', '=', 'sellers.id')
      ->join('users', 'sellers.user_id', '=', 'users.id') // Join with users table
      ->select('final_purchase.*', 'final_purchase_order.product_info', 'users.name as seller_name') // Get seller name from users table
      ->get();

            // echo "<pre>";
            // print_r($purchases);
            // die();

        return view('backend.purchase_order.final_purchase_list', compact('purchases'));
    }


    public function showImportForm()
    {
        return view('backend.purchase_order.purchase_order_excel_import');
    }

    public function importExcel(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'excel_file' => 'required|file|mimes:xls,xlsx'
        ], ['excel_file' => "File is required"]);

        // Get the real path of the uploaded file
        $filePath = $request->file('excel_file');

        $tableName = 'purchase_order';

        try {
            // Attempt to import the file
            Excel::import(new ExternalPurchaseOrder($tableName), $filePath);

            // If no exception occurs, consider it a success
            return redirect()->back()->with('success', 'Data imported successfully!');
        } catch (Exception $e) {
            // If an exception occurs, handle it and return an error message
            return redirect()->back()->with('error', 'Data import failed: ' . $e->getMessage());
        }
    }

    public function export($purchase_no)
    {
      $data = DB::table('final_purchase')
     
      ->join('final_purchase_order', 'final_purchase.purchase_order_no', '=', 'final_purchase_order.purchase_order_no')
      ->where('final_purchase.purchase_no', $purchase_no)
      ->select(
          'final_purchase.purchase_no',
          'final_purchase.purchase_order_no',
          'final_purchase.seller_info',  // Fetch seller_info JSON field
          'final_purchase.seller_invoice_no',
          'final_purchase.seller_invoice_date',
          'final_purchase.product_info'
      )
      ->orderBy('final_purchase.created_at', 'desc')
      ->get();

      // Process the data to filter out products with qty == 0
      $filteredData = $data->map(function ($item) {
          $productInfo = json_decode($item->product_info, true);

          // Filter out products where qty is 0
          $filteredProductInfo = array_filter($productInfo, function ($product) {
              return $product['qty'] != 0;
          });

          // Encode the filtered product info back to JSON
          $item->product_info = json_encode(array_values($filteredProductInfo));

          return $item;
      });

      
        return Excel::download(new FinalPurchaseExport($purchase_no), 'final_purchases.xlsx');
    }
	
	

  //purchase order code end
	
	// sales (nav menu) backend dashboard whatsaap send
	public function sendWhatsAppMessage($order_id)
	{
		
		// Fetching the order directly from the orders table
		$first_order = DB::table('orders')
			->where('id', $order_id)
			->first();

		// Fetching the user who placed the order
		$user = DB::table('users')
				->where('id', $first_order->user_id)
				->first();

		// Fetching the manager's phone number
		$manager_phone_number = DB::table('users')
			->where('id', $user->manager_id)
			->pluck('phone')
			->first();

		// Setting the recipients for the WhatsApp message
		$to = [
			json_decode($first_order->shipping_address)->phone,
			'+919709555576', // Replace with an actual number if needed
			$manager_phone_number
     
		];

		// Fetching the client's address information
		$client_address = DB::table('addresses')
			->where('id', $first_order->address_id)
			->first();

		// Order details for the WhatsApp message
		$company_name = $client_address->company_name;
		$order_code = $first_order->code;
		$date = date('d-m-Y H:i A', $first_order->date);
		$total_amount = $first_order->grand_total;

		// Generating the invoice file path
		$invoiceController = new InvoiceController();
		$file_url = $invoiceController->invoice_file_path($first_order->id);

		// Setting the file name for the invoice
		$file_name = "Order-" . $order_code;

		// Preparing the template data for WhatsApp message
		$templateData = [
			'name' => 'utility_order_template',
			'language' => 'en_US', 
			'components' => [
				[
					'type' => 'header',
					'parameters' => [
						[
							'type' => 'document', 
							'document' => [
								'link' => $file_url,
								'filename' => $file_name,
							]
						]
					]
				],
				[
					'type' => 'body',
					'parameters' => [
						['type' => 'text', 'text' => $company_name],
						['type' => 'text', 'text' => $order_code],
						['type' => 'text', 'text' => $date],
						['type' => 'text', 'text' => $total_amount]
					],
				],
			],
		];

		// Sending the WhatsApp message to each recipient
		$this->WhatsAppWebService = new WhatsAppWebService();
		foreach ($to as $person_to_send) {
			$response = $this->WhatsAppWebService->sendTemplateMessage($person_to_send, $templateData);
		}
    return response()->json(['message' => 'WhatsApp sent successfully']);
	// return redirect()->back()->with('message', 'whatsapp sent successfully');
	// 	return $response; 
	}

  public function downloadPDF($file_name)
  {
      // Construct the full path to the file in the public directory
      $filePath = public_path('abandoned_cart_pdf/' . $file_name);

      // Check if the file exists
      if (file_exists($filePath)) {
          // Return the file as a download response
          return Response::download($filePath, $file_name);
      } else {
          // Return a 404 error if the file does not exist
          return view('errors.link_expire');
      }
  }

  public function updateSlugs()
  {
    $messageId="wamid.HBgINjI4OTA2MjkVAgARGBI3MDk1RUMwQjUyMzM1RTlENkQA";
    // Set up the database connection dynamically within the function
    config([
        'database.connections.dynamic_mazingbusiness' => [
            'driver' => 'mysql',
            'host' => 'localhost',  // Replace with your cloud database host
            'port' => '3306',  // Replace with your cloud database port
            'database' => 'mazingbusiness',  // The database name is 'mazingbusiness'
            'username' => 'mazingbusiness',   // Replace with your database username
            'password' => 'Gd6de243%',   // Replace with your database password
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'strict' => true,
            'engine' => null,
        ]
    ]);

    // Fetch the message data from the cloud_response database
    $cloudResponseData = DB::connection('dynamic_mazingbusiness')
        ->table('cloud_response')  // Assume this is the table storing the message details
        ->where('msg_id', $messageId)
        ->first();

    return $cloudResponseData->status;

      // Get all products where the slug contains a slash
    //   $products = DB::table('products')
    //       ->where('slug', 'LIKE', '%/%')
    //       ->get();

    //   foreach ($products as $product) {
    //       // Replace slashes with hyphens
    //       $newSlug = str_replace('/', '-', $product->slug);

    //       // Update the product slug in the database
    //       DB::table('products')
    //           ->where('id', $product->id)
    //           ->update(['slug' => $newSlug]);
    //   }

    //   return response()->json(['message' => 'Slugs updated successfully.']);
  }

//   public function pushOrder($id)
//     {

       
      
//       // Push order data to Salezing
//       $orderData = DB::table('orders')->where('combined_order_id', $id)->first();
//       $result=array();
//       $result['code']= $orderData->code;
//       $response = Http::withHeaders([
//           'Content-Type' => 'application/json',
//       ])->post('https://mazingbusiness.com/api/v2/order-push', $result);

      
       
//         return redirect()->back();
//     }

    public function pushOrder($id)
    {
        // Fetch order data based on combined_order_id
        $orderData = DB::table('orders')->where('combined_order_id', $id)->first();

        if ($orderData) {
            // Check if a record exists in salezing_logs with the same order code
            $existingLog = DB::table('salezing_logs')->where('code', $orderData->code)->first();

            // If a record exists, delete it
            if ($existingLog) {
                DB::table('salezing_logs')->where('code', $orderData->code)->delete();
            }

            // Prepare the data to be pushed to the Salezing API
            $result = array();
            $result['code'] = $orderData->code;

            // Push order data to Salezing API
            $response = Http::withHeaders([
                'Content-Type' => 'application/json',
            ])->post('https://mazingbusiness.com/api/v2/order-push', $result);

            // Handle the response from the API
            if ($response->successful()) {
                // Set a success message
                session()->flash('success', 'Order pushed to Salezing successfully!');
            } else {
                // Set a failure message
                session()->flash('error', 'Failed to push order to Salezing.');
            }

           
        }else {
            // If no order data found, set an error message
            session()->flash('error', 'Order not found.');
        }
     
        // Redirect back to the previous page
        return redirect()->back();
    }


}