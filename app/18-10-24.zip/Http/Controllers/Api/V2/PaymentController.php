<?php

namespace App\Http\Controllers\Api\V2;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB; // Import DB facade
// WebhookLog

class PaymentController extends Controller
{
    public function cashOnDelivery(Request $request)
    {
        $order = new OrderController;
        return $order->store($request);
    }

    public function manualPayment(Request $request)
    {
        $order = new OrderController;
        return $order->store($request);
    }

    public function webhook(Request $request)
	{
        // print_r($request->getContent()); die;
		// Check if the request method is POST
		if ($request->isMethod('post')) {
			// Check if the content type is 'text/plain'
			$contentType = $request->header('Content-Type');

			if ($contentType === 'text/plain') {
				// Get the raw POST data
				$response = $request->getContent();
                // echo $rawPostData;die;
				// Log the raw POST data to a file

				// Decrypt the response
				$decrypted_response = $this->decrypt_response($response, storage_path('pay/private/key/private_cer.pem'));

				// print_r($decrypted_response); die;

				\File::append(storage_path('logs/callback_logs.txt'), $response . PHP_EOL);
				
				// Log the raw POST data into the webhook_logs table
				DB::table('webhook_logs')->insert(['payload' => $decrypted_response]);

				return response()->json(['message' => 'Callback received successfully.']);
			} else {
				return response('Invalid content type. Only text/plain is supported.', 400)
					   ->header('Content-Type', 'text/plain');
			}
		} else {
			return response('Only POST requests are allowed.', 405)
				   ->header('Content-Type', 'text/plain');
		}
	}

	private function decrypt_response($encrypted_response, $private_key_path){
		$private_key = file_get_contents($private_key_path);
		$decoded_response = base64_decode($encrypted_response);
		$decrypted = '';
  
		$decryption_successful = openssl_private_decrypt($decoded_response, $decrypted, $private_key, OPENSSL_PKCS1_PADDING);
  
		if ($decryption_successful) {
			return $decrypted;
		} else {
			return 'Decryption failed';
		}
	}

}
