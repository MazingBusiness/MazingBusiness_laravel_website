<?php

namespace App\Http\Controllers;

use App\Models\Currency;
use App\Models\Language;
use App\Models\Order;
use App\Models\User;
use App\Models\Address;
use Config;
use Hash;
use PDF;
use Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use App\Services\WhatsAppWebService;
use Illuminate\Support\Facades\Auth;

class AdminStatementController extends Controller
{
    //
    protected $whatsAppWebService;

    public function statementPdfDownload(Request $request)
    {
        try {
            $party_code = ($request->party_code); 
        } catch (\Exception $e) {
            Log::error('Decryption error: ' . $e->getMessage());
            return response()->json(['error' => 'Failed to decrypt party code.'], 500);
        }

        $currentDate = date('Y-m-d');
        $currentMonth = date('m');
        $currentYear = date('Y');

        if ($currentMonth >= 4) {
            $form_date = date('Y-04-01'); // Start of financial year
            $to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year
        } else {
            $form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
            $to_date = date('Y-03-31'); // Current year March
        }

        if ($request->has('from_date')) {
            $form_date = $request->from_date; // Use provided date
        }

        if ($request->has('to_date')) {
            $to_date = $request->to_date; // Use provided date
        }

        if ($to_date > $currentDate) {
            $to_date = $currentDate;
        }
        
        $headers = [
            'authtoken' => '65d448afc6f6b',
        ];

        $body = [
            'party_code' => $party_code,
            'from_date' => $form_date,
            'to_date' => $to_date,
        ];

        Log::info('Sending request to API', ['body' => $body]);

        $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);      

        Log::info('Received response from API', ['status' => $response->status(), 'body' => $response->body()]);

        if ($response->successful()) {

            $getData = $response->json();
            $getData = $getData['data'];

            $openingBalance = "0";
            $closingBalance = "0";
            $openDrOrCr = "";
            $closeDrOrCr = "";
            $dueAmount = 0;  // Initialize dueAmount
            $overdueAmount = 0;
            $overdueDrOrCr = 'Dr';
            $userData = User::where('party_code', $party_code)->first();
            $overdueDateFrom = date('Y-m-d', strtotime('-' . $userData->credit_days . ' days'));

            // Process the API data to get opening, closing balances, and calculate due amount
            foreach ($getData as $gKey => $gValue) {
                if ($gValue['ledgername'] == "Opening b/f...") {
                    $openingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
                    $openDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
                } elseif ($gValue['ledgername'] == "closing C/f...") {
                    $closingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
                    $closeDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
                    $dueAmount = $gValue['dramount'] != "0.00" ? $gValue['dramount'] : $gValue['cramount'];  // Calculate due amount
                    $overdueAmount = $closingBalance;
                }
            }

            // Overdue calculation logic
            $getOverdueData = array_reverse($getData);
            $drBalanceBeforeOVDate = 0;
            $crBalanceBeforeOVDate = 0;
            $overDueMark = [];

            foreach($getOverdueData as $ovKey => $ovValue){
                if($ovValue['ledgername'] != 'closing C/f...'){
                    if(strtotime($ovValue['trn_date']) <= strtotime($overdueDateFrom)){
                        $drBalanceBeforeOVDate += $ovValue['dramount'];
                        $crBalanceBeforeOVDate += $ovValue['cramount'];
                    }
                }
            }

            $overdueAmount = $drBalanceBeforeOVDate - $crBalanceBeforeOVDate;

            // Marking overdue transactions
            foreach($getOverdueData as $ovKey => $ovValue){
                if($ovValue['ledgername'] != 'closing C/f...'){
                    if(strtotime($ovValue['trn_date']) < strtotime($overdueDateFrom) && $ovValue['dramount'] > 0){
                        $overDueMark[] = [
                            'trn_no' => $ovValue['trn_no'],
                            'trn_date' => $ovValue['trn_date'],
                            'overdue_status' => ($overdueAmount > 0) ? 'Overdue' : 'Partial Overdue'
                        ];
                    }
                }
            }

            // Adding overdue status to each transaction in getData
            $overDueMarkTrnNos = array_column($overDueMark, 'trn_no');
            $overDueMarkOverdueStaus = array_column($overDueMark, 'overdue_status');

            if (count($overDueMark) > 0) {
                foreach ($getData as $gKey => $gValue) {
                    $key = array_search($gValue['trn_no'], $overDueMarkTrnNos);
                    if ($key !== false) {
                        $getData[$gKey]['overdue_status'] = $overDueMarkOverdueStaus[$key];
                    }
                }
            }

            // Generating PDF with overdue data and due amount
            $randomNumber = rand(1000, 9999);
            $fileName = 'statement-' . $randomNumber . '.pdf';
            $userId = Auth::id();
            $pdf = PDF::loadView('backend.invoices.statement_pdf', compact(
                'party_code',
                'getData',
                'openingBalance',
                'openDrOrCr',
                'closingBalance',
                'closeDrOrCr',
                'form_date',
                'to_date',
                'overdueAmount',
                'overdueDrOrCr',
                'overdueDateFrom',
                'overDueMark',
                'dueAmount' ,// Pass dueAmount to the view
                'userId' 
            ))->save(public_path('statements/' . $fileName));

            $publicUrl = url('public/statements/' . $fileName);
            return response()->json(['status' => 'success', 'message' => $publicUrl], $response->status());
        } else {
            return response()->json(['status' => 'failure'], $response->status());
        }
    }




    // public function statementPdfDownload(Request $request)
    // {
        
    //     // return response()->json([
    //     //     'status' => 'failure', 
    //     //     'error' => "Sorry for the inconvenience, but we're working on it."
    //     // ], 500);
       
    //     try {
    //         $party_code = ($request->party_code); 
    //     } catch (\Exception $e) {
    //         Log::error('Decryption error: ' . $e->getMessage());
    //         return response()->json(['error' => 'Failed to decrypt party code.'], 500);
    //     }
        
    //     $currentDate = date('Y-m-d');
    //     $currentMonth = date('m');
    //     $currentYear = date('Y');

    //     if ($currentMonth >= 4) {
    //         $form_date = date('Y-04-01'); // Start of financial year
    //         $to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year
    //     } else {
    //         $form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
    //         $to_date = date('Y-03-31'); // Current year March
    //     }

    //     if ($request->has('from_date')) {
    //         $form_date = $request->from_date; // Use provided date
    //     }

    //     if ($request->has('to_date')) {
    //         $to_date = $request->to_date; // Use provided date
    //     }

    //     if ($to_date > $currentDate) {
    //         $to_date = $currentDate;
    //     }
        
    //     $headers = [
    //         'authtoken' => '65d448afc6f6b',
    //     ];

    //     $body = [
    //         'party_code' => $party_code,
    //         'from_date' => $form_date,
    //         'to_date' => $to_date,
    //     ];

        

    //     Log::info('Sending request to API', ['body' => $body]);

        
        
    //     // Send request to external API
    //     // $response = Http::withHeaders($headers)->post('https://sz.saleszing.co.in/itaapi/getclientstatement.php', $body);
    //     $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);      
        
    //     Log::info('Received response from API', ['status' => $response->status(), 'body' => $response->body()]);

    //     if ($response->successful()) {
    //         $getData = $response->json();
    //         $getData = $getData['data'];

    //         $openingBalance = "0";
    //         $closingBalance = "0";
    //         $openDrOrCr = "";
    //         $closeDrOrCr = "";

    //         // Process the API data to get opening and closing balances
    //         foreach ($getData as $gValue) {
    //             if ($gValue['ledgername'] == "Opening b/f...") {
    //                 $openingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
    //                 $openDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
    //             } elseif ($gValue['ledgername'] == "closing C/f...") {
    //                 $closingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
    //                 $closeDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
    //             }
    //         }

    //         $randomNumber = rand(1000, 9999);
    //     $fileName = 'statement-' . $randomNumber . '.pdf';

    //         // Generate the PDF using the collected data
    //         $pdf = PDF::loadView('backend.invoices.statement_pdf', compact(
    //             'party_code',
    //             'getData',
    //             'openingBalance',
    //             'openDrOrCr',
    //             'closingBalance',
    //             'closeDrOrCr',
    //             'form_date',
    //             'to_date'
    //         ))->save(public_path('statements/' . $fileName));

    //         $publicUrl = url('public/statements/' . $fileName);
    //         return response()->json(['status' => 'success', 'message' => $publicUrl], $response->status());
    //         $message="statement";

    //          $to="6289062983"; 
    //          $phone = Auth::user()->phone;
             
             
    //         $templateData = [
    //             'name' => 'utility_statement_document', // Replace with your template name, 
    //             'language' => 'en_US', // Replace with your desired language code
    //             'components' => [
    //                 // [
    //                 //     'type' => 'header',
    //                 //     'parameters' => [
    //                 //         ['type' => 'document', 'document' => ['link' => $publicUrl,'filename' => $fileName,]],
    //                 //     ],
    //                 // ],
    //                 [
    //                     'type' => 'body',
    //                     'parameters' => [
    //                         ['type' => 'text', 'text' => Auth::user()->company_name],
    //                         ['type' => 'text', 'text' => $message],
    //                     ],
    //                 ],
    //                 [
    //                     'type' => 'button',
    //                     'sub_type' => 'url',
    //                     'index' => '0',
    //                     'parameters' => [
    //                         [
    //                             "type" => "text",
    //                             "text" => $fileName // Replace $button_text with the actual Parameter for the button.
    //                         ],
    //                     ],
    //                 ],
    //             ],
    //         ];

    //         // Send the template message using the WhatsApp web service
    //         $this->whatsAppWebService = new WhatsAppWebService();
    //         $jsonResponse  = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);
    //         // $responseData = json_decode($jsonResponse , true);
           
            
    //         // return $publicUrl;
    //         return response()->json(['status' => 'success', 'message' =>"Statement sent to whatsapp"], $response->status());

    //     } else {
          
    //         return response()->json(['status' => 'faliure'], $response->status());
    //     }
    // }

    
  
    public function getManagersByWarehouse(Request $request)
    {
        // Fetch managers based on the selected warehouse
        $managers = User::join('staff', 'users.id', '=', 'staff.user_id')
        ->where('staff.role_id', 5)
        ->where('users.warehouse_id', $request->warehouse_id)  // Apply condition on users table
        ->select('users.*')
        ->get();

    
        return response()->json($managers); // Return managers as JSON response
    }
    
    public function statement(Request $request)
    {
        // Fetch all warehouses
        $warehouses = DB::table('warehouses')->get();
    
        $managers = User::join('staff', 'users.id', '=', 'staff.user_id')
        ->where('staff.role_id', 5)
        ->select('users.*');

    
        // If warehouse_id is provided in the request, filter the managers by warehouse
        if ($request->has('warehouse_id') && !empty($request->warehouse_id)) {
            $managers->where('warehouse_id', $request->warehouse_id);
        }
    
        // Fetch filtered managers
        $managers = $managers->get();
        
    
        // Initialize the customers query
        $customersQuery = User::where('user_type', 'customer')
                              ->orderBy('company_name', 'asc'); // Sorting customers by name in ascending order
    
        // If manager_id is provided, filter the customers by manager
        if ($request->has('manager_id') && !empty($request->manager_id)) {
            $customersQuery->where('manager_id', $request->manager_id);
        }
    
        // If warehouse_id is provided, filter the customers by warehouse
        if ($request->has('warehouse_id') && !empty($request->warehouse_id)) {
            $customersQuery->where('warehouse_id', $request->warehouse_id);
        }
    
        // Fetch customers with pagination and append query parameters
        $customers = $customersQuery->paginate(100)->appends($request->query());
    
        // Initialize an array to store the processed data
        $processedData = [];
    
        // Iterate over each customer and their addresses
        foreach ($customers as $userData) {
            // Fetch the address data for the current customer without pagination
            $userAddressData = Address::where('user_id', $userData->id)
                ->groupBy('gstin')
                ->orderBy('acc_code', 'ASC')
                ->get(); // No pagination for addresses in this example
    
            // Calculate due and overdue amounts and generate PDF URL for each address
            foreach ($userAddressData as $address) {
                $party_code = $address->acc_code;
    
                // Call the function or API to get statement data and calculate due and overdue amounts
                $response = $this->calculateDueAndOverdueAmounts($party_code, $userData);
    
                // Assign due and overdue amounts to the address
                $address->dueAmount = $response['dueAmount'];
                $address->overdueAmount = $response['overdueAmount'];
    
                // Apply the "due" filter: Only add addresses with dueAmount > 0 if 'duefilter' is 'due'
                if ($request->has('duefilter')) {
                    if ($request->duefilter == 'due' && $address->dueAmount <= 0) {
                        continue; // Skip if duefilter is 'due' and dueAmount is not greater than zero
                    }
                    if ($request->duefilter == 'overdue' && $address->overdueAmount <= 0) {
                        continue; // Skip if duefilter is 'overdue' and overdueAmount is not greater than zero
                    }
                    if ($request->duefilter == 'due-overdue' && $address->dueAmount <= 0 && $address->overdueAmount <= 0) {
                        continue; // Skip if duefilter is 'due-overdue' and both amounts are not greater than zero
                    }
                }
    
                // Generate PDF for this party code (assuming a placeholder for actual PDF generation)
                $pdfUrl = ""; // Assuming no actual PDF generation in the sample code
                $address->pdfUrl = $pdfUrl; // Save the generated PDF URL
    
                // Store the processed data for this address
                $processedData[] = [
                    'user' => $userData,
                    'address' => $address
                ];
            }
        }
    
        // Pass all processed data, customers with pagination, and the list of managers/warehouses to the view
        return view('backend.statement.statement', compact('managers', 'warehouses', 'processedData', 'customers'));
    }
    


    
    
    

    private function generateStatementPdf($party_code, $dueAmount, $overdueAmount, $userData)
    {
        $currentDate = date('Y-m-d');
        $currentMonth = date('m');
        $currentYear = date('Y');
    
        if ($currentMonth >= 4) {
            $form_date = date('Y-04-01'); // Start of financial year
            $to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year
        } else {
            $form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
            $to_date = date('Y-03-31'); // Current year March
        }
    
        if (request()->has('from_date')) {
            $form_date = request()->from_date;
        }
    
        if (request()->has('to_date')) {
            $to_date = request()->to_date;
        }
    
        if ($to_date > $currentDate) {
            $to_date = $currentDate;
        }
    
        $headers = [
            'authtoken' => '65d448afc6f6b',
        ];
    
        $body = [
            'party_code' => $party_code,
            'from_date' => $form_date,
            'to_date' => $to_date,
        ];
    
        // Make the API request to fetch statement data
        $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);
    
        if ($response->successful()) {
            $getData = $response->json()['data'];
    
            $openingBalance = "0";
            $closingBalance = "0";
            $openDrOrCr = "";
            $closeDrOrCr = "";
            $overdueDrOrCr = ""; // Initialize this variable
    
            // Calculate opening and closing balances
            foreach ($getData as $gValue) {
                if ($gValue['ledgername'] == "Opening b/f...") {
                    $openingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
                    $openDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
                } elseif ($gValue['ledgername'] == "closing C/f...") {
                    $closingBalance = ($gValue['dramount'] != "0.00") ? $gValue['dramount'] : $gValue['cramount'];
                    $closeDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr";
                    $overdueDrOrCr = ($gValue['dramount'] != "0.00") ? "Dr" : "Cr"; // Set overdueDrOrCr value
                }
            }
    
            // Generate PDF with the statement data
            $randomNumber = rand(1000, 9999);
            $fileName = 'statement-' . $randomNumber . '.pdf';
            $userId = $userData->id;
            $pdf = PDF::loadView('backend.invoices.statement_pdf', compact(
                'party_code',
                'getData',
                'openingBalance',
                'openDrOrCr',
                'closingBalance',
                'closeDrOrCr',
                'form_date',
                'to_date',
                'dueAmount',
                'overdueAmount',
                'overdueDrOrCr', // Pass overdueDrOrCr to the view
                'userId'
            ))->save(public_path('statements/' . $fileName));
    
            // Return the public URL of the PDF
            return url('public/statements/' . $fileName);
        }
    
        return null;
    }
    

    /**
     * Function to calculate due and overdue amounts for a party code
     */
    private function calculateDueAndOverdueAmounts($party_code, $userData)
    {
        $currentDate = date('Y-m-d');
        $currentMonth = date('m');
        $currentYear = date('Y');
    
        if ($currentMonth >= 4) {
            $form_date = date('Y-04-01'); // Start of financial year
            $to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year
        } else {
            $form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
            $to_date = date('Y-03-31'); // Current year March
        }
    
        // Adjust the date range if provided
        if (request()->has('from_date')) {
            $form_date = request()->from_date; 
        }
    
        if (request()->has('to_date')) {
            $to_date = request()->to_date; 
        }
    
        if ($to_date > $currentDate) {
            $to_date = $currentDate;
        }
    
        $headers = [
            'authtoken' => '65d448afc6f6b',  // API auth token
        ];
    
        $body = [
            'party_code' => $party_code,
            'from_date' => $form_date,
            'to_date' => $to_date,
        ];
    
        // Make API request (or replace this with your data fetching logic)
        $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);      
    
        if ($response->successful()) {
            // Check if 'data' key exists in the response
            if (isset($response->json()['data'])) {
                $getData = $response->json()['data'];
    
                $dueAmount = 0;
                $overdueAmount = 0;
    
                // Calculate due and overdue amounts
                foreach ($getData as $gValue) {
                    if ($gValue['ledgername'] == "closing C/f...") {
                        $dueAmount = $gValue['dramount'] != "0.00" ? $gValue['dramount'] : $gValue['cramount'];
                    }
                }
    
                // Overdue calculation logic based on user's credit days
                $overdueDateFrom = date('Y-m-d', strtotime('-' . $userData->credit_days . ' days'));
                $drBalanceBeforeOVDate = 0;
                $crBalanceBeforeOVDate = 0;
    
                foreach (array_reverse($getData) as $ovValue) {
                    if ($ovValue['ledgername'] != 'closing C/f...') {
                        if (strtotime($ovValue['trn_date']) <= strtotime($overdueDateFrom)) {
                            $drBalanceBeforeOVDate += $ovValue['dramount'];
                            $crBalanceBeforeOVDate += $ovValue['cramount'];
                        }
                    }
                }
    
                $overdueAmount = $drBalanceBeforeOVDate - $crBalanceBeforeOVDate;
    
                return [
                    'dueAmount' => $dueAmount,
                    'overdueAmount' => $overdueAmount,
                ];
            } else {
                // Log or handle the missing 'data' key case
                return [
                    'dueAmount' => 0,
                    'overdueAmount' => 0,
                ];
            }
        }
    
        // Default to zero if the API call fails
        return [
            'dueAmount' => 0,
            'overdueAmount' => 0,
        ];
    }
    

    public function createStatementPdf(Request $request)
    {
        $party_code = $request->input('party_code');
        $dueAmount = $request->input('due_amount');
        $overdueAmount = $request->input('overdue_amount');
        $userId = $request->input('user_id');

        $user=User::find($userId);

        // return response()->json([
        //     'success' => true,
        //     'pdf_url' => $overdueAmount
        // ]);

        // Call the method to generate the PDF
        $pdfUrl = $this->generateStatementPdf($party_code, $dueAmount, $overdueAmount, User::find($userId));
        $fileName = basename($pdfUrl);

        $message="statement";
        $to="7044300330"; 
        $phone = $user->phone;
        $templateData = [
            'name' => 'utility_statement_document', // Replace with your template name, 
            'language' => 'en_US', // Replace with your desired language code
            'components' => [
                // [
                //     'type' => 'header',
                //     'parameters' => [
                //         ['type' => 'document', 'document' => ['link' => $publicUrl,'filename' => $fileName,]],
                //     ],
                // ],
                [
                    'type' => 'body',
                    'parameters' => [
                        ['type' => 'text', 'text' => $user->company_name],
                        ['type' => 'text', 'text' => $message],
                    ],
                ],
                [
                    'type' => 'button',
                    'sub_type' => 'url',
                    'index' => '0',
                    'parameters' => [
                        [
                            "type" => "text","text" => $fileName // Replace $button_text with the actual Parameter for the button.
                        ],
                    ],
                ],
            ],
        ];

        // Send the template message using the WhatsApp web service
        $this->whatsAppWebService = new WhatsAppWebService();
        $jsonResponse  = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);
               
        if ($pdfUrl) {
            return response()->json([
                'success' => true,
                'pdf_url' => "Statement Sent to whatsapp"
            ]);
        } else {
            return response()->json(['success' => false]);
        }
    }


    public function generateBulkStatements(Request $request)
    {
        $allData = $request->input('all_data');
        $user = User::find($allData[1]['user_id']);

       
        
        // Loop through the data and generate PDFs for each entry
        foreach ($allData as $data) {
            $party_code = $data['party_code'];
            $due_amount = $data['due_amount'];
            $overdue_amount = $data['overdue_amount'];
            $user_id = $data['user_id'];
            
            // Find the user
            $user = User::find($user_id);

            // Assuming you have a method to generate the PDF for each entry
            $pdfUrl = $this->generateStatementPdf($party_code, $due_amount, $overdue_amount, $user);
            $fileName = basename($pdfUrl);
            // Prepare message content
            $message = "Statement " ;
            
            // WhatsApp message sending code
            $to = "7044300330"; // Replace with recipient's phone number
            $templateData = [
                'name' => 'utility_statement_document', // Replace with your template name
                'language' => 'en_US', // Replace with your desired language code
                'components' => [
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $user->company_name],
                            ['type' => 'text', 'text' => $message],
                        ],
                    ],
                    [
                        'type' => 'button',
                        'sub_type' => 'url',
                        'index' => '0',
                        'parameters' => [
                            [
                                'type' => 'text',
                                'text' => $fileName // Add PDF download link as button parameter
                            ],
                        ],
                    ],
                ],
            ];

            // Send the template message using the WhatsApp web service
            $this->whatsAppWebService = new WhatsAppWebService();
            $jsonResponse = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);
            break;
            // Handle the response or logging if needed
        }
         // Return response as needed
         return response()->json([
            'success' => true,
            'pdf_url' => $user->phone
        ]);
    }


    public function generateStatementPdfChecked(Request $request)
    {
        // Get the selected data from the request
        $selectedData = $request->input('selected_data');

        // Check if any data is selected
        if (empty($selectedData)) {
            return response()->json(['success' => false, 'message' => 'No users selected.']);
        }

        // Loop through each selected person and process the WhatsApp message
        foreach ($selectedData as $data) {
            $partyCode = $data['party_code'];
            $dueAmount = $data['due_amount'];
            $overdueAmount = $data['overdue_amount'];
            $userId = $data['user_id'];

            $user = User::find($userId);

            // Implement your logic here to send WhatsApp message
           // Assuming you have a method to generate the PDF for each entry
           $pdfUrl = $this->generateStatementPdf($partyCode, $dueAmount, $overdueAmount, $user);
           $fileName = basename($pdfUrl);
           // Prepare message content
           $message = "Statement " ;
           
           // WhatsApp message sending code
           $to = "7044300330"; // Replace with recipient's phone number
           $templateData = [
               'name' => 'utility_statement_document', // Replace with your template name
               'language' => 'en_US', // Replace with your desired language code
               'components' => [
                   [
                       'type' => 'body',
                       'parameters' => [
                           ['type' => 'text', 'text' => $user->company_name],
                           ['type' => 'text', 'text' => $message],
                       ],
                   ],
                   [
                       'type' => 'button',
                       'sub_type' => 'url',
                       'index' => '0',
                       'parameters' => [
                           [
                               'type' => 'text',
                               'text' => $fileName // Add PDF download link as button parameter
                           ],
                       ],
                   ],
               ],
           ];

           // Send the template message using the WhatsApp web service
           $this->whatsAppWebService = new WhatsAppWebService();
           $jsonResponse = $this->whatsAppWebService->sendTemplateMessage($to, $templateData);
           break;
            
            // For demonstration, you can log the data
            \Log::info("Sending WhatsApp to Party Code: $partyCode, Due: $dueAmount, Overdue: $overdueAmount, User ID: $userId");
            
            // Call your WhatsApp API or function to send the message
            // Example:
            // WhatsAppService::sendMessage($partyCode, $dueAmount, $overdueAmount, $userId);
        }

        // Return a success response
        return response()->json(['success' => true, 'message' => 'WhatsApp messages sent to selected persons.']);
    }

}
