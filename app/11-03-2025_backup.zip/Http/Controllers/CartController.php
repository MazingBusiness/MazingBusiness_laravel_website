<?php

namespace App\Http\Controllers;

use App\Http\Resources\V2\ProductDetailCollection;
use App\Models\Cart;
use App\Models\CartSaveForLater;
use App\Models\Product;
use App\Models\Warehouse;
use App\Models\User;
use App\Models\Address;
use App\Models\Offer;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\OfferProduct;
use App\Models\OfferCombination;
use App\Models\AttributeValue;
use App\Models\Attribute;
use Auth;
use PDF;
use Cookie;
use Illuminate\Http\Request;
use Session;
use Illuminate\Support\Facades\DB;
use App\Services\WhatsAppWebService;
use App\Exports\AbandonedCartExport;
use App\Imports\ExternalPurchaseOrder;
use App\Exports\FinalPurchaseExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\JsonResponse;
use Exception;
use Illuminate\Support\Facades\Log;
use App\Services\StatementCalculationService;
use Carbon\Carbon;



class CartController extends Controller {
    protected $WhatsAppWebService;
    protected $statementCalculationService;

    public function __construct(StatementCalculationService $statementCalculationService)
    {
        $this->statementCalculationService = $statementCalculationService;
    }

    public function index(Request $request) {
        if (auth()->user() != null) {
        $user_id = Auth::user()->id;
        if ($request->session()->get('temp_user_id')) {
            Cart::where('temp_user_id', $request->session()->get('temp_user_id'))
            ->update(
                [
                'user_id'      => $user_id,
                'temp_user_id' => null,
                ]
            );

            Session::forget('temp_user_id');
        }
        $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
        } else {
            $temp_user_id = $request->session()->get('temp_user_id');
            // $carts = Cart::where('temp_user_id', $temp_user_id)->get();
            $carts = ($temp_user_id != null) ? Cart::where('temp_user_id', $temp_user_id)->get() : [];
        }

        return view('frontend.view_cart', compact('carts'));
    }

    public function cart_v02(Request $request) {
        session()->forget('overdueAmount');
        session()->forget('dueAmount');
        $overdueAmount = 0;
        if (auth()->user() != null) {
            $user_id = Auth::user()->id;
            if ($request->session()->get('temp_user_id')) {
                Cart::where('temp_user_id', $request->session()->get('temp_user_id'))
                ->update(
                    [
                    'user_id'      => $user_id,
                    'temp_user_id' => null,
                    ]
                );
                Session::forget('temp_user_id');
            }
            $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartSaveForLater = CartSaveForLater::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartSaveForLaterCategory = CartSaveForLater::with('category') ->where('user_id', $user_id) ->orWhere('customer_id', $user_id) ->selectRaw('category_id, COUNT(*) as product_count') ->groupBy('category_id')  ->get()
            ->map(function ($item) {
                return [
                    'category_id' => $item->category->id,
                    'category_name' => $item->category->name,
                    'product_count' => $item->product_count,
                ];
            });
            // --------------------------------- Calculate Due and Overdue amount --------------------------------------
            $currentDate = date('Y-m-d');
            $currentMonth = date('m');
            $currentYear = date('Y');
            $overdueDateFrom="";
            $overdueAmount="0";

            $openingBalance="0";
            $drBalance = 0;
            $crBalance = 0;
            $dueAmount = 0;

            $userData = User::where('id', $user_id)->first();
            $userAddressData = Address::where('acc_code',"!=","")->where('user_id',$userData->id)->groupBy('gstin')->orderBy('acc_code','ASC')->get();
            foreach($userAddressData as $key=>$value){
                $party_code = $value->acc_code;
                if ($currentMonth >= 4) {
                    $fy_form_date = date('Y-04-01'); // Start of financial year
                    $fy_to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year (next year)
                } else {
                    $fy_form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
                    $fy_to_date = date('Y-03-31'); // Current year March
                }
                $from_date = $fy_form_date;
                $to_date = $fy_to_date;
                $headers = [
                    'authtoken' => '65d448afc6f6b',
                ];
                $body = [
                    'party_code' => $party_code,
                    'from_date' => $from_date,
                    'to_date' =>  $to_date,
                ];
				//echo "Hello"; die;
                $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);
                \Log::info('Received response from Salzing API For Sync Statement Overdue Calculation', [
                    'status' => $response->status(),
                    'party_code' =>  $party_code,
                    'body' => $response->body()
                ]);
				/*$context = stream_context_create([
					'http' => [
						'method' => 'POST',
						'header' => "Content-Type: application/json\r\n" .
									"Authorization: Bearer your_token_here\r\n",
						'content' => json_encode($body),
						'timeout' => 10
					]
				]);
				$result = file_get_contents('https://saleszing.co.in/itaapi/getclientstatement.php', false, $context);
				dd($result);*/
				echo "<pre>"; print_r($response); die;
                if ($response->successful()) {
                    $getData = $response->json();
                    if(!empty($getData) AND isset($getData['data']) AND !empty($getData['data'])){
                        $getData = $getData['data'];
                        $closingBalanceResult = array_filter($getData, function ($entry) {
                            return isset($entry['ledgername']) && $entry['ledgername'] === 'closing C/f...';
                        });
                        $closingEntry = reset($closingBalanceResult);
                        $cloasingDrAmount = $closingEntry['dramount'];
                        $cloasingCrAmount = $closingEntry['cramount'];
                        $overdueDateFrom = date('Y-m-d', strtotime('-' . $userData->credit_days . ' days'));
                        if($cloasingCrAmount > 0){
                            $drBalanceBeforeOVDate = 0;
                            $crBalanceBeforeOVDate = 0;
                            $getData = array_reverse($getData);
                            foreach($getData as $ovKey=>$gValue){
                                if($gValue['ledgername'] != 'closing C/f...'){
                                    if(strtotime($gValue['trn_date']) > strtotime($overdueDateFrom)){
                                        // $drBalanceBeforeOVDate += $ovValue['dramount'];
                                        $crBalanceBeforeOVDate += $gValue['cramount'];
                                    }else{
                                        $drBalanceBeforeOVDate += $gValue['dramount'];
                                        $crBalanceBeforeOVDate += $gValue['cramount'];
                                    }
                                }
                                if ($gValue['dramount'] != 0.00 AND $gValue['ledgername'] != 'closing C/f...') {
                                    $drBalance = $drBalance + $gValue['dramount'];
                                    $dueAmount = $dueAmount + $gValue['dramount'];
                                } 
                                if($gValue['cramount'] != '0.00' AND $gValue['ledgername'] != 'closing C/f...') {
                                    $crBalance = $crBalance + $gValue['cramount'];
                                    $dueAmount = $dueAmount - $gValue['cramount'];
                                }
                            }
                            $overdueAmount = $drBalanceBeforeOVDate - $crBalanceBeforeOVDate;
                        }
                    }
                }
            }
            if($overdueAmount <= 0){
                $overdueAmount = 0;
            }
            // $overdueAmount = ceil($overdueAmount);
            // $dueAmount = ceil($dueAmount);
            $overdueAmount = $overdueAmount;
            $dueAmount = $dueAmount;
            session(['overdueAmount' => $overdueAmount]);
            session(['dueAmount' => $dueAmount]);
            // --------------------------------- Calculate Due and Overdue amount --------------------------------------
            
        } else {
            $temp_user_id = $request->session()->get('temp_user_id');
            // $carts = Cart::where('temp_user_id', $temp_user_id)->get();
            $carts = ($temp_user_id != null) ? Cart::where('temp_user_id', $temp_user_id)->get() : [];
        }
        $cash_and_carry_item_flag_for_later = CartSaveForLater::where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->count();
        return view('frontend.view_cart_v02', compact('carts','cartSaveForLater','cartSaveForLaterCategory','cash_and_carry_item_flag_for_later','overdueAmount','dueAmount'));
    }

    public function cart_v03(Request $request) {
       
        session()->forget('overdueAmount');
        session()->forget('dueAmount');
        $overdueAmount = 0;
        $validOffers = array();
        $achiveOfferArray = array();
        if (auth()->user() != null) {
            $user_id = Auth::user()->id;
            if ($request->session()->get('temp_user_id')) {
                Cart::where('temp_user_id', $request->session()->get('temp_user_id'))
                ->update(
                    [
                    'user_id'      => $user_id,
                    'temp_user_id' => null,
                    ]
                );
                Session::forget('temp_user_id');
            }
            $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartSaveForLater = CartSaveForLater::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartSaveForLaterCategory = CartSaveForLater::with('category') ->where('user_id', $user_id) ->orWhere('customer_id', $user_id) ->selectRaw('category_id, COUNT(*) as product_count') ->groupBy('category_id')  ->get()
            ->map(function ($item) {
                return [
                    'category_id' => $item->category->id,
                    'category_name' => $item->category->name,
                    'product_count' => $item->product_count,
                ];
            });

            $calculationResponse = $this->statementCalculationService->calculateForOneCompany(Auth::user()->id, 'live');
			//echo "<pre>"; print_r($calculationResponse);die;
            // Decode the JSON response to an array
            $calculationResponse = $calculationResponse->getData(true);

            $overdueAmount = $calculationResponse['overdueAmount'];
            $dueAmount = $calculationResponse['dueAmount'];
            session(['overdueAmount' => $overdueAmount]);
            session(['dueAmount' => $dueAmount]);
            // --------------------------------- Calculate Due and Overdue amount --------------------------------------

            $cash_and_carry_item_flag_for_later = CartSaveForLater::where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->count();
            
        } else {
            return redirect()->route('home');
            // $temp_user_id = $request->session()->get('temp_user_id');
            // // $carts = Cart::where('temp_user_id', $temp_user_id)->get();
            // $carts = ($temp_user_id != null) ? Cart::where('temp_user_id', $temp_user_id)->get() : [];
        }        

        // Offer Section        
        if(Auth::user()->id == '24185'){
            $carts = $this->addOfferTag($carts);
            $validOffersTemp = $this->checkValidOffer();
            $validOffers = $validOffersTemp['offers'] ?? [];
            $achiveOfferArray = $validOffersTemp['achiveOfferArray'] ?? [];
        }
        return view('frontend.view_cart_v02', compact('carts','cartSaveForLater','cartSaveForLaterCategory','cash_and_carry_item_flag_for_later','overdueAmount','dueAmount','validOffers','achiveOfferArray'));
    }

    

    public function updateCartPrice(Request $request) {
        try {
            $user_id = Auth::user()->id;        
            $cart_id = $request->has('cart_id')? $request->cart_id : '';
            $update_price = $request->has('update_price')? $request->update_price : '0';

            $cartItem = Cart::findOrFail($cart_id);        
            $cartItem['price'] = $update_price;
            $cartItem->save();

            $overdueAmount = session('overdueAmount');
            $dueAmount = session('dueAmount');
            
            $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $view = view('frontend.updateCartPrice', compact('carts','dueAmount','overdueAmount'))->render();
            return response()->json([
                'html' => $view,
                'nav_cart_view' => view('frontend.partials.cart')->render()
            ]);

        } catch (\Exception $e) {
            // Log any other exceptions
            \Log::error('An error occurred: ' . $e->getMessage());
            return response()->json([
                'status' => 'Error',
                'message' => 'An unexpected error occurred.',
            ], 500);
        }

    }

    public function saveForLater(Request $request) {
        try {
            $validOffers = array();
            $achiveOfferArray = array();
            $user_id = Auth::user()->id;        
            $cart_id = $request->has('cart_id')? $request->cart_id : '';

            $cartItem = Cart::with('product')->where('id', $cart_id)->first();
            // Remove offer
            $offer_id = $cartItem->applied_offer_id;
            $currentDate = now();
            if($offer_id != NULL OR $offer_id != ""){
                $currentDate = now();
                $offers = Offer::with('offerProducts')
                    ->where('status', 1)
                    ->whereDate('offer_validity_start', '<=', $currentDate)
                    ->whereDate('offer_validity_end', '>=', $currentDate)
                    ->where('id', $offer_id)->first();
                $offerProducts = $offers->offerProducts;            
                foreach($offerProducts as $opKey=>$opValue){
                    $cartProduct = Cart::where(function ($query) use ($opValue) {
                        $query->where('user_id', Auth::user()->id)
                                ->orWhere('customer_id', Auth::user()->id);
                    })->where('product_id', $opValue->product_id)->first();
                    
                    $product = Product::where('id',$opValue->product_id)->first();
                    $price = $product->mrp * ((100 - Auth::user()->discount) / 100);
                    $cartProduct->applied_offer_id = null;
                    $cartProduct->price = $price;
                    $cartProduct->save();
                }
                $cartProduct = Cart::where(function ($query) use ($opValue) {
                    $query->where('user_id', Auth::user()->id)
                            ->orWhere('customer_id', Auth::user()->id);
                })->where('applied_offer_id', $offer_id)->where('complementary_item', '1')->delete();
            }
            
            $cartSaveForLaterData = CartSaveForLater::where(function($query) use ($user_id, $cartItem) {
                $query->where('user_id', $user_id)
                      ->where('product_id', $cartItem->product_id);
            })->orWhere('customer_id', $user_id)->get();
           
            if ($cartSaveForLaterData->isEmpty()) {
                $cartItem->group_id = $cartItem->product->group_id;
                $cartItem->category_id = $cartItem->product->category_id;
                $cartItem->brand_id = $cartItem->product->brand_id;
                CartSaveForLater::create($cartItem->toArray());
            }           
            
            $cartItem->delete();

            $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
           
            $cartSaveForLater = CartSaveForLater::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartSaveForLaterCategory = CartSaveForLater::with('category') // Eager load the related category
            ->where('user_id', $user_id)
            ->orWhere('customer_id', $user_id)
            ->selectRaw('category_id, COUNT(*) as product_count') // Select category_id and the product count
            ->groupBy('category_id')
            ->get()
            ->map(function ($item) {
                return [
                    'category_id' => $item->category->id,
                    'category_name' => $item->category->name, // Assuming 'name' is the category's name column
                    'product_count' => $item->product_count,
                ];
            });

            $overdueAmount = $request->overdueAmount;
            $dueAmount = $request->dueAmount;
            $cash_and_carry_item_flag_for_later = CartSaveForLater::where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->count();


            // Offer Section 
            if(Auth::user()->id == '24185'){
                $carts = $this->addOfferTag($carts);
                $validOffersTemp = $this->checkValidOffer();
                $validOffers = $validOffersTemp['offers'] ?? [];
                $achiveOfferArray = $validOffersTemp['achiveOfferArray'] ?? [];
            }
            return response()->json([
                'html' =>  view('frontend.partials.cartSummary', compact('carts','overdueAmount','dueAmount','validOffers','achiveOfferArray'))->render(),
                'viewSaveForLater' => view('frontend.partials.cart_save_for_laters', compact('cartSaveForLater','cartSaveForLaterCategory','cash_and_carry_item_flag_for_later'))->render(),
                'nav_cart_view' => view('frontend.partials.cart', compact('carts','overdueAmount','dueAmount'))->render(),
            ]);
        } catch (\Exception $e) {
            // Log any other exceptions
            \Log::error('An error occurred: ' . $e->getMessage());
            return response()->json([
                'status' => 'Error',
                'message' => 'An unexpected error occurred.' . $e->getMessage(),
            ], 500);
        }

    }

    public function saveAllNoCreditItemForLater(Request $request) {
        try {
            $user_id = Auth::user()->id;        
            
            $cartItem = Cart::with('product')->where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();

            // echo "<pre>";print_r($cartItem);die();
            if(!$cartItem->isEmpty()){
                foreach($cartItem as $cKey=>$cValue){
                    $cartSaveForLaterData = CartSaveForLater::where(function($query) use ($user_id, $cValue) {
                        $query->where('user_id', $user_id)
                              ->where('product_id', $cValue->product_id);
                    })->orWhere('customer_id', $user_id)->get();
                   
                    if ($cartSaveForLaterData->isEmpty()) {
                        $cValue->group_id = $cValue->product->group_id;
                        $cValue->category_id = $cValue->product->category_id;
                        $cValue->brand_id = $cValue->product->brand_id;
                        CartSaveForLater::create($cValue->toArray());
                    }
                    Cart::where('id',$cValue->id)->delete();
                }
            }

            $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
           
            $cartSaveForLater = CartSaveForLater::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartSaveForLaterCategory = CartSaveForLater::with('category') // Eager load the related category
            ->where('user_id', $user_id)
            ->orWhere('customer_id', $user_id)
            ->selectRaw('category_id, COUNT(*) as product_count') // Select category_id and the product count
            ->groupBy('category_id')
            ->get()
            ->map(function ($item) {
                return [
                    'category_id' => $item->category->id,
                    'category_name' => $item->category->name, // Assuming 'name' is the category's name column
                    'product_count' => $item->product_count,
                ];
            });

            $overdueAmount = $request->overdueAmount;
            $dueAmount = $request->dueAmount;
            $cash_and_carry_item_flag_for_later = CartSaveForLater::where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->count();
            return response()->json([
                'html' =>  view('frontend.partials.cartSummary', compact('carts','overdueAmount','dueAmount'))->render(), 
                'viewSaveForLater' => view('frontend.partials.cart_save_for_laters', compact('cartSaveForLater','cartSaveForLaterCategory','cash_and_carry_item_flag_for_later'))->render(),
                'nav_cart_view' => view('frontend.partials.cart')->render(),
            ]);

        } catch (\Exception $e) {
            // Log any other exceptions
            \Log::error('An error occurred: ' . $e->getMessage());
            return response()->json([
                'status' => 'Error',
                'message' => 'An unexpected error occurred.' . $e->getMessage(),
            ], 500);
        }

    }

    public function moveAllNoCreditItemToCart(Request $request) {
        try {
            $user_id = Auth::user()->id;        
            // $id = $request->has('id')? $request->id : '';

            $cartItem = CartSaveForLater::where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartItemData = $cartItem->toArray();
            if(!$cartItem->isEmpty()){
                foreach($cartItem as $cKey=>$cValue){
                    $cartItemData = $cValue->toArray();
                    unset($cartItemData['group_id']);
                    unset($cartItemData['category_id']);
                    unset($cartItemData['brand_id']);
                    
                    Cart::create($cartItemData);
                    
                    CartSaveForLater::where('id',$cValue->id)->delete();
                }
            }

            $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
           
            $cartSaveForLater = CartSaveForLater::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartSaveForLaterCategory = CartSaveForLater::with('category') // Eager load the related category
            ->where('user_id', $user_id)
            ->orWhere('customer_id', $user_id)
            ->selectRaw('category_id, COUNT(*) as product_count') // Select category_id and the product count
            ->groupBy('category_id')
            ->get()
            ->map(function ($item) {
                return [
                    'category_id' => $item->category->id,
                    'category_name' => $item->category->name, // Assuming 'name' is the category's name column
                    'product_count' => $item->product_count,
                ];
            });

            $overdueAmount = $request->overdueAmount;
            $dueAmount = $request->dueAmount;
            $cash_and_carry_item_flag_for_later = CartSaveForLater::where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->count();
            return response()->json([
                'html' =>  view('frontend.partials.cartSummary', compact('carts','overdueAmount','dueAmount'))->render(), 
                'viewSaveForLater' => view('frontend.partials.cart_save_for_laters', compact('cartSaveForLater','cartSaveForLaterCategory','cash_and_carry_item_flag_for_later'))->render(),
                'nav_cart_view' => view('frontend.partials.cart')->render(),
            ]);

        } catch (\Exception $e) {
            // Log any other exceptions
            \Log::error('An error occurred: ' . $e->getMessage());
            return response()->json([
                'status' => 'Error',
                'message' => 'An unexpected error occurred.' . $e->getMessage(),
            ], 500);
        }

    }

    public function saveAllCheckedItemForLater(Request $request) {
        try {
            $user_id = Auth::user()->id;        
            
            foreach($request->itemIds as $key=>$value){
                $cartItem = Cart::with('product')->where('id', $value)->first();
                if($cartItem!==NULL){                    
                    $cartSaveForLaterData = CartSaveForLater::where(function($query) use ($user_id, $cartItem) {
                        $query->where('user_id', $user_id)
                            ->where('product_id', $cartItem->product->product_id);
                    })->orWhere('customer_id', $user_id)->get();
                
                    if ($cartSaveForLaterData->isEmpty()) {
                        $cartItem->group_id = $cartItem->product->group_id;
                        $cartItem->category_id = $cartItem->product->category_id;
                        $cartItem->brand_id = $cartItem->product->brand_id;
                        CartSaveForLater::create($cartItem->toArray());
                    }
                    Cart::where('id',$cartItem->id)->delete();                    
                }
            }            

            $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
           
            $cartSaveForLater = CartSaveForLater::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartSaveForLaterCategory = CartSaveForLater::with('category') // Eager load the related category
            ->where('user_id', $user_id)
            ->orWhere('customer_id', $user_id)
            ->selectRaw('category_id, COUNT(*) as product_count') // Select category_id and the product count
            ->groupBy('category_id')
            ->get()
            ->map(function ($item) {
                return [
                    'category_id' => $item->category->id,
                    'category_name' => $item->category->name, // Assuming 'name' is the category's name column
                    'product_count' => $item->product_count,
                ];
            });

            $overdueAmount = $request->overdueAmount;
            $dueAmount = $request->dueAmount;
            $cash_and_carry_item_flag_for_later = CartSaveForLater::where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->count();
            return response()->json([
                'html' =>  view('frontend.partials.cartSummary', compact('carts','overdueAmount','dueAmount'))->render(), 
                'viewSaveForLater' => view('frontend.partials.cart_save_for_laters', compact('cartSaveForLater','cartSaveForLaterCategory','cash_and_carry_item_flag_for_later'))->render(),
                'nav_cart_view' => view('frontend.partials.cart')->render(),
            ]);

        } catch (\Exception $e) {
            // Log any other exceptions
            \Log::error('An error occurred: ' . $e->getMessage());
            return response()->json([
                'status' => 'Error',
                'message' => 'An unexpected error occurred.' . $e->getMessage(),
            ], 500);
        }

    }

    public function moveAllCheckedItemToCart(Request $request) {
        try {
            $user_id = Auth::user()->id;
            
            foreach($request->itemIds as $key=>$value){
                $cartItem = CartSaveForLater::where('id', $value)->first();
                if($cartItem!==NULL){                    
                    $cartItemData = $cartItem->toArray();
                    unset($cartItemData['group_id']);
                    unset($cartItemData['category_id']);
                    unset($cartItemData['brand_id']);
                    
                    Cart::create($cartItemData);
                    
                    CartSaveForLater::where('id',$value)->delete();
                }
            }

            $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
           
            $cartSaveForLater = CartSaveForLater::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartSaveForLaterCategory = CartSaveForLater::with('category') // Eager load the related category
            ->where('user_id', $user_id)
            ->orWhere('customer_id', $user_id)
            ->selectRaw('category_id, COUNT(*) as product_count') // Select category_id and the product count
            ->groupBy('category_id')
            ->get()
            ->map(function ($item) {
                return [
                    'category_id' => $item->category->id,
                    'category_name' => $item->category->name, // Assuming 'name' is the category's name column
                    'product_count' => $item->product_count,
                ];
            });

            $overdueAmount = $request->overdueAmount;
            $dueAmount = $request->dueAmount;
            $cash_and_carry_item_flag_for_later = CartSaveForLater::where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->count();
            return response()->json([
                'html' =>  view('frontend.partials.cartSummary', compact('carts','overdueAmount','dueAmount'))->render(), 
                'viewSaveForLater' => view('frontend.partials.cart_save_for_laters', compact('cartSaveForLater','cartSaveForLaterCategory','cash_and_carry_item_flag_for_later'))->render(),
                'nav_cart_view' => view('frontend.partials.cart')->render(),
            ]);

        } catch (\Exception $e) {
            // Log any other exceptions
            \Log::error('An error occurred: ' . $e->getMessage());
            return response()->json([
                'status' => 'Error',
                'message' => 'An unexpected error occurred.' . $e->getMessage(),
            ], 500);
        }

    }

    public function moveToCart(Request $request) {
        try {
            $user_id = Auth::user()->id;        
            $id = $request->has('id')? $request->id : '';

            $cartItem = CartSaveForLater::where('id', $id)->first();
            $cartItemData = $cartItem->toArray();
            
            unset($cartItemData['group_id']);
            unset($cartItemData['category_id']);
            unset($cartItemData['brand_id']);
            
            Cart::create($cartItemData);
            // Cart::create($cartItem->toArray());         
            
            $cartItem->delete();

            $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
           
            $cartSaveForLater = CartSaveForLater::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartSaveForLaterCategory = CartSaveForLater::with('category') // Eager load the related category
            ->where('user_id', $user_id)
            ->orWhere('customer_id', $user_id)
            ->selectRaw('category_id, COUNT(*) as product_count') // Select category_id and the product count
            ->groupBy('category_id')
            ->get()
            ->map(function ($item) {
                return [
                    'category_id' => $item->category->id,
                    'category_name' => $item->category->name, // Assuming 'name' is the category's name column
                    'product_count' => $item->product_count,
                ];
            });


            // Offer Section 
            // Offer Section
            $validOffers = array();
            $achiveOfferArray = array();
            if(Auth::user()->id == '24185'){
                $carts = $this->addOfferTag($carts);
                $validOffersTemp = $this->checkValidOffer();
                $validOffers = $validOffersTemp['offers'] ?? [];
                $achiveOfferArray = $validOffersTemp['achiveOfferArray'] ?? [];
                // echo "<pre>"; print_r($validOffers);die;
            }

            $overdueAmount = $request->overdueAmount;
            $dueAmount = $request->dueAmount;
            $cash_and_carry_item_flag_for_later = CartSaveForLater::where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->count();
            return response()->json([
                'html' =>  view('frontend.partials.cartSummary', compact('carts','overdueAmount','dueAmount','validOffers','achiveOfferArray'))->render(), 
                'viewSaveForLater' => view('frontend.partials.cart_save_for_laters', compact('cartSaveForLater','cartSaveForLaterCategory','cash_and_carry_item_flag_for_later'))->render(),
                'nav_cart_view' => view('frontend.partials.cart')->render(),
            ]);

        } catch (\Exception $e) {
            // Log any other exceptions
            \Log::error('An error occurred: ' . $e->getMessage());
            return response()->json([
                'status' => 'Error',
                'message' => 'An unexpected error occurred.' . $e->getMessage(),
            ], 500);
        }

    }

    public function removeFromSaveForLeterView(Request $request) {
        try {
            $user_id = Auth::user()->id;        
            $id = $request->has('id')? $request->id : '';
            $cartItem = CartSaveForLater::where('id', $id)->first();            
            $cartItem->delete();
           
            $cartSaveForLater = CartSaveForLater::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            $cartSaveForLaterCategory = CartSaveForLater::with('category') ->where('user_id', $user_id) ->orWhere('customer_id', $user_id) ->selectRaw('category_id, COUNT(*) as product_count') ->groupBy('category_id')  ->get()
            ->map(function ($item) {
                return [
                    'category_id' => $item->category->id,
                    'category_name' => $item->category->name,
                    'product_count' => $item->product_count,
                ];
            });

            $overdueAmount = $request->overdueAmount;
            $dueAmount = $request->dueAmount;
            $cash_and_carry_item_flag_for_later = CartSaveForLater::where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->count();
            return response()->json([
                'viewSaveForLater' => view('frontend.partials.cart_save_for_laters', compact('cartSaveForLater','cartSaveForLaterCategory','cash_and_carry_item_flag_for_later'))->render(),
                // 'nav_cart_view' => view('frontend.partials.cart')->render(),
            ]);

        } catch (\Exception $e) {
            // Log any other exceptions
            \Log::error('An error occurred: ' . $e->getMessage());
            return response()->json([
                'status' => 'Error',
                'message' => 'An unexpected error occurred.' . $e->getMessage(),
            ], 500);
        }

    }

    public function sortByCategoryIdInSaveForLater(Request $request) {
        try {
            $user_id = Auth::user()->id;        
            $category_id = $request->has('category_id')? $request->category_id : '';
            $cartSaveForLaterCategory = CartSaveForLater::with('category') ->where('user_id', $user_id) ->orWhere('customer_id', $user_id) ->selectRaw('category_id, COUNT(*) as product_count') ->groupBy('category_id')  ->get()
            ->map(function ($item) {
                return [
                    'category_id' => $item->category->id,
                    'category_name' => $item->category->name,
                    'product_count' => $item->product_count,
                ];
            });
            $cartSaveForLater = CartSaveForLater::where('user_id', $user_id)->orWhere('customer_id', $user_id) ->orderByRaw("category_id = ? DESC", [$category_id])->get();

            $overdueAmount = $request->overdueAmount;
            $dueAmount = $request->dueAmount;
            $cash_and_carry_item_flag_for_later = CartSaveForLater::where('cash_and_carry_item', '1')->where('user_id', $user_id)->orWhere('customer_id',$user_id)->count();
            return response()->json([
                'viewSaveForLater' => view('frontend.partials.cart_save_for_laters', compact('cartSaveForLater','cartSaveForLaterCategory','cash_and_carry_item_flag_for_later'))->render(),
                // 'nav_cart_view' => view('frontend.partials.cart')->render(),
            ]);
        } catch (\Exception $e) {
            // Log any other exceptions
            \Log::error('An error occurred: ' . $e->getMessage());
            return response()->json([
                'status' => 'Error',
                'message' => 'An unexpected error occurred.' . $e->getMessage(),
            ], 500);
        }
    }

    public function viewFullStatement(Request $request) {
        try {
            $user_id = $request->userId;        
            // --------------------------------- Calculate Due and Overdue amount --------------------------------------
            $currentDate = date('Y-m-d');
            $currentMonth = date('m');
            $currentYear = date('Y');
            $overdueDateFrom="";
            $overdueAmount="0";

            $openingBalance="0";
            $drBalance = 0;
            $crBalance = 0;
            $dueAmount = 0;
            $openDrOrCr = "";
            $closeDrOrCr = "";
            $closingBalance = 0;
            $dueDrOrCr  = "";
            

            $userData = User::where('id', $user_id)->first();
            $userAddressData = Address::where('acc_code',"!=","")->where('user_id',$userData->id)->groupBy('gstin')->orderBy('acc_code','ASC')->get();
            $statementArray = array();
            foreach($userAddressData as $key=>$value){
                $party_code = $value->acc_code;
                if ($currentMonth >= 4) {
                    $fy_form_date = date('Y-04-01'); // Start of financial year
                    $fy_to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year (next year)
                } else {
                    $fy_form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
                    $fy_to_date = date('Y-03-31'); // Current year March
                }
                $from_date = $fy_form_date;
                $to_date = $fy_to_date;
                $headers = [
                    'authtoken' => '65d448afc6f6b',
                ];
                $body = [
                    'party_code' => $party_code,
                    'from_date' => $from_date,
                    'to_date' =>  $to_date,
                ];
                $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);
                \Log::info('Received response from Salzing API For Sync Statement Overdue Calculation', [
                    'status' => $response->status(),
                    'party_code' =>  $party_code,
                    'body' => $response->body()
                ]);
                if ($response->successful()) {
                    $getData = $response->json();
                    $statementArray[$key]['cmp_name'] = $value->company_name;
                    $statementArray[$key]['party_code'] = $value->acc_code;
                    $statementArray[$key]['statement'] = array();
                    if(!empty($getData) AND isset($getData['data']) AND !empty($getData['data'])){
                        $getData = $getData['data'];
                        
                        $closingBalanceResult = array_filter($getData, function ($entry) {
                            return isset($entry['ledgername']) && $entry['ledgername'] === 'closing C/f...';
                        });
                        $closingEntry = reset($closingBalanceResult);
                        $cloasingDrAmount = $closingEntry['dramount'];
                        $cloasingCrAmount = $closingEntry['cramount'];          
                        $overdueDateFrom = date('Y-m-d', strtotime('-' . $userData->credit_days . ' days'));
                        if($cloasingCrAmount > 0){
                            $drBalanceBeforeOVDate = 0;
                            $crBalanceBeforeOVDate = 0;
                            $getData = array_reverse($getData);
                            foreach($getData as $ovKey=>$gValue){
                                if($gValue['ledgername'] != 'closing C/f...'){
                                    if(strtotime($gValue['trn_date']) > strtotime($overdueDateFrom)){
                                        // $drBalanceBeforeOVDate += $ovValue['dramount'];
                                        $crBalanceBeforeOVDate += $gValue['cramount'];
                                    }else{
                                        $drBalanceBeforeOVDate += $gValue['dramount'];
                                        $crBalanceBeforeOVDate += $gValue['cramount'];
                                    }
                                }
                                if ($gValue['dramount'] != 0.00 AND $gValue['ledgername'] != 'closing C/f...') {
                                    $drBalance = $drBalance + $gValue['dramount'];
                                    $dueAmount = $dueAmount + $gValue['dramount'];
                                } 
                                if($gValue['cramount'] != '0.00' AND $gValue['ledgername'] != 'closing C/f...') {
                                    $crBalance = $crBalance + $gValue['cramount'];
                                    $dueAmount = $dueAmount - $gValue['cramount'];
                                }

                            }
                            $overdueAmount = $temOverDueBalance = $drBalanceBeforeOVDate - $crBalanceBeforeOVDate;
                            $overDueMark = array();
                            
                            foreach($getData as $ovKey=>$ovValue){
                                if($ovValue['ledgername'] != 'closing C/f...'){
                                    if(strtotime($ovValue['trn_date']) > strtotime($overdueDateFrom)){
                                        // $drBalanceBeforeOVDate += $ovValue['dramount'];
                                        // $crBalanceBeforeOVDate += $ovValue['cramount'];
                                    }elseif(strtotime($ovValue['trn_date']) <= strtotime($overdueDateFrom) AND $temOverDueBalance > 0 AND $ovValue['dramount'] != '0.00'){
                                        $temOverDueBalance -= $ovValue['dramount'];
                                        $date1 = $ovValue['trn_date'];
                                        $date2 = $overdueDateFrom;
            
                                        $diff = abs(strtotime($date2) - strtotime($date1));
            
                                        $dateDifference = floor($diff / (60 * 60 * 24)).' days';
                                        if($temOverDueBalance >= 0){
                                            $getData[$ovKey]['overdue_by_day'] = $dateDifference;
                                            $getData[$ovKey]['overdue_status'] = 'Overdue';
                                        }else{
                                            $getData[$ovKey]['overdue_by_day'] = $dateDifference;
                                            $getData[$ovKey]['overdue_status'] = 'Pertial Overdue';
                                        }
                                    }
                                }
                            }
                        }
                        if(count($getData) > 0){
                            $statementArray[$key]['statement'] = array_reverse($getData);
                        }                        
                    }
                }
            }
            // echo "<pre>";print_r($statementArray);die;
            // $overdueAmount = ceil($overdueAmount);
            if ($overdueAmount <= 0) {
                $overdueDrOrCr = 'Cr';
                $overdueAmount = 0;
            } else {
                $overdueDrOrCr = 'Dr';
            }
            // $dueAmount = ceil($dueAmount);
            if ($dueAmount <= 0) {
                $dueDrOrCr = 'Cr';
                $dueAmount = 0;
            } else {
                $dueDrOrCr = 'Dr';
            }
            // --------------------------------- Calculate Due and Overdue amount --------------------------------------

            // Prepare and generate the PDF
            $randomNumber = rand(1000, 9999);
            $fileName = 'statement-' . $randomNumber . '.pdf';

            // Load the Blade view for the PDF generation
            $pdf = PDF::loadView('frontend.partials.statement_from_cart_pdf', compact(
                'userData',
                'statementArray',
                'from_date',
                'to_date',
                'overdueAmount',
                'overdueDrOrCr',
                'dueDrOrCr',
                'dueAmount'
            ))->save(public_path('statements/' . $fileName));

            return response()->json(['pdf_url' =>'public/statements/' . $fileName]);
        } catch (\Exception $e) {
            // Log any other exceptions
            \Log::error('An error occurred: ' . $e->getMessage());
            return response()->json([
                'status' => 'Error',
                'message' => 'An unexpected error occurred.' . $e->getMessage(),
            ], 500);
        }
    }

   public function showCartModal(Request $request)
    {
        $product = Product::find($request->id);
        $order_id = $request->order_id;
        if (!$product) {
            return response()->json(['error' => 'Product not found'], 404);
        }

        try {
            // Initialize variables
            $attributeVariations = [];
            $selectedValues = [];

            if ($product->variant_product == 1) {
                // Fetch all products with the same variation_parent_part_no
                $parentProducts = Product::where('variation_parent_part_no', $product->variation_parent_part_no)
                    ->pluck('variations')
                    ->toArray();

                // Combine and get distinct variation IDs
                $allVariationIds = collect($parentProducts)
                    ->flatMap(function ($variations) {
                        return json_decode($variations, true);
                    })
                    ->unique()
                    ->toArray();

                // Fetch attribute values based on variation IDs
                $attributeValues = AttributeValue::whereIn('id', $allVariationIds)->get();

                // Fetch attributes and their corresponding values
                $attributeVariations = Attribute::whereIn('id', $attributeValues->pluck('attribute_id'))
                    ->where('is_variation', 1)
                    ->get()
                    ->map(function ($attribute) use ($attributeValues) {
                        return [
                            'attribute_id' => $attribute->id,
                            'attribute_name' => $attribute->name,
                            'values' => $attributeValues->where('attribute_id', $attribute->id)->pluck('value', 'id'),
                        ];
                    });

                // Get the selected values for the loaded product
                $selectedValues = $attributeValues->whereIn('id', json_decode($product->variations, true))
                    ->pluck('id', 'attribute_id');
            }
        } catch (\Exception $e) {
            // Log and return error for debugging
            \Log::error('Error fetching product variations: ' . $e->getMessage());
            return response()->json(['error' => 'An error occurred while fetching product variations'], 500);
        }

        // Return the view with the required data
        return view('frontend.partials.addToCart', compact('product', 'attributeVariations', 'selectedValues', 'order_id'));
    }


    public function addToCart(Request $request) {

        $product = Product::find($request->id);
        // echo "<pre>"; print_r($product);die;
        $carts   = array();
        $data    = array();

        if (auth()->user() != null) {
        $user_id         = Auth::user()->id;
        $data['user_id'] = $user_id;
        $carts = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
        } else {
        if ($request->session()->get('temp_user_id')) {
            $temp_user_id = $request->session()->get('temp_user_id');
        } else {
            $temp_user_id = bin2hex(random_bytes(10));
            $request->session()->put('temp_user_id', $temp_user_id);
        }
        $data['temp_user_id'] = $temp_user_id;
        $carts = Cart::where('temp_user_id', $temp_user_id)->get();
        }

        $data['product_id'] = $product->id;
        $data['owner_id']   = $product->user_id;

        $str     = '';
        $tax     = $ctax     = $price     = $carton_price     = 0;
        $wmarkup = 0;
        if ($product->digital != 1 && $request->quantity < $product->min_qty) {
        return array(
            'status'        => 0,
            'cart_count'    => count($carts),
            'modal_view'    => view('frontend.partials.minQtyNotSatisfied', ['min_qty' => $product->min_qty])->render(),
            'nav_cart_view' => view('frontend.partials.cart')->render(),
        );
        }

        //check the color enabled or disabled for the product
        if ($request->has('color')) {
        $str = $request['color'];
        }

        if ($product->digital != 1) {
        //Gets all the choice values of customer choice option and generate a string like Black-S-Cotton
        if(is_countable(json_decode(Product::find($request->id)->choice_options))){
            foreach (json_decode(Product::find($request->id)->choice_options) as $key => $choice) {
            if ($str != null) {
                $str .= '_' . str_replace(' ', '', strtolower($request['attribute_id_' . $choice->attribute_id]));
            } else {
                $str .= str_replace(' ', '', strtolower($request['attribute_id_' . $choice->attribute_id]));
            }
            }
        }
        
        }
        $str = $product->slug;
        $data['variation'] = $str;

        $product_stock = $product->stocks->where('variant', $str);
        
        //$price=calculate_discounted_price($product->mrp,false)['net_selling_price'];
        
        $user = Auth::user();

        $discount = 0;

        if ($user) {
            $discount = $user->discount;
        }

        if(!is_numeric($discount) || $discount == 0) {
            $discount = 20;
        }

        if($request->type == "piece"){
            $product_mrp = Product::where('id', $product->id)->select('mrp')->first();
            if ($product_mrp) {
                $price = $product_mrp->mrp;
            } else {
                $price = 0;
            }
            
            if (!is_numeric($price)) {
                $price = 0;
            }
            $price = $price * ((100 - $discount) / 100);
        }elseif($request->type == "bulk"){
            $price = $request->order_by_carton_price;
        }
        
        $data['quantity']  = $request['quantity'];
        $data['price']     = price_less_than_50($price,false);
        $data['tax']       = $tax;
        //$data['shipping'] = 0;
        $data['shipping_cost']         = 0;
        $data['product_referral_code'] = null;
        $data['cash_on_delivery']      = $product->cash_on_delivery;
        $data['cash_and_carry_item']      = $product->cash_and_carry_item;
        $data['digital']               = $product->digital;
        
        

        if ($request['quantity'] == null) {
        $data['quantity'] = 1;
        }

        if (Cookie::has('referred_product_id') && Cookie::get('referred_product_id') == $product->id) {
        $data['product_referral_code'] = Cookie::get('product_referral_code');
        }
        
        if ($carts && count($carts) > 0) {
        $foundInCart = false;
        foreach ($carts as $key => $cartItem) {
            $cart_product = Product::where('id', $cartItem['product_id'])->first();
            if ($cartItem['product_id'] == $request->id) {
            if ($cartItem['is_carton'] != $request['is_carton']) {
                $deleteCartRequest = new Request();
                $deleteCartRequest->replace(['id' => $cartItem['id']]);
                $this->removeFromCart($deleteCartRequest);
            }
            $product_stock = $cart_product->stocks->where('variant', $str);

            if (($str != null && $cartItem['variation'] == $str) || $str == null) {
                $foundInCart = true;
                $cartItem['quantity'] += $request['quantity'];
                $cartItem['price'] = $price;

                $cartItem->save();
            }
            }
        }
        if (!$foundInCart) {
            Cart::create($data);
        }
        } else {
        Cart::create($data);
        }

        if (auth()->user() != null) {
        $user_id = Auth::user()->id;
        $carts   = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
        } else {
        $temp_user_id = $request->session()->get('temp_user_id');
        $carts        = Cart::where('temp_user_id', $temp_user_id)->get();
        }
    
        return array(
        'status'        => 1,
        'cart_count'    => count($carts),
        'modal_view'    => view('frontend.partials.addedToCart', compact('product', 'data'))->render(),
        'nav_cart_view' => view('frontend.partials.cart')->render(),
        );
    }

    public function addProductToSplitOrder(Request $request) {
        try{
            $order_id = decrypt($request->order_id);
            $orderData = Order::where('id',$order_id)->first();
            $product = Product::find($request->id);
            // echo "<pre>"; print_r($product);die;
            $carts   = array();
            $data    = array();

            $data['order_id'] = $orderData->id;
            $data['seller_id'] = $product->seller_id;
            $data['product_id'] = $product->id;
            $data['owner_id']   = $product->user_id;

            $str     = '';
            $tax     = $ctax     = $price     = $carton_price     = 0;
            $wmarkup = 0;

            //check the color enabled or disabled for the product
            if ($request->has('color')) {
                $str = $request['color'];
            }

            if ($product->digital != 1) {
                //Gets all the choice values of customer choice option and generate a string like Black-S-Cotton
                if(is_countable(json_decode(Product::find($request->id)->choice_options))){
                    foreach (json_decode(Product::find($request->id)->choice_options) as $key => $choice) {
                        if ($str != null) {
                            $str .= '_' . str_replace(' ', '', strtolower($request['attribute_id_' . $choice->attribute_id]));
                        } else {
                            $str .= str_replace(' ', '', strtolower($request['attribute_id_' . $choice->attribute_id]));
                        }
                    }
                }        
            }
            $str = $product->slug;
            $data['variation'] = $str;

            $product_stock = $product->stocks->where('variant', $str);
            
            //$price=calculate_discounted_price($product->mrp,false)['net_selling_price'];
            
            $user = User::where('id',$orderData->user_id)->first();

            $discount = 0;

            if ($user) {
                $discount = $user->discount;
            }

            if(!is_numeric($discount) || $discount == 0) {
                $discount = 20;
            }

            if($request->type == "piece"){
                $product_mrp = Product::where('id', $product->id)->select('mrp')->first();
                if ($product_mrp) {
                    $price = $product_mrp->mrp;
                } else {
                    $price = 0;
                }
                
                if (!is_numeric($price)) {
                    $price = 0;
                }
                $price = $price * ((100 - $discount) / 100);
            }elseif($request->type == "bulk"){
                $price = $request->order_by_carton_price;
            }
            
            $data['quantity']  = $request['quantity'];
            $data['price']     = price_less_than_50($price,false);
            $data['tax']       = $tax;
            //$data['shipping'] = 0;
            $data['shipping_cost']         = 0;
            $data['product_referral_code'] = null;
            $data['cash_on_delivery']      = $product->cash_on_delivery;
            $data['cash_and_carry_item']      = $product->cash_and_carry_item;
            $data['digital']               = $product->digital;       

            if ($request['quantity'] == null) {
                $data['quantity'] = 1;
            }
            $getOrderDetails = OrderDetail::where('order_id', $order_id)->where('product_id',$product->id)->first();
            if($getOrderDetails == NULL){

                $order_detail = new OrderDetail;
                $order_detail->order_id = $orderData->id;
                $order_detail->seller_id = $product->user_id;
                $order_detail->product_id = $product->id;
                $order_detail->variation = $product->slug;

                $order_detail->quantity = $request['quantity'];
                $order_detail->price = price_less_than_50($price,false) * $request['quantity'];
                $order_detail->tax = $tax;
                $order_detail->shipping_cost = 0;
                $order_detail->product_referral_code = null;
                $order_detail->cash_and_carry_item = $product->cash_and_carry_item;
                $order_detail->save();
                
                $orderData->grand_total = $orderData->grand_total + (price_less_than_50($price,false) * $data['quantity']);
                $orderData->save();
            }
            
            
            // if (auth()->user() != null) {
            //     $user_id = Auth::user()->id;
            //     $carts   = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
            // } else {
            //     $temp_user_id = $request->session()->get('temp_user_id');
            //     $carts        = Cart::where('temp_user_id', $temp_user_id)->get();
            // }
        
            return array(
                'status'        => 1,
                'cart_count'    => count($carts),
                'modal_view'    => view('frontend.partials.addedToOrder', compact('product', 'data'))->render(),
            );
        } catch (\Exception $e) {
            return array('error' => $e->getMessage());
        }
    }

    public function removeProductFromSplitOrder(Request $request) {
        try{
            $getOrderDetails = OrderDetail::where('id',$request->order_details_id)->first();
            if($getOrderDetails != NULL){
                $getOrder = Order::where('id',$getOrderDetails->order_id)->first();
                $getOrder->grand_total = $getOrder->grand_total - $getOrderDetails->price;
                $getOrder->update();
                $getOrderDetails->delete();
                return response()->json(['msg' => 'Successfully delete this product from order.'], 200);
            }
        } catch (\Exception $e) {
            return array('error' => $e->getMessage());
        }
    }

  //removes from Cart
  public function removeFromCart(Request $request) {
    $cartItem = Cart::where('id',$request->id)->first();
    $offer_id = NULL;
    if(isset($cartItem->applied_offer_id)){
        $offer_id = $cartItem->applied_offer_id;
    }
    

    if($offer_id != NULL OR $offer_id != ""){
        $currentDate = now();
        $offers = Offer::with('offerProducts')
            ->where('status', 1)
            ->whereDate('offer_validity_start', '<=', $currentDate)
            ->whereDate('offer_validity_end', '>=', $currentDate)
            ->where('id', $offer_id)->first();
        $offerProducts = $offers->offerProducts;            
        foreach($offerProducts as $opKey=>$opValue){
            $cartProduct = Cart::where(function ($query) use ($opValue) {
                $query->where('user_id', Auth::user()->id)
                        ->orWhere('customer_id', Auth::user()->id);
            })->where('product_id', $opValue->product_id)->first();
            
            $product = Product::where('id',$opValue->product_id)->first();
            $price = $product->mrp * ((100 - Auth::user()->discount) / 100);
            $cartProduct->applied_offer_id = null;
            $cartProduct->price = $price;
            $cartProduct->save();
        }
        $cartProduct = Cart::where(function ($query) use ($opValue) {
            $query->where('user_id', Auth::user()->id)
                    ->orWhere('customer_id', Auth::user()->id);
        })->where('applied_offer_id', $offer_id)->where('complementary_item', '1')->delete();
    }

    Cart::destroy($request->id);

    if (auth()->user() != null) {
      $user_id = Auth::user()->id;
      $carts   = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
    } else {
      $temp_user_id = $request->session()->get('temp_user_id');
      $carts        = Cart::where('temp_user_id', $temp_user_id)->get();
    }

    // --------------------------------- Calculate Due and Overdue amount --------------------------------------
    $currentDate = date('Y-m-d');
    $currentMonth = date('m');
    $currentYear = date('Y');
    $overdueDateFrom="";
    $overdueAmount="0";

    $openingBalance="0";
    $drBalance = 0;
    $crBalance = 0;
    $dueAmount = 0;

    $userData = User::where('id', $user_id)->first();
    $userAddressData = Address::where('acc_code',"!=","")->where('user_id',$userData->id)->groupBy('gstin')->orderBy('acc_code','ASC')->get();
    foreach($userAddressData as $key=>$value){
        $party_code = $value->acc_code;
        if ($currentMonth >= 4) {
            $fy_form_date = date('Y-04-01'); // Start of financial year
            $fy_to_date = date('Y-03-31', strtotime('+1 year')); // End of financial year (next year)
        } else {
            $fy_form_date = date('Y-04-01', strtotime('-1 year')); // Previous year April
            $fy_to_date = date('Y-03-31'); // Current year March
        }
        $from_date = $fy_form_date;
        $to_date = $fy_to_date;
        $headers = [
            'authtoken' => '65d448afc6f6b',
        ];
        $body = [
            'party_code' => $party_code,
            'from_date' => $from_date,
            'to_date' =>  $to_date,
        ];
        $response = Http::withHeaders($headers)->post('https://saleszing.co.in/itaapi/getclientstatement.php', $body);
        \Log::info('Received response from Salzing API For Sync Statement Overdue Calculation', [
            'status' => $response->status(),
            'party_code' =>  $party_code,
            'body' => $response->body()
        ]);
        if ($response->successful()) {
            $getData = $response->json();
            if(!empty($getData) AND isset($getData['data']) AND !empty($getData['data'])){
                $getData = $getData['data'];
                $closingBalanceResult = array_filter($getData, function ($entry) {
                    return isset($entry['ledgername']) && $entry['ledgername'] === 'closing C/f...';
                });
                $closingEntry = reset($closingBalanceResult);
                $cloasingDrAmount = $closingEntry['dramount'];
                $cloasingCrAmount = $closingEntry['cramount'];
                $overdueDateFrom = date('Y-m-d', strtotime('-' . $userData->credit_days . ' days'));
                if($cloasingCrAmount > 0){
                    $drBalanceBeforeOVDate = 0;
                    $crBalanceBeforeOVDate = 0;
                    $getData = array_reverse($getData);
                    foreach($getData as $ovKey=>$gValue){
                        if($gValue['ledgername'] != 'closing C/f...'){
                            if(strtotime($gValue['trn_date']) > strtotime($overdueDateFrom)){
                                // $drBalanceBeforeOVDate += $ovValue['dramount'];
                                $crBalanceBeforeOVDate += $gValue['cramount'];
                            }else{
                                $drBalanceBeforeOVDate += $gValue['dramount'];
                                $crBalanceBeforeOVDate += $gValue['cramount'];
                            }
                        }
                        if ($gValue['dramount'] != 0.00 AND $gValue['ledgername'] != 'closing C/f...') {
                            $drBalance = $drBalance + $gValue['dramount'];
                            $dueAmount = $dueAmount + $gValue['dramount'];
                        } 
                        if($gValue['cramount'] != '0.00' AND $gValue['ledgername'] != 'closing C/f...') {
                            $crBalance = $crBalance + $gValue['cramount'];
                            $dueAmount = $dueAmount - $gValue['cramount'];
                        }
                    }
                    $overdueAmount = $drBalanceBeforeOVDate - $crBalanceBeforeOVDate;
                }
            }
        }
    }
    if($overdueAmount <= 0){
        $overdueAmount = 0;
    }
    // $overdueAmount = ceil($overdueAmount);
    // $dueAmount = ceil($dueAmount);
    $overdueAmount = $overdueAmount;
    $dueAmount = $dueAmount;
    session(['overdueAmount' => $overdueAmount]);
    session(['dueAmount' => $dueAmount]);
    // --------------------------------- Calculate Due and Overdue amount --------------------------------------

    // Offer Section 
    if(Auth::user()->id == '24185'){
        $carts = $this->addOfferTag($carts);
        $validOffersTemp = $this->checkValidOffer();
        $validOffers = $validOffersTemp['offers'] ?? [];
        $achiveOfferArray = $validOffersTemp['achiveOfferArray'] ?? [];
    }

    return array(
      'cart_count'    => count($carts),
      'cart_view'     => view('frontend.partials.cart_details', compact('carts'))->render(),
      'nav_cart_view' => view('frontend.partials.cart')->render(),
      'html' =>  view('frontend.partials.cartSummary', compact('carts','overdueAmount','dueAmount','validOffers','achiveOfferArray'))->render(),
    );
  }

    //updated the quantity for a cart item
    public function updateQuantity(Request $request) {
        $cartItem = Cart::findOrFail($request->id);

        if ($cartItem['id'] == $request->id) {
        $product       = Product::find($cartItem['product_id']);
        $product_stock = $product->stocks->where('variant', $cartItem['variation'])->first();
        $quantity      = $product_stock->qty;
        $price         = $product_stock->price;

        //discount calculation
        $discount_applicable = false;

        if ($product->discount_start_date == null) {
            $discount_applicable = true;
        } elseif (strtotime(date('d-m-Y H:i:s')) >= $product->discount_start_date &&
            strtotime(date('d-m-Y H:i:s')) <= $product->discount_end_date) {
            $discount_applicable = true;
        }

        if ($discount_applicable) {
            if ($product->discount_type == 'percent') {
            $price -= ($price * $product->discount) / 100;
            } elseif ($product->discount_type == 'amount') {
            $price -= $product->discount;
            }
        }

        if ($quantity >= $request->quantity) {
            if ($request->quantity >= $product->min_qty) {
            $cartItem['quantity'] = $request->quantity;
            }
        }

        if ($product->wholesale_product) {
            $wholesalePrice = $product_stock->wholesalePrices->where('min_qty', '<=', $request->quantity)->where('max_qty', '>=', $request->quantity)->first();
            if ($wholesalePrice) {
            $price = $wholesalePrice->price;
            }
        }

        $cartItem['price'] = $price;
        $cartItem->save();
        }

        if (auth()->user() != null) {
        $user_id = Auth::user()->id;
        $carts   = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
        } else {
        $temp_user_id = $request->session()->get('temp_user_id');
        $carts        = Cart::where('temp_user_id', $temp_user_id)->get();
        }

        return array(
        'cart_count'    => count($carts),
        'cart_view'     => view('frontend.partials.cart_details', compact('carts'))->render(),
        'nav_cart_view' => view('frontend.partials.cart')->render(),
        );
    }

    public function updateQuantityV02(Request $request) {
        $cartItem = Cart::findOrFail($request->id);
        $quantity = $request->quantity;
        $product = Product::find($cartItem->product_id);
        if($quantity >= $product->piece_by_carton ){
            $price = home_bulk_discounted_price($product,false)['price'];
        }else{
            $price = home_discounted_price($product,false)['price'];
        }
        // echo $price; die;
        if(Auth::user()->id == '24185'){
            if ($cartItem['id'] == $request->id) {
                // If offer already applied  
                if($cartItem['applied_offer_id'] != "" OR $cartItem['applied_offer_id'] != NULL){
                    $currentDate = now();
                    $appliedOffer = Offer::with('offerProducts')
                        ->where('status', 1)
                        ->whereDate('offer_validity_start', '<=', $currentDate)
                        ->whereDate('offer_validity_end', '>=', $currentDate)
                        ->where('id', $cartItem['applied_offer_id'])->first();
                    // If offer is valid then.
                    if ($appliedOffer !== NULL){                        
                        $offerProducts = $appliedOffer->offerProducts;
                        foreach($offerProducts as $opKey=>$opValue){
                            // If valid offer
                            if($appliedOffer->offer_type == 2){
                                
                                $cartItems = Cart::where(function ($query) {
                                    $query->where('user_id', Auth::user()->id)
                                          ->orWhere('customer_id', Auth::user()->id);
                                })
                                ->where('applied_offer_id', $cartItem['applied_offer_id'])
                                ->get(['product_id', 'quantity', 'price'])
                                ->groupBy('product_id');
                
                                // Prepare product IDs and quantities from the cart
                                $cartProductIds = $cartItems->keys()->toArray();                                
                                // Sum quantities for each product
                                $cartQuantities = $cartItems->mapWithKeys(function ($items, $productId) {
                                    return [$productId => $items->sum('quantity')];
                                })->toArray();

                                // Prepare prices for each product (assuming all prices for a given product are the same)
                                $cartItemPrice = $cartItems->mapWithKeys(function ($items, $productId) {
                                    return [$productId => $items->first()->price * $items->sum('quantity')]; // Use the price of the first item in the group
                                })->toArray();

                                // echo "<pre>";print_r($cartItemPrice);die;

                                $c_offer_price_calculate = 0 ;
                                foreach($cartQuantities as $cqKey=>$cqValue){
                                    $c_product = Product::find($cqKey);
                                    if($cqValue >= $product->piece_by_carton ){
                                        $c_price = home_bulk_discounted_price($c_product,false)['price'];
                                    }else{
                                        $c_price = home_discounted_price($c_product,false)['price'];
                                    }
                                    if($cqKey == $request->id){
                                        $c_offer_price_calculate += $c_price * $quantity;
                                    }else{
                                        $c_offer_price_calculate += $c_price * $cqValue;
                                    }                                    
                                }
                                // echo '@'.$appliedOffer->offer_value.'----'.$c_offer_price_calculate;
                                if(!empty($cartItems)){
                                    if($appliedOffer->offer_value > $c_offer_price_calculate){
                                        $this->removeOfferFromTable($cartItem['applied_offer_id']);                                    
                                        $cartItem->applied_offer_id = null;
                                        $cartItem->price = $price;
                                        $cartItem['quantity'] = $request->quantity;
                                        $cartItem->save(); 
                                    }else{
                                        $cartItem['quantity'] = $request->quantity;
                                        $cartItem->save();
                                    }
                                }else{
                                    $cartItem->price = $c_price;
                                    $cartItem['quantity'] = $request->quantity;
                                    $cartItem->save();
                                }
                            }else{
                                if($quantity < $opValue->min_qty AND $opValue->product_id == $product->id){
                                    $this->removeOfferFromTable($cartItem['applied_offer_id']);
                                    $cartItem['quantity'] = $request->quantity;
                                    $cartItem->applied_offer_id = null;
                                    $cartItem->price = $price;
                                    $cartItem->save();                                
                                }else{
                                    $cartItem['quantity'] = $request->quantity;
                                    // $cartItem->applied_offer_id = null;
                                    // if($opValue->discount_type == 'percent'){
                                    //     $price = $price * ((100 - $opValue->offer_discount_percent) / 100);
                                    // }else{
                                    //     $price = $opValue->offer_price;
                                    // }
                                    $cartItem->save(); 
                                } 
                            }                                    
                        }
                    }else{
                        // Offer Didn't get or not valid then remove the offer from all products if already have.
                        $offerProducts = $appliedOffer->offerProducts;            
                        foreach($offerProducts as $opKey=>$opValue){
                            $cartProduct = Cart::where(function ($query) use ($opValue) {
                                $query->where('user_id', Auth::user()->id)
                                    ->orWhere('customer_id', Auth::user()->id);
                            })->where('product_id', $opValue->product_id)->first();
                            
                            // $product = Product::where('id',$opValue->product_id)->first();
                            // $price = $product->mrp * ((100 - Auth::user()->discount) / 100);
                            $cartProduct->quantity = $request->quantity;
                            $cartProduct->applied_offer_id = null;
                            $cartProduct->price = $price;
                            $cartProduct->save();
                        }
                        $cartProduct = Cart::where(function ($query) use ($opValue) {
                            $query->where('user_id', Auth::user()->id)
                                ->orWhere('customer_id', Auth::user()->id);
                        })->where('applied_offer_id', $offer_id)->where('complementary_item', '1')->delete();
                    }              
                }else{
                    // echo "hello2"; die;
                    $cartItem['quantity'] = $request->quantity;
                    $cartItem['price'] = $price;
                    $cartItem->save();
                }
            }
        }else{
            $cartItem['quantity'] = $request->quantity;
            $cartItem['price'] = $price;
            $cartItem->save();
        }


        $user_id = Auth::user()->id;
        $carts = Cart::where('user_id', $user_id)->orWhere('customer_id', $user_id)->selectRaw('*, price * quantity as subtotal')->get();
        $totalSubtotal = $carts->sum('subtotal');
        $overdueAmount = $request->overdueAmount;
        $dueAmount = $request->dueAmount;
        
        $carts = Cart::where('user_id', $user_id)->orWhere('customer_id', $user_id)->get();
        $validOffers = array();
        $achiveOfferArray = array();
        // Offer Section 
        if(Auth::user()->id == '24185'){
            $carts = $this->addOfferTag($carts);
            $validOffersTemp = $this->checkValidOffer();
            $validOffers = $validOffersTemp['offers'] ?? [];
            $achiveOfferArray = $validOffersTemp['achiveOfferArray'] ?? [];
        }
        return array(
            'item_sub_total'    => format_price_in_rs($cartItem['price'] * $request->quantity),
            'span_sub_total'    => format_price_in_rs($totalSubtotal),
            'price' => format_price_in_rs($price),
            'update_price' => $price,
            // 'cart_summary'     => view('frontend.partials.cart_bill_amount_v02', compact('total','overdueAmount','cash_and_carry_item_flag','cash_and_carry_item_subtotal','cash_and_carry_item_subtotal','normal_item_flag','normal_item_subtotal'))->render(),
            'cart_summary'     => view('frontend.partials.cart_bill_amount_v02', compact('overdueAmount','dueAmount','validOffers','achiveOfferArray'))->render(),
            'nav_cart_view' => view('frontend.partials.cart')->render(),
            'html' =>  view('frontend.partials.cartSummary', compact('carts','overdueAmount','dueAmount','validOffers','achiveOfferArray'))->render(),
        );
    }
  // public function productDetails($id)
  // {
  //   $cart = Cart::where('id',$id)->with('product')->first();
  //   return [
  //     'cart' => $cart,
  //     'product' => $cart['product'],
  //     'brand' => $cart['product']['brand'],
  //     'category' => $cart['product']['category'],
  //     'stocks' => $cart['product']['stocks']->first(),
  //   ];
  // }

  public function productDetails($id)
  {
    try {
        $cart = Cart::where('id', $id)->with('product')->first();

        if (!$cart) {
            return response()->json(['error' => 'Cart not found'], 404);
        }

        $product = $cart->product;

        if (!$product) {
            return response()->json(['error' => 'Product not found in cart'], 404);
        }

        $brand = $product->brand;
        $category = $product->category;
        $stocks = $product->stocks->first();

        return [
            'cart' => $cart,
            'product' => $product,
            'brand' => $brand,
            'category' => $category,
            'stocks' => $stocks,
        ];
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500);
    }
  }


  // ABANDONED CART CODE START


  public function sendBulkWhatsApp(Request $request)
  {

    // send whatsapp button
  
      $userIds = $request->input('selected_carts');
      // Make the IDs distinct
    $userIds = array_unique($userIds);
      // echo "<pre>";
      // print_r($userIds);
      // die();

      if ($userIds) {
          foreach ($userIds as $userId) {
            $user = DB::table('users')
            ->join('carts', 'users.id', '=', 'carts.user_id')
            ->select('users.company_name', 'users.phone','users.manager_id')
            ->where('users.id', $userId)
            ->first();

            if (!$user) {
              return response()->json(['error' => 'User not found'], 404);
            }
             // Retrieve manager's information
             $manager = DB::table('users')
             ->select('name', 'phone')
             ->where('id', $user->manager_id)
             ->first();

              // Example of sending WhatsApp messages
              $cartItems = DB::table('carts')
              ->join('products', 'carts.product_id', '=', 'products.id')
              ->select('products.name as product_name', 'carts.quantity')
              ->where('carts.user_id', $userId)
              ->get();
  
              $itemCount = $cartItems->count();
            
                  $name = $user->company_name;
                 
                  $invoice=new InvoiceController();
                  $randomNumber = rand(1000, 9999); // Generates a random number between 1000 and 9999

                  $file_url=$invoice->invoice_file_path_abandoned_cart($userId,$randomNumber);
                  $file_name="Abandoned Cart";
                  $multipleItems = [
                    'name' => 'utility_abandoned_cart', // Replace with your template name, e.g., 'abandoned_cart_template'
                    'language' => 'en_US', // Replace with your desired language code
                    'components' => [
                        [
                            'type' => 'header',
                            'parameters' => [
                                ['type' => 'document', 'document' => ['link' => $file_url,'filename' => $file_name,]],
                            ],
                        ],
                        [
                            'type' => 'body',
                            'parameters' => [
                                ['type' => 'text', 'text' => $name],
                                ['type' => 'text', 'text' => $itemCount], // Second variable (Total Count)
                            ],
                        ],
                    ],
                ];

                 $this->WhatsAppWebService = new WhatsAppWebService();
                 $response = $this->WhatsAppWebService->sendTemplateMessage($user->phone, $multipleItems);
                  $response1 = $this->WhatsAppWebService->sendTemplateMessage($manager->phone, $multipleItems);
                  //$response2 = $this->WhatsAppWebService->sendTemplateMessage('+919894753728', $multipleItems);
                 return redirect()->back()->with('status', 'WhatsApp messages sent successfully!');
             
          }

          return redirect()->back()->with('status', 'WhatsApp messages sent successfully!')->withInput($request->all());
      }

      return redirect()->back()->with('status', 'No carts selected')->withInput($request->all());
  }


  public function abandoned_cart_send_single_whatsapp($cart_id)
  {

        // $userId = $user_id;
        $user = DB::table('users')
            ->join('carts', 'users.id', '=', 'carts.user_id')
            ->select('users.company_name', 'users.phone','users.manager_id','carts.user_id')
            ->where('carts.id', $cart_id)
            ->first();
       
        
        $userId = $user->user_id;
           
        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }

        // Retrieve manager's information
        $manager = DB::table('users')
        ->select('name', 'phone')
        ->where('id', $user->manager_id)
        ->first();

        $cartItems = DB::table('carts')
        ->join('products', 'carts.product_id', '=', 'products.id')
        ->select('products.name as product_name', 'carts.quantity')
        ->where('carts.user_id', $userId)
        ->get();
       


        $itemCount = $cartItems->count();

            // $itemCount = $cartItems->count();

        // $name = $user->company_name;
        // $item1 = $cartItems->product_name ?? 'N/A';
        // $qty1 = $cartItems->quantity ?? '0';

       

        $name = $user->company_name;
                 
        $invoice=new InvoiceController();
        $randomNumber = rand(1000, 9999); // Generates a random number between 1000 and 9999

        $file_url=$invoice->invoice_file_path_abandoned_cart($userId,$randomNumber);
        $file_name="Abandoned Cart";
        $multipleItems = [
          'name' => 'utility_abandoned_cart', // Replace with your template name, e.g., 'abandoned_cart_template'
          'language' => 'en_US', // Replace with your desired language code
          'components' => [
              [
                  'type' => 'header',
                  'parameters' => [
                      ['type' => 'document', 'document' => ['link' => $file_url,'filename' => $file_name,]],
                  ],
              ],
              [
                  'type' => 'body',
                  'parameters' => [
                      ['type' => 'text', 'text' => $name],
                      ['type' => 'text', 'text' => $itemCount], // Second variable (Total Count)
                  ],
              ],
          ],
      ];

        $this->WhatsAppWebService = new WhatsAppWebService();
         $response = $this->WhatsAppWebService->sendTemplateMessage($user->phone, $multipleItems);
         $response1 = $this->WhatsAppWebService->sendTemplateMessage($manager->phone, $multipleItems);
        //$response2 = $this->WhatsAppWebService->sendTemplateMessage('+916289062983', $multipleItems);

        return redirect()->back()->with('status', 'WhatsApp messages sent successfully!');
        
  }

  public function abandoned_cart_send_whatsapp(Request $request)
  {

    // whatsapp all
    set_time_limit(3000); 
    
      $distinctUser = DB::table('users')
          ->join('carts', 'users.id', '=', 'carts.user_id')
          ->join('products', 'carts.product_id', '=', 'products.id')
          ->select('users.company_name', 'users.phone', 'carts.user_id','users.manager_id')
          //  ->where('carts.user_id', 24185)
          ->groupBy('carts.user_id', 'users.name')
          ->get();
  
      $responses = [];
  
      foreach ($distinctUser as $user) {

         // Retrieve manager's information
          $manager = DB::table('users')
          ->select('name', 'phone')
          ->where('id', $user->manager_id)
          ->first();

          $cartItems = DB::table('carts')
              ->join('products', 'carts.product_id', '=', 'products.id')
              ->select('products.name as product_name', 'carts.quantity')
              ->where('carts.user_id', $user->user_id)
              ->get();
  
             $itemCount = $cartItems->count();
  
              $name = $user->company_name;

              $invoice=new InvoiceController();
              $randomNumber = rand(1000, 9999); // Generates a random number between 1000 and 9999

              $file_url=$invoice->invoice_file_path_abandoned_cart($user->user_id,$randomNumber);
              $file_name="Abandoned Cart";

              $multipleItems = [
                'name' => 'utility_abandoned_cart', // Replace with your template name, e.g., 'abandoned_cart_template'
                'language' => 'en_US', // Replace with your desired language code
                'components' => [
                    [
                        'type' => 'header',
                        'parameters' => [
                            ['type' => 'document', 'document' => ['link' => $file_url,'filename' => $file_name,]],
                        ],
                    ],
                    [
                        'type' => 'body',
                        'parameters' => [
                            ['type' => 'text', 'text' => $name],
                            ['type' => 'text', 'text' => $itemCount], // Second variable (Total Count)
                        ],
                    ],
                ],
            ];
  
              $this->WhatsAppWebService = new WhatsAppWebService();
              $response = $this->WhatsAppWebService->sendTemplateMessage($user->phone, $multipleItems);
              $response1 = $this->WhatsAppWebService->sendTemplateMessage($manager->phone, $multipleItems);
              $response2 = $this->WhatsAppWebService->sendTemplateMessage('+919894753728', $multipleItems);
              $responses[] = $response;
         
      }
  
      return redirect()->back()->with('status', 'WhatsApp messages sent to all successfully!');
  }
  
  public function abandoned_cart_list(Request $request)
{

  
    // Retrieve the filters and sorting options from the request
    $searchDate = $request->input('searchDate');
    $searchManagers = $request->input('searchManager', []); // Accept multiple manager IDs
    // $searchPartyCodes = $request->input('searchPartyCode', []); // Accept multiple party codes
    $searchCompanyNames = $request->input('searchCompanyName', []); // Accept multiple company names
    $sortField = $request->input('sortField', 'carts.created_at'); // Default sort field
    $sortDirection = $request->input('sortDirection', 'desc'); // Default sort direction

    $currentUserId = auth()->user()->id;

    // Determine if the current user should see all data or only data related to their manager_id
    $isSuperManager = in_array($currentUserId, [180, 169, 25606, 1]);

    // Get distinct managers based on the current user role
    $distinctManagersQuery = DB::table('users')
        ->join('carts', 'users.id', '=', 'carts.user_id')
        ->select('users.manager_id')
        ->groupBy('users.manager_id');

    if (!$isSuperManager) {
        $distinctManagersQuery->where('users.manager_id', '=', $currentUserId);
    }

    $distinctManagers = $distinctManagersQuery->get();

    // Get distinct party codes for the dropdown
    $distinctPartyCodes = DB::table('users')
        ->join('carts', 'users.id', '=', 'carts.user_id')
        ->select('users.party_code')
        ->groupBy('users.party_code')
        ->get();

    // Get distinct company names for the dropdown
    $distinctCompanyNames = DB::table('users')
        ->join('carts', 'users.id', '=', 'carts.user_id')
        ->select('users.company_name')
        ->groupBy('users.company_name')
        ->get();

    // Start building the main query
    $query = DB::table('users as u1')
        ->join('carts', 'u1.id', '=', 'carts.user_id')
        ->join('products', 'carts.product_id', '=', 'products.id')
        ->join('users as u2', 'u1.manager_id', '=', 'u2.id') // Join to get the manager's name
        ->select(
            'u1.company_name',
            'u1.phone',
            'u1.manager_id',
            'u1.party_code',
            'u2.name as manager_name', // Select manager's name
            'products.name as product_name',
            'carts.created_at',
            'carts.quantity',
            'carts.price',
            'carts.user_id',
            'carts.product_id',
            'carts.id as cart_id',
            DB::raw('carts.quantity * carts.price as total') // Calculate total per item
        );

    // Apply manager filter
    if ($isSuperManager) {
        if (!empty($searchManagers)) {
            $query->whereIn('u1.manager_id', $searchManagers);
        }
    } else {
        $query->where('u1.manager_id', '=', $currentUserId);
    }

    // Apply party code filter
    // if (!empty($searchPartyCodes)) {
    //     $query->whereIn('u1.party_code', $searchPartyCodes);
    // }

    // Apply company name filter
    if (!empty($searchCompanyNames)) {
        $query->whereIn('u1.company_name', $searchCompanyNames);
    }

    // Apply the date filter if it exists
    if ($searchDate) {
        $query->whereDate('carts.created_at', '=', $searchDate);
    }

    // Get the total sum of all items
    $totalSum = $query->sum(DB::raw('carts.quantity * carts.price'));

    // Apply sorting
    // $abandonedCart = $query->orderBy($sortField, $sortDirection)
    //     ->paginate(50)
    //     ->appends($request->all());

    $abandonedCart = $query->orderBy($sortField, $sortDirection)
        ->get();


        
        

    return view('backend.abandoned_cart.abandoned_cart_list', compact('abandonedCart', 'distinctManagers', 'distinctPartyCodes', 'distinctCompanyNames', 'totalSum'));
}

public function fetchCompanies(Request $request)
{
    $managerId = $request->input('manager_id');
    
    // Fetch distinct company names based on the selected manager
    $companies = DB::table('users')
        ->select('company_name')
        ->where('manager_id', $managerId)
        ->distinct()
        ->get();

    return response()->json($companies);
}

public function clearCart(Request $request)
{
    $userIds = $request->input('user_ids');

    if (empty($userIds)) {
        return response()->json(['success' => false, 'message' => 'No carts selected.']);
    }

    // Use query builder to delete all cart items for the selected user_ids
    DB::table('carts')->whereIn('user_id', $userIds)->delete();

    return response()->json(['success' => true, 'message' => 'All items for the selected users have been cleared successfully.']);
}


public function deleteCartItem(Request $request)
{
    // Get the user ID and product ID from the request
    $userId = $request->input('user_id');
    $productId = $request->input('product_id');

    // Validate that both user ID and product ID are provided
    if (!$userId || !$productId) {
        return response()->json([
            'success' => false,
            'message' => 'User ID and Product ID are required.'
        ]);
    }

    // Find the specific cart item for the user and product
    $cartItem = Cart::where('user_id', $userId)
                    ->where('product_id', $productId)
                    ->first();

    // Check if the cart item exists
    if ($cartItem) {
        // Delete the specific cart item
        $cartItem->delete();

        // Return success response
        return response()->json([
            'success' => true,
            'message' => 'Cart item has been removed successfully.'
        ]);
    }

    // If the specific cart item is not found
    return response()->json([
        'success' => false,
        'message' => 'No cart item found for the specified user and product.'
    ]);
}







public function abandonedCartExportList(Request $request){
  $searchDate = $request->input('searchDate');
  $searchManagers = $request->input('searchManager', []);
  $searchCompanyNames = $request->input('searchCompanyName', []);

  $currentUserId = auth()->user()->id;
  $isSuperManager = in_array($currentUserId, [180, 169, 25606, 1]);

  $query = DB::table('users as u1')
      ->join('carts', 'u1.id', '=', 'carts.user_id')
      ->join('products', 'carts.product_id', '=', 'products.id')
      ->join('users as u2', 'u1.manager_id', '=', 'u2.id')
      ->select(
          'u1.company_name',
          'u1.phone',
          'u1.manager_id',
          'u1.party_code',
          'u2.name as manager_name',
          'products.name as product_name',
          'carts.created_at',
          'carts.quantity',
          'carts.price',
          DB::raw('carts.quantity * carts.price as total')
      );

  // Apply filters based on the request
  if ($isSuperManager) {
      if (!empty($searchManagers)) {
          $query->whereIn('u1.manager_id', $searchManagers);
      }
  } else {
      $query->where('u1.manager_id', '=', $currentUserId);
  }

  if (!empty($searchCompanyNames)) {
      $query->whereIn('u1.company_name', $searchCompanyNames);
  }

  if ($searchDate) {
      $query->whereDate('carts.created_at', '=', $searchDate);
  }

  $abandonedCartData = $query->get();

  // Export the data to Excel
  return Excel::download(new AbandonedCartExport($abandonedCartData), 'abandoned_carts.xlsx');
}
    


  



  public function abandoned_cart_save_remark(Request $request){
    // return response()->json(['success' => true, 'message' => 'Remark saved successfully!']);
    // Validate the incoming request data
        $request->validate([
          'remark' => 'required'
          
      ]);

      // Insert the data into the remarks table
      DB::table('remarks')->insert([
          'remark_description' => $request->input('remark'),
          'created_at' => now(),
          'updated_at' => now(),
          'user_id' => $request->input('user_id'),
          'cart_id' => $request->input('cart_id'),
      ]);

      // Return a JSON response indicating success
      return response()->json([
          'success' => true,
          'message' => 'Remark saved successfully!',
      ]);
  }

  public function viewRemark($cart_id)
    {
        // Fetch the remark based on the cart_id
      
        $remarks = DB::table('remarks')
        ->join('users', 'remarks.user_id', '=', 'users.id')
        ->join('carts', 'remarks.cart_id', '=', 'carts.id')
        ->join('products', 'carts.product_id', '=', 'products.id')
        ->select(
            'remarks.remark_description',
            'remarks.created_at',
            'users.name as user_name',
            'carts.quantity',
            'carts.price',
            'products.name as product_name'
        )
        ->where('remarks.cart_id', $cart_id)
        ->get();

        // Pass the remark data to the view
        return view('backend.abandoned_cart.view_remark', compact('remarks'));
    }

    public function getRemarks(Request $request)
    {
        $cart_id = $request->input('cart_id');
    
        $remarks = DB::table('remarks')
            ->join('users', 'remarks.user_id', '=', 'users.id')
            ->select('remarks.remark_description', 'remarks.created_at', 'users.name as user_name')
            ->where('remarks.cart_id', $cart_id)
            ->orderBy('remarks.created_at', 'desc')
            ->get();
    
        if ($remarks->isNotEmpty()) {
            return response()->json([
                'success' => true,
                'remarks' => $remarks
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'No remarks found for the selected cart.'
            ]);
        }
    }


    public function send_quotations(Request $request) {
      $user_id = Auth::user()->id;

      // Retrieve manager's information
      $manager = DB::table('users')
      ->select('name', 'phone')
      ->where('id', Auth::user()->manager_id)
      ->first();

      // Retrieve all cart items related to the user, including the warehouse name
      $cartItems = DB::table('users')
          ->leftJoin('carts', 'users.id', '=', 'carts.user_id')
          ->leftJoin('products', 'carts.product_id', '=', 'products.id')
          ->leftJoin('warehouses', 'users.warehouse_id', '=', 'warehouses.id') // Join with warehouses table via users table
          ->leftJoin('addresses', 'carts.address_id', '=', 'addresses.id')
          ->select(
              'users.company_name',
              'users.phone',
              'users.manager_id',
              'users.party_code',
              'products.name as product_name',
              'warehouses.name as warehouse_name', // Get the warehouse name with alias
              'carts.created_at',
              'carts.quantity',
              'carts.address_id',
              'carts.price',
              'carts.user_id',
              'carts.product_id',
              'carts.id as cart_id',
              DB::raw('carts.quantity * carts.price as total') // Calculate total per item
          )
          ->where('carts.user_id', $user_id)  // Add the where condition
          ->get();
  
      // Get the warehouse name of the user
      $warehouse_name = strtoupper(substr($cartItems->first()->warehouse_name, 0, 3)); // Extract the first 3 letters and convert to uppercase
  
      // Generate the new quotation_id
      $maxQuotationId = DB::table('quotations')
          ->where('quotation_id', 'LIKE', $warehouse_name . '-%')
          ->orderBy('quotation_id', 'desc')
          ->value('quotation_id');
  
      if ($maxQuotationId) {
          $lastNumber = (int)substr($maxQuotationId, strlen($warehouse_name) + 1);
          $newNumber = $lastNumber + 1;
      } else {
          $newNumber = 1;
      }
  
      $newQuotationId = $warehouse_name . '-' . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
      
      foreach ($cartItems as $item) {
          DB::table('quotations')->insert([
              'cart_id' => $item->cart_id,
              'user_id' => $user_id,
              'quotation_id' => $newQuotationId, // Use the new quotation ID
              'status' => '0', // Set the initial status
              'created_at' => now(),
              'updated_at' => now(),
          ]);
      }
      
      $invoice=new InvoiceController();
      $file_url=$invoice->invoice_file_path_cart_quotations($user_id,$newQuotationId);
     
      $file_name="Quotations";
     // $to=['+916289062983'];
      $to=[Auth::user()->phone,$manager->phone,'+919894753728'];

      $templateData = [
        'name' => 'utility_quotation',
        'language' => 'en', 
        'components' => [
            [
                'type' => 'header',
                'parameters' => [
                    [
                        'type' => 'document', // Use 'image', 'video', etc. as needed
                        'document' => [
                            'link' => $file_url,
                            'filename' => $file_name,
                        ]
                    ]
                ]
            ],
            [
                'type' => 'body',
                'parameters' => [
                    ['type' => 'text', 'text' => $newQuotationId],
                ],
            ],
        ],
    ];
    

      $this->WhatsAppWebService=new WhatsAppWebService();
      foreach($to as $person_to_send){
        $response = $this->WhatsAppWebService->sendTemplateMessage($person_to_send, $templateData);
      }

      return response()->json(['status' => 'Quotation Sent to whatsapp!']);
  }
  
  

  // ABANDONED CART CODE END


      //purchase order code start
      //negative stock inventory
      public function purchase_order(Request $request) {
       
        // Retrieve the list of sellers for the dropdown
        $sellers = DB::table('users')
            ->join('sellers', 'users.id', '=', 'sellers.user_id')
            ->select('users.id', 'users.name')
            ->orderBy('users.name', 'asc')
            ->get();
    
       // Start query for purchase orders
        $query = DB::table('purchase_order')
        ->leftJoin('products', 'purchase_order.part_no', '=', 'products.part_no')
        ->leftJoin('sellers', 'products.seller_id', '=', 'sellers.id')
        ->leftJoin('users', 'sellers.user_id', '=', 'users.id')
        ->leftJoin('shops', 'sellers.id', '=', 'shops.seller_id') // Join sellers with shops
        ->select(
            'purchase_order.*',
            'products.seller_id',
            'sellers.user_id',
            'users.name as seller_name',
            'shops.name as seller_company_name' // Retrieve name as seller_company_name
        )
        // Add the condition to exclude records where delete_status is 1
        ->where('purchase_order.delete_status', '!=', 1);
    
        // Apply seller name filter if provided
        if ($request->filled('sellerName')) {
            $query->where('users.id', '=', $request->sellerName);
        }
    
        // Apply sorting if provided
        if ($request->filled('sort') && $request->filled('direction')) {
            $query->orderBy($request->sort, $request->direction);
        } else {
            $query->orderBy('purchase_order.id', 'asc'); // Default sorting
        }
    
        // Get paginated results
        $purchaseOrders = $query->paginate(100)->appends($request->all());
        // echo "<pre>";
        // print_r($purchaseOrders);
        // die();
    
        return view('backend.purchase_order.purchase_order', compact('purchaseOrders', 'sellers'));
    }

    public function purchaseOrderDeleteItems($id, Request $request)
    {
        // Validate the ID exists
        $order = DB::table('purchase_order')->where('id', $id)->first();
       
        
        if (!$order) {
            return redirect()->back()->with('status', 'Purchase order not found!');
        }

        // Get the order_id from the $order object
        $orderId = $order->order_no; // Assuming 'order_id' is the correct field name

        // Delete the purchase order
        // DB::table('purchase_order')->where('id', $id)->delete();
         // Update the delete_status to 1 instead of deleting the purchase order
        DB::table('purchase_order')
        ->where('id', $id)
        ->update(['delete_status' => 1]);

        // Redirect back with a success message, including the order_id
        return redirect()->back()->with('status', "Purchase order with Order ID $orderId deleted successfully!")->withInput($request->all());
    }

    


    public function showSelected(Request $request)
    {

      
        // Get the selected orders' IDs
        $selectedOrders = $request->input('selectedOrders', []);
        
        // Fetch the selected orders from the database, grouping by part_no and combining order_no and quantities
        $orders = DB::table('purchase_order')
            ->whereIn('purchase_order.id', $selectedOrders)
            ->leftJoin('products', 'purchase_order.part_no', '=', 'products.part_no')
            ->leftJoin('sellers', 'products.seller_id', '=', 'sellers.id')
            ->leftJoin('shops', 'sellers.id', '=', 'shops.seller_id')
            ->select(
                'purchase_order.part_no',
                'purchase_order.item',
                DB::raw('GROUP_CONCAT(DISTINCT purchase_order.order_no ORDER BY purchase_order.order_no ASC SEPARATOR ", ") as order_no'),
                DB::raw('GROUP_CONCAT(DISTINCT purchase_order.age ORDER BY purchase_order.age ASC SEPARATOR ", ") as age'),
                DB::raw('GROUP_CONCAT(DISTINCT DATE_FORMAT(purchase_order.order_date, "%d/%m/%y") ORDER BY purchase_order.order_date ASC SEPARATOR ", ") as order_date'),
                DB::raw('SUM(purchase_order.to_be_ordered) as total_quantity'),
                'products.seller_id',
                'products.purchase_price',
                'shops.name as seller_company_name',
                'shops.address as seller_address',
                'sellers.gstin as seller_gstin',
                'shops.phone as seller_phone'
            )
            ->groupBy('purchase_order.part_no', 'purchase_order.item', 'products.seller_id', 'products.purchase_price', 'shops.name', 'shops.address', 'sellers.gstin', 'shops.phone')
            ->get();

            // Fetch warehouses with id 1, 2, and 6
          $warehouses = DB::table('warehouses')
              ->whereIn('id', [1, 2, 6])
              ->select('id', 'name')
              ->get();

               // Fetch all sellers for the dropdown
          // $all_sellers = DB::table('sellers')
          //     ->join('shops', 'sellers.id', '=', 'shops.seller_id')
          //     ->select('sellers.id', 'shops.name as seller_company_name')
          //     ->get();

               // Fetch all sellers from final_purchase_order (JSON column 'seller_info')
    $all_sellers = DB::table('final_purchase_order')
        ->select(DB::raw('JSON_UNQUOTE(JSON_EXTRACT(seller_info, "$.seller_name")) as seller_name'))
        ->distinct()
        ->get();

              // Get the current seller ID from the first order in the collection (if any orders exist)
          // $current_seller_id = $orders->isNotEmpty() ? $orders->first()->seller_id : null;
        $current_seller_name = $orders->isNotEmpty() ? $orders->first()->seller_company_name : null;
          // echo $current_seller_id;
          // die();

        // Check if $orders is empty
        // Ensure $orders is not null
        if ($orders->isEmpty()) {
          $orders = collect(); // This will make $orders an empty collection
      }
      
      return view('backend.purchase_order.selected_orders', compact('orders', 'warehouses','all_sellers','current_seller_name'));
    }

     public function getSellerInfo($seller_name)
    {
        // Fetch the seller information based on the seller name from final_purchase_order
        $seller = DB::table('final_purchase_order')
            ->select(DB::raw('JSON_UNQUOTE(JSON_EXTRACT(seller_info, "$.seller_name")) as seller_name'),
                     DB::raw('JSON_UNQUOTE(JSON_EXTRACT(seller_info, "$.seller_address")) as seller_address'),
                     DB::raw('JSON_UNQUOTE(JSON_EXTRACT(seller_info, "$.seller_gstin")) as seller_gstin'),
                     DB::raw('JSON_UNQUOTE(JSON_EXTRACT(seller_info, "$.seller_phone")) as seller_phone'))
            ->where(DB::raw('JSON_UNQUOTE(JSON_EXTRACT(seller_info, "$.seller_name"))'), $seller_name)
            ->first();

        // Return the seller information as a JSON response
        return response()->json($seller);
    }

   // Function to get the message status by ID
    public function getMessageStatusById($messageId)
    {
        // Set up the database connection dynamically within the function
        config([
            'database.connections.dynamic_mazingbusiness' => [
                'driver' => 'mysql',
                'host' => 'localhost',  // Replace with your cloud database host
                'port' => '3306',  // Replace with your cloud database port
                'database' => 'mazingbusiness',  // The database name is 'mazingbusiness'
                'username' => 'mazingbusiness',   // Replace with your database username
                'password' => 'Gd6de243%',   // Replace with your database password
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'prefix' => '',
                'strict' => true,
                'engine' => null,
            ]
        ]);

        // Fetch the message data from the cloud_response database
        $cloudResponseData = DB::connection('dynamic_mazingbusiness')
            ->table('cloud_response')
            ->where('msg_id', $messageId)
            ->first();

        return $cloudResponseData->status;
    }

    

    public function saveSelected(Request $request)
    {

        // Validate the input data
        $validatedData = $request->validate([
            'orders.*.quantity' => 'required|integer|min:0',
            'orders.*.purchase_price' => 'required|numeric|min:0',
            'orders.*.order_no' => 'required|string',
            'seller_info.seller_name' => 'required|string|max:255',
            'seller_info.seller_phone' => 'required|string|max:15',
            'warehouse_id' => 'required'
        ], [
            'orders.*.quantity.required' => 'Quantity is required for each item.',
            'orders.*.quantity.integer' => 'Quantity must be a valid number.',
            'orders.*.purchase_price.required' => 'Purchase price is required for each item.',
            'orders.*.purchase_price.numeric' => 'Purchase price must be a valid number.',
            'orders.*.order_no.required' => 'Order number is required.',
            'seller_info.seller_name.required' => 'Seller name is required.',
            'seller_info.seller_phone.required' => 'Seller phone is required.',
            'warehouse_id.required' => 'Warehouse selection is required.', 
        ]);

        $sellerId = null;
        $productInfo = [];
        $orderNumbers = [];
        $productInfoWithOutZeroQty = [];

        foreach ($request->input('orders') as $orderId => $orderData) {
            $partNo = $orderData['part_no'];
            $quantity = $orderData['quantity'];
            $purchasePrice = $orderData['purchase_price'];
            $currentSellerId = $orderData['seller_id'];
            $orderNo = $orderData['order_no'];
            $orderDate =  $orderData['order_date'];
            $age =  $orderData['age'];

            if (!$sellerId) {
                $sellerId = $currentSellerId;
            }

            DB::table('products')
                ->where('part_no', $partNo)
                ->update(['purchase_price' => $purchasePrice]);

            $orderNoWithDate = $orderNo . " ($orderDate)";

            $productInfo[] = [
                'part_no' => $partNo,
                'qty' => $quantity,
                'order_no' => $orderNoWithDate,
                'age' => $age
            ];

            if ($quantity != 0) {
                $productInfoWithOutZeroQty[] = [
                    'part_no' => $partNo,
                    'qty' => $quantity,
                    'order_no' => $orderNoWithDate,
                    'age' => $age,
                ];

                DB::table('purchase_order')
                ->where('part_no', $partNo)
                ->where('order_no', $orderNo)
                ->update(['delete_status' => 1]);
            }

            $orderNumbers[] = $orderNoWithDate;
        }

        $lastOrder = DB::table('final_purchase_order')
            ->orderBy('id', 'desc')
            ->first();

        if ($lastOrder) {
            $lastOrderNumber = intval(substr($lastOrder->purchase_order_no, 3));
            $newOrderNumber = $lastOrderNumber + 1;
        } else {
            $newOrderNumber = 1;
        }

        $purchaseOrderNo = 'po-' . str_pad($newOrderNumber, 3, '0', STR_PAD_LEFT);

        $orderNumbersString = implode(',', array_unique($orderNumbers));

        $sellerInfo = [
            'seller_name' => $request->input('seller_info.seller_name'),
            'seller_address' => $request->input('seller_info.seller_address'),
            'seller_gstin' => $request->input('seller_info.seller_gstin'),
            'seller_phone' => $request->input('seller_info.seller_phone'),
        ];

        $data = [
            'purchase_order_no' => $purchaseOrderNo,
            'order_no' => $orderNumbersString,
            'date' => now()->format('Y-m-d'),
            'seller_id' => $sellerId,
            'product_info' => json_encode($productInfoWithOutZeroQty),
            'product_invoice' => json_encode($productInfoWithOutZeroQty),
            'seller_info' => json_encode($sellerInfo),
            'created_at' => now(),
            'updated_at' => now(),
        ];

        DB::table('final_purchase_order')->insert($data);

        $seller_warehouse = DB::table('final_purchase_order as fpo')
        ->join('sellers as s', 'fpo.seller_id', '=', 's.id')
        ->join('users as u', 's.user_id', '=', 'u.id')
        ->where('fpo.purchase_order_no', $purchaseOrderNo)
        ->value('u.warehouse_id');

        $invoiceController = new InvoiceController();
        $fileUrls = [
            $invoiceController->purchase_order_pdf_invoice($purchaseOrderNo),
            $invoiceController->packing_list_pdf_invoice($purchaseOrderNo)
        ];

        $fileNames = ["Purchase Order", "Packing List"];

        $sellerPhone = DB::table('final_purchase_order')
            ->where('purchase_order_no', $purchaseOrderNo)
            ->value(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(seller_info, '$.seller_phone'))"));

        // List of phone numbers to send the message to
        $toNumbers = [
            // $sellerPhone,  // Original seller phone number from the database
            '+919930791952' , // Additional phone number 1
            // '9730377752'   // Additional phone number 2
            '+919894753728'
            
        ];


        // Manager phone numbers based on seller_warehouse condition
        // Get the selected warehouse from the request
         $warehouseId = $request->warehouse_id;
        if ($warehouseId == 2) {
            $toNumbers[] = '+919763268640';  // Manager 1 (m1) //delhi
        } elseif ($warehouseId == 6) {
            $toNumbers[] = '+919860433981';  // Manager 2 (m2) mumbai
        }

        // Loop through each phone number and send the WhatsApp message with retry logic
        foreach ($toNumbers as $to) {
            foreach ($fileUrls as $index => $fileUrl) {
                $templateData = [
                    'name' => 'utility_purchase_order',
                    'language' => 'en_US',
                    'components' => [
                        [
                            'type' => 'header',
                            'parameters' => [
                                [
                                    'type' => 'document',
                                    'document' => [
                                        'link' => $fileUrl,
                                        'filename' => $fileNames[$index],
                                    ],
                                ],
                            ],
                        ],
                        [
                            'type' => 'body',
                            'parameters' => [
                                ['type' => 'text', 'text' =>$purchaseOrderNo],
                            ],
                        ],
                    ],
                ];

                // Retry mechanism
                $retryCount = 0;
                $maxRetries = 1;
                $messageSent = false;

                while ($retryCount < $maxRetries && !$messageSent) {
                    try {
                        $this->WhatsAppWebService = new WhatsAppWebService();
                        $response1 = $this->WhatsAppWebService->sendTemplateMessage($to, $templateData);

                        if (isset($response1['messages'][0]['id'])) {
                            $messageId = $response1['messages'][0]['id'];

                            sleep(2); // Delay for 1 second before checking the status
                            // Call the function to get the message status
                            $messageStatus = $this->getMessageStatusById($messageId);

                            if ($messageStatus === 'sent') {
                                $messageSent = true;  // Mark as sent
                                break;  // Break out of the retry loop
                            } else {
                                throw new Exception("Message sending failed");
                            }
                        } else {
                            throw new Exception("Message ID not found in the response");
                        }
                    } catch (Exception $e) {
                        $retryCount++;
                        if ($retryCount >= $maxRetries) {
                            // Log or handle failure after 3 retries
                            Log::error("Failed to send message to $to after $maxRetries attempts. Error: " . $e->getMessage());
                            // Optionally, you can notify admin via email or other methods
                        } else {
                            // You may introduce a short delay before retrying (optional)
                            sleep(2); // Delay for 2 seconds before retrying
                        }
                    }
                }
            }
        }

        return redirect()->route('admin.purchase_order')->with('status', 'Purchase order saved successfully!');
    }

    
public function showFinalizedOrders(Request $request)
{
    // Get search and sorting parameters
    $search = $request->input('search');
    $sortColumn = $request->input('sort_column', 'date'); // Default sorting column is 'date'
    $sortOrder = $request->input('sort_order', 'desc');   // Default sorting order is 'desc'

    // Base query
    $query = DB::table('final_purchase_order')
        ->join('sellers', 'final_purchase_order.seller_id', '=', 'sellers.id')
        ->select(
            'final_purchase_order.*',
            DB::raw("JSON_UNQUOTE(JSON_EXTRACT(seller_info, '$.seller_name')) as seller_name"),
            DB::raw("JSON_UNQUOTE(JSON_EXTRACT(seller_info, '$.seller_phone')) as seller_phone"),
            'final_purchase_order.force_closed'
        )
        ->where('is_closed', '=', 0); // Check if is_closed is 0

    // Apply search filter if search query exists
    if ($search) {
        $query->where(function ($query) use ($search) {
            $query->where('final_purchase_order.purchase_order_no', 'LIKE', '%' . $search . '%')
                  ->orWhere(DB::raw("JSON_UNQUOTE(JSON_EXTRACT(seller_info, '$.seller_name'))"), 'LIKE', '%' . $search . '%');
        });
    }

    // Apply sorting
    $query->orderBy($sortColumn, $sortOrder);

    // Paginate results and keep the query string
    $orders = $query->paginate(50)->withQueryString();

    // Process orders
    foreach ($orders as $order) {
        // Decode the product_info JSON
        $productInfo = json_decode($order->product_info, true);

        // Check the convert_to_purchase_status and filter accordingly
        if ($order->convert_to_purchase_status == 1) {
            // Filter only products with quantity zero for converted orders
            $filteredProducts = array_filter($productInfo, function ($product) {
                return $product['qty'] == 0;
            });
        } else {
            // For orders not yet converted, show all products
            $filteredProducts = $productInfo;
        }

        // Fetch product names and attach them to the products
        foreach ($filteredProducts as &$product) {
            $productName = DB::table('products')
                ->where('part_no', $product['part_no'])
                ->value('name');
            $product['product_name'] = $productName;
        }

        // Assign the filtered product info back to the order
        $order->product_info = $filteredProducts;
    }

    // Return the view with the orders
    return view('backend.purchase_order.finalized_purchase_order_listing', compact('orders', 'search', 'sortColumn', 'sortOrder'));
}



    public function forceClose($id)
{
    // Fetch the purchase order by ID
    $purchaseOrder = DB::table('final_purchase_order')->where('id', $id)->first();

    if (!$purchaseOrder) {
        // Redirect with an error message if the purchase order doesn't exist
        return redirect()->back()->with('status', 'Purchase order not found.');
    }

    // Decode the product_info field
    $productInfo = json_decode($purchaseOrder->product_info);

    foreach ($productInfo as $product) {
        $partNo = $product->part_no; // Use object notation
        $orderNosWithDates = explode(',', $product->order_no); // Split in case of multiple order numbers
        $qty = $product->qty; // Quantity for the entire entry

        foreach ($orderNosWithDates as $orderNoWithDate) {
            // Extract the order number without the date part
            if (preg_match('/(SO\/[^ ]+)/', trim($orderNoWithDate), $matches)) {
                $orderNo = trim($matches[1]);

                // Update the purchase_order table where part_no and order_no match
                DB::table('purchase_order')
                    ->where('part_no', $partNo)
                    ->where('order_no', $orderNo)
                    ->update(['delete_status' => 1]);
            }
        }
    }

    // Mark the purchase order as closed by updating the 'force_closed' field
    DB::table('final_purchase_order')
        ->where('id', $id)
        ->update([
            'force_closed' => 1,
            'updated_at' => now(), // Update the updated_at timestamp
        ]);

    // Redirect with a success message after closing the order
    return redirect()->back()->with('status', 'Purchase order has been force closed successfully.');
}






    public function showProductInfo($id)
    {
        // Fetch the purchase order by ID
        $order = DB::table('final_purchase_order')
            ->where('id', $id)
            ->first();

        // Decode the product info JSON
        $productInfo = json_decode($order->product_info, true);

        // Decode the seller info JSON
        $sellerInfo = json_decode($order->seller_info, true);

        $purchaseNo = "";
        $finalPurchase = null; // Initialize $finalPurchase to null

        // Check the convert_to_purchase_status
        if ($order->convert_to_purchase_status == 1) {
            // If status is 1, filter only products with quantity zero
            $finalPurchase = DB::table('final_purchase')
                ->where('purchase_order_no', $order->purchase_order_no)
                ->first();

            if ($finalPurchase) {
                $purchaseNo = $finalPurchase->purchase_no;
            }

            $productInfo = array_filter($productInfo, function ($product) {
                return $product['qty'] == 0;
            });
        }

        // Fetch the product details for each part number
        foreach ($productInfo as &$product) {
            $productDetails = DB::table('products')
                ->where('part_no', $product['part_no'])
                ->select('name', 'purchase_price', 'hsncode')
                ->first();

            $product['product_name'] = $productDetails->name ?? 'Unknown';
            $product['purchase_price'] = $productDetails->purchase_price ?? 'N/A';
            $product['hsncode'] = $productDetails->hsncode ?? 'N/A';
        }
        

        // Pass the seller information and product information to the view
        return view('backend.purchase_order.product_info', compact('order', 'productInfo', 'sellerInfo', 'purchaseNo', 'finalPurchase'));
    }

    
    public function viewProducts($purchaseOrderNo)
    {
        // Retrieve the purchase order based on the purchase_order_no
        $order = DB::table('final_purchase')
            ->where('purchase_no', $purchaseOrderNo)
            ->first();
            // echo "<pre>";
            // print_r($order);
            // die();
    
        // Decode the product info JSON
        $productInfo = json_decode($order->product_info, true);
    
        // Filter the product info to include only those products with qty != 0
        $filteredProductInfo = array_filter($productInfo, function($product) {
            return $product['qty'] != 0;
        });
    
        // Fetch additional product details if needed
        foreach ($filteredProductInfo as &$product) {
            $productDetails = DB::table('products')
                ->where('part_no', $product['part_no'])
                ->select('name', 'purchase_price', 'hsncode') // Adjust fields as needed
                ->first();
    
            $product['product_name'] = $productDetails->name ?? 'Unknown';
            $product['purchase_price'] = $productDetails->purchase_price ?? 'N/A';
            $product['hsncode'] = $productDetails->hsncode ?? 'N/A';
        }
    
        return view('backend.purchase_order.final_product_info', compact('order', 'filteredProductInfo'));
    }
    

    

   public function convertToPurchase(Request $request, $id)
   {
      

      $validatedData = $request->validate([
        'seller_invoice_no' => 'required|string|max:255',
        'seller_invoice_date' => 'required|date',
        'products.*.hsncode' => 'required|string|max:255',
        'products.*.qty' => 'required|integer|min:0',
        'products.*.purchase_price' => 'required|numeric|min:0',
    ], [
        'seller_invoice_no.required' => "Seller Invoice Number is required.",
        'seller_invoice_date.required' => "Seller Invoice Date is required.",
        'products.*.hsncode.required' => "HSN Code is required for each product.",
        'products.*.qty.required' => "Quantity is required for each product.",
        'products.*.qty.integer' => "Quantity must be an integer.",
        'products.*.purchase_price.required' => "Purchase Price is required for each product.",
        'products.*.purchase_price.numeric' => "Purchase Price must be a valid number.",
    ]);
    


      
      // Get the product_info from the final_purchase_order table
      $order = DB::table('final_purchase_order')->where('id', $id)->first();
      $productInfo = json_decode($order->product_info, true);

      $isClosed = 1; // Assume the purchase order will be closed unless a product has zero qty

      

      // Initialize an array to collect updated product information
      $updatedProductInfo = [];

      // Iterate over the products from the request to update the product table and collect updated information
      foreach ($request->input('products') as $productData) {
          $partNo = $productData['part_no'];
          $qty = $productData['qty'];
          if($qty == 0){
            $isClosed=0;
          }
          $hsncode = $productData['hsncode'];
          $purchasePrice = $productData['purchase_price'];
          $orderNo = $productData['order_no']; // Get the order number
          $age = $productData['age']; // Get the age

          $sellerId = $request->input('seller_id');
          $purchaseOrderNo = $request->input('purchase_order_no');

          // Update the product table with the new HSN code and purchase price
          DB::table('products')
              ->where('part_no', $partNo)
              ->update([
                  'hsncode' => $hsncode,
                  'purchase_price' => $purchasePrice,
              ]);

          // Update the existing product info in the array
          foreach ($productInfo as &$existingProduct) {
              if ($existingProduct['part_no'] === $partNo) {
                  $existingProduct['qty'] = $qty;
                  $existingProduct['hsncode'] = $hsncode;
                  $existingProduct['order_no'] = $orderNo;
                  $existingProduct['age'] = $age;
                  break;
              }
          }

          // Collect updated product information
          $updatedProductInfo[] = [
              'part_no' => $partNo,
              'qty' => $qty,
              'order_no' => $orderNo, // Include the order number in the product info
              'age' => $age // Include the age in the product info
          ];

          // Push only the part_no to Salezing API if the quantity is not zero
        // if ($qty != 0) {
            //   $result = [
            //       'part_no' => $partNo
            //   ];
            $result=array();
            $result['part_no']= $partNo;

            $salzingResponse = Http::withHeaders([
                'Content-Type' => 'application/json',
            ])->post('https://mazingbusiness.com/api/v2/item-push', $result);

            \Log::info('Salezing Item Push Status: ' . json_encode($salzingResponse->json(), JSON_PRETTY_PRINT));
        //   }
       
      }
     

      
      // Check if purchase_no is provided; if not, generate a new one
  
      $lastPurchase = DB::table('final_purchase')
      ->orderBy('id', 'desc')
      ->first();

      if ($lastPurchase) {
          // Extract the number from the last purchase_no
          $lastPurchaseNumber = intval(substr($lastPurchase->purchase_no, 3));
          $newPurchaseNumber = $lastPurchaseNumber + 1;
      } else {
          // Start from 1 if no purchase records exist
          $newPurchaseNumber = 1;
      }
      // Format the new purchase_no with leading zeros (e.g., pn-001)
      $purchaseNo = 'pn-' . str_pad($newPurchaseNumber, 3, '0', STR_PAD_LEFT);
    
      
      // $sellerInfo = json_decode($order->seller_info, true);
      // Prepare the seller_info array
      $sellerInfo = [
        'seller_name' => $request->input('seller_info.seller_name'),
        'seller_address' => $request->input('seller_info.seller_address'),
        'seller_gstin' => $request->input('seller_info.seller_gstin'),
        'seller_phone' => $request->input('seller_info.seller_phone'),
    ];

    

      // Prepare data to be inserted into the final_purchase table
      $data = [
          'purchase_no' => $purchaseNo,
          'purchase_order_no' => $purchaseOrderNo,
          'seller_id' => $sellerId,
          'seller_invoice_no' => $request->input('seller_invoice_no'),  // Use the provided seller invoice number
          'seller_invoice_date' => $request->input('seller_invoice_date'), // Use the provided seller invoice date
          'seller_info' => json_encode($sellerInfo), // Insert seller info
          'product_info' => json_encode($updatedProductInfo), // Insert updated product info
          'created_at' => now(),
          'updated_at' => now(),
      ];

      // Use updateOrInsert to update the final_purchase table
      DB::table('final_purchase')->insert(
        
          $data // Data to update or insert
      );

      // Update the final_purchase_order table with the updated product information and convert_to_purchase_status
      DB::table('final_purchase_order')
          ->where('id', $id)
          ->update([
              'convert_to_purchase_status' => 1, // Mark as closed only if no qty is zero
              'seller_info' => json_encode($sellerInfo),
              'product_info' => json_encode($productInfo), // Update product info in final_purchase_order table as well
              'is_closed' => $isClosed, // Update the is_closed column based on the status
          ]);
      
      // Iterate through productInfo to delete items from purchase_order table
    //   foreach ($productInfo as &$product) {
    //       $partNo = $product['part_no'];
    //       $orderNosWithDates = explode(',', $product['order_no']); // Split in case of multiple order numbers
    //       $qty = $product['qty']; // Quantity for the entire entry

    //       // If any product has qty 0, do not close the purchase order
    //       if ($qty == 0) {
    //           $isClosed = 0;
    //           continue; // Skip deletion for this product
    //       }

    //       foreach ($orderNosWithDates as $orderNoWithDate) {
    //           // Extract the order number without the date part
    //           if (preg_match('/(SO\/[^ ]+)/', trim($orderNoWithDate), $matches)) {
    //               $orderNo = trim($matches[1]);

    //               // Perform the deletion for the specific order_no and part_no
    //               DB::table('purchase_order')
    //                   ->where('order_no', $orderNo)
    //                   ->where('part_no', $partNo)
    //                   ->delete();

               
    //           }
    //       }
    //   }

      // Return success message
      return redirect()->route('finalized.purchase.orders')->with('status', 'Purchase order converted successfully!');
  }



    public function showFinalizedPurchaseOrders()
    {
      
      $purchases = DB::table('final_purchase')
      ->join('final_purchase_order', 'final_purchase.purchase_order_no', '=', 'final_purchase_order.purchase_order_no')
      ->join('sellers', 'final_purchase.seller_id', '=', 'sellers.id')
      ->join('users', 'sellers.user_id', '=', 'users.id') // Join with users table
      ->select('final_purchase.*', 'final_purchase_order.product_info', 'users.name as seller_name') // Get seller name from users table
      ->get();

            // echo "<pre>";
            // print_r($purchases);
            // die();

        return view('backend.purchase_order.final_purchase_list', compact('purchases'));
    }


    public function showImportForm()
    {
        return view('backend.purchase_order.purchase_order_excel_import');
    }

    public function importExcel(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'excel_file' => 'required|file|mimes:xls,xlsx'
        ], ['excel_file' => "File is required"]);

        // Get the real path of the uploaded file
        $filePath = $request->file('excel_file');

        $tableName = 'purchase_order';

        try {
            // Attempt to import the file
            Excel::import(new ExternalPurchaseOrder($tableName), $filePath);

            // If no exception occurs, consider it a success
            return redirect()->back()->with('success', 'Data imported successfully!');
        } catch (Exception $e) {
            // If an exception occurs, handle it and return an error message
            return redirect()->back()->with('error', 'Data import failed: ' . $e->getMessage());
        }
    }

    public function export($purchase_no)
    {
      $data = DB::table('final_purchase')
     
      ->join('final_purchase_order', 'final_purchase.purchase_order_no', '=', 'final_purchase_order.purchase_order_no')
      ->where('final_purchase.purchase_no', $purchase_no)
      ->select(
          'final_purchase.purchase_no',
          'final_purchase.purchase_order_no',
          'final_purchase.seller_info',  // Fetch seller_info JSON field
          'final_purchase.seller_invoice_no',
          'final_purchase.seller_invoice_date',
          'final_purchase.product_info'
      )
      ->orderBy('final_purchase.created_at', 'desc')
      ->get();

      // Process the data to filter out products with qty == 0
      $filteredData = $data->map(function ($item) {
          $productInfo = json_decode($item->product_info, true);

          // Filter out products where qty is 0
          $filteredProductInfo = array_filter($productInfo, function ($product) {
              return $product['qty'] != 0;
          });

          // Encode the filtered product info back to JSON
          $item->product_info = json_encode(array_values($filteredProductInfo));

          return $item;
      });

      
        return Excel::download(new FinalPurchaseExport($purchase_no), 'final_purchases.xlsx');
    }
	
	

  //purchase order code end
	
	// sales (nav menu) backend dashboard whatsaap send
	public function sendWhatsAppMessage($order_id)
	{
		
		// Fetching the order directly from the orders table
		$first_order = DB::table('orders')
			->where('id', $order_id)
			->first();

		// Fetching the user who placed the order
		$user = DB::table('users')
				->where('id', $first_order->user_id)
				->first();

		// Fetching the manager's phone number
		$manager_phone_number = DB::table('users')
			->where('id', $user->manager_id)
			->pluck('phone')
			->first();

		// Setting the recipients for the WhatsApp message
		$to = [
			json_decode($first_order->shipping_address)->phone,
			'+919709555576', // Replace with an actual number if needed
			$manager_phone_number
     
		];

		// Fetching the client's address information
		$client_address = DB::table('addresses')
			->where('id', $first_order->address_id)
			->first();

		// Order details for the WhatsApp message
		$company_name = $client_address->company_name;
		$order_code = $first_order->code;
		$date = date('d-m-Y H:i A', $first_order->date);
		$total_amount = $first_order->grand_total;

		// Generating the invoice file path
		$invoiceController = new InvoiceController();
		$file_url = $invoiceController->invoice_file_path($first_order->id);

		// Setting the file name for the invoice
		$file_name = "Order-" . $order_code;

		// Preparing the template data for WhatsApp message
		$templateData = [
			'name' => 'utility_order_template',
			'language' => 'en_US', 
			'components' => [
				[
					'type' => 'header',
					'parameters' => [
						[
							'type' => 'document', 
							'document' => [
								'link' => $file_url,
								'filename' => $file_name,
							]
						]
					]
				],
				[
					'type' => 'body',
					'parameters' => [
						['type' => 'text', 'text' => $company_name],
						['type' => 'text', 'text' => $order_code],
						['type' => 'text', 'text' => $date],
						['type' => 'text', 'text' => $total_amount]
					],
				],
			],
		];

		// Sending the WhatsApp message to each recipient
		$this->WhatsAppWebService = new WhatsAppWebService();
		foreach ($to as $person_to_send) {
			$response = $this->WhatsAppWebService->sendTemplateMessage($person_to_send, $templateData);
		}
    return response()->json(['message' => 'WhatsApp sent successfully']);
	// return redirect()->back()->with('message', 'whatsapp sent successfully');
	// 	return $response; 
	}

  public function downloadPDF($file_name)
  {
      // Construct the full path to the file in the public directory
      $filePath = public_path('abandoned_cart_pdf/' . $file_name);

      // Check if the file exists
      if (file_exists($filePath)) {
          // Return the file as a download response
          return Response::download($filePath, $file_name);
      } else {
          // Return a 404 error if the file does not exist
          return view('errors.link_expire');
      }
  }

  public function updateSlugs()
  {
    $messageId="wamid.HBgINjI4OTA2MjkVAgARGBI3MDk1RUMwQjUyMzM1RTlENkQA";
    // Set up the database connection dynamically within the function
    config([
        'database.connections.dynamic_mazingbusiness' => [
            'driver' => 'mysql',
            'host' => 'localhost',  // Replace with your cloud database host
            'port' => '3306',  // Replace with your cloud database port
            'database' => 'mazingbusiness',  // The database name is 'mazingbusiness'
            'username' => 'mazingbusiness',   // Replace with your database username
            'password' => 'Gd6de243%',   // Replace with your database password
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'strict' => true,
            'engine' => null,
        ]
    ]);

    // Fetch the message data from the cloud_response database
    $cloudResponseData = DB::connection('dynamic_mazingbusiness')
        ->table('cloud_response')  // Assume this is the table storing the message details
        ->where('msg_id', $messageId)
        ->first();

    return $cloudResponseData->status;

      // Get all products where the slug contains a slash
    //   $products = DB::table('products')
    //       ->where('slug', 'LIKE', '%/%')
    //       ->get();

    //   foreach ($products as $product) {
    //       // Replace slashes with hyphens
    //       $newSlug = str_replace('/', '-', $product->slug);

    //       // Update the product slug in the database
    //       DB::table('products')
    //           ->where('id', $product->id)
    //           ->update(['slug' => $newSlug]);
    //   }

    //   return response()->json(['message' => 'Slugs updated successfully.']);
  }

//   public function pushOrder($id)
//     {

       
      
//       // Push order data to Salezing
//       $orderData = DB::table('orders')->where('combined_order_id', $id)->first();
//       $result=array();
//       $result['code']= $orderData->code;
//       $response = Http::withHeaders([
//           'Content-Type' => 'application/json',
//       ])->post('https://mazingbusiness.com/api/v2/order-push', $result);

      
       
//         return redirect()->back();
//     }

    public function pushOrder($id)
    {
        // Fetch order data based on combined_order_id
        $orderData = DB::table('orders')->where('combined_order_id', $id)->first();

        if ($orderData) {
            // Check if a record exists in salezing_logs with the same order code
            $existingLog = DB::table('salezing_logs')->where('code', $orderData->code)->first();

            // If a record exists, delete it
            if ($existingLog) {
                DB::table('salezing_logs')->where('code', $orderData->code)->delete();
            }

            // Prepare the data to be pushed to the Salezing API
            $result = array();
            $result['code'] = $orderData->code;

            // Push order data to Salezing API
            $response = Http::withHeaders([
                'Content-Type' => 'application/json',
            ])->post('https://mazingbusiness.com/api/v2/order-push', $result);

            // Handle the response from the API
            if ($response->successful()) {
                // Set a success message
                session()->flash('success', 'Order pushed to Salezing successfully!');
            } else {
                // Set a failure message
                session()->flash('error', 'Failed to push order to Salezing.');
            }

           
        }else {
            // If no order data found, set an error message
            session()->flash('error', 'Order not found.');
        }
     
        // Redirect back to the previous page
        return redirect()->back();
    }

    // ------------------------- Offer Section ------------------------
    public function getOffers(Request $request){
        $currentDate = now();
        $productId = $request->input('product_id');
        $offers = Offer::with('offerProducts')
                ->where('status', 1)
                ->whereDate('offer_validity_start', '<=', $currentDate)
                ->whereDate('offer_validity_end', '>=', $currentDate)
                ->whereHas('offerProducts', function ($query) use ($productId) {
                    $query->where('product_id', $productId);
                })->get();
        $html = view('frontend.partials.offerDetails', compact('offers'))->render();
        return response()->json(['html' => $html]);
    }

    public function applyOffer($offer_id){
        $offer_id = decrypt($offer_id);
        $currentDate = now();
        $offers = Offer::with('offerProducts','offerComplementoryProducts.offerComplementoryProductDetails')
                ->where('status', 1)
                ->whereDate('offer_validity_start', '<=', $currentDate)
                ->whereDate('offer_validity_end', '>=', $currentDate)
                ->where('id', $offer_id)->first();

        if($offers == NULL){
            return redirect()->route('cart')->with('statusErrorMsg', '* Offer is no loanger valid now.');
        }else{
            // Check offer had applied previously or not for single offer applied at a time.
            $appliedOffer = Cart::where('user_id', Auth::user()->id) ->orWhere('customer_id', Auth::user()->id)->where('applied_offer_id', '!=', NULL )->get();
            if (!$appliedOffer->isEmpty()){
                foreach($appliedOffer as $aoKey=>$aoValue){
                    $cartProduct = Cart::where('id',$aoValue->id)->first();
                    if($aoValue->complementary_item == 1){
                        $cartProduct->delete();
                    }else{
                        $product = Product::where('id',$aoValue->product_id)->first();
                        if($aoValue->quantity >= $product->piece_by_carton ){
                            $price = home_bulk_discounted_price($product,false)['price'];
                        }else{
                            $price = home_discounted_price($product,false)['price'];
                        }
                        // $price = $product->mrp * ((100 - Auth::user()->discount) / 100);
                        
                        $cartProduct->applied_offer_id = null;
                        $cartProduct->price = $price;
                        $cartProduct->save();
                    }                    
                }
            }
            // Offer Products discount options
            $offerProducts = $offers->offerProducts;
            $rewards = 0;  
            
            if (!$offerProducts->isEmpty()) {
                foreach ($offerProducts as $opKey => $opValue) {
                    // Fetch the cart product for the current user or customer
                    $cartProduct = Cart::where(function ($query) use ($opValue) {
                        $query->where('user_id', Auth::user()->id)
                            ->orWhere('customer_id', Auth::user()->id);
                    })->where('product_id', $opValue->product_id)->first();
                    
                    // Fetch product details
                    $product = Product::find($opValue->product_id); // Use find for simplicity
                    
                    if (!$product) {
                        continue; // Skip if product doesn't exist
                    }

                    // Calculate the base price with user-specific discount
                    // $price = $product->mrp * ((100 - Auth::user()->discount) / 100);
                    

                    if ($offers->offer_type == 2) { // Type 2 offer logic
                        if ($offers->value_type == 'percent') {
                            $rewards = ($offers->offer_value * ($offers->discount_percent)) / 100;
                        } else {
                            $rewards = $offers->discount_percent;
                        }
                    } else { // Other offer types
                        if ($opValue->discount_type == 'percent') {
                            $price = $price * ((100 - $opValue->offer_discount_percent) / 100);
                        } else {
                            $price = $opValue->offer_price;
                        }
                    }
                    // Update cart product if it exists
                    if ($cartProduct != null) {
                        if($cartProduct->quantity >= $product->piece_by_carton ){
                            $price = home_bulk_discounted_price($product,false)['price'];
                        }else{
                            $price = home_discounted_price($product,false)['price'];
                        }
                        // If Offer type is Item Wise
                        // if ($offers->offer_type == 2 AND $opValue->offer_price != "") {
                        //     $price = $opValue->offer_price;
                        // }

                        $cartProduct->applied_offer_id = $offers->id;
                        $cartProduct->offer_rewards = $rewards;
                        $cartProduct->price = $price;
                        $cartProduct->save();
                    }
                }
            } else { // Handle cases when no specific offer products are provided
                if ($offers->value_type == 'percent') {
                    $rewards = ($offers->offer_value * ($offers->discount_percent)) / 100;
                } else {
                    $rewards = $offers->discount_percent;
                }
                Cart::where('user_id', Auth::user()->id)->orWhere('customer_id', Auth::user()->id)->update(
                    [
                        'applied_offer_id'      => $offers->id,
                        'offer_rewards' => $rewards,
                    ]
                );
            }
            // Offer Complementory Products
            $offerComplementoryProducts = $offers->offerComplementoryProducts;
            if($offerComplementoryProducts != NULL){
                foreach($offerComplementoryProducts as $ocpKey=>$ocpValue){
                    $data = array();
                    $data['user_id'] = Auth::user()->id;
                    $data['owner_id']   = Auth::user()->id;
                    $data['product_id'] = $ocpValue->offerComplementoryProductDetails->id;
                    $data['owner_id']   = $ocpValue->offerComplementoryProductDetails->user_id;
                    $data['variation']   = $ocpValue->offerComplementoryProductDetails->slug;
                    // if($request['type'] == "piece"){
                    //     $price = $product->mrp * ((100 - $discount) / 100);
                    // }elseif($request['type'] == "bulk"){
                    //     $price = $request['order_by_carton_price'];
                    // }
                    $data['price']= '1';
                    $data['quantity']= $ocpValue->free_product_qty;
                    $data['tax']= 0;
                    $data['shipping_cost']= 0;
                    $data['product_referral_code'] = null;
                    $data['cash_on_delivery']= $ocpValue->offerComplementoryProductDetails->cash_on_delivery;
                    $data['cash_and_carry_item']= $ocpValue->offerComplementoryProductDetails->cash_and_carry_item;
                    $data['digital']= $ocpValue->offerComplementoryProductDetails->digital;
                    $data['complementary_item'] = '1';
                    $data['applied_offer_id'] = $offers->id;
                    Cart::create($data);
                }
            }
            return redirect()->route('cart')->with('statusSuccessMsg', $offers->offer_name.' offer applied.');
        }
    }

    public function removeOffer($offer_id){
        $offer_id = decrypt($offer_id);
        $offers = $this->removeOfferFromTable($offer_id);
        return redirect()->route('cart')->with('statusSuccessMsg', $offers->offer_name.' offer removed.');
    }

    public function removeOfferFromTable($offer_id){
        $currentDate = now();
        $offers = Offer::with('offerProducts')
                ->where('status', 1)
                ->whereDate('offer_validity_start', '<=', $currentDate)
                ->whereDate('offer_validity_end', '>=', $currentDate)
                ->where('id', $offer_id)->first();
        if($offers == NULL){
            $cartProduct = Cart::where(function ($query) {
                $query->where('user_id', Auth::user()->id)
                      ->orWhere('customer_id', Auth::user()->id);
            })->where('applied_offer_id', $offer_id)->get();
            if(!$cartProduct->isEmpty()){
                foreach($cartProduct as $cpKey=>$cpValue){
                    $updateCart = Cart::where('id',$cpValue->id)->first();
                    $product = Product::where('id',$cpValue->product_id)->first();
                    // $price = $product->mrp * ((100 - Auth::user()->discount) / 100);
                    if($cpValue->quantity >= $product->piece_by_carton ){
                        $price = home_bulk_discounted_price($product,false)['price'];
                    }else{
                        $price = home_discounted_price($product,false)['price'];
                    }
                    $updateCart->applied_offer_id = null;
                    $updateCart->offer_rewards = null;
                    $updateCart->price = $price;
                    $updateCart->save();
                }
            }
            return redirect()->route('cart')->with('statusErrorMsg', '* Offer is no loanger valid now.');
        }else{
            $offerProducts = $offers->offerProducts;
            if (!$offerProducts->isEmpty()) {
                foreach($offerProducts as $opKey=>$opValue){
                    $cartProduct = Cart::where(function ($query) use ($opValue) {
                        $query->where('user_id', Auth::user()->id)
                            ->orWhere('customer_id', Auth::user()->id);
                    })->where('product_id', $opValue->product_id)->first();
                    
                    $product = Product::where('id',$opValue->product_id)->first();
                    // $price = $product->mrp * ((100 - Auth::user()->discount) / 100);
                    if($cartProduct != NULL){
                        if($cartProduct->quantity >= $product->piece_by_carton ){
                            $price = home_bulk_discounted_price($product,false)['price'];
                        }else{
                            $price = home_discounted_price($product,false)['price'];
                        }
                        $cartProduct->applied_offer_id = null;
                        $cartProduct->price = $price;
                        $cartProduct->offer_rewards = null;
                        $cartProduct->save();
                    }                
                }
                $cartProduct = Cart::where('applied_offer_id', $offer_id)
                ->where('complementary_item', '1')
                ->where(function ($query) {
                    $query->where('user_id', Auth::id())
                        ->orWhere('customer_id', Auth::id());
                })
                ->delete();
            }else{
                if ($offers->value_type === 'percent') {
                    $rewards = ($offers->offer_value * ($offers->discount_percent)) / 100;
                } else {
                    $rewards = $offers->discount_percent;
                }

                $cartProduct = Cart::where('applied_offer_id', $offer_id)
                ->where('complementary_item', '1')
                ->where(function ($query) {
                    $query->where('user_id', Auth::id())
                        ->orWhere('customer_id', Auth::id());
                })
                ->delete();
                Cart::where('user_id', Auth::user()->id)->orWhere('customer_id', Auth::user()->id)->update(
                    [
                        'applied_offer_id' => NULL,
                        'offer_rewards' => NULL,
                    ]
                );
            }    
            return $offers;
        }
    }

    public function addOfferTag($carts){
        $userDetails = User::with(['get_addresses' => function ($query) {
            $query->where('set_default', 1);
        }])->where('id', Auth::user()->id)->first();
        // echo "<pre>"; print_r($userDetails);die;
        $state_id = $userDetails->get_addresses[0]->state_id;
        $currentDate = Carbon::now(); // Get the current date and time
        foreach($carts as $cKey=>$cValue){
            $offerCount = 0;
            $productId=$cValue->product_id;
            $offers = Offer::with('offerProducts')
            ->where('status', 1) // Check for offer status
            ->where(function ($query) use ($userDetails) {
                $query->where('manager_id', $userDetails->manager_id)
                    ->orWhereNull('manager_id');
            })            
            ->where(function ($query) use ($state_id) {
                $query->where('state_id', $state_id)
                    ->orWhereNull('state_id');
            })
            ->whereDate('offer_validity_start', '<=', $currentDate) // Start date condition
            ->whereDate('offer_validity_end', '>=', $currentDate) // End date condition
            ->whereHas('offerProducts', function ($query) use ($productId) {
                $query->where('product_id', $productId);
            })->get();
            $offerCount = $offers->count();
            if($offerCount > 0){
                $cValue->offer = $offers;
            }else{
                $cValue->offer = "";
            }
        }
        return $carts;
    }

    public function checkValidOffer(){
        $currentDate = now();

        $userDetails = User::with('get_addresses')->where('id',Auth::user()->id)->first();        
        $state_id = $userDetails->get_addresses[0]->state_id;

        $cartItems = Cart::where('user_id', Auth::user()->id)
        ->orWhere('customer_id', Auth::user()->id)
        ->get(['product_id', 'quantity', 'price'])
        ->groupBy('product_id');

        $cartProductIds = $cartItems->keys()->toArray();
        // Sum quantities for each product
        $cartQuantities = $cartItems->mapWithKeys(function ($items, $productId) {
            return [$productId => $items->sum('quantity')];
        })->toArray();
        // Prepare prices for each product (assuming all prices for a given product are the same)
        $cartItemPrice = $cartItems->mapWithKeys(function ($items, $productId) {
            return [$productId => $items->first()->price * $items->sum('quantity')]; // Use the price of the first item in the group
        })->toArray();

        $achiveOfferArray = array();

        $offers = Offer::with('offerProducts')
            ->where('status', 1)
            ->where(function ($query) use ($userDetails) {
                $query->where('manager_id', $userDetails->manager_id)
                    ->orWhereNull('manager_id');
            })            
            ->where(function ($query) use ($state_id) {
                $query->where('state_id', $state_id)
                    ->orWhereNull('state_id');
            })
            ->whereDate('offer_validity_start', '<=', $currentDate)
            ->whereDate('offer_validity_end', '>=', $currentDate)
            ->get()
            ->filter(function ($offer) use ($cartProductIds, $cartQuantities, $cartItemPrice, &$achiveOfferArray) {
                $getLogedUserAppliedOfferCount = Order::where('user_id',Auth::user()->id)->where('applied_offer_id',$offer->id)->count();
                $getAppliedOfferCount = Order::where('applied_offer_id',$offer->id)->count();
                $validOfferFlag = 1;
                if($getLogedUserAppliedOfferCount>=$offer->per_user){
                    $validOfferFlag = 0;
                }elseif($getAppliedOfferCount>=$offer->max_uses){
                     $validOfferFlag = 0;
                }
                $offerProductsArray = $offer->offerProducts->pluck('product_id')->toArray();
                if($validOfferFlag == 1){
                    if ($offer->offer_type == 1) {
                        // Logic for offer type ITEM WISE: Any one product must meet the minimum quantity
                        $offerProductsArray = $offer->offerProducts->pluck('product_id')->toArray();
                        $offerProductNames = $offer->offerProducts->pluck('name', 'product_id')->toArray();
                        if (!empty(array_intersect($offerProductsArray, $cartProductIds))) {
                            foreach ($offerProductsArray as $productId => $minQty) {
                                if (in_array($productId, $cartProductIds)) {
                                    $productName = $offerProductNames[$productId] ?? 'Product';
                                    $achiveOfferArray[] = "Add $minQty of $productName to get OFFER ".$offer->offer_name;
                                }
                            }
                        }
                        return false;
                    }elseif ($offer->offer_type == 2) {
                        // Logic for offer type TOTAL
                        $offerProducts = $offer->offerProducts->pluck('min_qty', 'product_id')->toArray();
                        $offerProductNames = $offer->offerProducts->pluck('name')->toArray();
                        $offerValue = $offer->offer_value;
                        $offerSubTotal = 0;
                        if(count($offerProducts) > 0){
                            foreach ($offerProducts as $productId => $minQty) {
                                // Case 1 : Any offer product had added in cart and the subtotal will be >= offer_value and offer product should be greter than or equal then it will pass
                                // if (isset($cartQuantities[$productId]) && $cartQuantities[$productId] >= $minQty) {

                                // Edited Case 1 : Any offer product had added in cart and the subtotal will be >= offer_value then it will pass
                                if (isset($cartQuantities[$productId])) {    
                                    $offerSubTotal += $cartItemPrice[$productId];
                                }
                            }
                            if($offerSubTotal >= $offerValue){
                                return true;
                            }else{
                                if (!empty(array_intersect($offerProductsArray, $cartProductIds))) {
                                    $achiveOfferArray[]="Add more <b>₹".($offerValue-$offerSubTotal)."</b> on ".implode(', OR ',$offerProductNames)." to get OFFER <b>".$offer->offer_name."</b>";
                                }                              
                                return false;
                            }
                        }else{
                            // Case 2 : If the offer will be all over the subtotal ( there is no specific product)
                            if($offer->offer_value <= array_sum($cartItemPrice)){
                                return true;
                            }else{
                                $achiveOfferArray[]="Add more <b>₹".($offer->offer_value - array_sum($cartItemPrice))."</b> to get OFFER <b>".$offer->offer_name."</b>";
                                return true;
                            }
                        }                        
                        return false;
                    }elseif ($offer->offer_type == 3) {
                        $complementoryOfferFlag = 0;
                        // Logic for offer type COMPLEMENTARY
                        $offerProducts = $offer->offerProducts->pluck('min_qty', 'product_id')->toArray();
                        $offerProductNames = $offer->offerProducts->pluck('name', 'product_id')->toArray();
                        foreach ($offerProducts as $productId => $minQty) {
                            if (!isset($cartQuantities[$productId]) || $cartQuantities[$productId] < $minQty || !in_array($productId, $cartProductIds)) {
                                $productName = $offerProductNames[$productId] ?? 'Product';  // Get product name, fallback to 'Product' if not found
                                if (!empty(array_intersect($offerProductsArray, $cartProductIds))) {
                                    $achiveOfferArray[] = "Add <b>".$minQty."</b> of ".$productName." to get OFFER <b>".$offer->offer_name."</b>";
                                    $complementoryOfferFlag = 1;
                                }
                            }
                        }
                        if($complementoryOfferFlag == 1){
                            return false;
                        }elseif(empty(array_intersect($offerProductsArray, $cartProductIds))){
                            return false;
                        }  
                    }
                }else{
                    return false;
                }                              
                return true; 
            });
        return ["offers" => $offers, "achiveOfferArray" => $achiveOfferArray];
    }

    public function addOfferProductToCart(Request $request) {
        $offer_id = $request->offer_id;
        $product_id_array = explode(',',$request->product_id);
        $currentDate = now();
        foreach($product_id_array as $pKey => $pValue){

            $product = Product::find($pValue);
            $carts   = array();
            $data    = array();
            $user_id         = Auth::user()->id;
            $data['user_id'] = $user_id;
            $carts = Cart::where(function ($query) use ($user_id) {
                $query->where('user_id', $user_id)
                      ->orWhere('customer_id', $user_id);
            })->where('product_id', $pValue)->get();

            $data['product_id'] = $product->id;
            $data['owner_id']   = $product->user_id;

            $str     = '';
            $tax     = $ctax     = $price     = $carton_price     = 0;
            $wmarkup = 0;

            $str = $product->slug;
            $data['variation'] = $str;

            $product_stock = $product->stocks->where('variant', $str);
            
            //$price=calculate_discounted_price($product->mrp,false)['net_selling_price'];
            
            $user = Auth::user();
            $discount = 0;
            if ($user) {
                $discount = $user->discount;
            }
            if(!is_numeric($discount) || $discount == 0) {
                $discount = 20;
            }
            
            $price = $product->mrp * ((100 - $discount) / 100);

            $data['quantity']  = $request['quantity'];
            $data['price']     = price_less_than_50($price,false);
            $data['tax']       = $tax;
            $data['shipping_cost']         = 0;
            $data['product_referral_code'] = null;
            $data['cash_on_delivery']      = $product->cash_on_delivery;
            $data['cash_and_carry_item']      = $product->cash_and_carry_item;
            $data['digital']               = $product->digital;

            // Get Offer Qty
            $getOfferDetails = Offer::with(['offerProducts' => function ($query) use ($pValue) {
                $query->where('product_id', $pValue);
            }])
            ->where('status', 1)
            ->whereDate('offer_validity_start', '<=', $currentDate)
            ->whereDate('offer_validity_end', '>=', $currentDate)
            ->where('id', $offer_id)
            ->first();
            if($getOfferDetails->offerProducts[0]->min_qty != "" AND $getOfferDetails->offerProducts[0]->min_qty > 0){
                $data['quantity'] = $getOfferDetails->offerProducts[0]->min_qty;
            }else{
                $data['quantity'] = 1;
            }
            
            if ($carts && count($carts) <= 0) {
                Cart::create($data);
            }elseif($carts[0]->quantity < $getOfferDetails->offerProducts[0]->min_qty){
                Cart::where('id',$carts[0]->id)->update(['quantity'=> $getOfferDetails->offerProducts[0]->min_qty]);
            }
        }
        $carts   = Cart::where('user_id', $user_id)->orWhere('customer_id',$user_id)->get();
        return redirect()->route('cart');
    }
}