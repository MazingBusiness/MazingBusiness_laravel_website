<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Requests\ProductRequest;
use App\Http\Requests\OwnBrandProductRequest;
use Illuminate\Support\Facades\File;
use App\Models\Attribute;
use App\Models\AttributeValue;
use App\Models\Cart;

use App\Models\Product;
use App\Models\ProductTax;
use App\Models\ProductTranslation;
use App\Models\ProductWarehouse;

use App\Models\Seller;
use App\Models\Category;
use App\Models\CategoryGroup;
use App\Models\Brand;
use App\Models\User;
use App\Models\Warehouse;
use App\Models\Upload;
use App\Models\OwnBrandCategoryGroup;
use App\Models\OwnBrandCategory;
use App\Models\OwnBrandProduct;

use App\Services\ProductFlashDealService;
use App\Services\ProductService;
use App\Services\ProductStockService;
use App\Services\ProductTaxService;
use App\Services\GoogleSheetsService;

use App\Http\Controllers\SearchController;

use Artisan;
use Cache;
use Carbon\Carbon;
use Combinations;
use CoreComponentRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Str;

class ProductController extends Controller {
  protected $productService;
  protected $productTaxService;
  protected $productFlashDealService;
  protected $productStockService;
  protected $sheetsService;

  public function __construct(
    ProductService $productService,
    ProductTaxService $productTaxService,
    ProductFlashDealService $productFlashDealService,
    ProductStockService $productStockService,
    GoogleSheetsService $sheetsService
  ) {
    $this->productService          = $productService;
    $this->productTaxService       = $productTaxService;
    $this->productFlashDealService = $productFlashDealService;
    $this->productStockService     = $productStockService;
    $this->sheetsService           = $sheetsService;

    // Staff Permission Check
    $this->middleware(['permission:add_new_product'])->only('create');
    $this->middleware(['permission:show_all_products'])->only('all_products', 'no_images');
    $this->middleware(['permission:show_in_house_products'])->only('admin_products');
    $this->middleware(['permission:show_seller_products'])->only('seller_products');
    $this->middleware(['permission:product_edit'])->only('admin_product_edit', 'seller_product_edit');
    $this->middleware(['permission:product_duplicate'])->only('duplicate');
    $this->middleware(['permission:product_delete'])->only('destroy');
  }
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */


   public function getCategoriesByGroup(Request $request)
   {
      try {
          \Log::info('Fetching categories for group_id: ' . $request->group_id);
          
          $categories = DB::table('categories')
                          ->where('category_group_id', $request->group_id)
                          ->select('id', 'name')
                          ->get();
                          
          return response()->json(['categories' => $categories]);
      } catch (\Exception $e) {
          \Log::error('Error fetching categories: ' . $e->getMessage());
          return response()->json(['error' => 'Something went wrong!'], 500);
      }
   }
  public function admin_products(Request $request) {

    CoreComponentRepository::instantiateShopRepository();



    $type        = 'In House';
    $col_name    = null;
    $query       = null;
    $sort_search = null;

    $products = Product::where('added_by', 'admin');

    if ($request->type != null) {
      $var       = explode(",", $request->type);
      $col_name  = $var[0];
      $query     = $var[1];
      $products  = $products->orderBy($col_name, $query);
      $sort_type = $request->type;
    }
    if ($request->search != null) {
      $sort_search = $request->search;
      $products    = $products
        ->where('name', 'like', '%' . $sort_search . '%')
        ->orWhereHas('stocks', function ($q) use ($sort_search) {
          $q->where('part_no', 'like', '%' . $sort_search . '%');
        });
    }

    $products = $products->orderBy('created_at', 'desc')->paginate(15);

    return view('backend.product.products.index', compact('products', 'type', 'col_name', 'query', 'sort_search'));
  }

  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function seller_products(Request $request) {
    $col_name    = null;
    $query       = null;
    $seller_id   = null;
    $sort_search = null;
    $products    = Product::where('added_by', 'seller');
    if ($request->has('user_id') && $request->user_id != null) {
      $products  = $products->where('user_id', $request->user_id);
      $seller_id = $request->user_id;
    }
    if ($request->search != null) {
      $products = $products
        ->where('name', 'like', '%' . $request->search . '%');
      $sort_search = $request->search;
    }
    if ($request->type != null) {
      $var       = explode(",", $request->type);
      $col_name  = $var[0];
      $query     = $var[1];
      $products  = $products->orderBy($col_name, $query);
      $sort_type = $request->type;
    }

    $products = $products->orderBy('created_at', 'desc')->paginate(15);
    $type     = 'Seller';

    return view('backend.product.products.index', compact('products', 'type', 'col_name', 'query', 'seller_id', 'sort_search'));
  }

  public function all_products(Request $request) {


    $col_name    = null;
    $query       = null;
    $seller_id   = null;
    $sort_search = null;
    // $products    = Product::orderBy('created_at', 'desc');
    // Join the uploads table with the product table based on thumbnail_img and id
    $products = Product::orderBy('products.created_at', 'desc')
                ->leftJoin('uploads', 'uploads.id', '=', 'products.thumbnail_img')
                ->select('products.*', 'uploads.file_name as thumbnail_image');

    if ($request->has('user_id') && $request->user_id != null) {
      $products  = $products->where('user_id', $request->user_id);
      $seller_id = $request->user_id;
    }
    if ($request->search != null) {
      $sort_search = $request->search;
      $products    = $products
        ->where('name', 'like', '%' . $sort_search . '%')
        ->orWhereHas('stocks', function ($q) use ($sort_search) {
          $q->where('part_no', 'like', '%' . $sort_search . '%');
        });
    }
    if ($request->type != null) {
      $var       = explode(",", $request->type);
      $col_name  = $var[0];
      $query     = $var[1];
      $products  = $products->orderBy($col_name, $query);
      $sort_type = $request->type;
    }

    $products = $products->paginate(15);
    $type     = 'All';

    // $seller = Seller::with('user')->get();
    $seller = $sellers = Seller::join('users', 'sellers.user_id', '=', 'users.id')
    ->orderBy('users.name', 'ASC')
    ->get(['sellers.id', 'users.name']);
    $category_group=CategoryGroup::orderBy('name','asc')->get();
    $brands=Brand::where('name','!=','')->orderBy('name','asc')->get();
    // foreach($seller as $key=>$value){
    //   echo "<pre>"; print($value->user);
    // }
    // echo "<pre>";print_r($seller);die;
    // echo "<pre>";
    // print_r($products->toArray());
    // die();

    return view('backend.product.products.index', compact('products', 'type', 'col_name', 'query', 'seller_id', 'sort_search', 'seller', 'category_group', 'brands'));
  }

  public function no_images(Request $request) {
    $col_name    = null;
    $query       = null;
    $seller_id   = null;
    $sort_search = null;
    $products    = Product::whereNull('photos')->orderBy('created_at', 'desc');
    if ($request->has('user_id') && $request->user_id != null) {
      $products  = $products->where('user_id', $request->user_id);
      $seller_id = $request->user_id;
    }
    if ($request->search != null) {
      $sort_search = $request->search;
      $products    = $products
        ->where('name', 'like', '%' . $sort_search . '%')
        ->orWhereHas('stocks', function ($q) use ($sort_search) {
          $q->where('part_no', 'like', '%' . $sort_search . '%');
        });
    }
    if ($request->type != null) {
      $var       = explode(",", $request->type);
      $col_name  = $var[0];
      $query     = $var[1];
      $products  = $products->orderBy($col_name, $query);
      $sort_type = $request->type;
    }

    $products = $products->paginate(15);
    $type     = 'All';

    return view('backend.product.products.no-images', compact('products', 'type', 'col_name', 'query', 'seller_id', 'sort_search'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create() {
    CoreComponentRepository::initializeCache();

    $categories = Category::where('parent_id', 0)
      ->with('childrenCategories')
      ->get();

    return view('backend.product.products.create', compact('categories'));
  }

  public function add_more_choice_option(Request $request) {
    $all_attribute_values = AttributeValue::with('attribute')->where('attribute_id', $request->attribute_id)->get();

    $html = '';

    foreach ($all_attribute_values as $row) {
      $html .= '<option value="' . $row->value . '">' . $row->value . '</option>';
    }

    echo json_encode($html);
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(ProductRequest $request) {
    $product = $this->productService->store($request->except([
      '_token', 'warehouse_id', 'seller_sku', 'choice', 'tax_id', 'tax', 'tax_type', 'flash_deal_id', 'flash_discount', 'flash_discount_type',
    ]));
    $request->merge(['product_id' => $product->id]);

    //VAT & Tax
    if ($request->tax_id) {
      $this->productTaxService->store($request->only([
        'tax_id', 'tax', 'tax_type', 'product_id',
      ]));
    }

    //Flash Deal
    $this->productFlashDealService->store($request->only([
      'flash_deal_id', 'flash_discount', 'flash_discount_type',
    ]), $product);

    //Product Stock
    $this->productStockService->store($request->only([
      'warehouse_id', 'seller_id', 'colors_active', 'colors', 'choice_no', 'unit_price', 'carton_price', 'piece_per_carton', 'seller_sku', 'current_stock', 'seller_stock', 'product_id', 'part_no', 'model_no', 'cbm', 'carton_cbm', 'length', 'breadth', 'height', 'weight',
    ]), $product);

    // Product Translations
    $request->merge(['lang' => env('DEFAULT_LANGUAGE')]);
    ProductTranslation::create($request->only([
      'lang', 'name', 'unit', 'description', 'product_id',
    ]));

    flash(translate('Product has been inserted successfully'))->success();

    Artisan::call('view:clear');
    Artisan::call('cache:clear');

    return redirect()->route('products.admin');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id) {
    //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function org_admin_product_edit(Request $request, $id) {


    CoreComponentRepository::initializeCache();

    $product = Product::findOrFail($id);

    $lang       = $request->lang;
    $tags       = json_decode($product->tags);

    $sellers = Seller::join('users', 'sellers.user_id', '=', 'users.id')->select('sellers.*', 'users.name as user_name')->get();

    $categoryGroups = CategoryGroup::orderBy('name','ASC')->get();

    $categories = Category::where('category_group_id', $product->group_id)->get();

    $warehouses =  Warehouse::orderBy('name','ASC')->get();

    $photos = array();
    if($product->photos != "" OR $product->photos != NULL){
      $proPhotosArray = explode(',',$product->photos);
      $photos = Upload::whereIn('id', $proPhotosArray)->get();
    }
    // print_r($photos);die;
    
    return view('backend.product.products.edit', compact('product', 'categoryGroups', 'categories', 'warehouses', 'photos', 'tags', 'sellers', 'lang'));
  }
  public function admin_product_edit(Request $request, $id)
  {

      CoreComponentRepository::initializeCache();

      $product = Product::findOrFail($id);

      $lang = $request->lang;
      $tags = json_decode($product->tags);

      $sellers = Seller::join('users', 'sellers.user_id', '=', 'users.id')
          ->select('sellers.*', 'users.name as user_name')
          ->get();

      $categoryGroups = CategoryGroup::orderBy('name', 'ASC')->get();

      $categories = Category::where('category_group_id', $product->group_id)->get();

      $warehouses = Warehouse::orderBy('name', 'ASC')->get();

      $photos = [];
      if ($product->photos != "" || $product->photos != null) {
          $proPhotosArray = explode(',', $product->photos);
          $photos = Upload::whereIn('id', $proPhotosArray)->get();
      }

     // Fetch product variations and attributes
    $attributeVariations = [];
    $combinedIds = array_unique(array_merge(
        json_decode($product->attributes, true) ?? [],
        json_decode($product->variations, true) ?? []
    ));

    if (!empty($combinedIds)) {
        // Fetch attribute values based on the combined IDs
        $attributeValues = AttributeValue::whereIn('id', $combinedIds)->get();

        // Map attributes and their values
        $attributeVariations = Attribute::whereIn('id', $attributeValues->pluck('attribute_id'))
            ->get()
            ->map(function ($attribute) use ($attributeValues) {
                return [
                    'attribute_id' => $attribute->id,
                    'attribute_name' => $attribute->name,
                    'is_variation' => $attribute->is_variation,
                    'values' => $attributeValues->where('attribute_id', $attribute->id)->pluck('value', 'id'),
                ];
            });
    }

    $allAttributes = Attribute::all();
    $allValues = AttributeValue::all();

          return view('backend.product.products.edit', compact(
              'product',
              'categoryGroups',
              'categories',
              'warehouses',
              'photos',
              'tags',
              'sellers',
              'lang',
              'attributeVariations',
             'allAttributes',
             'allValues'
          ));
  }




public function deleteFile($part_no)
{
    // Fetch all files linked to the given part_no
    $files = Upload::where('file_original_name', $part_no)->get();

    if ($files->isEmpty()) {
        return redirect()->back()->with('error', 'File not found.');
    }

    foreach ($files as $file) {
        // Construct the full file path
        $filePath = public_path($file->file_name);

        // Debugging: Check if the file path is correct
        \Log::info("Deleting file: " . $filePath);

        // Delete the actual file if it exists
        if (File::exists($filePath)) {
            File::delete($filePath);
        }
    }

    // Delete file records from the `uploads` table
    Upload::where('file_original_name', $part_no)->forceDelete();


    // Update the `products` table (set `photos` and `thumbnail_img` to NULL)
    Product::where('part_no', $part_no)->update([
        'photos' => null,
        'thumbnail_img' => null
    ]);

    return redirect()->back()->with('success', 'Files deleted successfully.');
}

public function addVariation(Request $request)
{
    // Fetch the product
    $product = Product::findOrFail($request->product_id);

    $attributeId = null;
    $valueId = null;

    // Handle attribute selection or creation
    if (!empty($request->new_attribute)) {
        $attribute = Attribute::firstOrCreate(
            ['name' => $request->new_attribute],
            [
                'is_variation' => $request->is_variations ? 1 : 0, // Use checkbox value
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );
        $attributeId = $attribute->id;
    } elseif (!empty($request->selected_attribute)) {
        $attributeId = $request->selected_attribute;
    }

    // Handle value selection or creation
    if (!empty($request->new_value)) {
        $value = AttributeValue::firstOrCreate(
            ['attribute_id' => $attributeId, 'value' => $request->new_value],
            ['created_at' => now(), 'updated_at' => now()]
        );
        $valueId = $value->id;
    } elseif (!empty($request->selected_value)) {
        $valueId = $request->selected_value;
    }

    // Add the attribute_values ID to the attributes column
    if ($valueId) {
        $existingAttributes = json_decode($product->attributes, true) ?? [];
        $existingAttributes[] = $valueId; // Add the value ID
        $product->attributes = json_encode(array_unique($existingAttributes));
    }

    // Add the attribute_values ID to the variations column if is_variation is 1
    if ($attributeId) {
        $attribute = Attribute::find($attributeId);

        if ($attribute && $attribute->is_variation == 1 && $valueId) {
            $existingVariations = json_decode($product->variations, true) ?? [];
            $existingVariations[] = $valueId;
            $product->variations = json_encode(array_unique($existingVariations));
        }
    }

    $product->save();

    return redirect()->back()->with('success', translate('Variation added successfully!'));
}





  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function seller_product_edit(Request $request, $id) {

    $product = Product::findOrFail($id);
    $lang    = $request->lang;
    $tags    = json_decode($product->tags);
    // $categories = Category::all();
    $categories = Category::where('parent_id', 0)
      ->with('childrenCategories')
      ->get();
    
    
    return view('backend.product.products.edit', compact('product', 'categories', 'tags', 'lang'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(ProductRequest $request, Product $product) {

    // Update the variant_parent_part_no field
    $variant_parent_part_no= $request->input('variant_parent_part_no');
 
    // echo "<pre>";print_r($request->all());die;
    $part_no = $request->part_no;
    $product = Product::where('part_no', $part_no)->first();
    if($request->mrp == 0){
      $piece_by_carton = 0;
    }else{
      $piece_by_carton = round(50000/($request->mrp - (($request->mrp*24)/100)));
    }
    $product->update([
        'brand_id' => $request->brand_id,
        'group_id' => $request->group_id,
        'category_id' => $request->category_id,
        'seller_id' => $request->seller_id,
        'user_id' => 1,
        'meta_title' => $request->meta_title ?? '',
         'meta_description' => $request->meta_description ?? '',
          'meta_keywords' => $request->meta_keywords ?? '',
        'slug' => strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $request->name ?? '')),
        // 'attributes'=>'[]',
        // 'variations'=>'[]',
        'choice_options'=>'[]',
        'colors'=>'[]',
        'name' => $request->name ?? $product->name,
        'alias_name' => $request->alias_name ?? $product->alias_name,
        'billing_name' => $request-> billing_name?? $product->billing_name,                    
        'mrp' => $request->mrp ?? $product->mrp,
        'warehouse_id' => $request->warehouse_id,                    
        'current_stock' => $request->current_stock ?? $product->current_stock ?? 0,
        'seller_stock' => $request->seller_stock ?? $product->seller_stock ?? 0,
        'hsncode' => $request->hsncode ?? $product->hsncode,
        'tax' => $request->tax ?? $product->tax,
        'tax_type' => $request->tax_type ?? $product->tax_type,
        'generic_name' => $request->generic_name ?? $product->generic_name,
        'weight' => $request->weight ?? $product->weight,
        'piece_by_carton' => $piece_by_carton,
        'purchase_price' => $request->purchase_price ?? $product->purchase_price,
        'approved' => $request->approved ?? $product->approved,
        'published' => $request->published ?? $product->published,
        'description' => $request->description,
        
    ]);

        
        // Handle attributes and variations
            $attributes = [];
            $variations = [];

            // Fetch the updated `is_variation` data from the request
            $isVariationUpdates = $request->input('is_variation', []);

            if ($request->has('attribute_values')) {
                foreach ($request->input('attribute_values') as $attributeId => $values) {
                    foreach ($values as $value) {
                        // Find the attribute by ID
                        $attribute = \App\Models\Attribute::find($attributeId);

                        // If the attribute does not exist, skip this value
                        if (!$attribute) {
                            \Log::warning("Attribute not found: {$attributeId}");
                            continue;
                        }

                        // Update is_variation based on the checkbox input
                        if (isset($isVariationUpdates[$attributeId]) && $isVariationUpdates[$attributeId] == 1) {
                            $attribute->update(['is_variation' => 1]);
                        } else {
                            $attribute->update(['is_variation' => 0]);
                        }

                        // Check if the attribute value exists
                        $existingValue = \App\Models\AttributeValue::where('attribute_id', $attribute->id)
                            ->where('value', $value)
                            ->first();

                        if ($existingValue) {
                            // Add the value ID to attributes
                            $attributes[] = $existingValue->id;

                            // Add to variations if is_variation is 1
                            if ($attribute->is_variation == 1) {
                                $variations[] = $existingValue->id;
                            }
                        } else {
                            // If the value doesn't exist, create a new attribute value
                            $newValue = \App\Models\AttributeValue::create([
                                'attribute_id' => $attribute->id,
                                'value' => $value,
                                'created_at' => now(),
                                'updated_at' => now(),
                            ]);

                            // Add the new value's ID to attributes
                            $attributes[] = $newValue->id;

                            // Add to variations if is_variation is 1
                            if ($attribute->is_variation == 1) {
                                $variations[] = $newValue->id;
                            }
                        }
                    }
                }
            }

            // Ensure attributes and variations are unique
            $attributes = array_unique($attributes);
            $variations = array_unique($variations);

            // Debugging logs
            \Log::info('Final Attributes:', $attributes);
            \Log::info('Final Variations:', $variations);

            // Update attributes and variations in the product table
            $product->update([
                'attributes' => json_encode($attributes), // Store only attribute values
                'variations' => json_encode($variations), // Store variations where is_variation = 1
                'variant_product' => count($variations) > 0 ? 1 : 0,
            ]);

        // end of attribute and variations


    $productWarehouse = ProductWarehouse::where('part_no', $part_no)->first();
    $productWarehouse->update([
        'warehouse_id' => $request->warehouse_id,
        'seller_id' => $request->seller_id,
        'hsncode' => $request->hsncode ?? $product->hsncode,
        'seller_stock' => 1,
        'sz_manual_price' => $request->mrp ?? $product->mrp,
        'variant' => strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $request->name ?? '')),
    ]);

    //Product
    // $product = $this->productService->update($request->except([
    //   '_token', 'sku', 'choice', 'tax_id', 'tax', 'tax_type', 'flash_deal_id', 'flash_discount', 'flash_discount_type',
    // ]), $product);

    // //Product Stock
    // foreach ($product->stocks as $key => $stock) {
    //   $stock->delete();
    // }

    // $request->merge(['product_id' => $product->id]);
    // $this->productStockService->store($request->only([
    //   'colors_active', 'colors', 'choice_no', 'unit_price', 'sku', 'current_stock', 'product_id',
    // ]), $product);

    // //Flash Deal
    // $this->productFlashDealService->store($request->only([
    //   'flash_deal_id', 'flash_discount', 'flash_discount_type',
    // ]), $product);

    // //VAT & Tax
    // if ($request->tax_id) {
    //   ProductTax::where('product_id', $product->id)->delete();
    //   $this->productTaxService->store($request->only([
    //     'tax_id', 'tax', 'tax_type', 'product_id',
    //   ]));
    // }

    // Product Translations
    ProductTranslation::updateOrCreate(
      $request->only([
        'lang', 'product_id',
      ]),
      $request->only([
        'name', 'unit', 'description',
      ])
    );

    // Push item data to Salezing
    $result=array();
    $result['part_no']= $part_no;
    $response = Http::withHeaders([
        'Content-Type' => 'application/json',
    ])->post('https://mazingbusiness.com/api/v2/item-push', $result);
    \Log::info('Salzing Item Push Status: '  . json_encode($response->json(), JSON_PRETTY_PRINT));
    
    flash(translate('Product has been updated successfully'))->success();

    Artisan::call('view:clear');
    Artisan::call('cache:clear');

    return back();
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id) {
    $product = Product::findOrFail($id);

    $product->product_translations()->delete();
    $product->stocks()->delete();
    $product->taxes()->delete();

    if (Product::destroy($id)) {
      Cart::where('product_id', $id)->delete();

      flash(translate('Product has been deleted successfully'))->success();

      Artisan::call('view:clear');
      Artisan::call('cache:clear');

      return back();
    } else {
      flash(translate('Something went wrong'))->error();
      return back();
    }
  }

  public function bulk_product_delete(Request $request) {
    if ($request->id) {
      foreach ($request->id as $product_id) {
        $this->destroy($product_id);
      }
    }

    return 1;
  }

  /**
   * Duplicates the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function duplicate(Request $request, $id) {
    $product = Product::find($id);

    $product_new       = $product->replicate();
    $product_new->slug = $product_new->slug . '-' . Str::random(5);
    $product_new->save();

    //Product Stock
    $this->productStockService->product_duplicate_store($product->stocks, $product_new);

    //VAT & Tax
    $this->productTaxService->product_duplicate_store($product->taxes, $product_new);

    flash(translate('Product has been duplicated successfully'))->success();
    if ($request->type == 'In House') {
      return redirect()->route('products.admin');
    } elseif ($request->type == 'Seller') {
      return redirect()->route('products.seller');
    } elseif ($request->type == 'All') {
      return redirect()->route('products.all');
    }

  }

  public function get_products_by_brand(Request $request) {
    $products = Product::where('brand_id', $request->brand_id)->get();
    return view('partials.product_select', compact('products'));
  }

  public function updateTodaysDeal(Request $request) {
    $product              = Product::findOrFail($request->id);
    $product->todays_deal = $request->status;
    $product->save();
    Cache::forget('todays_deal_products');
    return 1;
  }

  public function updatePublished(Request $request) {
    $product            = Product::findOrFail($request->id);
    $product->published = $request->status;

    if ($product->added_by == 'seller' && addon_is_activated('seller_subscription') && $request->status == 1) {
      $shop = $product->user->shop;
      if (
        $shop->package_invalid_at == null
        || Carbon::now()->diffInDays(Carbon::parse($shop->package_invalid_at), false) < 0
        || $shop->product_upload_limit <= $shop->user->products()->where('published', 1)->count()
      ) {
        return 0;
      }
    }

    $product->save();

    Artisan::call('view:clear');
    Artisan::call('cache:clear');
    return 1;
  }

  public function updateProductApproval(Request $request) {
    $product           = Product::findOrFail($request->id);
    $product->approved = $request->approved;

    if ($product->added_by == 'seller' && addon_is_activated('seller_subscription')) {
      $shop = $product->user->shop;
      if (
        $shop->package_invalid_at == null
        || Carbon::now()->diffInDays(Carbon::parse($shop->package_invalid_at), false) < 0
        || $shop->product_upload_limit <= $shop->user->products()->where('published', 1)->count()
      ) {
        return 0;
      }
    }

    $product->save();

    Artisan::call('view:clear');
    Artisan::call('cache:clear');
    return 1;
  }

  public function updateFeatured(Request $request) {
    $product           = Product::findOrFail($request->id);
    $product->featured = $request->status;
    if ($product->save()) {
      Artisan::call('view:clear');
      Artisan::call('cache:clear');
      return 1;
    }
    return 0;
  }
  public function updateOwnBrandPublished(Request $request) {
      $product           = OwnBrandProduct::findOrFail($request->id);
      $product->published = $request->status;
      if ($product->save()) {
        Artisan::call('view:clear');
        Artisan::call('cache:clear');
        return 1;
      }
      return 0;
  }
  public function updateOwnBrandProductApproval(Request $request) {
      $product           = OwnBrandProduct::findOrFail($request->id);
      $product->approved = $request->approved;
      if ($product->save()) {
        Artisan::call('view:clear');
        Artisan::call('cache:clear');
        return 1;
      }
      return 0;
  }
  public function sku_combination(Request $request) {
    $options = array();
    if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
      $colors_active = 1;
      array_push($options, $request->colors);
    } else {
      $colors_active = 0;
    }

    $unit_price   = $request->unit_price;
    $product_name = $request->name;

    if ($request->has('choice_no')) {
      foreach ($request->choice_no as $key => $no) {
        $name = 'choice_options_' . $no;
        $data = array();
        // foreach (json_decode($request[$name][0]) as $key => $item) {
        foreach ($request[$name] as $key => $item) {
          // array_push($data, $item->value);
          array_push($data, $item);
        }
        array_push($options, $data);
      }
    }

    $combinations = Combinations::makeCombinations($options);
    return view('backend.product.products.sku_combinations', compact('combinations', 'unit_price', 'colors_active', 'product_name'));
  }

  public function sku_combination_edit(Request $request) {
    $product = Product::findOrFail($request->id);

    $options = array();
    if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
      $colors_active = 1;
      array_push($options, $request->colors);
    } else {
      $colors_active = 0;
    }

    $product_name = $request->name;
    $unit_price   = $request->unit_price;

    if ($request->has('choice_no')) {
      foreach ($request->choice_no as $key => $no) {
        $name = 'choice_options_' . $no;
        $data = array();
        // foreach (json_decode($request[$name][0]) as $key => $item) {
        foreach ($request[$name] as $key => $item) {
          // array_push($data, $item->value);
          array_push($data, $item);
        }
        array_push($options, $data);
      }
    }

    $combinations = Combinations::makeCombinations($options);
    return view('backend.product.products.sku_combinations_edit', compact('combinations', 'unit_price', 'colors_active', 'product_name', 'product'));
  }

  public function exportDataToGoogleSheet(Request $request)
  {
    $seller_id = $request->input('seller_id') ?? 0;
    $category_group_id = $request->input('category_group_id') ?? 0;
    $category_id = $request->input('category_id') ?? 0;
    $brand_id = $request->input('brand_id') ?? 0;
    $stock = $request->input('stock') ?? 2;
    // Fetch product data from the database
    $products = Product::query()
    ->join('category_groups', 'products.group_id', '=', 'category_groups.id')
    ->join('categories', 'products.category_id', '=', 'categories.id')
    ->join('brands', 'products.brand_id', '=', 'brands.id')
    ->join('warehouses', 'products.warehouse_id', '=', 'warehouses.id')
    ->join('sellers', 'products.seller_id', '=', 'sellers.id') // Join with sellers table
    ->join('users', 'sellers.user_id', '=', 'users.id') // Join with users table using sellers.user_id
    ->when(!empty($seller_id) && $seller_id != 0, function($query) use ($seller_id) {
        $query->whereIn('products.seller_id', $seller_id);
    })
    ->when(!empty($category_group_id) && $category_group_id != 0, function($query) use ($category_group_id) {
        $query->whereIn('products.group_id', $category_group_id);
    })
    ->when(!empty($category_id) && $category_id != 0, function($query) use ($category_id) {
        $query->whereIn('products.category_id', $category_id);
    })
    ->when(!empty($brand_id) && $brand_id != 0, function($query) use ($brand_id) {
        $query->whereIn('products.brand_id', $brand_id);
    })
    ->when(!empty($stock), function($query) use ($stock) {
        if ($stock == 1) {
            $query->where('products.current_stock', '>', 0); // Ensure products with stock
        } elseif ($stock == 0) {
            $query->where('products.current_stock', '<=', 0); // Ensure products without stock
        }
    })
    ->select(
        'products.*', 
        'brands.name as brand_name', 
        'category_groups.name as category_group_name',
        'categories.name as category_name', 
        'warehouses.name as warehouse_name',
        'users.name as seller_name' // Fetch the user's name through sellers and users tables
    )
    ->orderBy('products.name', 'ASC')
    ->get();


    // Convert the data to an array of arrays									
    $values = $products->map(function ($product) {
        return [
            $product->part_no ?? '',
            $product->brand_name ?? '',
            $product->name ?? '',
            $product->alias_name ?? '',
            $product->billing_name ?? '',            
            $product->category_group_name ?? '',
            $product->category_name ?? '', 
            $product->mrp ?? '',
            $product->warehouse_name ?? '',            
            $product->seller_name ?? '',
            $product->seller_stock ?? '',
            $product->hsncode ?? '',
            $product->tax ?? '',
            $product->generic_name ?? '',
            $product->weight ?? '',
            $product->purchase_price ?? '',
            $product->cash_and_carry_item ?? ''            
        ];
    })->toArray();
    // dd($values);
    
    // Clear previous data
    $clearRange = config('sheets.clear_range');
    $this->sheetsService->clearData($clearRange);

    // Specify the range where you want to start inserting the data (e.g., starting from cell A1)
    $range = config('sheets.range');

    // Append data to Google Sheets
    $this->sheetsService->appendData($range, $values);

    return response()->json(['status' => 'success']);
  }

  public function updateProductsFromGoogleSheet()
  {
      // Specify the range of data you want to fetch from the Google Sheet
      $range = config('sheets.get_data_range'); // e.g., 'Sheet1!A2:M' to fetch from A2 to M

      // Fetch data from Google Sheets
      $rows = $this->sheetsService->getData($range);

      // Process each row of data
      foreach ($rows as $row) {
          // Assuming the following order of data in the sheet:
          $part_no = $row[0]; // part_no should be in the first column
          $brand_name =  $row[1];
          $category_group_name = $row[5];
          $category_name = $row[6];
          $warehouse_name = $row[8];
          $seller_name = $row[9];          

          $brandData = Brand::where('name',$brand_name)->first();
          if (!$brandData) {
              $slug = strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $brand_name ?? ''));
              $brandData = Brand::create(['name' => $brand_name,'slug' => $slug]);
          }
          $brand_id = $brandData->id;
          $categoryData = Category::where('name', $category_name)->first();
          $catGroupData = CategoryGroup::where('name', $category_group_name)->first();
          if (!$catGroupData) {
			  $slug = strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $category_group_name ?? ''));
              $catGroupData = CategoryGroup::create(['name' => $category_group_name,'slug' => $slug]);
              if (!$categoryData) {
				 $slug = strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $category_name ?? '')); 
                 $categoryData = Category::create(['name' => $category_name,'category_group_id'=>$catGroupData->id,'slug' => $slug]);
              }
          }
          $category_group_id = $catGroupData->id;
          $categoryData = Category::where('name', $category_name)->first();
          if (!$categoryData) {
			  $slug = strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $category_name ?? ''));
              $categoryData = Category::create(['name' => $category_name,'category_group_id'=>$catGroupData->id,'slug' => $slug]);
          }
          $category_id = $categoryData->id;

          $sellerUserData = User::where('name', $seller_name)->first();
          $sellerData = Seller::where('user_id',$sellerUserData->id)->first();
          $seller_id = $sellerData->id;

          $warehouseData = Warehouse::where('name', $warehouse_name)->first();
          $warehouse_id = $warehouseData->id;
          
          if($row[7] == 0){
            $piece_by_carton = 0;
          }else{
            $piece_by_carton = round(50000/($row[7] - (($row[7]*24)/100)));
          }

          if($part_no != ""){           
            // Find the product by part_no
            $product = Product::where('part_no', $part_no)->first();
            // If the product exists, update its details
            if ($product) {                
                $product->update([
                    'brand_id' => $brand_id,
                    'group_id' => $category_group_id,
                    'category_id' => $category_id,
                    'seller_id' => $seller_id,
                    'user_id' => 1,
                    'meta_title' => $row[2] ?? '',
                    'slug' => strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $row[2] ?? '')),
                    'attributes'=>'[]',
                    'choice_options'=>'[]',
                    'colors'=>'[]',
                    'variations'=>'[]',
                    'name' => $row[2] ?? $product->name,
                    'alias_name' => $row[3] ?? $product->alias_name,
                    'billing_name' => $row[4] ?? $product->billing_name,                    
                    'mrp' => $row[7] ?? $product->mrp,
                    'warehouse_id' => $warehouse_id,                    
                    'seller_stock' => $row[10] ?? $product->seller_stock,
                    'hsncode' => $row[11] ?? $product->hsncode,
                    'tax' => $row[12] ?? $product->tax,
                    'generic_name' => $row[13] ?? $product->generic_name,
                    'weight' => $row[14] ?? $product->weight,
                    'piece_by_carton' => $piece_by_carton,
                    'purchase_price' => $row[15] ?? $product->purchase_price,
                    'cash_and_carry_item' => $row[16] ?? $product->cash_and_carry_item,
                ]);
                $productWarehouse = ProductWarehouse::where('part_no', $part_no)->first();
                $productWarehouse->update([
                    'warehouse_id' => $warehouse_id,
                    'seller_id' => $seller_id,
                    'hsncode' => $row[11] ?? $product->hsncode,
                    'seller_stock' => 1,
                    'sz_manual_price' => $row[7] ?? $product->mrp,
                    'variant' => strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $row[2] ?? '')),
                ]);
            }
          }else{
            $productData = Product::orderBy('part_no','DESC')->first();
            $part_no = 'MZ'.(str_replace('MZ', '', $productData->part_no) + 1);
            $data = [
                'brand_id' => $brand_id,
                'group_id' => $category_group_id,
                'category_id' => $category_id,
                'seller_id' => $seller_id,
                'user_id' => 1,
                'meta_title' => $row[2] ?? '',
                'slug' => strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $row[2] ?? '')),
                'attributes'=>'[]',
                'choice_options'=>'[]',
                'colors'=>'[]',
                'variations'=>'[]',
                'part_no' => $part_no,
                'name' => $row[2] ?? '',
                'alias_name' => $row[3] ?? '',
                'billing_name' => $row[4] ?? '',
                'mrp' => $row[7] ?? '',
                'warehouse_id' => $warehouse_id ?? '',
                'seller_stock' => $row[10] ?? '',
                'hsncode' => $row[11] ?? '',
                'tax' => $row[12] ?? '',
                'generic_name' => $row[13] ?? '',
                'weight' => $row[14] ?? '',
                'piece_by_carton' => $piece_by_carton,
                'purchase_price' => $row[15] ?? '',
                'cash_and_carry_item' => $row[16] ?? '0',
            ];
            $productData = Product::create($data);

            $data_pw = [
                'product_id' => $productData->id,
                'part_no' => $part_no,
                'warehouse_id' => $warehouse_id,
                'seller_id' => $seller_id,
                'hsncode' => $row[11] ?? $product->hsncode,
                'seller_stock' => 1,
                'sz_manual_price' => $row[7] ?? $product->mrp,
                'variant' => strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $row[2] ?? '')),
            ];
            // Create a new product record in the database
            ProductWarehouse::create($data_pw);            
          }
          // Push item data to Salezing
          $result=array();
          $result['part_no']= $part_no;

          //print_r($result);
          $response = Http::withHeaders([
              'Content-Type' => 'application/json',
          ])->post('https://mazingbusiness.com/api/v2/item-push', $result);
          \Log::info('Salzing Item Push Status: '  . json_encode($response->json(), JSON_PRETTY_PRINT));
      }
      return response()->json(['status' => 'success']);
  }

  public function allOwnBrandProducts(Request $request) {
    $col_name    = null;
    $query       = null;
    $seller_id   = null;
    $sort_search = null;
    $products    = OwnBrandProduct::orderBy('created_at', 'desc');
    
    if ($request->search != null) {
      $sort_search = $request->search;
      $products    = $products
        ->where('name', 'like', '%' . $sort_search . '%')
        ->orWhere('part_no', 'like', '%' . $sort_search . '%');
    }
    if ($request->type != null) {
      $var       = explode(",", $request->type);
      $col_name  = $var[0];
      $query     = $var[1];
      $products  = $products->orderBy($col_name, $query);
      $sort_type = $request->type;
    }

    $products = $products->paginate(15);
    $type     = 'All';

    $category_group=OwnBrandCategoryGroup::orderBy('name','asc')->get();

    return view('backend.product.products.allOwnBrandProducts', compact('products', 'type', 'col_name', 'query',  'sort_search', 'category_group'));
  }
  
  public function createOrUpdateTheOwnBrandProductsFromGoogleSheet()
  {
      // Specify the range of data you want to fetch from the Google Sheet
      $range = config('sheets.get_own_brand_data_range'); // e.g., 'Sheet1!A2:M' to fetch from A2 to M
      // $range = 'OwnBrandProduct'; // Fetches the entire sheet dynamically
      $rows = $this->sheetsService->getData($range);
      // Fetch data from Google Sheets
      // $rows = $this->sheetsService->getData($range);
      // echo "<pre>";print_r($rows);die;
      // Process each row of data
      foreach ($rows as $row) {
        // echo "<pre>"; print_r($row[17]);die;
        // Assuming the following order of data in the sheet:
        $part_no = !empty($row[0]) ? $row[0] : ''; // part_no should be in the first column
        $product_name =  !empty($row[1]) ? $row[1] : '';
        $alias_name = !empty($row[2]) ? $row[2] : '';;
        $category_group_name = !empty($row[3]) ? $row[3] : '';
        $category_name = !empty($row[4]) ? $row[4] : '';
        $dollar_purchase_price = !empty($row[5]) ? $row[5] : '';
        $inr_br = !empty($row[6]) ? $row[6] : '';
        $inr_sl = !empty($row[7]) ? $row[7] : '';
        $inr_go = !empty($row[8]) ? $row[8] : '';
        $doller_br = !empty($row[9]) ? $row[9] : '';
        $doller_sl = !empty($row[10]) ? $row[10] : '';
        $doller_go = !empty($row[11]) ? $row[11] : '';
        $weight = !empty($row[12]) ? $row[12] : '';
        $moq1 = !empty($row[13]) ? $row[13] : '';
        $moq2 = !empty($row[14]) ? $row[14] : '';
        $compatable_model = !empty($row[15]) ? $row[15] : '';
        $country_origin = !empty($row[16]) ? $row[16] : '';
        $cbm = !empty($row[17]) ? $row[17] : '';
        $description = !empty($row[18]) ? $row[18] : '';
        // print_r($product);die;
        $categoryData = OwnBrandCategory::where('name', $category_name)->first();
        $catGroupData = OwnBrandCategoryGroup::where('name', $category_group_name)->first();
        if (!$catGroupData) {
            $catGroupData = OwnBrandCategoryGroup::create(['name' => $category_group_name,'slug'=>strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $category_group_name ?? ''). '-' . Str::random(5))]);
            if (!$categoryData) {
              $categoryData = OwnBrandCategory::create(['name' => $category_name,'category_group_id'=>$catGroupData->id,'slug'=>strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $category_name ?? ''). '-' . Str::random(5))]);
            }
        }
        $category_group_id = $catGroupData->id;
        $categoryData = OwnBrandCategory::where('name', $category_name)->first();
        if (!$categoryData) {
            $categoryData = OwnBrandCategory::create(['name' => $category_name,'category_group_id'=>$catGroupData->id,'slug'=>strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $category_name ?? ''). '-' . Str::random(5))]);
        }
        $category_id = $categoryData->id;          

        if($part_no != ""){           
          // Find the product by part_no
          $product = OwnBrandProduct::where('part_no', $part_no)->first();
          
          // If the product exists, update its details
          if ($product !== NULL) {                
              $product->update([
                  'part_no' => $part_no,
                  'alias_name' => $alias_name,
                  'dollar_purchase_price' => $dollar_purchase_price,
                  'name' => $product_name,
                  'group_id' => $category_group_id,
                  'category_id' => $category_id,
                  'slug' => strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $product_name ?? ''). '-' . Str::random(5)),
                  'description'=>$description,
                  'min_order_qty_1'=>$moq1,
                  'min_order_qty_2'=>$moq2,
                  'weight'=>$weight,
                  'country_of_origin' => $country_origin,
                  'compatable_model' => $compatable_model,
                  'cbm' => $cbm,
                  'inr_bronze' => $inr_br,
                  'inr_silver' => $inr_sl,
                  'inr_gold' => $inr_go,
                  'doller_bronze' => $doller_br,
                  'doller_silver' => $doller_sl,
                  'doller_gold' => $doller_go,
              ]);
          }
        }else{
          $productData = OwnBrandProduct::orderBy('part_no','DESC')->first();
          if($productData!==NULL){
            $number = str_replace('IMZ', '', $productData->part_no) + 1;
            $number = str_pad($number, 5, '0', STR_PAD_LEFT);
            $part_no = 'IMZ'.$number;
          }else{
            $part_no = 'IMZ00001';
          }

          $product = new OwnBrandProduct();
          $product->part_no = $part_no;
          $product->alias_name = $alias_name;
          $product->dollar_purchase_price = $dollar_purchase_price;
          $product->name = $product_name;
          $product->group_id = $category_group_id;
          $product->category_id = $category_id;
          $product->slug = strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $product_name ?? ''). '-' . Str::random(5));
          $product->description = $description;
          $product->min_order_qty_1 = $moq1;
          $product->min_order_qty_2 = $moq2;
          $product->weight = $weight;
          $product->country_of_origin = $country_origin;
          $product->compatable_model = $compatable_model;
          $product->cbm = $cbm;
          $product->inr_bronze = $inr_br;
          $product->inr_silver = $inr_sl;
          $product->inr_gold = $inr_go;
          $product->doller_bronze = $doller_br;
          $product->doller_silver = $doller_sl;
          $product->doller_gold = $doller_go;
          $product->save();
          
          // $data = [
          //     'part_no' => $part_no,
          //     'alias_name' => $alias_name,
          //     'dollar_purchase_price' => $dollar_purchase_price,
          //     'name' => $product_name,
          //     'group_id' => $category_group_id,
          //     'category_id' => $category_id,
          //     'slug' => strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $product_name ?? ''). '-' . Str::random(5)),
          //     'description'=>$description,
          //     'min_order_qty_1'=>$moq1,
          //     'min_order_qty_2'=>$moq2,
          //     'weight'=>$weight,
          //     'country_of_origin' => $country_origin,
          //     'compatable_model' => $compatable_model,
          //     'cbm' => $cbm,
          //     'inr_bronze' => $inr_br,
          //     'inr_silver' => $inr_sl,
          //     'inr_gold' => $inr_go,
          //     'doller_bronze' => $doller_br,
          //     'doller_silver' => $doller_sl,
          //     'doller_gold' => $doller_go,
          // ];
          
          // $productData = OwnBrandProduct::create($data); dd($data);           
        }
        // Push item data to Salezing
        // $result=array();
        // $result['part_no']= $part_no;

        //print_r($result);
        // $response = Http::withHeaders([
        //     'Content-Type' => 'application/json',
        // ])->post('https://mazingbusiness.com/api/v2/item-push', $result);
        // \Log::info('Salzing Item Push Status: '  . json_encode($response->json(), JSON_PRETTY_PRINT));
      }
      return response()->json(['status' => 'success']);
  }

  public function own_brand_product_edit(Request $request, $id) {
    CoreComponentRepository::initializeCache();

    $product = OwnBrandProduct::findOrFail($id);

    $lang       = $request->lang;
    $tags       = json_decode($product->tags);

    $categoryGroups = OwnBrandCategoryGroup::orderBy('name','ASC')->get();
    $categories = OwnBrandCategory::where('category_group_id', $product->group_id)->get();
    $photos = array();
    if($product->photos != "" OR $product->photos != NULL){
      $proPhotosArray = explode(',',$product->photos);
      $photos = Upload::whereIn('id', $proPhotosArray)->get();
    }
    // print_r($photos);die;
    
    return view('backend.product.products.own_brand_product_edit', compact('product', 'categoryGroups', 'categories', 'photos', 'lang'));
  }

  public function ownBrandProductUpdate(OwnBrandProductRequest $request, Product $product) {

    // echo "<pre>";print_r($request->all());die;
    $part_no = $request->part_no;
    $product = OwnBrandProduct::where('part_no', $part_no)->first();
    
    $product->update([
        'part_no' => $request->part_no,
        'alias_name' => $request->alias_name,
        'mrp' => $request->mrp,
        'name' => $request->name,
        'group_id' =>  $request->group_id,
        'category_id' => $request->category_id,
        'slug' => strtolower(str_replace([' ', '"', "'", '(', ')', '/', '\\', '.'], '-', $request->name ?? '')),
        'description'=>$request->description,
        'approved'=>$request->approved,
        'min_order_qty_1'=>$request->min_order_qty_1,
        'min_order_qty_2'=>$request->min_order_qty_2,
        'weight' => $request->weight ?? $product->weight,
        'country_of_origin' => $request->country_of_origin ?? $product->country_of_origin,
        'compatable_model' => $request-> compatable_model?? $product->compatable_model,                    
        'cbm' => $request->cbm ?? $product->cbm,
        'inr_bronze' => $request->inr_bronze ?? $product->inr_bronze,                    
        'inr_silver' => $request->inr_silver ?? $product->inr_silver,
        'inr_gold' => $request->inr_gold ?? $product->inr_gold,
        'doller_bronze' => $request->doller_bronze ?? $product->doller_bronze,
        'doller_silver' => $request->doller_silver ?? $product->doller_silver,
        'doller_gold' => $request->doller_gold ?? $product->doller_gold,
        'meta_title' => $request->meta_title ?? $product->meta_title,
        'meta_keywords' => $request->meta_keywords ?? $product->meta_keywords,
        'meta_description' => $request->meta_description,
        'published' => $request->published ?? $product->published
    ]);

    // Product Translations
    // ProductTranslation::updateOrCreate(
    //   $request->only([
    //     'lang', 'product_id',
    //   ]),
    //   $request->only([
    //     'name', 'unit', 'description',
    //   ])
    // );

    // // Push item data to Salezing
    // $result=array();
    // $result['part_no']= $part_no;
    // $response = Http::withHeaders([
    //     'Content-Type' => 'application/json',
    // ])->post('https://mazingbusiness.com/api/v2/item-push', $result);
    // \Log::info('Salzing Item Push Status: '  . json_encode($response->json(), JSON_PRETTY_PRINT));
    
    flash(translate('Product has been updated successfully'))->success();

    Artisan::call('view:clear');
    Artisan::call('cache:clear');

    return back();
  }

  public function ownBrandProductDelete($id) {
    $product = OwnBrandProduct::findOrFail($id);

    if (OwnBrandProduct::destroy($id)) {
      // Cart::where('product_id', $id)->delete();

      flash(translate('Product has been deleted successfully'))->success();

      Artisan::call('view:clear');
      Artisan::call('cache:clear');

      return back();
    } else {
      flash(translate('Something went wrong'))->error();
      return back();
    }
  }

  

}
