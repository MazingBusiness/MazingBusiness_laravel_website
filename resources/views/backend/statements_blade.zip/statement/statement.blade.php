@extends('backend.layouts.app')

@section('content')
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
<meta name="csrf-token" content="{{ csrf_token() }}">
<style>

.sync-button {
    background-color: #007bff; /* Blue color for Sync Button */
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 13px;
    cursor: pointer;
    border-radius: 42px;
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 149px; /* Same size as WhatsApp button */
    height: 45px; /* Set fixed height */
}
.sync-button .loader {
    border: 4px solid rgba(255, 255, 255, 0.3); /* Light white with transparency */
    border-top: 4px solid white; /* Solid white */
    border-radius: 50%;
    width: 20px;
    height: 20px;
    animation: spin 1s linear infinite;
    display: none; /* Initially hidden */
    position: absolute;
}

.sync-button .button-text {
    visibility: visible; /* Initially visible */
}

/* Add loader animation */
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
    .d-inline-flex {
        display: inline-flex;
        align-items: center;
    }

    .btn-icon {
        margin-right: 5px;
    }

    .table td {
        vertical-align: middle;
    }

    .whatsapp-button {
        background-color: #25D366;
        color: white;
        border: none;
        padding: 10px 20px;
        font-size: 13px;
        cursor: pointer;
        border-radius: 42px;
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 123px;
        height: 45px;
    }

    .whatsapp-button .loader {
        border: 4px solid rgba(255, 255, 255, 0.3);
        border-top: 4px solid white;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        animation: spin 1s linear infinite;
        display: none;
        position: absolute;
    }

    .whatsapp-button .button-text {
        visibility: visible;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    .button-group {
        display: flex;
        gap: 10px;
    }

    .small-column {
        width: 100px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    @media (max-width: 767.98px) {
        .whatsapp-button {
            width: 150px;
            font-size: 14px;
        }

        .table th, .table td {
            white-space: nowrap;
        }

        .small-column {
            width: 80px;
        }
    }

    .notify-manager-button {
    background-color: #ff9800; /* Orange color for Notify Button */
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 12px;
    cursor: pointer;
    border-radius: 42px;
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 149px; /* Same size as Sync button */
    height: 45px;
}

.notify-manager-button .loader {
    border: 4px solid rgba(255, 255, 255, 0.3); /* Light white with transparency */
    border-top: 4px solid white; /* Solid white */
    border-radius: 50%;
    width: 20px;
    height: 20px;
    animation: spin 1s linear infinite;
    display: none; /* Initially hidden */
    position: absolute;
}

.notify-manager-button .button-text {
    visibility: visible; /* Initially visible */
}

 /* Custom Date Picker Styling */
    .custom-date-picker {
        padding: 10px;
        font-size: 14px;
        border: 2px solid #ced4da;
        border-radius: 8px;
        width: 100%;
        background-color: #fff;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        color: #495057;
        outline: none;
        appearance: none; /* Remove default date picker arrow */
        position: relative;
    }

    .custom-date-picker::-webkit-calendar-picker-indicator {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        height: 20px;
        width: 20px;
        opacity: 0.5;
    }

    /* On hover effect */
    .custom-date-picker:hover {
        border-color: #80bdff;
        background-color: #f8f9fa;
    }

    /* On focus effect */
    .custom-date-picker:focus {
        border-color: #80bdff;
        background-color: #fff;
        outline: none;
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }

    /* Adjust date picker icon visibility */
    .custom-date-picker::-webkit-calendar-picker-indicator:hover {
        opacity: 1;
    }
</style>

<div class="aiz-titlebar text-left mt-2 mb-3 d-flex justify-content-between">
    <div class="align-items-center">
        <h1 class="h3">Statement</h1>
    </div>
    <div class="button-group">
        <div class="whatsapp-button-container">
            <button type="button" class="whatsapp-button btn btn-sm" id="whatsapp-all">
                <span class="button-text"><i class="fab fa-whatsapp"></i> WhatsApp</span>
                <div class="loader"></div>
            </button>
            <input type="hidden" name="" value="{{$totalCustomersWithDueOrOverdue}}" id="total_customer_with_due_overdue">
        </div>
        <!-- <div class="whatsapp-button-container">
            <button type="button" class="whatsapp-button" id="whatsapp-checked">
                <span class="button-text"><i class="fab fa-whatsapp"></i> WhatsApp Checked</span>
                <div class="loader"></div>
            </button>
        </div> -->

        <!-- Notify Manager Button -->
        <div class="notify-manager-button-container">
    <button type="button" class="notify-manager-button btn btn-sm" id="notify-manager">
        <span class="button-text"><i class="fas fa-bell"></i> Notify Manager</span>
        <div class="loader" style="display: none;"></div>
    </button>
</div>

        <!-- Sync Checked Button -->
        <div class="sync-button-container">
            <button type="button" class="sync-button btn btn-sm" id="sync-checked">
                <span class="button-text"><i class="fas fa-sync"></i> Sync Checked</span>
                <div class="loader"></div>
            </button>
        </div>

         <!-- Add the Export Button -->
         <div class="export-button-container">
            <form method="GET" action="{{ route('adminStatementExport') }}">
                <input type="hidden" name="warehouse_id" value="{{ request()->warehouse_id }}">
                <input type="hidden" name="manager_id" value="{{ request()->manager_id }}">
                <input type="hidden" name="duefilter" value="{{ request()->duefilter }}">
                <button type="submit" style="border-radius:42px;background-color:#6A5ACD;" class="btn btn-success">
                    <i class="fas fa-file-export"></i> Export
                </button>
            </form>
        </div>

        
    </div>
</div>

<div class="card">
    <div class="card-header row gutters-5">
        <form method="GET" action="{{ route('adminStatement') }}">
            <!-- Search Bar -->
            <div class="row gutters-5 mb-4">
                <div class="col-md-12">
                    <label for="party_code" class="form-label font-weight-bold">Search</label>
                    <input type="text" name="party_code" id="party_code" class="form-control" 
                           placeholder="Search by Party Code, Company Name, or Name" 
                           value="{{ request()->party_code }}">
                </div>
            </div>

            <!-- Filters -->
            <div class="row gutters-5 mb-4">
                <!-- Branch -->
                <div class="col-md-3">
                    <label for="branch-select" class="form-label font-weight-bold">Branch</label>
                    <select class="form-control" name="warehouse_id" id="branch-select">
                        <option value="">Select Branch</option>
                        @foreach($warehouses as $warehouse)
                            @if($warehouse->id != 3 && $warehouse->id != 5)
                                <option value="{{ $warehouse->id }}" 
                                    {{ request()->warehouse_id == $warehouse->id ? 'selected' : '' }}>
                                    {{ $warehouse->name }}
                                </option>
                            @endif
                        @endforeach
                    </select>
                </div>

                <!-- Manager -->
                <div class="col-md-3">
                    <label for="manager-select" class="form-label font-weight-bold">Manager</label>
                    <select class="form-control" name="manager_id" id="manager-select">
                        <option value="">Select Manager</option>
                        @foreach($managers as $manager)
                            <option value="{{ $manager->id }}" 
                                {{ request()->manager_id == $manager->id ? 'selected' : '' }}>
                                {{ $manager->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <!-- City -->
                <div class="col-md-3">
                    <label for="city-select" class="form-label font-weight-bold">City</label>
                    <select class="form-control" name="city_id" id="city-select">
                        <option value="">Select City</option>
                        <!-- Cities will be populated dynamically via AJAX -->
                    </select>
                </div>

                <!-- Due Filter -->
                <div class="col-md-3">
                    <label for="duefilter-select" class="form-label font-weight-bold">Due Filter</label>
                    <select class="form-control" name="duefilter" id="duefilter-select">
                        <option value="">Select Due Filter</option>
                        <option value="due" {{ request()->duefilter == 'due' ? 'selected' : '' }}>Due</option>
                        <option value="overdue" {{ request()->duefilter == 'overdue' ? 'selected' : '' }}>Overdue</option>
                    </select>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="row">
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary btn-sm w-100">Apply Filters</button>
                </div>
            </div>
        </form>



        
    </div>

    <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-3">
    <div style="background-color: white; color: black; padding: 9px 14px; border-radius: 10px; font-size:13px;">
    <h4 style="font-size: 15px;">
    Total due Amount: 
    <strong>₹{{ number_format($totalDueAmount, 2) }}</strong>
</h4>
    </div>
    <div style="background-color: white; color: black; padding: 9px 14px; border-radius: 10px;font-size:13px;">
        <h4 style="font-size: 15px;">
        Total Overdue Amount: 
        <strong>₹{{ number_format($totalOverdueAmount, 2) }}</strong>
         </h4>
    </div>
</div>
    @if(!empty($processedData) && count($processedData) > 0)
        <div class="table-responsive">
            <table class="table aiz-table mb-0">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="select-all"></th>
                        <th>Party Name</th>
                        <th>Party Code</th>
                        <!-- <th>Ledger Code</th> -->
                        <th>Phone</th>
                        <!-- Credit Days Sorting -->
                        <th>
                            <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'credit_days', 'sort_order' => (request('sort_by') == 'credit_days' && request('sort_order') == 'asc') ? 'desc' : 'asc']) }}">
                                Credit Days
                                @if(request('sort_by') == 'credit_days')
                                    <i class="fas fa-sort-{{ request('sort_order') == 'asc' ? 'up' : 'down' }}"></i>
                                @else
                                    <i class="fas fa-sort"></i>
                                @endif
                            </a>
                        </th>

                        <!-- Credit Limit Sorting -->
                        <th>
                            <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'credit_limit', 'sort_order' => (request('sort_by') == 'credit_limit' && request('sort_order') == 'asc') ? 'desc' : 'asc']) }}">
                                Credit Limit
                                @if(request('sort_by') == 'credit_limit')
                                    <i class="fas fa-sort-{{ request('sort_order') == 'asc' ? 'up' : 'down' }}"></i>
                                @else
                                    <i class="fas fa-sort"></i>
                                @endif
                            </a>
                        </th>



                        <th>Manager</th>
                        <th>Warehouse</th>
                        <!-- <th>City</th> -->
                        <!-- City -->
                        <th>
                            <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'addresses.city', 'sort_order' => (request('sort_by') == 'addresses.city' && request('sort_order') == 'asc') ? 'desc' : 'asc']) }}">
                                City
                                @if(request('sort_by') == 'addresses.city')
                                    <i class="fas fa-sort-{{ request('sort_order') == 'asc' ? 'up' : 'down' }}"></i>
                                @else
                                    <i class="fas fa-sort"></i>
                                @endif
                            </a>
                        </th>
                        <!-- <th>Due Amount</th> -->
                         <th>
                            <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'due_amount', 'sort_order' => (request('sort_by') == 'due_amount' && request('sort_order') == 'asc') ? 'desc' : 'asc']) }}">
                                Due Amount
                                @if(request('sort_by') == 'due_amount')
                                    <i class="fas fa-sort-{{ request('sort_order') == 'asc' ? 'up' : 'down' }}"></i>
                                @else
                                    <i class="fas fa-sort"></i>
                                @endif
                            </a>
                        </th> 

                                                <!-- <th>Overdue Amount</th> -->
                                                 <th>
                            <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'overdue_amount', 'sort_order' => (request('sort_by') == 'overdue_amount' && request('sort_order') == 'asc') ? 'desc' : 'asc']) }}">
                                Overdue Amount
                                @if(request('sort_by') == 'overdue_amount')
                                    <i class="fas fa-sort-{{ request('sort_order') == 'asc' ? 'up' : 'down' }}"></i>
                                @else
                                    <i class="fas fa-sort"></i>
                                @endif
                            </a>
                        </th> 
                        <th>Options</th> <!-- New Column -->
                       
                    </tr>
                </thead>
                <tbody>
                @foreach($processedData as $data)
                    @if($data['address']->due_amount > 0 || $data['address']->overdue_amount > 0)
                        <tr data-party-code="{{ $data['address']->acc_code }}" 
                            data-due-amount="{{ $data['address']->due_amount }}" 
                            data-overdue-amount="{{ $data['address']->overdue_amount }}" 
                            data-user-id="{{ $data['user']->id }}">

                            <td>
                                <input type="checkbox" class="select-person" 
                                 data-manager-id="{{ $data['user']->manager_id }}" 
                                    data-party-code="{{ $data['address']->acc_code }}" 
                                    data-due-amount="{{ $data['address']->due_amount }}" 
                                    data-overdue-amount="{{ $data['address']->overdue_amount }}" 
                                    data-user-id="{{ $data['user']->id }}">
                            </td>
                            <td>{{ $data['address']->company_name }}  </td>
                            <td>{{ $data['address']->acc_code }}</td>
                            <!-- <td>{{ str_replace(' ', '_', $data['user']->name) . $data['address']->acc_code }}</td>  -->
                            <td>{{ $data['user']->phone }}</td>
                              <td class="credit-days">{{ $data['user']->credit_days }}</td>
    <td class="credit-limit">{{ $data['user']->credit_limit }}</td>
                            <td class="manager-name">{{ $data['manager_name'] ?? 'N/A' }}</td>
                            <td>{{ $data['warehouse_name'] ?? 'N/A' }}</td>
                            <td>{{ $data['address']->city }}</td>
                            <td>₹{{ number_format($data['address']->due_amount, 2) }}</td>
                            <td>₹{{ number_format($data['address']->overdue_amount, 2) }}</td>
                           <td style="white-space: nowrap;">
                                <a href="#" 
                                   class="btn btn-primary btn-sm" 
                                   data-toggle="modal" 
                                   data-target="#commentModal" 
                                   data-party-code="{{ $data['address']->acc_code }}" 
                                   data-party-name="{{ $data['user']->company_name }}"
                                   data-user-id="{{ $data['user']->id }}"
                                   style="margin-right: 5px; padding: 6px 8px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-comment" style="font-size: 16px;"></i>
                                </a>
                                <a href="#" 
                                   class="btn btn-primary btn-sm my_pdf" 
                                   data-party-code="{{ $data['address']->acc_code }}" 
                                   data-party-name="{{ $data['user']->company_name }}"
                                   data-user-id="{{ $data['user']->id }}"
                                   style="padding: 6px 8px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-file-pdf" style="font-size: 16px;"></i>
                                </a>
                                <br>
                                <a href="{{ route('customers.login', encrypt($data['user']->id)) }}"
                                           class="btn btn-soft-primary btn-icon btn-circle btn-sm"
                                           title="{{ translate('Log in as this Customer') }}">
                                            <i class="las la-sign-in-alt"></i>
                                        </a>

                                   
                                   <!-- Assign Manager Button -->
                                <button class="btn btn-success btn-sm assign-manager-btn" 
                                        data-user-id="{{ $data['user']->id }}" 
                                        data-party-code="{{ $data['address']->acc_code }}" 
                                        data-party-name="{{ $data['address']->company_name }}" 
                                        data-user-creditDays="{{ $data['user']->credit_days }}"
                                        data-user-creditLimit="{{ $data['user']->credit_limit }}"
                                        data-current-manager-id="{{ $data['user']->manager_id }}" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#assignModel" 
                                        title="Assign Manager"
                                        style="padding: 6px 8px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-user-plus" style="font-size: 14px; margin-right: 0;"></i>
                                </button>

                            </td>
                             <!-- New Column with anchor tag -->

                            
                        </tr>
                    @endif
                @endforeach
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-3">
    <!-- Showing record count -->
    <div>
        <p class="mb-0">
            <!-- Showing {{ $customers->count() }} of {{ $customers->total() }} records  -->
        </p>
    </div>

    <!-- Pagination links with Bootstrap 4 styling (works with Bootstrap 5) -->
    <div>
        {{ $customers->onEachSide(1)->links('pagination::bootstrap-4') }}
    </div>
</div>
    @else
        <div class="alert alert-warning">
            No records found.
        </div>
    @endif
</div>
</div>

<!-- Modal -->
<div class="modal fade" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="commentModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="commentModalLabel">Add Comment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="commentForm">
          @csrf <!-- CSRF token for security -->
          <input type="hidden" name="user_id" id="user-id">
          <input type="hidden" name="party_code" id="party-code">
          
          <div class="form-group">
            <label for="party-name">Party Name</label>
            <input type="text" class="form-control" id="party-name" readonly>
          </div>
          <div class="form-group">
            <label for="comment">Comment</label>
            <textarea class="form-control" id="comment" name="statement_comment" rows="3"></textarea>
          </div>
          <div class="form-group">
            <label for="due_date">Date</label>
            <input type="date" class="form-control custom-date-picker" id="due-date-picker" name="statement_comment_date">
          </div>
          <button type="button" class="btn btn-primary" id="saveComment">Save Comment</button>
        </form>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="pdfModal" tabindex="-1" role="dialog" aria-labelledby="pdfModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content" style="height: 90vh;"> <!-- Set modal height -->
            <div class="modal-header">
                <h5 class="modal-title" id="pdfModalLabel">View PDF</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="padding: 0; height: 100%;">
                <!-- Embed PDF here -->
                <iframe id="pdfViewer" src="" frameborder="0" width="100%" height="100%" style="height: 100%;"></iframe>
            </div>
        </div>
    </div>
</div>



<!-- Assign Manager Modal -->
<div class="modal fade" id="assignModel" tabindex="-1" role="dialog" aria-labelledby="assignModelLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="assignModelLabel">Assign Manager</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="assignManagerForm">
          @csrf <!-- CSRF token for security -->
          <input type="hidden" name="user_id" id="user-id-assign">
          <div class="form-group">
            <label for="party-name">Party Name</label>
            <input type="text" class="form-control" id="party-name-assign" readonly>
          </div>
          <div class="form-group">
            <label for="assignmanager-select">Select Manager</label>
            <select class="form-control" name="manager_id" id="assignmanager-select">
              <option value="">Select Manager</option>
              @foreach($managers as $manager)
                  <option value="{{ $manager->id }}">{{ $manager->name }}</option>
              @endforeach
            </select>
          </div>

          <div class="form-group">
            <label for="credit-days-assign">Credit Days</label>
            <input type="number" class="form-control" name="credit_days" id="credit-days-assign">
          </div>
          <div class="form-group">
            <label for="credit-limit-assign">Credit Limit</label>
            <input type="number" class="form-control" name="credit_limit" id="credit-limit-assign">
          </div>
          <button type="button" class="btn btn-primary" id="assignManagerForUser">Assign</button>
        </form>
      </div>
    </div>
  </div>
</div>


@endsection

@section('script')
<script>
    $(document).ready(function() {




    $('#whatsapp-all').click(function() {
    var button = $(this);
    var loader = button.find('.loader');
    var buttonText = button.find('.button-text');

    buttonText.css('visibility', 'hidden');
    loader.show();
    button.prop('disabled', true);

     // Gather filter parameters
    var warehouseId = $('#branch-select').val();
    var managerId = $('#manager-select').val();
    var duefilter = $('#duefilter-select').val();

    // Get selected checkboxes (WhatsApp Checked)
    var selectedData = [];
    $('.select-person:checked').each(function() {
        selectedData.push({
            party_code: $(this).data('party-code'),
            due_amount: $(this).data('due-amount'),
            overdue_amount: $(this).data('overdue-amount'),
            user_id: $(this).data('user-id')
        });
    });

    var selectedCount = selectedData.length;

    // Retrieve the total number of customers with due/overdue from the hidden input field
   var totalCustomerWithDueOverdue = parseInt($('#total_customer_with_due_overdue').val()) ;


    // Ensure that there are records to process
    if (selectedCount === 0) {
        // No checkboxes are selected, ask if the user wants to send to all
        loader.hide();
        buttonText.css('visibility', 'visible');
        button.prop('disabled', false);

        
        if (confirm("No checkboxes selected. Do you want to send WhatsApp to all " + totalCustomerWithDueOverdue + " users?")) {
            loader.show();
            buttonText.css('visibility', 'hidden');
            button.prop('disabled', true);
            
            $.ajax({
                url: "{{ route('get.all.users.data') }}", // The unified route
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    warehouse_id: warehouseId,
                    manager_id: managerId,
                    duefilter: duefilter
                },
                timeout: -1,  // Timeout set to 60 seconds
                success: function(response) {
                    
                    if (response.success) {
                        loader.hide();
                        buttonText.css('visibility', 'visible');
                        button.prop('disabled', false);
                         AIZ.plugins.notify('success', 'WhatsApp messages sent successfully.');


                        
                       
						var groupId = response.group_id;

                        // New AJAX request to pass the groupId to processWhatsapp route
                        $.ajax({
                            url: "{{ route('processWhatsapp') }}", // Replace this with the correct route
                            type: "POST",
                            data: {
                                _token: "{{ csrf_token() }}",
                                group_id: groupId
                            },
                            success: function(processResponse) {
                                
                                // alert('Group ID passed: ' + processResponse.group_id);
                                AIZ.plugins.notify('success', 'WhatsApp messages sent successfully.');
                            },
                            error: function() {
                               // alert('Failed to process the WhatsApp request.');
                            }
                        });

					

                        // AIZ.plugins.notify('success', response.groupId);
                    } else {
                        alert('Failed to send WhatsApp messages. Please try again.');
                    }
                },
                error: function(xhr, status, error) {
                    loader.hide();
                    buttonText.css('visibility', 'visible');
                    button.prop('disabled', false);
                    var errorMessage = `An error occurred: \n` +
                                       `Status Code: ${xhr.status}\n` +
                                       `Status Text: ${xhr.statusText}\n` +
                                       `Error Thrown: ${error}\n` +
                                       `Response: ${xhr.responseText}`;
                    alert(errorMessage);
                }
            });

            return; // Stop further execution to prevent running the else part
        } else {
            // User canceled the action
            loader.hide();
            buttonText.css('visibility', 'visible');
            button.prop('disabled', false);
            return;
        }
    } else {
        // Show confirmation message with selected count
        if (confirm("You are about to send WhatsApp messages to " + selectedCount + " users. Do you want to proceed?")) {
            // Send AJAX request if checkboxes are selected
            $.ajax({
                url: "{{ route('generate.statement.pdf.bulk.checked') }}", // The unified route
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    all_data: selectedData
                },
                success: function(response) {
                    loader.hide();
                    buttonText.css('visibility', 'visible');
                    button.prop('disabled', false);
                    if (response.success) {
                        AIZ.plugins.notify('success', 'WhatsApp messages sent successfully.');
                    } else {
                        alert('Failed to send WhatsApp messages. Please try again.');
                    }
                },
                error: function() {
                    loader.hide();
                    buttonText.css('visibility', 'visible');
                    button.prop('disabled', false);
                    alert('An error occurred. Please try again.');
                }
            });
        } else {
            // User canceled the action
            loader.hide();
            buttonText.css('visibility', 'visible');
            button.prop('disabled', false);
        }
    }
});





        // $('#whatsapp-checked').click(function() {
        //     var button = $(this);
        //     var loader = button.find('.loader');
        //     var buttonText = button.find('.button-text');

        //     var selectedData = [];
        //     $('.select-person:checked').each(function() {
        //         selectedData.push({
        //             party_code: $(this).data('party-code'),
        //             due_amount: $(this).data('due-amount'),
        //             overdue_amount: $(this).data('overdue-amount'),
        //             user_id: $(this).data('user-id')
        //         });
        //     });

        //     if (selectedData.length === 0) {
        //         AIZ.plugins.notify('warning', 'Please select at least one person.');
        //         return;
        //     }

        //     buttonText.css('visibility', 'hidden');
        //     loader.show();
        //     button.prop('disabled', true);

        //     $.ajax({
        //         url: "{{ route('generate.statement.pdf.checked') }}",
        //         type: "POST",
        //         data: {
        //             _token: "{{ csrf_token() }}",
        //             selected_data: selectedData
        //         },
        //         success: function(response) {
        //             loader.hide();
        //             buttonText.css('visibility', 'visible');
        //             button.prop('disabled', false);
        //             if (response.success) {
        //                 AIZ.plugins.notify('success', 'WhatsApp messages sent successfully to checked persons.');
        //             } else {
        //                 alert('Failed to send WhatsApp messages. Please try again.');
        //             }
        //         },
        //         error: function() {
        //             loader.hide();
        //             buttonText.css('visibility', 'visible');
        //             button.prop('disabled', false);
        //             alert('An error occurred. Please try again.');
        //         }
        //     });
        // });

        $('#branch-select').on('change', function() {

        
            var warehouseId = $(this).val();
            $('#manager-select').empty().append('<option value="">Select Manager</option>');
            
            if (warehouseId) {
                $.ajax({
                    url: "{{ route('getManagersByWarehouse') }}",
                    type: "GET",
                    data: { warehouse_id: warehouseId },
                    success: function(response) {
                        
                        $.each(response, function(key, manager) {
                            
                            $('#manager-select').append('<option value="' + manager.id + '">' + manager.name + '</option>');
                        });
                    }
                });
            }
        });

        // $(document).on('click', '.send-whatsapp-btn', function () {
        //     var partyCode = $(this).data('party-code');
        //     var dueAmount = $(this).data('due-amount');
        //     var overdueAmount = $(this).data('overdue-amount');
        //     var userId = $(this).data('user-id');

        //     $.ajax({
        //         url: "{{ route('generate.statement.pdf') }}",
        //         type: "POST",
        //         data: {
        //             _token: "{{ csrf_token() }}",
        //             party_code: partyCode,
        //             due_amount: dueAmount,
        //             overdue_amount: overdueAmount,
        //             user_id: userId
        //         },
        //         success: function (response) {
        //             if (response.success) {
        //                 AIZ.plugins.notify('success', response.pdf_url);
        //             } else {
        //                 alert('Failed to generate PDF. Please try again.');
        //             }
        //         },
        //         error: function () {
        //             alert('An error occurred. Please try again.');
        //         }
        //     });
        // });

        $(document).on('click', '#select-all', function() {
            var isChecked = $(this).prop('checked');
            $('.select-person').prop('checked', isChecked);
        });


        // Sync Checked Button Handler
        $('#sync-checked').click(function() {
        
            var button = $(this);
            var loader = button.find('.loader');
            var buttonText = button.find('.button-text');

            

            buttonText.css('visibility', 'hidden');
            loader.show();
            button.prop('disabled', true);

            var selectedData = [];
            $('.select-person:checked').each(function() {
                selectedData.push({
                    party_code: $(this).data('party-code'),
                    user_id: $(this).data('user-id')
                });
            });

            if (selectedData.length === 0) {
                AIZ.plugins.notify('warning', 'Please select at least one record.');
                buttonText.css('visibility', 'visible');
                loader.hide();
                button.prop('disabled', false);
                return;
            }

            $.ajax({
                url: "{{ route('sync.statement') }}",
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    selected_data: selectedData
                },
                success: function(response) {
                    loader.hide();
                    buttonText.css('visibility', 'visible');
                    button.prop('disabled', false);
                    if (response.success) {
                        AIZ.plugins.notify('success', 'Statements synced successfully.');
                        location.reload();
                    } else {
                        alert('Failed to sync statements. Please try again.');
                    }
                },
                error: function() {
                    loader.hide();
                    buttonText.css('visibility', 'visible');
                    button.prop('disabled', false);
                    alert('An error occurred. Please try again.');
                }
            });
        });


        

    $('#notify-manager').click(function() {
        var button = $(this);
        var loader = button.find('.loader');
        var buttonText = button.find('.button-text');

        buttonText.css('visibility', 'hidden');
        loader.show();
        button.prop('disabled', true);

        var managerId = $('#manager-select').val();
        var warehouseId = $('#branch-select').val();

        // Collect unique manager IDs from selected checkboxes
        var uniqueManagers = new Set();
        $('.select-person:checked').each(function() {
            uniqueManagers.add($(this).data('manager-id'));
        });

        var managerIds = Array.from(uniqueManagers);

        // Determine the condition to send notifications
        if (managerIds.length > 0) {
            // Case 1: Notify only selected checkboxes' managers (unique manager IDs from selected checkboxes)
            sendNotificationRequest(managerIds, warehouseId);
        } else if (managerId) {
            // Case 2: Notify only the specific manager selected in the dropdown
            sendNotificationRequest([managerId], warehouseId);
        } else if (warehouseId) {
            // Case 3: Notify all managers in the selected branch
            $.ajax({
                url: "{{ route('getManagersByWarehouse') }}",
                type: "GET",
                data: { warehouse_id: warehouseId },
                success: function(response) {
                    var allManagerIds = response.map(manager => manager.id);
                    sendNotificationRequest(allManagerIds, warehouseId);
                },
                error: function() {
                    loader.hide();
                    buttonText.css('visibility', 'visible');
                    button.prop('disabled', false);
                    alert('Failed to fetch managers for the branch.');
                }
            });
        } else {
            AIZ.plugins.notify('warning', 'Please select a manager, branch, or checkboxes.');
            loader.hide();
            buttonText.css('visibility', 'visible');
            button.prop('disabled', false);
        }
    });

    // Function to send the AJAX request for notifications
    function sendNotificationRequest(managerIds, warehouseId) {
        $.ajax({
            url: "{{ route('notify.manager') }}",
            type: "POST",
            data: {
                _token: "{{ csrf_token() }}",
                manager_ids: managerIds,
                warehouse_id: warehouseId
            },
            success: function(response) {
                $('#notify-manager .loader').hide();
                $('#notify-manager .button-text').css('visibility', 'visible');
                $('#notify-manager').prop('disabled', false);

                if (response.status) {
                    AIZ.plugins.notify('success', 'Notifications sent successfully.');
                } else {
                    AIZ.plugins.notify('warning', 'Failed to notify manager(s). Please try again.');
                }
            },
            error: function() {
                $('#notify-manager .loader').hide();
                $('#notify-manager .button-text').css('visibility', 'visible');
                $('#notify-manager').prop('disabled', false);
                alert('An error occurred. Please try again.');
            }
        });
    }

      // When the modal is shown, populate the party name and ids
        $('#commentModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var partyCode = button.data('party-code');
            var partyName = button.data('party-name');
            var userId = button.data('user-id'); // You need to pass the user ID in the button as well
            
            // Populate the modal fields
            $('#party-name').val(partyName);
            $('#party-code').val(partyCode);
            $('#user-id').val(userId);
        });

        // Handle the form submission
        $('#saveComment').on('click', function() {
            var formData = {
                user_id: $('#user-id').val(),
                party_code: $('#party-code').val(),
                statement_comment: $('#comment').val(),
                statement_comment_date: $('#due-date-picker').val(),
                _token: $('input[name="_token"]').val() // CSRF token
            };

            // AJAX request to save the comment
            $.ajax({
                type: "POST",
                url: "{{ route('submitComment') }}", // Make sure this route is correct
                data: formData,
                success: function(response) {
                    if(response.success) {
                        alert(response.message);
                        alert('Comment added successfully');
                        $('#commentModal').modal('hide');
                        location.reload(); // Optionally reload the page
                    } else {
                        alert('Failed to add comment');
                    }
                },
                error: function() {
                    alert('Something went wrong');
                }
            });
        });



        $(document).on('click', '.my_pdf', function(event) {
            event.preventDefault(); // Prevent default link behavior

            // Get user ID from data attribute
            let userId = $(this).data('party-code');

            // Make an AJAX request to get the PDF URL
            $.ajax({
                url: `/admins/create-pdf/${userId}`, // Updated to match the correct route
                type: 'GET',
                success: function(response) {
                    console.log("AJAX Response:", response); // Log the response for debugging
                    if (response.pdf_url) {
                        // Set the PDF URL in the iframe
                        $('#pdfViewer').attr('src', response.pdf_url);

                        // Show the modal
                        $('#pdfModal').modal('show');
                    } else {
                        alert("Failed to generate PDF. Please try again.");
                    }
                },
                error: function(xhr, status, error) {
                    console.error("Error: ", error); // Log the error for debugging
                    console.error("Response Text: ", xhr.responseText);
                    alert("An error occurred while generating the PDF. Please check the console for details.");
                }
            });
        });



         $('#manager-select').on('change', function () {
            const managerId = $(this).val();
            const $citySelect = $('#city-select');

            // Clear existing options
            $citySelect.html('<option value="">City</option>');

            if (managerId) {
                $.ajax({
                    url: "{{ route('get_cities_by_manager_statement') }}", //route given in admin.php
                    type: "GET",
                    data: { manager_id: managerId },
                    success: function (cities) {
                        cities.forEach(function (city) {
                            $citySelect.append(`<option value="${city}">${city}</option>`);
                        });
                    },
                    error: function (xhr, status, error) {
                        console.error('Error fetching cities:', error);
                    }
                });
            }
        });



           
        // When Assign Manager button is clicked
        $(document).on('click', '.assign-manager-btn', function () {
            var userId = $(this).data('user-id');
            var partyName = $(this).data('party-name');
            var partyCode = $(this).data('party-code');
            var creditDays = $(this).data('user-creditdays');
            var creditLimit = $(this).data('user-creditlimit');
            var currentManagerId = $(this).data('current-manager-id'); // Add the current manager 

             $('#credit-days-assign').val(creditDays);
            $('#credit-limit-assign').val(creditLimit);
            // Populate modal fields
            $('#user-id-assign').val(userId);
            $('#party-name-assign').val(partyName);
            // Reset the manager dropdown
            $('#assignmanager-select').val('');
              // Set the current manager as selected in the dropdown
            $('#assignmanager-select').val(currentManagerId);
            
            // Open the modal
            $('#assignModel').modal('show');
        });

        // Handle Save button click
        $('#assignManagerForUser').on('click', function () {
            var userId = $('#user-id-assign').val();
            var managerId = $('#assignmanager-select').val();
            var creditDays = $('#credit-days-assign').val();
            var creditLimit = $('#credit-limit-assign').val();


            if (!managerId) {
                alert('Please select a manager.');
                return;
            }

            $.ajax({
                url: '{{ route("assign.manager") }}', // Replace with your actual route
                method: 'POST',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    user_id: userId,
                    manager_id: managerId,
                    credit_days: creditDays,
                    credit_limit: creditLimit
                },
                success: function (response) {
                    if (response.success) {

                     // Update the corresponding button's data attributes
                      var button = $(`button[data-user-id="${userId}"]`);
                      button.data('current-manager-id', managerId);
                      button.data('user-creditdays', creditDays);
                      button.data('user-creditlimit', creditLimit);

                      $(`tr[data-user-id="${userId}"] td.manager-name`).text(`${response.manager.name}`);
                      $(`tr[data-user-id="${userId}"] td.credit-days`).text(creditDays);
                      $(`tr[data-user-id="${userId}"] td.credit-limit`).text(creditLimit);
                      AIZ.plugins.notify('success', 'Manager Assigned Successfully.');
                      $('#assignModel').modal('hide'); // Close the modal
                        // Reset modal fields
              
                       // location.reload(); // Reload the page to reflect changes
                    } else {
                        alert('Error assigning manager. Please try again.');
                    }
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('An error occurred. Please try again.');
                }
            });
        });


       
        
    });


</script>
@endsection
