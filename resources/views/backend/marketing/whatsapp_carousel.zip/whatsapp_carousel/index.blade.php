@extends('backend.layouts.app')

@section('content')
<div class="row">
  <div class="col">
    <div class="card">
      <div class="card-header d-flex align-items-center justify-content-between">
        <h5 class="mb-0 h6">WhatsApp Carousel Templates</h5>
        <a href="{{ route('wa.carousel.create-template.form') }}" class="btn btn-primary btn-sm">+ Create Template</a>
      </div>

      <div class="card-body">
        @if(session('wa_templates_error'))
          <div class="alert alert-danger">{{ session('wa_templates_error') }}</div>
        @endif
        @if(session('wa_templates_ok'))
          <div class="alert alert-success">{{ session('wa_templates_ok') }}</div>
        @endif

        <div class="table-responsive">
          <table class="table table-striped align-middle">
            <thead>
              <tr>
                <th>Name / ID</th>
                <th>Language</th>
                <th>Status</th>
                <th>Category</th>
                <th>Cards</th>
                <th class="text-right">Details</th>
              </tr>
            </thead>
            <tbody>
              @forelse($templates as $t)
                @php
                  // derive cards count + header format from components
                  $components   = $t['components'] ?? [];
                  $carousel     = collect($components)->firstWhere('type', 'CAROUSEL');
                  $cards        = $carousel['cards'] ?? [];
                  $cardsCount   = is_array($cards) ? count($cards) : 0;
                  $headerFormat = '-';
                  if ($cardsCount > 0) {
                    $firstHdr = $cards[0]['components'][0] ?? null;
                    $headerFormat = strtoupper($firstHdr['format'] ?? '-') ;
                  }
                  $bodyComp   = collect($components)->firstWhere('type', 'BODY');
                  $bodyText   = $bodyComp['text'] ?? '';
                  $status     = strtoupper($t['status'] ?? '');
                @endphp

                <tr>
                  <td class="fw-600">
                    <div>{{ $t['name'] ?? '-' }}</div>
                    <div class="small text-muted">ID: {{ $t['id'] ?? '—' }}</div>
                  </td>
                  <td>{{ $t['language'] ?? '—' }}</td>
                  <td>
                    <span style="width: auto;" class="badge
                      @if($status==='APPROVED') badge-success
                      @elseif($status==='REJECTED') badge-danger
                      @elseif($status==='PAUSED') badge-warning
                      @else badge-secondary @endif">
                      {{ $status ?: '—' }}
                    </span>
                  </td>
                  <td>{{ $t['category'] ?? '—' }}</td>
                  <td>
                    <div>{{ $cardsCount }} cards</div>
                    <div class="small text-muted">Header: {{ $headerFormat }}</div>
                  </td>
                  <td class="text-right">
                    <button class="btn btn-soft-secondary btn-sm"
                            type="button"
                            data-toggle="collapse"
                            data-target="#tpl-row-{{ $loop->index }}"
                            aria-expanded="false">
                      View
                    </button>
                  </td>
                </tr>

                <tr class="collapse" id="tpl-row-{{ $loop->index }}">
                  <td colspan="6">
                    <div class="p-3 bg-light rounded">
                      <div class="mb-2">
                        <strong>Top Body:</strong>
                        <div class="text-monospace">{{ $bodyText }}</div>
                      </div>

                      @if($cardsCount)
                        <div class="row">
                          @foreach($cards as $ci => $card)
                            @php
                              $cBody = collect($card['components'] ?? [])->firstWhere('type','BODY');
                              $cBtns = collect($card['components'] ?? [])->firstWhere('type','BUTTONS');
                              $example = data_get($cBody,'example.body_text.0.0');
                            @endphp
                            <div class="col-md-6 mb-3">
                              <div class="border rounded p-3 h-100">
                                <div class="mb-2 text-muted">Card #{{ $ci + 1 }}</div>
                                <div><strong>Body:</strong>
                                  <span class="text-monospace">{{ $cBody['text'] ?? '—' }}</span>
                                </div>
                                @if($example)
                                  <div class="small text-muted mt-1">Example: {{ $example }}</div>
                                @endif

                                @if($cBtns)
                                  <div class="mt-2">
                                    <strong>Buttons:</strong>
                                    <ul class="small pl-3 mb-0">
                                      @foreach(($cBtns['buttons'] ?? []) as $b)
                                        <li>{{ $b['type'] ?? '' }} — {{ $b['text'] ?? '' }}</li>
                                      @endforeach
                                    </ul>
                                  </div>
                                @endif
                              </div>
                            </div>
                          @endforeach
                        </div>
                      @endif
                    </div>
                  </td>
                </tr>
              @empty
                <tr>
                  <td colspan="6" class="text-center text-muted">No templates found.</td>
                </tr>
              @endforelse
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>
</div>
@endsection
