@extends('backend.layouts.app')

@section('content')
    <div class="aiz-titlebar text-left mt-2 mb-3">
        <h1 class="h3">Finalized Purchase Orders</h1>
    </div>

    <div class="card">
        <div class="card-body">
            <!-- Display Success Message -->
            @if (session('status'))
                <div class="alert alert-success">
                    {{ session('status') }}
                </div>
            @endif

            <table class="table aiz-table mb-0">
                <thead>
                    <tr>
                        <th>Purchase Order No</th>
                        <th>Date</th>
                        <th>Seller Name</th>
                        <th>Seller Phone</th>
                        <th>Product Info</th>
                        <th>Status</th> <!-- New column for status -->
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                @foreach($orders as $order)
                    <tr>
                        <td>{{ $order->purchase_order_no }}</td>
                        <td>{{ $order->date }}</td>
                        <td>{{ $order->seller_name }}</td>
                        <td>{{ $order->seller_phone }}</td>
                        <td>
                            <a href="{{ route('purchase-order.product-info', $order->id) }}" class="btn btn-sm btn-info">
                                <i class="las la-eye"></i> View Products
                            </a>
                        </td>
                        <td>
                            @if($order->force_closed == 1)
                                <span class="badge badge-inline  badge-danger">Canceled</span>
                            @else
                                <span class="badge badge-inline  badge-success">Open</span>
                            @endif
                        </td>
                        <td>
                            @if($order->force_closed == 0)
                                <!-- Force Close Form -->
                                <form action="{{ route('purchase-order-force-close', $order->id) }}" method="get" onsubmit="return confirm('Are you sure you want to force close this order?');">
                                    @csrf
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="las la-times"></i> Force Close
                                    </button>
                                </form>
                            @else
                                <span class="badge badge-inline badge-secondary">No Action</span>
                            @endif
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
