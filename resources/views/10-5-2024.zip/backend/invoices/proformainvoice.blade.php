<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ translate('PROFORMA INVOICE') }}</title>
  <meta http-equiv="Content-Type" content="text/html;" />
  <meta charset="UTF-8">
  <style media="all">
    @page {
      margin: 0;
      padding: 0;
    }

    body {
      font-size: 0.875rem;
      font-family: '{{ $font_family }}';
      direction: {{ $direction }};
      text-align: {{ $text_align }};
      padding: 0;
      margin: 0;
    }

    .text-white *,
    .text-white {
      color: white;
    }

    table {
      width: 100%;
    }

    table.padding th {
      padding: .25rem .7rem;
    }

    table.padding td {
      padding: .25rem .7rem;
    }

    table.sm-padding td {
      padding: .1rem .7rem;
    }

    .border-bottom td,
    .border-bottom th {
      border-bottom: 1px solid #eceff4;
    }

    .text-left {
      text-align: {{ $text_align }};
    }

    .text-right {
      text-align: {{ $not_text_align }};
    }

    .bank-details-section {
      background-color: #f2f2f2; /* Light grey background */
      padding: 2px; /* Reduced padding */
      border: 1px solid #eceff4; /* Light border */
      border-radius: 5px;
    }

    .bank-details-section td {
      vertical-align: top;
    }

    .bank-details-section strong {
      font-size: 1rem;
      color: #333;
    }

    .bank-details-section span {
      display: block;
      color: #333;
    }

    .terms-conditions-section {
      background-color: #f7f7f7; /* Soft light grey background */
      padding: 5px; /* Reduced padding */
      border: 1px solid #ddd; /* Light border */
      border-radius: 10px;
      margin-top: 5px;
      font-size: 0.875rem;
      line-height: 1.6;
      color: #444;
    }

    .terms-conditions-section h4 {
      margin-bottom: 10px;
      font-size: 1.2rem;
      color: #222;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      border-bottom: 2px solid #074E86;
      padding-bottom: 5px;
    }

    .terms-conditions-section ul {
      padding-left: 20px;
    }

    .terms-conditions-section li {
      margin-bottom: 5px; /* Reduced margin for a more compact list */
    }
  </style>
</head>

<body>
  <div>

    @php
      $logo = get_setting('header_logo');
    @endphp
    <div style="font-size: 1.5rem; padding: 15px; text-align:center; font-weight: bold;">
      {{ translate('PROFORMA INVOICE') }}
    </div>
    <div style="background: #074E86; padding: 1rem; color: white !important;">
      <table style="width: 100%; border-collapse: collapse;">
        <tr>
          <td style="width: 50%; vertical-align: top; color: white;">
            <div style="font-size: 1.5rem; margin-bottom: 20px; font-weight: bold;">
              ACE TOOLS PRIVATE LIMITED
            </div>
            <br>
            <div style="font-size: 0.875rem; line-height: 1.5;">
              PLOT NO. 220/219 KH NO. 85/2,<br>
              RITHALA ROAD,<br>
              New Delhi – 110085
            </div>
            <div style="font-size: 0.875rem; margin-top: 10px;">
              {{ translate('GSTIN') }}: 07ABACA4198B1ZX
            </div>
          </td>
          <td style="width: 50%; text-align: center; vertical-align: top; color: white;">
            @if (isset($logo))
              <img src="https://mazingbusiness.com/public/uploads/all/PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png" height="30" style="display:inline-block; margin-bottom: 20px;">
            @else
              <img src="https://mazingbusiness.com/public/uploads/all/PH8lWzw1Qs3Z2QxgCOTYpdQe2DmP0GQHCSZaxXAk.png" height="30" style="display:inline-block; margin-bottom: 20px;">
            @endif

            <div style="margin-top: 20px; text-align: center;">
              <img src="https://admin.mazingbusiness.com/assets/pdf/mazing_business_qr.jpg" alt="Scan QR Code" style="width: 100px; height: 100px; display: block; margin: 0 auto;">
            </div>
          </td>
        </tr>
      </table>
    </div>

    <div style="padding: 1rem;padding-bottom: 30px">
      <table>
        <tr>
          @php
            $shipping_address = json_decode($order->shipping_address);
            $client_address = DB::table('addresses')->where('id', $order->address_id)->first();
          @endphp
          <td class="strong small gry-color">
            <div style="width: 100%">
              <div style="font-weight: bold;">{{ translate('Customer Info:') }}<br><br></div>
              <!-- {{ $shipping_address->name }}<br> -->
              {{ $client_address->company_name }}<br>
              {{ $client_address->address }},<br> {{ $client_address->address_2 }},<br>
               @if (isset($client_address->city))
                {{ $client_address->city }} 
              @endif 
              {{ $client_address->postal_code }}<br>
              GSTIN: {{ $client_address->gstin }}<br>
              <!-- {{ translate('Email') }}: {{ $shipping_address->email }}<br> -->
              {{ translate('Phone') }}: {{ $client_address->phone }}
            </div>
          </td>
          <td style="background: #eceff4; padding: 1rem;">
            <table>
              <tr>
                <td colspan="2" style="padding-bottom: 15px;text-align: center;"><span
                    style="font-weight: bold">{{ translate('Proforma Invoice No.') }}:</span>
                  {{ $order->code }}
                </td>
              </tr>
              <tr>
                <td>{{ translate('Order Date') }}</td>
                <td class="text-right">{{ date('d/m/Y', $order->date) }}</td>
              </tr>
              <tr>
                <td>{{ translate('Amount') }}</td>
                <td class="text-right">₹ {{ $order->grand_total }}</td>
              </tr>
            </table>
          </td>
      </table>
    </div>

    <div style="padding: 1rem;">
      <table class="padding text-left small border-bottom">
        <thead>
          <tr class="gry-color" style="background: #eceff4;">
            <th width="5%" class="text-left">{{ translate('No.') }}</th>
            <th width="12%" class="text-left">{{ translate('Part NO.') }}</th>
            <th width="12%" class="text-left">{{ translate('Photo.') }}</th>
            <th width="25%" class="text-left">{{ translate('Product Name') }}</th>
            <th width="10%" class="text-left">{{ translate('Quantity') }}</th>
            <th width="15%" class="text-left">{{ translate('Rate') }}</th>
            <th width="25%" class="text-right">{{ translate('Sub Total') }}</th>
          </tr>
        </thead>
        <tbody class="strong">
          @foreach ($order->orderDetails as $key => $orderDetail)
            @if ($orderDetail->product != null)
              <tr>
                <td class="text-left">{{ $key + 1 }}</td>
                <td class="text-left">
                  @php
                    $product_stock = json_decode($orderDetail->product->stocks->first(), true);
                  @endphp
                  {{ $product_stock['part_no'] }}
                </td>
                <td>
                @php
                // Retrieve the thumbnail image ID from the product
                $thumbnailId = $orderDetail->product->photos;

                if($thumbnailId != null){
                    // Fetch the file_name from the uploads table
                    $item = DB::table('uploads')->where('id', $thumbnailId)->first();
                    
                    // Fetch base URL from the .env file
                    $baseUrl = env('UPLOADS_BASE_URL', url('public'));
                    
                    // Construct the thumbnail path
                    $thumbnailPath = $item && $item->file_name 
                                    ? $baseUrl . '/' . $item->file_name 
                                    : asset('assets/img/placeholder.jpg');
                }else{
                    $thumbnailPath = asset('assets/img/placeholder.jpg');
                }
              @endphp

                    <img style="width:50px;height:50px;" class="img-fit lazyload mx-auto" src="{{ $thumbnailPath }}"
                  data-src="" alt=""
                  onerror="this.onerror=null;this.src='{{ static_asset('assets/img/placeholder.jpg') }}';">
                 
                </td>
                <td>
                  {{ $orderDetail->product->name }}
                  <br>
                  <small>
                    {{ translate('SKU') }}: {{ $product_stock['part_no'] }}
                  </small>
                </td>
                <td class="">{{ $orderDetail->quantity }}</td>
                <td class="currency">{{ single_price($orderDetail->price / $orderDetail->quantity) }}</td>
                <td class="text-right currency">{{ single_price($orderDetail->quantity * ($orderDetail->price / $orderDetail->quantity)) }}</td>
              </tr>
            @endif
          @endforeach
        </tbody>
      </table>
    </div>

    <div style="padding:0 1.5rem;">
      <table class="text-right sm-padding small strong">
        <thead>
          <tr>
            <th width="60%"></th>
            <th width="40%"></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="text-left">
              <?php
                $removedXML = '<?xml version="1.0" encoding="UTF-8"?>';
              ?>
              <!-- {!! str_replace($removedXML, '', QrCode::size(100)->generate($order->code)) !!} -->
              <!-- <img src="https://admin.mazingbusiness.com/assets/pdf/mazing_business_qr.jpg" alt="logo" border="0" style="position: absolute;top: 7px;right: 67px;width: 132px;" /> -->
            </td>
            <td>
              <table class="text-right sm-padding small strong">
                <tbody>
                  <tr class="border-bottom">
                    <th class="text-left strong">{{ translate('Grand Total') }}</th>
                    <td class="currency">{{ single_price($order->grand_total) }}</td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
    </div>


    <div style="padding: 0 0.8rem;">
      <table class="bank-details-section" style="width: 100%; margin-top: 5px;">
        <tr>
          <td style="width: 50%; padding: 2px;"> <!-- Reduced padding -->
            <strong>Bank Details:</strong><br>
            <span>A/C Name: ACE TOOLS PRIVATE LIMITED</span><br>
            <span>A/C No: 235605001202</span><br>
            <span>IFSC Code: ICIC0002356</span><br>
            <span>Bank Name: ICIC Bank</span>
          </td>
          <td style="width: 50%; text-align: right; padding: 10px;"> <!-- Reduced padding -->
            <img src="https://mazingbusiness.com/public/assets/img/barcode.png" alt="Scan QR Code" style="width: 100px; height: 100px;">
            <br><span style="font-size: 12px;">Scan the barcode with any UPI app to pay.</span>
          </td>
        </tr>
      </table>
    </div>

    <div class="terms-conditions-section">
      <h4>Terms and Conditions</h4>
      <ul>
        <li>Payment must be made within the credit periods mentioned above , if the credit periods is zero the payment has to made before dispatch.</li>
        <li>Goods once sold will not be taken back or exchanged.</li>
        <li>Any disputes arising will be subject to New Delhi jurisdiction only.</li>
        
      </ul>
    </div>
  </div>
</body>

</html>
