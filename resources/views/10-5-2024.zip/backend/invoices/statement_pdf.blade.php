<!-- Header -->
<table width="100%" border="0" cellpadding="0" cellspacing="0">
    <tr>
        <td style="text-align: right; position: relative;">
            <img src="https://mazingbusiness.com/public/assets/img/pdfHeader.png" width="100%" alt="Header Image" style="display: block;" />
        </td>
    </tr>
</table>

<!-- Static Address and User Details -->
<table width="100%" border="0" cellpadding="10" cellspacing="0" style="margin-top: 20px;">
    <tr>
        <td width="50%" style="text-align: left; font-family: Arial, sans-serif; font-size: 14px; font-weight: bold; color: #174e84;">
            ACE TOOLS PRIVATE LIMITED<br>
            Plot No 220/219 & 220 Kh No 58/2,<br>
            Rithala Road, Rithala,<br>
            New Delhi - 110085
        </td>
        @php
            // Get the user ID
            $userId = Auth::id();

            // Fetch the first address for the authenticated user
            $addressData = DB::table('addresses')
                ->where('user_id', $userId)
                ->first();

            // Set default values if no address is found
            $address = $addressData ? $addressData->address : 'Address not found';
            $address_2 = $addressData ? $addressData->address_2 : '';
            $postal_code = $addressData ? $addressData->postal_code : '';

            // Get user credit details
            $userCreditDetails = DB::table('users')
                ->where('id', $userId)
                ->select('credit_days', 'credit_limit')
                ->first();

            // Set default values for credit details if not available
            $creditDays = $userCreditDetails ? $userCreditDetails->credit_days : 'N/A';
            $creditLimit = $userCreditDetails ? $userCreditDetails->credit_limit : 0;

            // Calculate total outstanding debit (amount the user owes)
            $totalOutstandingDebit = 0;
            foreach ($getData as $transaction) {
                $totalOutstandingDebit += $transaction['dramount']; // Sum of all debits
            }

            // Calculate available credit
            $availableCredit = $creditLimit - $totalOutstandingDebit;
        @endphp

        <td width="50%" style="text-align: right; font-family: Arial, sans-serif; font-size: 14px; color: #174e84;">
            {{ Auth::user()->company_name }}<br>
            {{ $address }}<br>
            {{ $address_2 }}<br>
            Pincode: {{ $postal_code }}<br>
        </td>
    </tr>
</table>

<!-- Credit Information -->
<table width="100%" border="0" cellpadding="10" cellspacing="0" style="margin-top: 20px;">
    <tr>
        <td width="33%" style="text-align: center; font-family: Arial, sans-serif; font-size: 14px; color: #174e84;">
            <strong>Credit Days</strong><br>
            <span style="font-size: 12px; color: #333;">{{ $creditDays }} days</span> <!-- Dynamic value for credit days -->
        </td>
        <td width="33%" style="text-align: center; font-family: Arial, sans-serif; font-size: 14px; color: #174e84;">
            <strong>Credit Limit</strong><br>
            <span style="font-size: 12px; color: #333;">₹{{ number_format($creditLimit, 2) }}</span> <!-- Dynamic value for credit limit -->
        </td>
        <td width="33%" style="text-align: center; font-family: Arial, sans-serif; font-size: 14px; color: #174e84;">
    <strong>Available Credit</strong><br>
    <span style="font-size: 12px; color: #000;">₹{{ number_format($availableCredit, 2) }}</span> <!-- Changed color to black -->
</td>

    </tr>
</table>

<!-- Date Range Information -->
@php
    // Assuming getData contains all transactions
    $transactionDates = array_column($getData, 'trn_date');

    // Find the first (earliest) and last (latest) transaction dates
    $firstTransactionDate = $form_date;
    $lastTransactionDate = $to_date;

    // Format the dates in 'd-M-Y' format
    $firstTransactionDateFormatted = $firstTransactionDate ? date('d-M-y', strtotime($firstTransactionDate)) : 'N/A';
    $lastTransactionDateFormatted = $lastTransactionDate ? date('d-M-y', strtotime($lastTransactionDate)) : 'N/A';

    // Custom format for displaying the date range
    $dateRangeFormatted = $firstTransactionDateFormatted . ' to ' . $lastTransactionDateFormatted;
@endphp

<!-- Display the Date Range -->
<p style="font-size: 14px; text-align: center;">
    <strong>{{ $dateRangeFormatted }}</strong>
</p>

<!-- Transaction Table with Updated Design -->
@if (count($getData) > 0)
<table width="100%" style="border-collapse: collapse; margin-bottom: 25px;">
    <thead>
        <tr>
            <th style="border: 1px solid #d1d1d1; padding: 10px; text-align: center; background: linear-gradient(135deg, #f5f7fa, #e4e5e6); color: #333; font-size: 13px; text-transform: uppercase; letter-spacing: 0.05em; font-family: Arial, sans-serif; font-weight: 600; box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);">
                {{ translate('Date') }}
            </th>
            <th style="border: 1px solid #d1d1d1; padding: 10px; text-align: center; background: linear-gradient(135deg, #f5f7fa, #e4e5e6); color: #333; font-size: 13px; text-transform: uppercase; letter-spacing: 0.05em; font-family: Arial, sans-serif; font-weight: 600; box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);">
                {{ translate('Particulars') }}
            </th>
            <th style="border: 1px solid #d1d1d1; padding: 10px; text-align: center; background: linear-gradient(135deg, #f5f7fa, #e4e5e6); color: #333; font-size: 13px; text-transform: uppercase; letter-spacing: 0.05em; font-family: Arial, sans-serif; font-weight: 600; box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);">
                {{ translate('Txn No') }}
            </th>
            <th style="border: 1px solid #d1d1d1; padding: 10px; text-align: center; background: linear-gradient(135deg, #f5f7fa, #e4e5e6); color: #333; font-size: 13px; text-transform: uppercase; letter-spacing: 0.05em; font-family: Arial, sans-serif; font-weight: 600; box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);">
                {{ translate('Debit') }}
            </th>
            <th style="border: 1px solid #d1d1d1; padding: 10px; text-align: center; background: linear-gradient(135deg, #f5f7fa, #e4e5e6); color: #333; font-size: 13px; text-transform: uppercase; letter-spacing: 0.05em; font-family: Arial, sans-serif; font-weight: 600; box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);">
                {{ translate('Credit') }}
            </th>
            <th style="border: 1px solid #d1d1d1; padding: 10px; text-align: center; background: linear-gradient(135deg, #f5f7fa, #e4e5e6); color: #333; font-size: 13px; text-transform: uppercase; letter-spacing: 0.05em; font-family: Arial, sans-serif; font-weight: 600; box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);">
                {{ translate('Balance') }}
            </th>
            <th style="border: 1px solid #d1d1d1; padding: 10px; text-align: center; background: linear-gradient(135deg, #f5f7fa, #e4e5e6); color: #333; font-size: 13px; text-transform: uppercase; letter-spacing: 0.05em; font-family: Arial, sans-serif; font-weight: 600; box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);">
                {{ translate('Dr / Cr') }}
            </th>
        </tr>
    </thead>
    <tbody>
        @php
            $balance = 0;
            $totalDebit = 0;
            $totalCredit = 0;
            $drBalance = 0;
            $crBalance = 0;
            $closingDrBalance = 0;
            $closingCrBalance = 0;
        @endphp
        @foreach($getData as $gKey => $gValue)
            @if($gValue['ledgername'] != 'closing C/f...')
            <tr>
                <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: center;">{{ date('d-M-y', strtotime($gValue['trn_date'])) }}</td>
                <td style="border: 1px solid #ecf0f1; padding: 12px; text-align: center;">
                    {{ strtoupper($gValue['vouchertypebasename']) }}
                    @if(trim($gValue['narration']) != "")
                        <p style="font-size: 10px; text-align: left;"><small>({{ $gValue['narration'] }})</small></p>
                    @endif
                </td>
                <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: center;">{{ $gValue['trn_no'] != "" ? $gValue['trn_no'] : '' }}</td>
                <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;">
                    <span >{{ $gValue['dramount'] != "0.00" ? single_price($gValue['dramount']) : '' }}</span>
                    @php
                        $totalDebit += $gValue['dramount'];
                        $drBalance += $gValue['dramount'];
                    @endphp
                </td>
                <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;">
                    <span style="color: #8bc34a;">{{ $gValue['cramount'] != "0.00" ? single_price($gValue['cramount']) : '' }}</span>
                    @php
                        $totalCredit += $gValue['cramount'];
                        $crBalance += $gValue['cramount'];
                    @endphp
                </td>
                <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;">
                    @if($gValue['ledgername'] == 'Opening b/f...')
                        @php
                            $balance = $gValue['dramount'] != "" ? $gValue['dramount'] : -$gValue['cramount'];
                        @endphp
                    @else
                        @php
                            $balance += $gValue['dramount'] - $gValue['cramount'];
                        @endphp
                    @endif
                    {{ single_price($balance) }}
                </td>
                <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;">
                    {!! $gValue['dramount'] != "0.00" ? '<span >Dr</span>' : '<span >Cr</span>' !!}
                </td>
            </tr>
            @else
                @php
                    $closingDrBalance = $gValue['dramount'];
                    $closingCrBalance = $gValue['cramount'];
                @endphp
            @endif
        @endforeach

       
        <!-- Total and Closing Balance Row -->
        <tr>
            <td colspan="3" style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;"><strong>Total</strong></td>
            <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;"><strong>{{ single_price($drBalance) }}</strong></td>
            <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;"><strong>{{ single_price($crBalance) }}</strong></td>
            <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;"><!-- Remove balance value here --></td>
            <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;"></td>
        </tr>


        <tr>
            <td colspan="3" style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;"><strong>Closing Balance</strong></td>
            <td colspan="2" style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;">
                {!! $closingDrBalance != "0.00" ? '<span >' . single_price($closingDrBalance) . '</span>' : '<span >' . single_price($closingCrBalance) . '</span>' !!}
            </td>
            <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;">
                {!! $closingDrBalance != "0.00" ? '<span style="color:#ff0707;">Dr</span>' : '' !!}
            </td>
        </tr>

        <!-- Grand Total Row -->
        <tr>
            <td colspan="3" style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;"><strong>Grand Total</strong></td>
            <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;"><strong>{{ single_price($drBalance + $closingDrBalance) }}</strong></td>
            <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;"><strong>{{ single_price($crBalance + $closingCrBalance) }}</strong></td>
            <td style="border: 1px solid #ecf0f1; padding: 10px; text-align: right;"></td>
        </tr>
    </tbody>
</table>
@endif

<!-- Bank Details and QR Code -->
<table width="100%" border="0" cellpadding="10" cellspacing="0" style="margin-top: 20px;">
    <tr>
        <td width="50%" style="font-family: Arial, sans-serif; font-size: 14px; color: #174e84;">
            <strong>Bank Details:</strong><br>
            A/C Name: ACE TOOLS PRIVATE LIMITED<br>
            A/C No: 235605001202<br>
            IFSC Code: ICICI0002356<br>
            Bank Name: ICICI Bank<br>
        </td>
        <td style="width: 50%; text-align: right; padding: 10px;">
            <img src="https://mazingbusiness.com/public/assets/img/barcode.png" alt="Scan QR Code" style="width: 100px; height: 100px;">
            <br><span style="font-size: 12px;">Scan the barcode with any UPI app to pay.</span>
        </td>
    </tr>
</table>

<!-- Footer -->
<table width="100%" border="0" cellpadding="0" cellspacing="0">
    <tbody>
        <tr bgcolor="#174e84">
            <td style="height: 40px; text-align: center; color: #fff; font-family: Arial; font-weight: bold;">
                Mazing Business Statement
            </td>
        </tr>
    </tbody>
</table>
