@extends('backend.layouts.app')

@section('content')
    <div class="aiz-titlebar text-left mt-2 mb-3">
        <h1 class="h3">Finalized Purchase Orders</h1>
    </div>

    <div class="card">
        <div class="card-body">
            <!-- Display Success Message -->
            @if (session('status'))
                <div class="alert alert-success">
                    {{ session('status') }}
                </div>
            @endif

           
            <table class="table aiz-table mb-0">
                <thead>
                    <tr>
                        <th>Purchase Order No</th>
                        <th>Date</th>
                        <th>Seller Name</th>
                        <th>Product Info</th>
                        
                    </tr>
                </thead>
                <tbody>
                @foreach($orders as $order)
                    <tr>
                        <td>{{ $order->purchase_order_no }}</td>
                        <td>{{ $order->date }}</td>
                        <td>{{ $order->seller_name }}</td>
                        <td>
                            <a href="{{ route('purchase-order.product-info', $order->id) }}" class="btn btn-sm btn-info">
                                <i class="las la-eye"></i> View Products
                            </a>
                        </td>
                        
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
