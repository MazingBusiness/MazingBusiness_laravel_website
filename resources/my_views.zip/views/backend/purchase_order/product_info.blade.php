@extends('backend.layouts.app')

@section('content')
    <div class="aiz-titlebar text-left mt-2 mb-3">
        <h1 class="h3">Product Information for Order: {{ $order->purchase_order_no }}</h1>
    </div>

    <div class="card">
        <div class="card-body">
            <!-- Display Success Message -->
            @if (session('status'))
                <div class="alert alert-success">
                    {{ session('status') }}
                </div>
            @endif

            <!-- Display Validation Errors -->
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('purchase-order.convert', $order->id) }}" method="POST">
                @csrf

                 <!-- Hidden input to pass the seller ID -->
                 <input type="hidden" name="seller_id" value="{{ $order->seller_id }}">
                 <input type="hidden" name="purchase_order_no" value="{{ $order->purchase_order_no }}">

                <!-- Global Inputs for Seller Invoice No and Date -->
                <div class="form-group row">
                    <label for="seller_invoice_no" class="col-md-2 col-form-label text-right font-weight-bold">Seller Invoice No:</label>
                    <div class="col-md-4">
                        <input type="text" id="seller_invoice_no" name="seller_invoice_no" class="form-control border rounded shadow-sm" placeholder="Enter Invoice Number">
                    </div>

                    <label for="seller_invoice_date" class="col-md-2 col-form-label text-right font-weight-bold">Seller Invoice Date:</label>
                    <div class="col-md-4">
                        <input type="date" id="seller_invoice_date" name="seller_invoice_date" class="form-control border rounded shadow-sm">
                    </div>
                </div>

                <!-- Table for Product Information -->
                <table class="table aiz-table mb-0">
                    <thead>
                        <tr>
                            <th>Part No.</th>
                            <th>HSN Code</th>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Purchase Price</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody id="productTableBody">
                    @php
                        $grandTotal = 0;
                    @endphp
                    @foreach($productInfo as $index => $product)
                        @php
                            $subtotal = $product['qty'] * $product['purchase_price'];
                            $grandTotal += $subtotal;
                        @endphp
                        <tr>
                            <td>{{ $product['part_no'] }}</td>
                            <td>
                                <input type="text" name="products[{{ $index }}][hsncode]" value="{{ $product['hsncode'] }}" class="form-control border rounded shadow-sm">
                            </td>
                            <td>{{ $product['product_name'] }}</td>
                            <td>
                                <input type="number" name="products[{{ $index }}][qty]" value="{{ $product['qty'] }}" class="form-control qty-input border rounded shadow-sm" data-index="{{ $index }}" onchange="recalculateSubtotal({{ $index }})">
                            </td>
                            <td>
                                <input type="number" step="0.01" name="products[{{ $index }}][purchase_price]" value="{{ $product['purchase_price'] }}" class="form-control price-input border rounded shadow-sm" data-index="{{ $index }}" onchange="recalculateSubtotal({{ $index }})">
                            </td>
                            <td class="subtotal" data-index="{{ $index }}">{{ ($subtotal) }}</td>
                        </tr>
                        <input type="hidden" name="products[{{ $index }}][part_no]" value="{{ $product['part_no'] }}">
                        <input type="hidden" name="products[{{ $index }}][order_no]" value="{{ $product['order_no'] }}">
                        <input type="hidden" name="products[{{ $index }}][age]" value="{{ $product['age'] }}">
                    @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="5" class="text-right">Total:</th>
                            <th id="grandTotal">{{ ($grandTotal) }}</th>
                        </tr>
                    </tfoot>
                </table>

                <div class="mt-4 text-left">
                    <button type="submit" class="btn btn-sm btn-success  py-2">
                        <i class="las la-check"></i> Convert to Purchase
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('scripts')
<!-- script is written in app.blade.php -->
@endsection
