@extends('backend.layouts.app')

@section('content')
  <div class="aiz-titlebar text-left mt-2 mb-3">
    <div class="align-items-center">
      <h1 class="h3">{{ translate('Abandoned Carts') }}</h1>
      @if (session('status'))
        {{ session('status') }}
      @endif
    </div>
    <div class="col text-right">
    <a href="{{route('abandoned-carts.send_whatsapp')}}"  class="btn btn-success" title="{{ translate('Send WhatsApp') }}">
            <span>Whatsapp All</span>
          </a>
      </div>
  </div>

  <div class="card">
    <div class="card-header row gutters-5">
      <form method="GET" action="{{ route('abandoned.cartlist') }}" class="d-flex w-100">
        <div class="col-md-3">
            <input type="date" class="form-control" id="searchDate" name="searchDate" value="{{ request('searchDate') }}" placeholder="{{ translate('Search by Date') }}">
        </div>
        <div class="col-md-3">
            <select class="form-control" id="searchManager" name="searchManager">
              <option value="">{{ translate('Select Manager') }}</option>
              @foreach($distinctManagers as $data)
                  @php
                      $managerUser = DB::table('users')
                          ->where('id', $data->manager_id)
                          ->first();
                  @endphp
                  @if(!is_null($managerUser))
                  <option value="{{ $managerUser->id }}" 
                          {{ request('searchManager') == $managerUser->id ? 'selected' : '' }}>
                      {{ $managerUser->name }}
                  </option>
                  @endif
              @endforeach
          </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary">{{ translate('Filter') }}</button>
        </div>
        <!-- <div class="col-md-1">
          <a href="{{route('abandoned-carts.send_whatsapp')}}"  class="btn btn-success" title="{{ translate('Send WhatsApp') }}">
            <i class="lab la-whatsapp"></i>
          </a>
        </div> -->
      </form>
    </div>

    <div class="card-body">
      <form method="POST" action="{{ route('abandoned-carts.send_bulk_whatsapp') }}">
        @csrf
        <div class="mb-3">
            <strong style="font-size: 24px;">{{ translate('Total Cart Value:') }} {{ number_format($totalSum, 2) }}</strong>
        </div>
        <div class="mt-3">
            <button type="submit" class="btn btn-success">{{ translate('Send WhatsApp') }}</button>
        </div>
        <table class="table aiz-table mb-0">
          <thead>
            <tr>
              <th><input type="checkbox" id="select-all"></th>
              <th>{{ translate('Customer Name') }}</th>
              <th>{{ translate('Manager Name') }}</th>
              <th>{{ translate('Phone') }}</th>
              <th>{{ translate('Party Code') }}</th>
              <th>{{ translate('Date') }}</th>
              <th>{{ translate('Item Name') }}</th>
              <th>{{ translate('Quantity') }}</th>
              <th>{{ translate('Price') }}</th>
              <th>{{ translate('Total') }}</th>
              <th class="text-right">{{ translate('Options') }}</th>
            </tr>
          </thead>
          <tbody>
            @foreach ($abandonedCart as $cart)
              <tr>
                <td><input type="checkbox" name="selected_carts[]" value="{{ $cart->user_id }}"></td>
                <td>{{ $cart->company_name }}</td>
                <td>
                  @php
                    $managerUser = DB::table('users')
                      ->where('id', $cart->manager_id)
                      ->first();
                  @endphp
                  {{ $managerUser->name ?? 'N/A' }} <!-- Handling potential null value -->
                </td>
                <td>{{ $cart->phone }}</td>
                <td>{{ $cart->party_code }}</td>
                <td>{{ $cart->created_at }}</td>
                <td>{{ $cart->product_name }}</td>
                <td>{{ $cart->quantity }}</td>
                <td>{{ $cart->price }}</td>
                <td>{{ $cart->quantity * $cart->price }}</td>
                <td class="text-right">
                  <div class="d-flex align-items-center justify-content-end">
                    @if($cart->quantity > 0)
                      <a href="{{ route('abandoned-carts-single.send_single_whatsapp', $cart->cart_id) }}" class="btn btn-success btn-icon btn-circle btn-sm" title="{{ translate('Send WhatsApp') }}">
                        <i class="lab la-whatsapp"></i>
                      </a>
                    @endif
                    <a href="#" class="btn btn-soft-primary btn-icon btn-circle btn-sm" title="{{ translate('Remark') }}" data-toggle="modal" data-target="#remarkModal" data-id="{{ $cart->cart_id }}" data-user-id="{{ $cart->user_id }}">
                      <i class="las la-comment"></i>
                    </a>
                    <a href="#" class="btn btn-soft-primary btn-icon btn-circle btn-sm ml-2" title="{{ translate('View Remarks') }}" data-toggle="modal" data-target="#viewRemarksModal" data-id="{{ $cart->cart_id }}">
                      <i class="las la-eye"></i>
                    </a>
                  </div>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
        
      </form>
    </div>

    <div class="aiz-pagination">
      {{ $abandonedCart->links('pagination::bootstrap-4') }}
    </div>
  </div>

  <!-- Remark Modal -->
  <div class="modal fade" id="remarkModal" tabindex="-1" role="dialog" aria-labelledby="remarkModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="remarkModalLabel">{{ translate('Add Remark') }}</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form id="remarkForm">
            @csrf
            <div class="form-group">
              <label for="remark">{{ translate('Remark') }}</label>
              <textarea class="form-control" id="remark" name="remark" rows="4"></textarea>
              <span class="text-danger" id="remark-error"></span>
            </div>
            <input type="hidden" id="cart_id" name="cart_id" value="">
            <input type="hidden" id="user_id" name="user_id" value="">
            <button type="button" class="btn btn-primary" id="saveRemark">{{ translate('Save Remark') }}</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- View Remarks Modal -->
  <div class="modal fade" id="viewRemarksModal" tabindex="-1" role="dialog" aria-labelledby="viewRemarksModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="viewRemarksModalLabel">{{ translate('View Remarks') }}</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div id="remarksTableBody">
            <!-- Remarks will be loaded here dynamically -->
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ translate('Close') }}</button>
        </div>
      </div>
    </div>
  </div>
@endsection

@section('script')
<script type="text/javascript">
  $('#remarkModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget); // Button that triggered the modal
    var cartId = button.data('id'); // Extract info from data-* attributes
    var userId = button.data('user-id'); // Extract the user ID
    var modal = $(this);
    modal.find('.modal-body #cart_id').val(cartId);
    modal.find('.modal-body #user_id').val(userId);
  });

  $('#saveRemark').on('click', function() {
    var form = $('#remarkForm');
    var data = form.serialize();
    $('#remark-error').text('');
    // Make an AJAX request to save the remark
    $.ajax({
      url: '{{ route("abandoned-carts.save_remark") }}',
      type: 'POST',
      data: data,
      success: function(response) {
        if (response.success) {
          form.trigger("reset");
          $('#remarkModal').modal('hide');
          alert(response.message);
        }
      },
      error: function(response) {
        if (response.status === 422) {
                var errors = response.responseJSON.errors;
                if (errors.remark) {
                    $('#remark-error').text(errors.remark[0]);
                }
            } else {
                alert('Error saving remark');
            }
      }
    });
  });

  $('#viewRemarksModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var cartId = button.data('id');
    var modal = $(this);

    // Clear previous data
    $('#remarksTableBody').empty();

    // Make an AJAX request to get the remarks
    $.ajax({
        url: '{{ route("abandoned-carts.get_remarks") }}',
        type: 'GET',
        data: { cart_id: cartId },
        success: function(response) {
            if (response.success) {
                var remarks = response.remarks;
                if (remarks.length > 0) {
                    remarks.forEach(function(remark) {
                        var row = '<div class="remark-item">' +
                                  '<div class="remark-description">' + remark.remark_description + '</div>' +
                                  '<div class="remark-timestamp">' + remark.created_at + '</div>' +
                                  '</div>';
                        $('#remarksTableBody').append(row);
                    });
                } else {
                    $('#remarksTableBody').append('<div class="text-center">No remarks found.</div>');
                }
            } else {
                $('#remarksTableBody').append('<div class="text-center">' + response.message + '</div>');
            }
        },
        error: function(response) {
            alert('Error loading remarks');
        }
    });
  });

  // Select all checkboxes
  document.getElementById('select-all').onclick = function() {
      var checkboxes = document.getElementsByName('selected_carts[]');
      for (var checkbox of checkboxes) {
          checkbox.checked = this.checked;
      }
  }
</script>

<style>
/* Container for the remarks */
#remarksTableBody {
    padding: 15px;
    background-color: #f0f2f5;
    border-radius: 10px;
    max-height: 300px;
    overflow-y: auto;
    font-size: 14px;
}

/* Individual Remark Item */
.remark-item {
    background-color: #ffffff;
    border-radius: 12px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    padding: 15px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

/* Hover Effect for Remark Item */
.remark-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}

/* Remark Description Styling */
.remark-description {
    font-size: 16px;
    font-weight: 700;
    color: #222;
    margin-bottom: 10px;
    line-height: 1.4;
}

/* Remark Timestamp Styling */
.remark-timestamp {
    font-size: 13px;
    color: #666;
    font-style: italic;
}
</style>
@endsection
