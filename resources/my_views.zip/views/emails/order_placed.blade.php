<p><b>Order Id:</b> {{$order_id}}</p>
<p><b>Order Items:</b> {{$product_name['name']}} x {{$quantity}}</p>