<p><b>Product: </b>{{$product}}</p>
<p><b>Customer Name: </b>{{$name}}</p>
<p><b>Customer Contact: </b>{{$contact}}</p>