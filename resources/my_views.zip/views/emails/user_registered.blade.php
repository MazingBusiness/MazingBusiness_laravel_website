<p><b>User Id:</b> {{$id}} </p>
<p><b>Name:</b> {{$name}} </p>
<p><b>Company Name:</b> {{$company_name}} </p>
<p><b>GSTIN:</b> {{$gstin}} </p>
<p><b>Contact No:</b> {{$phone}} </p>
<p><b>Email ID:</b> {{$email}} </p>