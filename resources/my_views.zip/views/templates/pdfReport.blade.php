<table width="100%" style="border-collapse: collapse;position: relative;top: 50px;left: 32px;margin-bottom: 20px;">
    <thead>
        <tr>
            <th style="border: 2px solid #000; text-align: center; font-family: Arial, Helvetica, sans-serif; color:#174e84;padding-top: 7px;padding-bottom: 7px;">SN</th>
            <th style="border: 2px solid #000; text-align: center; font-family: Arial, Helvetica, sans-serif; color:#174e84;padding-top: 7px;padding-bottom: 7px;">PART NO</th>
            <th style="border: 2px solid #000; text-align: center; font-family: Arial, Helvetica, sans-serif; color:#174e84;padding-top: 7px;padding-bottom: 7px;">IMAGE</th>
            <th style="border: 2px solid #000; text-align: center; font-family: Arial, Helvetica, sans-serif; color:#174e84;padding-top: 7px;padding-bottom: 7px;">ITEM</th>
            <th style="border: 2px solid #000; text-align: center; font-family: Arial, Helvetica, sans-serif; color:#174e84;padding-top: 7px;padding-bottom: 7px;">GROUP</th>
            <th style="border: 2px solid #000; text-align: center; font-family: Arial, Helvetica, sans-serif; color:#174e84;padding-top: 7px;padding-bottom: 7px;">CATEGORY</th>
            <th style="border: 2px solid #000; text-align: center; font-family: Arial, Helvetica, sans-serif; color:#174e84;padding-top: 7px;padding-bottom: 7px;">NET PRICE</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>