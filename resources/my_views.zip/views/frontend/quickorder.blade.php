@extends('frontend.layouts.app')
@section('content')
  <style>
    .ajax-loader {
      visibility: hidden;
      background-color: rgba(255,255,255,0.7);
      position: absolute;
      z-index: +100 !important;
      width: 100%;
      height:100%;
    }

    .ajax-loader img {
      position: relative;
      top:50%;
      left:50%;
    }
  </style>
  <div class="ajax-loader">
    <img src="{{ url('https://mazingbusiness.com/public/assets/img/ajax-loader.gif') }}" class="img-responsive" />
  </div>
  <section class="mb-4">
    <div class="container-fluid sm-px-0">
      <form class="" id="search-form" action="" method="GET">
        <div class="row">
          <div class="col-12 mb-4 mb-lg-0">
            <div class="row gutters-10 position-relative mb-4">
              <div class="col-xl-2 d-flex align-items-center">
                <input type="text" value="{{$srch_prod_name}}" id="prod_name" name="prod_name" class="form-control" placeholder="Product Name or Part No" >
              </div>
              <select class="js-select-cat-group abc cats_grp_drop" multiple="multiple" id="cat_group_drop", name="cat_groups[]">
                @php
                    $category_groups = $category_groups->sortBy('name');
                @endphp
                @foreach ($category_groups as $group)
                  @php
                    $count = \App\Models\Product::where('group_id', $group->id)->where('current_stock', 1)->count();
                  @endphp
                  @if ($count > 0)
                    <option value="{{ $group->id}}">{{ strtoupper($group->name)}} (  {{ $count }} )</option>
                  @endif
                @endforeach
              </select>
              <script type="text/javascript">
                $(document).ready(function() {
                    $(".js-select-cat-group").select2({
                        closeOnSelect : false,
                        placeholder : "Category Group",
                        allowHtml: true,
                        allowClear: true,
                        tags: true
                    });
                });
              </script>
              <select class="js-select-category category_drop" multiple="multiple" id="cat_drop">
                  <option value="">{{ translate('All Categories') }}</option>
                    @php
                        $categories = $categories->sortBy('name');
                    @endphp
                    @foreach ($categories as $category)
                      @if ($count > 0)
                        <option value="{{ $category->id }}">{{ strtoupper($category->name) }}</option>
                      @endif
                    @endforeach
              </select>
              <script type="text/javascript">
                $(document).ready(function() {
                    $(".js-select-category").select2({
                        closeOnSelect : false,
                        placeholder : "All Categories",
                        allowHtml: true,
                        allowClear: true,
                        tags: true
                    });
                });
              </script>
              <select class="js-select-all-brand b_drop" multiple="multiple"  id="brand_drop">
                <option value="">{{ translate('All Brands') }}</option>
                @foreach ($brands as $brand)
                  <option value="{{ $brand->id }}">{{ $brand->getTranslation('name') }}</option>
                @endforeach
              </select>
              <script type="text/javascript">
                $(document).ready(function() {
                    $(".js-select-all-brand").select2({
                        closeOnSelect : false,
                        placeholder : "All Brands",
                        allowHtml: true,
                        allowClear: true,
                        tags: true
                    });
                });
              </script>
              <div class="col-xl-2 align-items-center">
               <input type="button" id="btnSearch" value="Search" class="d-block rounded btn-primary btn-block text-light p-2 shadow-sm">
              </div>
            </div>
          </div>
          <!-- <div class="col-12 mb-4 mb-lg-0">
            <div class="row gutters-10 position-relative mb-4">
              <div class="col-xl-2 d-flex align-items-center">
               <input type="text" value="{{$srch_prod_name}}" name="prod_name" class="form-control" placeholder="Product Name or Part No" >
              </div>
              <div class="col-xl-2">
                  <select class="form-control form-control-sm aiz-selectpicker" title="Category Group" id="cat_group_drop" data-live-search="true" multiple="multiple" name="cat_groups[]" data-selected='["{{ implode('","', $selected_cat_groups) }}"]'>
                      @php
                          $category_groups = $category_groups->sortBy('name');
                      @endphp
                      @foreach ($category_groups as $group)
                        @php
                          $count = \App\Models\Product::where('group_id', $group->id)->where('current_stock', 1)->count();
                        @endphp
                        @if ($count > 0)
                          <option value="{{ $group->id}}">{{ strtoupper($group->name)}} (  {{ $count }} )</option>
                        @endif
                      @endforeach
                  </select>
              </div>
              <div class="col-xl-2">
                <select class="form-control form-control-sm aiz-selectpicker" id="cat_drop"  title="Categories" data-live-search="true"
                multiple="multiple" name="categories[]"
                  data-selected='["{{ implode('","', $selected_categories) }}"]'>
                  <option value="">{{ translate('All Categories') }}</option>
                    @php
                        $categories = $categories->sortBy('name');
                    @endphp
                  @foreach ($categories as $category)

                  @if ($count > 0)
                    <option value="{{ $category->id }}">{{ strtoupper($category->name) }}</option>
                  @endif
                  @endforeach
                </select>
              </div>
              <div class="col-xl-2">
                <select class="form-control form-control-sm aiz-selectpicker" data-live-search="true" name="brands[]"
                multiple="multiple" data-selected='["{{ implode('","', $selected_brands) }}"]'>
                  <option value="">{{ translate('All Brands') }}</option>
                  @foreach ($brands as $brand)
                    <option value="{{ $brand->id }}">
                      {{ $brand->getTranslation('name') }}</option>
                  @endforeach
                </select>
              </div>
              <div class="col-xl-2 align-items-center">
               <input type="submit" class="d-block rounded btn-primary btn-block text-light p-2 shadow-sm">
              </div>
            </div>
          </div> -->
          <div class="col-12">
            <div class="text-left">
              <div class="row gutters-5 flex-wrap align-items-center">
                <div class="col-md-8 col-8 col-lg-auto flex-fill">
                  <h1 class="h4 mb-lg-0 fw-600 text-body">
                    @if ($category_group)
                      {{ translate('All ' . Str::ucfirst($category_group->name)) }}
                    @else
                      {{ translate('All Products') }}
                    @endif
                  </h1>
                </div>
                @php
                    $user = Auth::user();
                @endphp

                @if ($user)
                  @php
                      $userId = Auth::user()->id;
                  @endphp
                  <input type="hidden" id="userId" value="{{ $userId }}">
                  <div class="col-2 align-items-center">
                    <!-- <a target="_blank" href="{{ url('https://mazingbusiness.com/api/products_pdf.php?' . $queyparam . '&user_id=' . $userId) }}"
                      class="d-block rounded btn-primary btn-block text-light p-2 shadow-sm">
                      <div class="text-truncate fs-12 fw-700 text-center">
                        DOWNLOAD PDF</div>
                    </a> -->
                    <a target="_blank" id="downloadPDFLink" class="d-block rounded btn-primary btn-block text-light p-2 shadow-sm" style="cursor: pointer;">
                      <div class="text-truncate fs-12 fw-700 text-center">
                         PDF</div>
                    </a>
                  </div>
                  <div class="col-2 align-items-center">
                    <!-- <a target="_blank" href="{{ url('https://mazingbusiness.com/api/products_excel.php?' . $queyparam . '&user_id=' . $userId) }}" class="d-block rounded btn-success btn-block text-light p-2 shadow-sm">
                      <div class="text-truncate fs-12 fw-700 text-center">
                        DOWNLOAD EXCEL</div>
                    </a> -->
                    <a target="_blank" id="downloadExcelLink" class="d-block rounded btn-success btn-block text-light p-2 shadow-sm" style="cursor: pointer;">
                      <div class="text-truncate fs-12 fw-700 text-center">
                         EXCEL</div>
                    </a>
                  </div>
                  @endif
              </div>
            </div>
          </div>
          <div class="col-12">
            <div class="row gutters-5 row-cols-1">
              <div id="postsContainer">
                <div class="col" id="post-data">
                  @include('frontend.partials.quickorder_list_box')
                </div>
                <div class="text-center p-3 d-none" id="loading">Loading...</div>
              </div>
              <input type="hidden" id="searchActive" value="0">
            </div>
          </div>
        </div>
      </form>
    </div>
  </section>
@endsection

@section('script')
  <script type="text/javascript">
  $(document).ready(function() {
    function getUrlParameter(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? null : decodeURIComponent(results[1].replace(/\+/g, ' '));
    }

    function getUrlParameterArray(name) {
        var results = [];
        var regex = new RegExp('[\\?&]' + name + '%5B%5D=([^&#]*)', 'g');  // Updated regex to handle [] in parameter names
        var result;
        while ((result = regex.exec(location.search)) !== null) {
            results.push(decodeURIComponent(result[1].replace(/\+/g, ' ')));
        }
        return results;
    }

    //JS Pagination
    var page = 1;
    $(window).scroll(bindScroll);

    function bindScroll() {
      if (($(window).scrollTop() + $(window).height()) >= ($(document).height() - $('#footerstart').height() - 300)) {
        $(window).unbind('scroll');
        page++;
        var searchActive = $('#searchActive').val();

        if(searchActive == 0){
          loadMoreData(page);
        }
      }
    }

    function loadMoreData(page) {
      $("#loading").removeClass('d-none');
      $.ajax({
        data: {
          'page': page
        },
        type: "get",
      })
      .done(function(data) {
        $("#loading").addClass('d-none');
        if (data.html) {
          $("#post-data").append(data.html);
          $(window).bind('scroll', bindScroll);
        }
      });
    }

    function filter() {
      $('#search-form').submit();
    }

    $('#cat_drop').on('blur', function(){
        $('#search-form').submit();
    });

    $('#cat_group_drop').change(function () {
        var category_group_id = $(this).val();
        if (category_group_id.length != 0) {
            // AJAX call to fetch child options
            $.ajax({
                url: '{{ route("getcategories") }}',
                type: 'GET',
                data: { category_group_id: category_group_id },
                dataType: 'json',
                success: function (response) {
                    $('#cat_drop').empty();
                    // Enable child selectpicker
                    $('#cat_drop').prop('disabled', false);
                    // Get selected categories from URL parameters
                    var selectedCategories = getUrlParameterArray('categories');
                    // Append new options and mark selected ones
                    $.each(response, function (key, value) {
                        var option = $('<option></option>')
                            .attr('value', value.id)
                            .text(value.name);
                        if (selectedCategories.includes(value.id.toString())) {
                            option.prop('selected', true);
                        }
                        $('#cat_drop').append(option);
                    });
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
            $('#brand_drop').prop('disabled', true);
        } else {
            // If no parent selected, disable and reset child selectpicker
            $('#cat_drop').empty().prop('disabled', true);


            $.ajax({
                url: '{{ route("getcategories") }}',
                type: 'GET',
                data: { category_group_id: 0 },
                dataType: 'json',
                success: function (response) {
                    $('#cat_drop').empty();
                    // Enable child selectpicker
                    $('#cat_drop').prop('disabled', true);
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
            $.ajax({
                url: '{{ route("getbrands") }}',
                type: 'GET',
                data: { category_group_id: 0, category_id: 0 },
                dataType: 'json',
                success: function (response) {
                    $('#brand_drop').empty();
                    // Enable child selectpicker
                    $('#brand_drop').prop('disabled', false);
                    // Append new options and mark selected ones
                    $.each(response, function (key, value) {
                        var option = $('<option></option>')
                            .attr('value', value.id)
                            .text(value.name);
                        $('#brand_drop').append(option);
                    });
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
            location.reload();
        }
    });

    $('#cat_drop').change(function () {
        var category_id = $(this).val();
        var category_group_id = $("#cat_group_drop").val();
        if (category_group_id != "" && category_id != "") {
            // AJAX call to fetch child options
            $.ajax({
                url: '{{ route("getbrands") }}',
                type: 'GET',
                data: { category_group_id: category_group_id, category_id: category_id },
                dataType: 'json',
                success: function (response) {
                    $('#brand_drop').empty();
                    // Enable child selectpicker
                    $('#brand_drop').prop('disabled', false);
                    // Get selected categories from URL parameters
                    var selectedCategories = getUrlParameterArray('categories');

                    // Append new options and mark selected ones
                    $.each(response, function (key, value) {
                        var option = $('<option></option>')
                            .attr('value', value.id)
                            .text(value.name);
                        if (selectedCategories.includes(value.id.toString())) {
                            option.prop('selected', true);
                        }
                        $('#brand_drop').append(option);
                    });
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        }else{
          //$('#brand_drop').prop('disabled', true);


            $.ajax({
                url: '{{ route("getbrands") }}',
                type: 'GET',
                data: { category_group_id: 0, category_id: 0 },
                dataType: 'json',
                success: function (response) {
                    $('#brand_drop').empty();
                    // Enable child selectpicker
                    $('#brand_drop').prop('disabled', true);
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        }
    });

    $('#btnSearch').click(function(){
      var prod_name = $('#prod_name').val();
      var cat_groups = $('#cat_group_drop').val();
      var categories = $('#cat_drop').val();
      var brands = $('#brand_drop').val();


      if(prod_name == "" && cat_groups =="" && categories=="" && brands==""){
          alert("Please select alteast one or type any product name.")
      }else{
        $('#searchActive').val('1');
        $.ajax({
            url: '{{ route("quickOrderSearchList") }}',
            type: 'GET',
            beforeSend: function(){
              $('.ajax-loader').css("visibility", "visible");
            },
            data: { prod_name: prod_name, cat_groups: cat_groups, categories: categories, brands: brands },
            dataType: 'json',
            success: function (response) {
                console.log(response); // Log the response for debugging
                $('#postsContainer').empty(); // Clear the div before appending new data
                $('#postsContainer').append(response.html); // Append the response data
            },
            complete: function(){
              $('.ajax-loader').css("visibility", "hidden");
            },
            error: function (xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
      }


    });


    $('.b_drop').change(function(){

      var brands = $('.b_drop').val();
      let cat_groups = $('.cats_grp_drop').val();
        var category_drop = $('.category_drop').val();

        if(brands.length == 0){
        location.reload();
      }

    });
    // $('body').on('change', '.b_drop, .category_drop', function() {
    //   var prod_name = $('#prod_name').val();
    //     let cat_groups = $('.cats_grp_drop').val();
    //      var category_drop = $('.category_drop').val();
    //      var brands = $('.b_drop').val();
    //     // alert(cat_groups);
    //      if(cat_groups.length != 0 || category_drop.length != 0 || brands.length != 0){
    //          $('#searchActive').val('1');
    //         $.ajax({
    //             url: '{{ route("quickOrderSearchList") }}',
    //             type: 'GET',
    //             beforeSend: function(){
    //                 $('.ajax-loader').css("visibility", "visible");
    //             },
    //             data: { prod_name: prod_name,cat_groups: cat_groups, categories: category_drop, brands: brands },
    //             dataType: 'json',
    //             success: function (response) {
    //                 console.log(response); // Log the response for debugging
    //                 $('#postsContainer').empty(); // Clear the div before appending new data
    //                 $('#postsContainer').append(response.html); // Append the response data
    //             },
    //             complete: function(){
    //                 $('.ajax-loader').css("visibility", "hidden");
    //             },
    //             error: function (xhr, status, error) {
    //                 console.error(xhr.responseText);
    //             }
    //         });
    //     }
    //     else if ( brands.length==0) {
    //         $('#searchActive').val('1');
    //             $.ajax({
    //             url: '{{ route("products.quickorder") }}',
    //             type: 'GET',
    //             beforeSend: function(){
    //             $('.ajax-loader').css("visibility", "visible");
    //             },
    //             // data: { prod_name: prod_name, cat_groups: cat_groups, categories: categories, brands: brands },
    //             dataType: 'json',
    //             success: function (response) {

    //                 console.log(response); // Log the response for debugging
    //                 $('#postsContainer').empty(); // Clear the div before appending new data
    //                 $('#postsContainer').append(response.html); // Append the response data
    //             },
    //             complete: function(){
    //             $('.ajax-loader').css("visibility", "hidden");
    //             },
    //             error: function (xhr, status, error) {
    //                 console.error(xhr.responseText);
    //             }
    //         });
    //     }

    // });



    $('#downloadExcelLink').click(function(){
      var prod_name = $('#prod_name').val();
      var cat_groups = $('#cat_group_drop').val();
      var categories = $('#cat_drop').val();
      var brands = $('#brand_drop').val();
      var userId = $('#userId').val();

      // Create a form
      var form = $('<form>', {
            action: 'https://mazingbusiness.com/api/products_excel.php',
            method: 'GET',
            target: '_blank'
        });

        // Append the parameters as hidden fields
        form.append($('<input>', { type: 'hidden', name: 'prod_name', value: prod_name }));
        form.append($('<input>', { type: 'hidden', name: 'cat_groups', value: cat_groups }));
        form.append($('<input>', { type: 'hidden', name: 'categories', value: categories }));
        form.append($('<input>', { type: 'hidden', name: 'brands', value: brands }));
        form.append($('<input>', { type: 'hidden', name: 'user_id', value: userId }));
        form.append($('<input>', { type: 'hidden', name: 'type', value: 'net' }));

        // Append the form to the body
        $('body').append(form);

        // Submit the form
        form.submit();
    })

    document.getElementById('downloadPDFLink').addEventListener('click', function(event) {
        event.preventDefault();

        $('.ajax-loader').css("visibility", "visible");
        // Collect additional data
        var prod_name = $('#prod_name').val();
        var cat_groups = $('#cat_group_drop').val();
        var categories = $('#cat_drop').val();
        var brands = $('#brand_drop').val();
        var userId =  $('#userId').val();
        // Construct form data
        var formData = new FormData();
        formData.append('prod_name', prod_name);
        formData.append('cat_groups', cat_groups);
        formData.append('categories', categories);
        formData.append('brands', brands);
        formData.append('userId', userId);
        formData.append('type', 'net');

        // Add CSRF token
        formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));

        // Fetch options
        var options = {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRF-TOKEN': formData.get('_token')
            }
        };
        // Send request to the server
        fetch('/generate-pdf', options)
          .then(response => response.json())
          .then(data => {
              if (data.filename) {
                  checkPdfAvailability(data.filename);
              }
          })
          .catch(error => console.error('Error:', error));
    });

    //---------------- Below fnction is now on footer.blade.php ----------------------
    // function checkPdfAvailability(filename) {
    //     fetch(`/pdf-status/${filename}`)
    //         .then(response => response.json())
    //         .then(data => {
    //             if (data.ready) {
    //                 downloadFile(`public/pdfs/${filename}`);
    //                 $('.ajax-loader').css("visibility", "hidden");
    //             } else {
    //                 setTimeout(() => checkPdfAvailability(filename), 2000);
    //             }
    //         })
    //         .catch(error => console.error('Error:', error));
    // }
    // function downloadFile(url) {
    //     const link = document.createElement('a');
    //     link.href = url;
    //     link.download = url.substring(url.lastIndexOf('/') + 1);
    //     document.body.appendChild(link);
    //     link.click();
    //     document.body.removeChild(link);
    // }
    //--------------------------------------------------------------------------------

    function selectCategories() {
        var selectedCategories = getUrlParameterArray('categories[]');
        if (selectedCategories.length) {
            $('#cat_drop').val(selectedCategories).selectpicker('refresh');
        }
    }

    // Trigger change event on page load if there are pre-selected values
    // if ($('#cat_group_drop').val()) {
    //     $('#cat_group_drop').change();
    // }


    // $('body').on('click', '#cart_items', function() {
    //     alert("click");
    //     $(this).addClass('show');
    //     $('#cart_items div').addClass('show');
    // });

});
  </script>
  <script>
        document.getElementById('generatePdfForm').addEventListener('submit', function(event) {
            event.preventDefault();
            var form = event.target;
            var formData = new FormData(form);
            fetch(form.action, {
                method: form.method,
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': formData.get('_token')
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.filename) {
                    checkPdfAvailability(data.filename);
                }
            })
        });

        // function checkPdfAvailability(filename) {
        //     fetch(`/pdf-status/${filename}`)
        //         .then(response => response.json())
        //         .then(data => {
        //             if (data.ready) {
        //                 // alert('Hello');
        //                 window.location.href = `/pdf/${filename}`;
        //             } else {
        //                 setTimeout(() => checkPdfAvailability(filename), 2000);
        //             }
        //         });
        // }
    </script>


@endsection
