@extends('frontend.layouts.user_panel')
@section('panel_content')
    <div class="aiz-titlebar mt-2 mb-4">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="h3">{{ translate('My Statement') }}</h1>
            </div>
        </div>
    </div>
    <div class="row gutters-10">
        <div class="col-md-4 mx-auto mb-3">
            <div class="bg-grad-3 text-white rounded-lg overflow-hidden">
                <span
                    class="size-30px rounded-circle mx-auto bg-soft-primary d-flex align-items-center justify-content-center mt-3">
                    <i class="las la-rupee-sign la-2x text-white"></i>
                </span>
                <div class="px-3 pt-3 pb-3">
                    <div class="h4 fw-700 text-center">{{ single_price($openingBalance) }}</div>
                    <div class="opacity-50 text-center">{{ translate('Opening Balance') }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mx-auto mb-3">
            <div class="bg-grad-1 text-white rounded-lg overflow-hidden">
                <span
                    class="size-30px rounded-circle mx-auto bg-soft-primary d-flex align-items-center justify-content-center mt-3">
                    <i class="las la-rupee-sign la-2x text-white"></i>
                </span>
                <div class="px-3 pt-3 pb-3">
                    <div class="h4 fw-700 text-center">{{ single_price($closingBalance) }}</div>
                    <div class="opacity-50 text-center">{{ translate('Closing Balance') }}</div>
                </div>
            </div>
        </div>        
    </div>
    <div class="card">
        <div class="card-header">
            <div class="row" style="width:100%">
                <div class="col-md-4"><h5 class="mb-0 h6">{{ translate('Statement') }}</h5></div>
                <div class="col-md-3">From Date: <input type="date"></div>
                <div class="col-md-3">To Date:<input type="date"></div>
                <div class="col-md-2"><button type="button" class="btn btn-info">Search</button></div>
            </div>
        </div>
        @if (count($getData) > 0)
            <div class="card-body">
                <table class="table aiz-table mb-0">
                    <thead>
                        <tr>
                            <th>{{ translate('Date')}}</th>
                            <th data-breakpoints="md">{{ translate('Particulers and Txn No')}}</th>
                            <th data-breakpoints="md">{{ translate('Debit')}}</th>
                            <th data-breakpoints="md">{{ translate('Credit')}}</th>
                            <th data-breakpoints="md">{{ translate('Balance')}}</th>
                            <th class="text-right">{{ translate('Dr / Cr')}}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($getData as $gKey=>$gValue)
                            <tr>
                                <td><a href="#">{{ date('d-m-Y', strtotime($gValue['trn_date'])) }}</a></td>
                                <td>{{ $gValue['ledgername'] }} {{ $gValue['trn_no'] != "" ? ' - '.$gValue['trn_no'] : '' }}</td>
                                <td><span style="color:#ff0707;">{{ $gValue['dramount'] != "0.00" ? single_price($gValue['dramount']) : '' }}</spn></td>
                                <td><span style="color:#8bc34a;">{{ $gValue['cramount'] != "0.00" ? single_price($gValue['cramount']) : '' }}</span></td>
                                <td></td>
                                <td class="text-right">{!! $gValue['dramount'] != "0.00" ? '<span style="color:#ff0707;">Dr</span>': '<span style="color:#8bc34a;">Cr</span>' !!}</td>
                            </tr>
                        @endforeach
                        <!-- <tr>
                            <td><a href="#">01-10-2022</a></td>
                            <td>Opening</td>
                            <td></td>
                            <td><span style="color:#8bc34a;">{{ single_price('92093.12') }}</span></td>
                            <td>{{ single_price('92093.12') }}</td>
                            <td class="text-right"><span style="color:#8bc34a;">Cr</span></td>
                        </tr>
                        <tr>
                            <td><a href="#">05-10-2022</a></td>
                            <td>Purchase - P/KOL/0001/23-24</td>
                            <td></td>
                            <td><span style="color:#8bc34a;">{{ single_price('158852.92') }}</span></td>
                            <td>{{ single_price('-66760') }}</td>
                            <td class="text-right"> <span style="color:#8bc34a;">Cr</span></td>
                        </tr>
                        <tr>
                            <td><a href="#">01-11-2022</a></td>
                            <td>Sales - KOL/0007/24-25</td>
                            <td><span style="color:#ff0707;">{{ single_price('92093.12') }}</span></td>
                            <td></td>
                            <td>{{ single_price('25333') }}</td>
                            <td class="text-right"><span style="color:#ff0707;">Dr</span></td>
                        </tr> -->
                        <tr>
                            <td colspan=4 align="right"><a href="#">Closing Balance</a></td>
                            <td>{{ single_price($closingBalance) }}</td>
                            <td class="text-right"></td>
                        </tr>
                    </tbody>
                </table>
                <?php /* ?><div class="aiz-pagination">
                    {{ $orders->links() }}
              	</div> <?php */ ?>
            </div>
        @endif
    </div>
@endsection