<div class="aiz-card-box border border-light hov-shadow-md mt-1 mb-2 has-transition bg-white">
  <div class="position-relative">
    <a href="{{ route('products.brand', $brand->slug) }}" class="d-block">
      <img class="img-contain lazyload mx-auto h-140px h-md-210px" src="{{ static_asset('assets/img/placeholder.jpg') }}"
        data-src="{{ uploaded_asset($brand->logo) }}" alt="{{ $brand->getTranslation('name') }}"
        onerror="this.onerror=null;this.src='{{ static_asset('assets/img/placeholder.jpg') }}';">
    </a>
  </div>
</div>
